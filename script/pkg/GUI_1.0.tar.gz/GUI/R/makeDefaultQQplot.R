makeDefaultQQplot <-
function(title, Defaults){																
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	Defaults[[paste("groupP", title, sep="")]]=FALSE					
	Defaults[[paste("group", title, sep="")]]=NULL
	Defaults[[paste("markBy", title, sep="")]]=NULL				 
	Defaults[[paste("markByAdd", title, sep="")]]=""
	Defaults[[paste("facetBy", title, sep="")]]=""
	Defaults[[paste("facetFact", title, sep="")]]=""
	Defaults[[paste("strat", title, sep="")]]=""
	Defaults[[paste("reorg", title, sep="")]]=FALSE
	Defaults[[paste("plotdeets", title, sep="")]]=FALSE
	Defaults[[paste("Title", title, sep="")]]=""
	Defaults[[paste("Xtit", title, sep="")]]='sprintf("Theoretical %s", xBy)'
	Defaults[[paste("Ytit", title, sep="")]]='sprintf("Observed %s", xBy)'
	Defaults[[paste("Xlim", title, sep="")]]=NULL
	Defaults[[paste("Ylim", title, sep="")]]=NULL
	Defaults[[paste("xForm", title, sep="")]]="comma"
	Defaults[[paste("xScale", title, sep="")]]="identity"
	Defaults[[paste("yForm", title, sep="")]]="comma"
	Defaults[[paste("yScale", title, sep="")]]="identity"
	Defaults[[paste("DataLim", title, sep="")]]=""
	Defaults[[paste("Trans", title, sep="")]]=""
	Defaults[[paste("AES", title, sep="")]]=FALSE	
	Defaults[[paste("xBy", title, sep="")]]="ETA1"						
	Defaults[[paste("LegendTitle", title, sep="")]]=sprintf("Legend Title", title)
	Defaults[[paste("Legend", title, sep="")]]=sprintf("Information about figure", title)
		Defaults[[paste("Footnote", title, sep="")]]=sprintf("Figure footnote", title)
	Defaults[[paste("reset", title, sep="")]]=FALSE
	return(Defaults)
	
}
