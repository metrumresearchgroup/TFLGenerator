panelTypeNMTab <-
function(plotType, input, Set=list()){
	
	#All if statements relate to a specific output type, which then add an additional panel
	if(input[[paste(plotType, "Num", sep="")]]>=1){
		
		numbers=as.numeric(unlist(str_extract_all(input[[paste(plotType, "Num", sep="")]], "\\d+")))
		if(length(numbers)>1){numRange=numbers[which(numbers!=0)]}
		if(length(numbers)==1){numRange=c(1:numbers)}
		for (n in numRange){
			
			title=paste(plotType, n, sep="")
			#set originating defaults
			checkPriors(plotType=plotType, input=input, n=n)
			
			nn=length(Set)
			
			Set[[nn+1]]=
				tabPanel(paste(plotType,n, sep="#"),
								 
								 sidebarPanel(
actionButton(paste("button", plotType, n, sep=""), "Generate Plot"),										 	numberRow(paste("Sig", plotType, n, sep=""), "Significant Figures", Defaults[[paste("Sig", title, sep="")]]),
								 	numberRow(paste("ConfInt", plotType, n, sep=""), "Confidence Interval", Defaults[[paste("ConfInt", title, sep="")]]),
								 	checkboxInput(paste("OffDiagonals", plotType, n, sep=""), "Display Off Diagonals", Defaults[[paste("OffDiagonals", title, sep="")]]),
								 	checkboxInput(paste("unTransform", plotType, n, sep=""), "Untransform Log Normal Columns", Defaults[[paste("unTransform", title, sep="")]]),
								 	checkboxInput(paste("removeFixed", plotType, n, sep=""), "Remove Fixed Values", Defaults[[paste("removeFixed", title, sep="")]]),
								 	checkboxInput(paste("reset", plotType, n, sep=""), "Reset to Defaults", FALSE)
								 ),
								 
								 mainPanel(div(align="center",
								 	boxInputLong(paste("LegendTitle", plotType, n, sep=""), "Figure Title", Defaults[[paste("LegendTitle", title, sep="")]]),
								 	plotOutput(paste("Plot", plotType,n,  sep=""), width="800px", height="600px"),
								 	boxInputWide(paste("Legend", plotType, n, sep=""), "Legend Text", Defaults[[paste("Legend", title, sep="")]]),
								 							boxInputLong(paste("Footnote", plotType, n, sep=""), "Footnote", Defaults[[paste("Footnote", title, sep="")]])
								 							
								 ))
								 
				)
			names(Set)[[nn+1]]=paste("Tab", plotType,n,  sep="")
		}
	}
	return(Set)	
}
