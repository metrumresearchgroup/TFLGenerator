makeDefaultConcvTimeMult <-
function(title, Defaults){		
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	Defaults[[paste("reorg", title, sep="")]]=FALSE
	Defaults[[paste("plotdeets", title, sep="")]]=FALSE
	Defaults[[paste("Title", title, sep="")]]="A Plot Title"
	Defaults[[paste("Xtit", title, sep="")]]="Time"
	Defaults[[paste("Ytit", title, sep="")]]="Serum Concentration"
	Defaults[[paste("Xlim", title, sep="")]]=NULL
	Defaults[[paste("Ylim", title, sep="")]]=NULL
	Defaults[[paste("xForm", title, sep="")]]="comma"
	Defaults[[paste("xScale", title, sep="")]]="none"
	Defaults[[paste("yForm", title, sep="")]]="comma"
	Defaults[[paste("yScale", title, sep="")]]="log10"
	Defaults[[paste("DataLim", title, sep="")]]=""
	Defaults[[paste("Trans", title, sep="")]]=""
	Defaults[[paste("AES", title, sep="")]]=FALSE	
	Defaults[[paste("xBy", title, sep="")]]="TAFD"						
	Defaults[[paste("yBy", title, sep="")]]="DV"
	Defaults[[paste("idVar", title, sep="")]]="NMID"
	Defaults[[paste("predVar", title, sep="")]]="IPRE"
	Defaults[[paste("LegendTitle", title, sep="")]]=sprintf("Legend Title", title)
	Defaults[[paste("Legend", title, sep="")]]=sprintf("Information about figure", title)
	Defaults[[paste("Footnote", title, sep="")]]=sprintf("Figure footnote", title)
	Defaults[[paste("minorTicks", title, sep="")]]=FALSE
	Defaults[[paste("reset", title, sep="")]]=FALSE
	Defaults[[paste("facetBy", title, sep="")]]=""
	Defaults[[paste("facetFact", title, sep="")]]=""
	return(Defaults)
	
	
}
