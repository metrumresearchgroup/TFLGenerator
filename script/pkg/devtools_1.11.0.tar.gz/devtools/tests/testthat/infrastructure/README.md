# infrastructure

The goal of infrastructure is to ...

## Installation

You can install infrastructure from github with:

```R
# install.packages("devtools")
devtools::install_github("devtools/hadley")
```

## Example

This is a basic example which shows you how to solve a common problem:

```R
...
```
