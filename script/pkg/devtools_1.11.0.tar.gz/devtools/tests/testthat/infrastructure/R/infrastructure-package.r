#' infrastructure.
#'
#' @name infrastructure
#' @docType package
NULL
