captureFunSimple <-
function(Name, plotName, toWhat, input){
funText=capture.output(eval(parse(text=Name)))
start=grep("[//{]", funText)[1]
end=grep("return", funText)
end=end[length(end)]
funText=funText[(start+1):(end-1)]
funText=gsub("p1", plotName, funText)

#write arguments
funText=c(makeArgs(toWhat, addComma=FALSE), funText)

#remove any "..." arguments
funText=gsub(",[//.]{3}", "", funText)

funText=paste(funText, collapse="\n")


return(funText)
}
