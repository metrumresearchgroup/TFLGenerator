makeDefaultNMTab <-
function(title, Defaults){		
	Defaults[[paste("Sig", title, sep="")]]=3
	Defaults[[paste("ConfInt", title, sep="")]]=0.95
	Defaults[[paste("OffDiagoNULLls", title, sep="")]]=FALSE
	Defaults[[paste("unTransform", title, sep="")]]=FALSE
	Defaults[[paste("removeFixed", title, sep="")]]=FALSE
	Defaults[[paste("LegendTitle", title, sep="")]]=sprintf("Legend Title", title)
	Defaults[[paste("Legend", title, sep="")]]=sprintf("Information about figure", title)
	Defaults[[paste("Footnote", title, sep="")]]=sprintf("Figure footnote", title)
	Defaults[[paste("reset", title, sep="")]]=FALSE

	return(Defaults)
	

	
}
