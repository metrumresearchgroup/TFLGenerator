recordGUI <-
function(doWhat, toWhat, input, number, manipArgs=list()){
	newDir=sprintf("%s/%s/%s_%s/", currentWD, input$runno, gsub("[[:space:]]|\\.", "_", input$projectTitle), Sys.Date())
	fileHead=sprintf("%s%s_%s", newDir, input$saveAs, Sys.Date())
	grobTitle=paste(fileHead, "_Grobs.R", sep="")
	fileTitle=paste(fileHead, "_Script.R", sep="")
	
	pngFolder=paste(newDir, "PNGs/", sep="")
	
	#This section readies a file for input of function calls
	if(!file.exists(newDir)){
		dir.create(newDir)}
	
	if(!file.exists(fileTitle)){
		#create the *R script
		foo=c(paste("#Project~", input$projectTitle), sprintf("#R Script Recorded from GUI\n#on %s\n#%s\n\nlibrary(TFL)\n\n#For Help with active grobs see:
																													\n#?indexGrobs\n#?revealGrobs\n#?loadGrobs\n", as.character(Sys.Date()), input$projectInfo))
		write(foo, file=fileTitle, append=FALSE)
		
		#write in the initial parameters
		foo=c("\n########\n#Initial Global Parameters\n",
					sprintf("#Project Directory\nprojDir='%s'",newDir),
					"#Create Directory (no warning if directory exists)\ndir.create(projDir, showWarnings=FALSE)",
					sprintf("\n#Project File Header\nprojHead='%s'",fileHead),
					sprintf("\n#Grob File\ngrobFile='%s'",grobTitle)
		)
		write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		
		if(input$PNG){
			foo=sprintf("\n#PNG Folder\npngFolder='%s'",pngFolder)
			write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		}
		
		#write in color pallete
		
		if(input$Color){
			foo=sprintf("\n#Color Pallette, shapes and lines for Plotting\ncleanScales=setColorScale()")
			write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		}
		
		if(!input$Color){
			foo=sprintf("\n#Black and White Pallette, shapes and lines for Plotting\ncleanScales=setGrayScale()")
			write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		}
		
		#write in the initial dataFile
		foo=c("\n########\n#DataInput\n",
					sprintf("dataFile=read.table(file='%s'", sprintf("%s/%s/%s%s", currentWD, input$runno, input$runno, input$ext)),
					", header=",input$header,
					", skip=",input$skipLines,
					", stringsAsFactors=FALSE)",
					
					"\n\tdataFile=apply(dataFile, c(2), as.numeric)",
					"\n\tdataFile=data.frame(dataFile, stringsAsFactors=FALSE)",
					"\n#########\n#Initial Dataset Changes")
		write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		
		#Adjust any ER-SSAP Default Changes
		if(input$DVCol!="DV"){
			foo=c(sprintf("names(dataFile)[which(names(dataFile)=='%s')]='DV'", input$DVCol))
			write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		}
		if(input$TAFDCol!="TAFD"){
			foo=c(sprintf("names(dataFile)[which(names(dataFile)=='%s')]='TAFD'", input$TAFDCol))
			write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		}
		if(input$STUDCol!="STUD"){
			foo=c(sprintf("names(dataFile)[which(names(dataFile)=='%s')]='STUD'", input$STUDCol))
			write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		}
		if(input$NMIDCol!="NMID"){
			foo=c(sprintf("names(dataFile)[which(names(dataFile)=='%s')]='NMID'", input$NMIDCol))
			write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		}
		
		#Adjust transformations and limitations
		if(input$dataLimits!=""){
			foo=c(sprintf("wholeLim=%s", makeArgs(list(dataLimits=limitations(input$dataLimits)),  completeArg=FALSE)))
			write(foo, file=fileTitle, Sys.Date(), append=TRUE)
						if(input$dataTrans==""){
							foo=c(sprintf("dataFile=manipDat(dataFile, dataLim=wholeLim)"))
										write(foo, file=fileTitle, Sys.Date(), append=TRUE)		
						}
		}
		
		if(input$dataTrans!=""){
			foo=c(sprintf("wholeTrans=%s", makeArgs(list(dataTrans=transformations(input$dataTrans)), completeArg=FALSE)))
						write(foo, file=fileTitle, Sys.Date(), append=TRUE)
						if(input$dataLimits==""){
							foo=c(sprintf("dataFile=manipDat(dataFile, dataTrans=wholeTrans)"))
										write(foo, file=fileTitle, Sys.Date(), append=TRUE)		
						}
		}
		
		if(input$dataTrans!="" & input$dataLimits!=""){
						foo=c(sprintf("dataFile=manipDat(dataFile, dataLimits=wholeLim, dataTrans=wholeTrans)"))
										write(foo, file=fileTitle, Sys.Date(), append=TRUE)		
						
		}
		
		
		#####	#Add in a section for the Function 
		
		foo=c("\n#########\n" , "#Plotting")
		write(foo, file=fileTitle, Sys.Date(), append=TRUE)	
	}
	
	#Now input that particular Function
	plotNum=paste(doWhat, number, sep="")
	foo=c("\n##\n#Plot of", plotNum,
				"\n#", 	input[[paste("LegendTitle", str_sub(doWhat,end=-4), number, sep="")]],
				"\n#", 	input[[paste("Legend", str_sub(doWhat,end=-4), number, sep="")]],
				"\n##\n",
				sprintf("plotNum='%s'\n", plotNum)
	)
	write(foo, file=fileTitle, Sys.Date(), append=TRUE)			
	
	if(length(manipArgs)>0){
		#write in data manipulation if it occurs
		foo=sprintf("#Manipulate data by limitation or transformation\ntempDat=manipDat(%s)\n", makeArgs(manipArgs, completeArg=TRUE))
		write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		
		toWhat[["datFile"]]="tempDat"
	}
		
		
		foo=ifelse(input$verbose,
							 c(sprintf("#Text for function %s\n\n%s",
							 					doWhat, captureFunSimple(doWhat, plotNum, toWhat, input=input))),
							 c(sprintf("\t\t%s=%s(%s\n\t\t\t\t\t)",plotNum, doWhat, makeArgs(toWhat, completeArg=TRUE)))
							 )
	 
	
	
	write(foo, file=fileTitle, Sys.Date(), append=TRUE)		
	
	foo=c(
				sprintf("\n\n\tprint(%s)", plotNum),
				sprintf("\n#Update the Grob\nsaveGrob(%s, Name='%s', file=grobFile)", plotNum, plotNum)
	)
	
	write(foo, file=fileTitle, Sys.Date(), append=TRUE)	
	
	if(input$PNG){
		dir.create(paste(newDir, "PNG/", sep=""), showWarnings=FALSE)
		foo=sprintf("\n#Save the Plot\nsavePlots(%s, file='%s%s.png')",plotNum, pngFolder, plotNum )
		write(foo, file=fileTitle, Sys.Date(), append=TRUE)
	}
	
	if(input$RTF){
		#delete all previous RTF writes
		test=readLines(fileTitle)	
		idx=c(grep("#Create an RTF", test), grep("writeRTF", test))
		idn=c(1:length(test))[which(c(1:length(test)) %nin% idx)]
		test=test[idn]
		test[length(test)+1]=""
		test[length(test)+1]="#Create an RTF"
		test[length(test)+1]=""
		test[length(test)+1]=sprintf("writeRTF('%s')",grobTitle)
		writeLines(test, con=fileTitle)
		
	}
	
}
