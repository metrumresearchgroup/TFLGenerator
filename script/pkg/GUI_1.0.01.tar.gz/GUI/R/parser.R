parser <- function(parsethis){
  
}