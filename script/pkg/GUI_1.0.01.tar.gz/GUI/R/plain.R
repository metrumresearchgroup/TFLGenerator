plain <- function(x,...){
  format(x,..., scientific=F)
}