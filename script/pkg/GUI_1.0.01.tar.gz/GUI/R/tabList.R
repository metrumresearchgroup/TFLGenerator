tabList=function(){
        foo=list(
            inputId=c("ConcvTimeNum",
                          "ConcvTimeMultNum",
                       "ConcvTimeGroupNum",
                       "demogTabNum",
                      #"demog1TabNum",
                       "OBSvPREDNum", 
                       "paramDistNum", 
                       "covCatNum", 
                       "covConNum", 
                       "corPairsNum", 
                       "QQplotNum",
                       "DescParamStatNum", 
                       "NMTabNum"
                      #, "DescListNum"
                       ),
             label=c("Serum Concentration Versus Time-Individuals",
                     "Serum Concentration Versus Time with Prediction-Individuals",
                     "Serum Concentration Versus Time-Groups",
                     "Basic Demographics", 
                     #"Demographics Type 1",  
                     "Observed Versus Predicted", 
                     "Parameter Distribution",
                     "Categorical Covariance",
                     "Continuous Covariance",
                     "Correlation Pairs",
                     "Quantile Plot",
                     "Descriptive Parameter Statistics", 
                     "Tabulated NM Diagnostic"
                     #, "Descriptive Listing"
                     ),
             value=c(Defaults$ConcvTimeNum,
                     Defaults$ConcvTimeMultNum,
                     Defaults$ConcvTimeGroupNum,
                     Defaults$demogTabNum,
                     #Defaults$demog1TabNum,
                     Defaults$OBSvPREDNum,
                     Defaults$paramDistNum,
                     Defaults$covCatNum,
                     Defaults$covConNum,
                     Defaults$corPairsNum,
                     Defaults$QQplotNum,
                     Defaults$DescParamStatNum,
                     Defaults$NMTabNum
                     #, Defaults$DescListNum
                      ),
             tabType=c("PKInputFigures",
                       "PKInputFigures",
                       "PKInputFigures",
                       "InputTables", 
                       #"InputTables", 
                       "ModelFigures",
                       "ModelFigures",
                       "ModelFigures",
                       "ModelFigures",
                       "ModelFigures",
                       "ModelFigures",
                       "AnalysisFigures",
                       "AnalysisFigures"
                       #, "Listings"
                       ),
            sidebarType=c("Figures",
                          "Figures",
                          "Figures",
                          "Tables",
                          #"Tables",
                          "Figures",
                          "Figures",
                          "Figures",
                          "Figures",
                          "Figures",
                          "Figures",
                          "Tables",
                          "Tables"
                          #,"Listings"
            )
)		

return(foo)
}

