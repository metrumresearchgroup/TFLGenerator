makeDefaultinputTable <-
function(title, Defaults){		
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	Defaults[[paste("LegendTitle", title, sep="")]]=sprintf("Table Title", title)
	Defaults[[paste("Legend", title, sep="")]]=sprintf("Table caption", title)
	Defaults[[paste("Footnote", title, sep="")]]=sprintf("Table footnote", title)
	Defaults[[paste("reset", title, sep="")]]=FALSE

	Defaults[[paste("filelocation", title, sep="")]]=""
	Defaults[[paste("previewhead",title,sep="")]]=20
	
	return(Defaults)
	
	
}

makeDefaultinputFigure <-
  function(title, Defaults){		
    Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
    Defaults[[paste("LegendTitle", title, sep="")]]=sprintf("Figure title", title)
    Defaults[[paste("Legend", title, sep="")]]=sprintf("Figure caption", title)
    Defaults[[paste("Footnote", title, sep="")]]=sprintf("Figure footnote", title)
    Defaults[[paste("reset", title, sep="")]]=FALSE
    
    Defaults[[paste("filelocation", title, sep="")]]=""
    Defaults[[paste("previewhead",title,sep="")]]=20
    
    return(Defaults)
  }

makeDefaultinputListing <-
  function(title, Defaults){		
    Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
    Defaults[[paste("LegendTitle", title, sep="")]]=sprintf("Listing Title", title)
    Defaults[[paste("Legend", title, sep="")]]=sprintf("Listing caption", title)
    Defaults[[paste("Footnote", title, sep="")]]=sprintf("Listing footnote", title)
    Defaults[[paste("reset", title, sep="")]]=FALSE
    
    Defaults[[paste("filelocation", title, sep="")]]=""
    Defaults[[paste("previewhead",title,sep="")]]=20
    
    return(Defaults)
    
    
  }

makeDefaultinputListing_text <-
  function(title, Defaults){		
    Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
    Defaults[[paste("LegendTitle", title, sep="")]]=sprintf("Listing Title", title)
    Defaults[[paste("Legend", title, sep="")]]=sprintf("Listing caption", title)
    Defaults[[paste("Footnote", title, sep="")]]=sprintf("Listing footnote", title)
    Defaults[[paste("reset", title, sep="")]]=FALSE
    
    Defaults[[paste("filelocation", title, sep="")]]=""
    Defaults[[paste("previewhead",title,sep="")]]=20
    
    return(Defaults)
    
    
  }
