makeDefaultdemogTabCont <-
function(title, Defaults){		
	Defaults[[paste("AES", title, sep="")]]=FALSE	
	Defaults[[paste("group", title, sep="")]]="STUDY;Study"	
	Defaults[[paste("idVar", title, sep="")]]="NMID"
	Defaults[[paste("conList", title, sep="")]]="AGE;Age (years)\nHGTB;Height (cm)\nWGTB;Weight (kg)"
	Defaults[[paste("catList", title, sep="")]]="DIS;Disease"
	Defaults[[paste("sigDig", title, sep="")]]=3
	
	
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	Defaults[[paste("reorg", title, sep="")]]=FALSE
	Defaults[[paste("DataLim", title, sep="")]]=""
	Defaults[[paste("Trans", title, sep="")]]=""

	Defaults[[paste("idVar", title, sep="")]]="NMID"
	Defaults[[paste("LegendTitle", title, sep="")]]=sprintf("Legend Title", title)
	Defaults[[paste("Legend", title, sep="")]]=sprintf("Information about figure", title)
	Defaults[[paste("Footnote", title, sep="")]]=sprintf("Figure footnote", title)
	Defaults[[paste("reset", title, sep="")]]=FALSE
	
	Defaults[[paste("margins",title,sep="")]]=FALSE
	Defaults[[paste("leftmargin",title,sep="")]]=10
	Defaults[[paste("topmargin",title,sep="")]]=5
	Defaults[[paste("rightmargin",title,sep="")]]=50
	Defaults[[paste("bottommargin",title,sep="")]]=5
	
	
	return(Defaults)
	
	
}
