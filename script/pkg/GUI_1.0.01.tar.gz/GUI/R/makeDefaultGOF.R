makeDefaultGOF <-
function(title, Defaults){																
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
  
	Defaults[[paste("markBy", title, sep="")]]=NULL
	Defaults[[paste("preserveMarkByLevels",title,sep="")]]=FALSE
	Defaults[[paste("timeBy", title, sep="")]]="TAFD"
	Defaults[[paste("timeLimit",title,sep="")]]=NULL
	Defaults[[paste("timeScale",title,sep="")]]="identity"
	Defaults[[paste("timeLab",title,sep="")]]="Time (weeks)"
	Defaults[[paste("timeFmt",title,sep="")]]="plain"
	Defaults[[paste("concBy",title,sep="")]]="DV"
	Defaults[[paste("concLimit",title,sep="")]]=NULL
	Defaults[[paste("concScale",title,sep="")]]="log10"
	Defaults[[paste("concLab",title,sep="")]]="Observed Serum Concentration (ug/mL)"
	Defaults[[paste("predBy",title,sep="")]]="PRED"
	Defaults[[paste("predLimit",title,sep="")]]=NULL
	Defaults[[paste("predScale",title,sep="")]]="log10"
	Defaults[[paste("predLab",title,sep="")]]="Population Prediction (ug/mL)"
	Defaults[[paste("ipredBy",title,sep="")]]="IPRED"
	Defaults[[paste("ipredLimit",title,sep="")]]=NULL
	Defaults[[paste("ipredScale",title,sep="")]]="log10"
	Defaults[[paste("ipredLab",title,sep="")]]="Individual Prediction (ug/mL)"
	Defaults[[paste("cwresBy",title,sep="")]]="CWRES"
	Defaults[[paste("cwresLimit",title,sep="")]]=NULL
	Defaults[[paste("cwresScale",title,sep="")]]="identity"
	Defaults[[paste("cwresLab",title,sep="")]]="Conditional Weighted Residuals"
	Defaults[[paste("npdeBy",title,sep="")]]="NPDE"
	Defaults[[paste("npdeLimit",title,sep="")]]=NULL
	Defaults[[paste("npdeScale",title,sep="")]]="identity"
	Defaults[[paste("npdeLab",title,sep="")]]="NPDE"
	
	Defaults[[paste("Title",title,sep="")]]="Goodness of Fit Plots"
	
	Defaults[[paste("smooth",title,sep="")]]=TRUE
	Defaults[[paste("plotDeets",title,sep="")]]=FALSE
	Defaults[[paste("timeDeets",title,sep="")]]=FALSE
	Defaults[[paste("concDeets",title,sep="")]]=FALSE
	Defaults[[paste("predDeets",title,sep="")]]=FALSE
	Defaults[[paste("ipredDeets",title,sep="")]]=FALSE
	Defaults[[paste("cwresDeets",title,sep="")]]=FALSE
	Defaults[[paste("npdeDeets",title,sep="")]]=FALSE
	
	Defaults[[paste("reorg",title,sep="")]]=FALSE
	Defaults[[paste("DataLim", title, sep="")]]=""
	Defaults[[paste("Trans", title, sep="")]]=""
	Defaults[[paste("LegendTitle", title, sep="")]]=sprintf("Legend Title", title)
	Defaults[[paste("Legend", title, sep="")]]=sprintf("Information about figure", title)
	Defaults[[paste("Footnote", title, sep="")]]=sprintf("Figure footnote", title)
	Defaults[[paste("reset", title, sep="")]]=FALSE
	return(Defaults)	
}
