presentCTL=function(run, type="theta", project=getwd()){	
	require(XML)
	require(Hmisc)
	require(gridExtra)
	require(stringr)
	
	readIn=xmlTreeParse(sprintf("%s/%s/%s.xml", project, run, run), useInternalNodes=FALSE)
	readIn=readIn$doc$children[["output"]]
	
	
	#set up ctl
	ctl=xmlValue(readIn[["control_stream"]])
	ctl=unlist(ctl)
	ctl=unlist(str_split(ctl, "[$]"))
	idx=grep(paste("^", toupper(type),sep=""), ctl)
	if(length(idx)==0 & type!="PRE"){
		
		return(sprintf("%s is not available option", type))
		
	}
	
	if(length(idx)>0){
		foo=ctl[idx]
		foo=gsub(toupper(type), "", foo)
	}
	
	if(length(idx)==0 & type=="PRE"){
		idx=grep("^PROB", ctl)
		idx=c(1:(idx-1))
		if(length(idx)>0){foo=ctl[idx]
		}else(foo="")
	}
	
	return(foo)
}