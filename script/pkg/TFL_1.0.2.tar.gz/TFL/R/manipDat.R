manipDat <-
function(datFile,
									xBy="TAFD", yBy="DV",
									markBy="DOSE", markByAdd="",
                  preserveMarkByLevels=F,
									facetBy="", facetFact="",
									dataLimits="", dataTrans="",
									groupBy="NMID",
									sumType="mean", sumVar="sd", 
									sumThis=FALSE,
									...){
	
  # If preserveMarkBy, then set factor levels on full data
  if(!is.null(markBy) & preserveMarkByLevels){
    if(markBy %in% names(datFile)){
      #perform factoring to include details
      if(class(datFile[,markBy])=="factor"){
        levels0 <- levels(datFile[,markBy])
      }else{
        levels0 <- sort(unique(datFile[,markBy]))
      }
    }
  }
  
	#perform any limits on the data set
  if (class(dataLimits)!="list" & length(dataLimits)==3) dataLimits <- list(dataLimits)
	if (class(dataLimits)=="list" | length(dataLimits)>1){
	  for(i in 1:length(dataLimits)){
	    if(
	      (length(grep("(",dataLimits[[i]], fixed=T)) == length(grep(")",dataLimits[[i]],fixed=T))) &
	      (length(grep("[",dataLimits[[i]], fixed=T)) == length(grep("]",dataLimits[[i]],fixed=T))) &
	      (dataLimits[[i]][length(dataLimits[[i]])] != "")
	    ){
	      eval(
	      parse(text=paste0("datFile <- subset(datFile,", paste0(dataLimits[[i]],collapse=""),")"))
	    )
	    }
	  }
	}
  
  if(markByAdd!=""){
    if(class(datFile[,markBy])=="factor"){
      if(preserveMarkByLevels){
        levels(datFile[,markBy]) <- paste(levels0,str_trim(markByAdd))
      }else{
        levels(datFile[,markBy]) <- paste(levels(datFile[,markBy]),str_trim(markByAdd))
      }
    }else{
      if(preserveMarkByLevels){
        datFile[,markBy] <- factor(datFile[,markBy], levels=levels0, 
                                   labels=paste(levels0,str_trim(markByAdd)))
      }else{
        datFile[,markBy] <- factor(datFile[,markBy], levels=sort(unique(datFile[,markBy])), 
                                   labels=paste(sort(unique(datFile[,markBy])),str_trim(markByAdd)))
      }
    }
  }
	
	
	#perform any transformations on the data set
	if (class(dataTrans)=="list" | length(dataTrans)>1){
		if(class(dataTrans)!="list"){dataTrans=list(dataTrans)}
		for(n in c(1:length(dataTrans))){
			if(length(dataTrans[[n]])==3){
				if (dataTrans[[n]][[1]] %nin% names(datFile)){break}
				datFile[,dataTrans[[n]][[1]]]=do.call(dataTrans[[n]][[2]],
																					list(
																					suppressWarnings(as.numeric(datFile[,dataTrans[[n]][[1]]])),
																						suppressWarnings(as.numeric(dataTrans[[n]][[3]]))
																					)
																				)
			}
		}
	}
  
  #summarize if grouped
  if(sumThis==TRUE){
    gr=unique(c(xBy, groupBy, markBy, facetBy))
    if(facetBy==""){gr=unique(c(xBy, groupBy, markBy))}
    datFile=summarySE(datFile, measurevar=yBy, groupvars=gr)
    datFile=addMinMax(datFile, measurevar=sumType, devvar=sumVar)	
    
  }
	

	
 if (facetBy!="" & class(facetFact)=="list" ) {datFile[,facetBy]=factor(datFile[,facetBy], levels=facetFact[[1]], labels=facetFact[[2]])}	
	
	
	return(datFile)
}
