ggpairs <-
function(datFile, xCols=grep("ETA", names(datFile), value=TRUE),
         xLab=xCols,
								 xLimit=NULL, yLimit=NULL,
								 xForm=waiver(), yForm=waiver(),
								 xScale="identity", yScale="identity",
								facetBy="", corstat="R2",
								 ...){
	
	if(all(xCols=="") | is.null(xCols)) xCols <- grep("ETA", names(datFile), value=TRUE)
	names=factor(xCols, levels=xCols, labels=c(1:length(xCols)))
	pList=list() #create an empty list
	
	for (i in names){
		i=as.numeric(i)
		for (j in names){	
			j=as.numeric(j)
			#fit the linear regression line
			mod1 = lm(datFile[,xCols[i]]~datFile[,xCols[j]], data = datFile)
			modsum = summary(mod1)
			r2 = ifelse("adj.r.squared" %in% names(modsum), paste("R^2=",signif(modsum$adj.r.squared, digits=3)), "")
			r <- paste0("r=",
			            signif(cor(datFile[,xCols[i]],datFile[,xCols[j]],use="pairwise.complete.obs",method="pearson"),digits=3))
			my.p =ifelse(((dim(modsum$coefficients)[1]>=2) & dim(modsum$coefficients)[2]>=4), 
			             {
			               ifelse(modsum$coefficients[2,4]>0.001, paste("p=",signif(modsum$coefficients[2,4],digits=3)), paste("p<0.001"))
			             },
			             "")
			
			if(i==j){
				pList[[paste("plot",i,j, sep="")]]=
				  ggplot() + annotate("text", x=.5, y=.5, label=xLab[i],size=7+(2-length(names))) +
				  theme(axis.text=element_blank(),	axis.line=element_line(size=0),
				        axis.title=element_blank(), axis.ticks=element_line(size=0),
				        plot.background=element_rect(fill='white',colour="black"),
				        panel.background=element_rect(fill='white',size=0),
				        panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
				        plot.margin=unit(c(.1,0,.1,0), "cm"))
				
			}
			if(j>i){
			  label <- ifelse(corstat=="R2", sprintf("%s\n%s",r2, my.p), sprintf("%s\n%s",r, my.p))
				pList[[paste("plot",i,j, sep="")]] <-
				  ggplot() + annotate("text", x=.5, y=.5, label=label, size=7+(2-length(names)) ) +
				  theme(axis.text=element_blank(),	axis.line=element_line(size=0),
				        axis.title=element_blank(), axis.ticks=element_line(size=0),
				        plot.background=element_rect(fill='white',colour="black"),
				        panel.background=element_rect(fill='white',size=0),
				        panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
				        plot.margin=unit(c(.1,0,.1,0), "cm"))
				
				  #   rect <- rectGrob(.5,.5,width=unit(.99,"npc"), height=unit(0.99,"npc"), 
				  #             gp=gpar(lwd=3, fill=NA, col="black"),vp=vp)
				  # 	text <- textGrob(sprintf("%s\n%s",eval(r2), eval(my.p)), gp=gpar(fontsize=10),vp=vp)
				
			}
			
			if(i>j){
				pList[[paste("plot",i,j, sep="")]]=
					ggplot(datFile, aes_string(x=xCols[j], y=xCols[i]))+
					geom_point(shape=79)+
					geom_smooth(method="loess", se=FALSE, colour="red")+
					# geom_hline(yintercept=0, lty=2)+
					# geom_vline(xintercept=0, lty=2)+
					labs(x=NULL, y=NULL)+
					scale_x_continuous(breaks=pretty_breaks(), limits=xLimit, labels=eval(xForm), trans=xScale)+
					scale_y_continuous(breaks=pretty_breaks(), limits=yLimit, labels=eval(yForm), trans=yScale)+
					cleanTheme+theme(axis.text=element_text(size=10*4/(2+length(names)), colour="black"))
				# theme(axis.text=element_text(size=10*4/(2+length(names)), colour="black"),	axis.line=element_line(),
				# 				plot.background=element_rect(fill='white',colour="black"),
				# 				panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
				# 				plot.margin=unit(c(.1,0,.1,0), "cm"))
				
				if(j==1 & i!=as.numeric(names)[length(names)]) pList[[paste("plot",i,j,sep="")]] <- 
				    pList[[paste("plot",i,j,sep="")]] + 
				    theme(axis.text.x=element_text(size=0),axis.ticks=element_line(size=0))

				if(j>1 & i==as.numeric(names)[length(names)]) pList[[paste("plot",i,j,sep="")]] <- 
				    pList[[paste("plot",i,j,sep="")]] + 
				    theme(axis.text.y=element_text(size=0), axis.ticks.y=element_line(size=0))
				
				
			}
			
		}
	}
	# for(i in 1:length(pList)){
	#   if(any(grepl("ggplot",class(pList[[i]])))) class(pList[[i]]) <- "ggplot"
	# } 
	# p1 <- do.call("arrangeGrob",c(pList,ncol=length(xCols)))
	# return(do.call("arrangeGrob", c(pList, ncol=length(xCols))))	
	
	p1=list(pList,plotCols = length(xCols),plotRows = length(xCols))
	return(p1)
	
}
