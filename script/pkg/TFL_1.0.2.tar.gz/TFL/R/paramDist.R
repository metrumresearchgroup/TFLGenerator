paramDist<-function(datFile, xCols = "ETA1", binWidth = 0.1, groupBy = NULL,
           xLimit = NULL, yLimit = NULL, xForm = waiver(), 
           yForm = waiver(), xScale = "identity", yScale = "identity", 
           Title = "", xLab = "xCols",
           yLab = "Percent", facetBy = "", fF="", fnrow=NULL, fncol=NULL,fscales="fixed",
           runno = "", project = getwd(),
           ncol = 1, nrow = 1,
           themeUpdate=list(),
           themeTextSize=14,
           themePlotTitleSize=1.2,
           themeAxisTxtSize=0.8,
           themeAxisTxtColour='black',
           themeAxisTitleTxtSize=0.9,
           themeAxisTitleColour='black',
           themePanelBackgroundFill='white',
           themePanelGridSize=NULL,
           themePanelGridColour='white',
           themePanelLineType=1,
           themePanelTitleSize=1.2,
           themePlotTitleColour='black',
           ...){
    if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
    if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
    
    if(facetBy!="" & all(fF!="")){
      datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
    }

    ncol <- as.numeric(ncol); nrow <- as.numeric(nrow)
    if(ncol*nrow < length(xCols)){
      ncol <- 1
      nrow <- length(xCols)
    }

    rel=ggplot2:::rel
    themeUpdate=theme(text=              element_text(size=themeTextSize),
                      axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                      axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                      plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                      panel.background = element_rect(fill = themePanelBackgroundFill),
                      panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
    )
    
    
    
    pList <- lapply(xCols, function(xBy){
      
      if (facetBy != "") {
        
        newDat=data.frame(matrix(,ncol=4))
        names(newDat)=c(xBy, "normFit", "meanCol", facetBy)
        for (facet in unique(datFile[, facetBy])) {
          xx=	datFile[datFile[,facetBy] == facet, xBy]
          padx=c(
            seq(from=min(xx, na.rm=TRUE)-abs(min(xx, na.rm=TRUE)), to=min(xx, na.rm=TRUE), length.out=10),
            xx,
            seq(from=max(xx,na.rm=TRUE), to=max(xx,na.rm=TRUE)+abs(max(xx,na.rm=TRUE)), length.out=10)
          )
          normFit=dnorm(x=padx, mean=mean(xx, na.rm=TRUE), sd=sd(xx, na.rm=TRUE))
          meanCol=rep(mean(xx, na.rm=TRUE), times=length(padx))
          f=rep(facet, times=length(padx))
          foo=data.frame(cbind(padx, normFit, meanCol,f))
          names(foo)=c(xBy, "normFit", "meanCol", facetBy)
          newDat=rbind(newDat, foo)
          newDat=newDat[!is.na(newDat$normFit),]
          newDat=unique(newDat)
        }
        
        
        datFile=merge(datFile,newDat, all=TRUE)
      }
      
      if (facetBy == "") {
        newDat=data.frame(matrix(,ncol=3))
        names(newDat)=c(xBy, "normFit", "meanCol")
        
        xx=	datFile[, xBy]
        padx=c(
          seq(from=min(xx, na.rm=TRUE)-abs(min(xx, na.rm=TRUE)), to=min(xx, na.rm=TRUE), length.out=10),
          xx,
          seq(from=max(xx,na.rm=TRUE), to=max(xx,na.rm=TRUE)+abs(max(xx,na.rm=TRUE)), length.out=10)
        )
        normFit=dnorm(x=padx, mean=mean(xx, na.rm=TRUE), sd=sd(xx, na.rm=TRUE))
        meanCol=rep(mean(xx, na.rm=TRUE), times=length(padx))
        foo=data.frame(cbind(padx, normFit, meanCol))
        names(foo)=c(xBy, "normFit", "meanCol")
        newDat=rbind(newDat, foo)
        newDat=newDat[!is.na(newDat$normFit),]
        newDat=unique(newDat)
        datFile=merge(datFile, newDat, all=TRUE)
      }	

      
      if (runno %nin% c(""," ","#")) {
        shrink = presentXML(runno, type = "etashrink", project = project)
        Title = ifelse(xBy %in% names(shrink), paste(Title, "\n", "Shrinkage=", 
                                                     shrink[xBy], "%", sep = ""), "")
      }
      
      datFile[,xBy]=as.numeric(datFile[,xBy])
      datFile$normFit=as.numeric(datFile$normFit)
      datFile$meanCol=as.numeric(datFile$meanCol)
      
      #if(length(xLab)>1) xLabPlot <- xCols[xBy == xCols]
      if(length(yLab)>1) yLab <- yLab[xBy == xCols]

      p=
        ggplot(datFile, aes_string(x=xBy, group=groupBy))	+
        cleanScales+
        geom_density(colour="dodgerblue3", adjust=3, kernel="gaussian",lwd=1.25)+
        geom_histogram(aes(y=..density..),colour="white", fill="deepskyblue", binwidth=binWidth, alpha=.4)+
        scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
        scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
        geom_line(aes(y=normFit), col="red", lty="dotted",lwd=1.25)+	
        geom_vline(aes(xintercept=meanCol), colour="red")+	
        labs(title=Title, x=xCols[xBy == xCols], y=yLab)
      
      
      #Add in the faceting if it exists
      if (facetBy!=""){
        p=p +facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,ncol=fncol,scales=fscales)
      }
      
      p=p+cleanTheme +themeUpdate
      
      p
    })
    names(pList)=xCols
    p1=list(pList=pList,plotCols = as.numeric(ncol),plotRows = as.numeric(nrow))
    return(p1)
  }