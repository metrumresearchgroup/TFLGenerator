ConcvTimeSum <-
function(datFile, groupBy="DOSE", xBy="TAFD", yBy="DV",
         sumType="mean", sumVar="sd", 
         markBy="DOSE", preserveMarkByLevels=F, Color=T,
         xLimit=NULL,yLimit=NULL,
         xForm=waiver(), yForm=waiver(),
         xScale="identity", yScale="log10", 
         Title="Individuals by Dose Cohort", xLab="Time", yLab="Concentration",
         facetBy="", fF="",fnrow=NULL, fncol=NULL,fscales="fixed",
         ...)
{
  if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
  if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
  
                                        # Only update in the scope of this function
  if(preserveMarkByLevels){
    if(Color){ cleanScales <- setColorScale(drop=F) }else{ cleanScales <- setGrayScale(drop=F)}
  }
  
  if(facetBy!="" & all(fF!="")){
    datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
  }
  
  var_lvls=length(levels(datFile[[markBy]]))
  pt_aes=if(var_lvls<=6){
    aes_string(shape=markBy) 
  }else{
    aes_string()
  }
  
  p1=
    ggplot(datFile, aes_string(x=xBy, y=sumType, ymax="Max", ymin="Min", group=groupBy, color=markBy, lty=markBy))+
      geom_line()+
        geom_point(pt_aes)+
          geom_errorbar()+
            cleanTheme+
              cleanScales+
		scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
                  scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
                    labs(title=Title, x=xLab, y=yLab)
  
                                        #Add in better ticks if the scale is log10
  if (as.character(yScale)[1]=="log-10"){
    p1=p1+annotation_logticks(, sides="l", mid=unit(0.1, "cm"))
  }
  
  if (as.character(xScale)[1]=="log-10"){
    p1=p1+annotation_logticks(, sides="b", mid=unit(0.1, "cm"))
    
  }
  
                                        #Add in the faceting if it exists
  if (facetBy!=""){
    p1=p1 +facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,ncol=fncol,scales=fscales)
		
  }

  p1 <- list(p1,plotCols=1,plotRows=1)
  return(p1)
  
  
}
