ConcvTimeSum <-
function(datFile, groupBy="DOSE", xBy="TAFD", yBy="DV",
         sumType="mean", sumVar="sd", 
         markBy="DOSE", markByType="Discrete",preserveMarkByLevels=F, 
         Color=T,
         xLimit=NULL,yLimit=NULL,
         xForm=waiver(), yForm=waiver(),
         xScale="identity", yScale="log10", 
         Title="Individuals by Dose Cohort", xLab="Time", yLab="Concentration",
         facetBy="", fF="",fnrow=NULL, fncol=NULL,fscales="fixed",
         themeUpdate=list(),
         themeTextSize=14,
         themePlotTitleSize=1.2,
         themeAxisTxtSize=0.8,
         themeAxisTxtColour='black',
         themeAxisTitleTxtSize=0.9,
         themeAxisTitleColour='black',
         themePanelBackgroundFill='white',
         themePanelGridSize=NULL,
         themePanelGridColour='white',
         themePanelLineType=1,
         themePanelTitleSize=1.2,
         themePlotTitleColour='black',
         themePlotLegendPosition='right',
         ...)
{
  if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
  if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
  
                                        # Only update in the scope of this function
  if(preserveMarkByLevels){
    if(Color){ cleanScales <- setColorScale(shapeList = shape_pal()(6),drop=F) }else{ cleanScales <- setGrayScale(shapeList = shape_pal()(6),drop=F)}
  }
  
  if(facetBy!="" & all(fF!="")){
    datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
  }
  
  
  var_lvls=length(levels(datFile[[markBy]]))
  shp_aes=if(var_lvls<=6&markByType=="Discrete"){
    aes_string(shape=markBy) 
  }else{
    aes_string()  
  }
  
  aes_base=aes_string(x=xBy, y=sumType, group=groupBy, color=markBy, ymax="Max", ymin="Min")
  
  p1=
    ggplot(datFile, aes_base)+
      geom_line(shp_aes)+
        geom_point(shp_aes)+
          geom_errorbar()+
		scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
                  scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
                    labs(title=Title, x=xLab, y=yLab)
  
                                        #Add in better ticks if the scale is log10
  if (as.character(yScale)[1]=="log-10"){
    p1=p1+annotation_logticks(, sides="l", mid=unit(0.1, "cm"))
  }
  
  if (as.character(xScale)[1]=="log-10"){
    p1=p1+annotation_logticks(, sides="b", mid=unit(0.1, "cm"))
    
  }
  
                                        #Add in the faceting if it exists
  if (facetBy!=""){
    p1=p1 +facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,ncol=fncol,scales=fscales)
		
  }

  rel=ggplot2:::rel
  themeUpdate=theme(text=              element_text(size=themeTextSize),
                    axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                    axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                    plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                    panel.background = element_rect(fill = themePanelBackgroundFill),
                    panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
                    legend.position =  themePlotLegendPosition
  )
  
  if(markByType=='Discrete') p1=p1+cleanScales
  
  p1=p1+cleanTheme +themeUpdate
  
  p1 <- list(pList=list(p1),plotCols=1,plotRows=1)
  class(p1)<-c(class(p1),'TFL')
  return(p1)
  
  
}
