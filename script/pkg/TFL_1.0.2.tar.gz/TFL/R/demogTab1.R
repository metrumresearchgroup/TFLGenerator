demogTab <-
	function(datFile, group="STUD",idVar="NMID",
					 statList=c("n", "Mean", "Median", "CV", "Min", "Max"),
					 conList=list(c("AGE", "years"), c("HGTB", "cm"), c("WGTB", "kg")),
					 covList=c("SEX", "DIS"),
						sigDig=3)
		{ 
		
		cons=sapply(conList, function(x){x[[1]][1]})
		units=sapply(conList, function(x){if(length(x)==2) x[[2]][1] else ""})
		subData=datFile[!duplicated(datFile[c(idVar, group)]),]
		
		
		subDataCon=subData[,c(group,cons)]
		subDataCon=melt(subDataCon, id.vars=c(group), variable_name="Parameter")
		
		subDataCov=subData[,c(group,covList)]
		
		
		# New version of length which can handle NA's: if na.rm==T, don't count them
		length2 <- function (x, na.rm=TRUE) {
			if (na.rm) sum(!is.na(x))
			else       length(x)
		}
		
		###Analyze the continuous variables
		statData=ddply(subDataCon, .variables=c(group, "Parameter"),
									 .fun= function(xx) {
									   c( n     	= length2(xx[,"value"], na.rm=TRUE),
									      Mean= signif(mean(xx[,"value"], na.rm=TRUE), digits=sigDig),
									      Median=signif(median(xx[,"value"], na.rm=TRUE), digits=sigDig),
									      sd=signif(sd(xx[,"value"], na.rm=TRUE), digits=sigDig),
									      CV=signif((sd(xx[,"value"], na.rm=TRUE)/mean(xx[,"value"], na.rm=TRUE)*100),digits=sigDig),
									      Min=signif(min(xx[,"value"], na.rm=TRUE),digits=sigDig),
									      Max=signif(max(xx[,"value"], na.rm=TRUE),digits=sigDig)
									   )
									   
									 } )
		
		statData=statData[,c(group, statList, "Parameter")]
		statData=melt(statData, id.vars=c("Parameter", group), measure.vars=statList, variable_name="DS")
		for(i in c(1:length(statData$value))){
			statData$value[i]=ifelse(statData$DS[i]=="n",as.character(as.integer(statData$value[i])), as.character(signif(as.numeric(statData$value[i]), digits=sigDig)))
		}


		statData=cast(statData, formula=as.formula(sprintf("Parameter+DS~%s", group)), value="value")
		statData=data.frame(statData[order(statData$"Parameter"),], stringsAsFactors=FALSE, check.names=FALSE)
		statData$Parameter=as.character(statData$Parameter)
		statData$Parameter[duplicated(statData[,c("Parameter")])]=""

		###Analyze the categorical variables
		for (i in covList){
			dummy=subDataCov[,c(group, i)]
			dummy=data.frame(t(table(dummy)), stringsAsFactors=FALSE)
			dummy$Freq=as.numeric(dummy$Freq)
			dummy=data.frame(cast(dummy, formula=as.formula(sprintf("%s~%s",i, group)), value="Freq"), stringsAsFactors=FALSE, check.names=FALSE)
			dummy[dim(dummy)[1]+1,-1]=apply(dummy[,-1], c(2), sum)
			for (j in c(2:dim(dummy)[2])){
				dummy[-length(dummy[,j]),j]=sprintf("%s (%s%%)",dummy[-length(dummy[,j]),j], signif(dummy[-length(dummy[,j]),j]/dummy[length(dummy[,j]),j], digits=sigDig)*100)
				dummy$DS=rep("n", length(dummy[,j]))
			}
				dummy[,i]=as.character(dummy[,i])
				dummy[is.na(dummy[,i]),i]=i
				names(dummy)[1]="Parameter"
				dummy=dummy[,names(statData)]
				
				statData=data.frame(rbind(statData, dummy[dim(dummy)[1],]), stringsAsFactors=FALSE, check.names=FALSE)
				statData=data.frame(rbind(statData, dummy[-dim(dummy)[1],]), stringsAsFactors=FALSE, check.names=FALSE)
	
			}
			
		statData=rename(statData, c("DS"="Descriptive\nStatistics"))
		p1=renderTableGrob(statData)
		return(p1)
	}
