QQplot=function(
  datFile,  xBy="ETA1",
  groupBy=NULL,
  markBy=NULL,
  xLimit=NULL, yLimit=NULL,
  xForm=waiver(), yForm=waiver(),
  xScale="identity", yScale="identity", 
  Title="",
  xLab='sprintf("Theoretical %s", xBy)',
  yLab='sprintf("Observed %s", xBy)',
  facetBy="", fF="",fnrow=NULL, fncol=NULL,fscales="fixed",
  ...){
  if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
  if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
  
  if(facetBy!="" & all(fF!="")){
    datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
  }
  
  if(!is.null(markBy)){
    if(class(datFile[,markBy])!="factor") datFile[,markBy] <- factor(datFile[,markBy], sort(unique(datFile[,markBy])))
  }

  p1=
    ggplot(datFile, aes_string(sample=xBy, group=groupBy, color=markBy, lty=markBy))	+
    cleanScales+
    cleanTheme+
    scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
    scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
    stat_qq(na.rm=TRUE)+
    stat_qqline()+
    labs(title=Title, x=xLab, y=yLab)
  
  #Add in the faceting if it exists
  if (facetBy!=""){
    p1=p1 +facet_wrap(as.formula(paste("~", facetBy)), nrow=fnrow,ncol=fncol,scales=fscales)
  }
  
  p1=list(pList=list(p1),plotCols=1,plotRows=1)
  return(p1)
  
}