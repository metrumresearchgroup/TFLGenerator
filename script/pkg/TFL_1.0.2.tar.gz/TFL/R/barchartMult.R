barchartMult <-
	function(datFile,
	         ID='NMID',
					 catList=list(c("SEX", "Gender"),
					              c("RACE", "Race"),
					              c("DIS", "Disease status")),
            themeUpdate=list(),
            themeTextSize=14,
            themePlotTitleSize=1.2,
            themeAxisTxtSize=0.8,
            themeAxisTxtColour='black',
            themeAxisTitleTxtSize=0.9,
            themeAxisTitleColour='black',
            themePanelBackgroundFill='white',
            themePanelGridSize=NULL,
            themePanelGridColour='white',
            themePanelLineType=1,
            themePanelTitleSize=1.2,
            themePlotTitleColour='black',
					 nrow=1
	){ 
	 
	  if(class(catList)!="list"){
	    catList <- list(catList)
	  }

          cats=sapply(catList, function(x){x[[1]][1]})
          catLabs=sapply(catList, function(x){x[[2]][1]})
		

		
	p=datFile%>%dplyr::select_(.dots=c(ID,cats))%>%
	  melt(.,id=ID)%>%
	  count(variable,value)%>%
	  ggplot(aes(x=paste0(factor(value),'\nn=',n),y=n))+
	          geom_bar(stat='identity',fill='dodgerblue4')+
	          facet_wrap(~variable,scales='free',nrow=nrow)+
	          labs(x='',y='Number of Subjects')
	
	rel=ggplot2:::rel
	themeUpdate=theme(text=              element_text(size=themeTextSize),
	                  axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
	                  axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
	                  plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
	                  panel.background = element_rect(fill = themePanelBackgroundFill),
	                  panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
	)
	
	p=p+cleanTheme +themeUpdate
		
		p1=list(pList=list(p),plotCols=1,plotRows=1)
		return(p1)

	}
