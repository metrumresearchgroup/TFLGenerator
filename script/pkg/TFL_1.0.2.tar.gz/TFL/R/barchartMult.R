barchartMult <-
	function(datFile,
	         ID='NMID',
					 catList=list(c("SEX", "Gender"),
					              c("RACE", "Race"),
					              c("DIS", "Disease status"),
            themeUpdate=list(),
            themeTextSize=14,
            themePlotTitleSize=1.2,
            themeAxisTxtSize=0.8,
            themeAxisTxtColour='black',
            themeAxisTitleTxtSize=0.9,
            themeAxisTitleColour='black',
            themePanelBackgroundFill='white',
            themePanelGridSize=NULL,
            themePanelGridColour='white',
            themePanelLineType=1,
            themePanelTitleSize=1.2,
            themePlotTitleColour='black'
					 ),
					 nrow=1
	){ 
	 
	  if(class(catList)!="list"){
	    catList <- list(catList)
	  }

		cats=sapply(catList, function(x){x[[1]][1]})
		catLabs=sapply(catList, function(x){x[[2]][1]})
		
		# pList <- lapply(cats, function(xBy){
		#   
		#   tab <- table(datFile[,xBy])
		#   datFile[,xBy] <- factor(datFile[,xBy], levels=names(tab), labels=paste0(names(tab), "\nn=", tab))
		#   if(length(catLabs)>1) xLab <- catLabs[xBy == cats]
		# 
		#   p=
		#     ggplot(datFile, aes_string(x=xBy))	+
		#     cleanScales+
		#     geom_histogram(colour="dodgerblue4",fill="dodgerblue4",stat='count') +
		#     cleanTheme + 
		#     labs(x=xLab) + ylab("Number of Subjects") + 
		#     theme(axis.text=element_text(size=8), axis.title=element_text(size=8))
		#   
		#   list(p=p, levels=length(tab))
		# })
		# 
		# if(length(pList)==1){
		#   p1 <- pList[[1]]
		#   return(pList[[1]]) 
		# }else{
		#   for(i in 1:length(pList)){
		#       if(any(grepl("ggplot",class(pList[[i]]$p)))){
		#         class(pList[[i]]$p) <- "ggplot"
		#     }
		#   }
		# }
		# pList2 <- unlist(pList, recursive = F)
		# ns <- unlist(pList2[grep("levels",names(pList2))])
		# pList2[grep("levels",names(pList2))] <- NULL
		# #p1 <- do.call("arrangeGrob", c(pList2, nrow=nrow))
		# 
		# 
		# if(nrow == 1){
		#   pList3 <- pList2
		# }else{
		#   i <- 0
		#   maxlevels <- max(max(ns), sum(ns)/nrow)
		#   chunk <- NULL
		#   for(i in 1:length(ns)){
		#     begin <- ifelse(i==1, 1, end+1)
		#     chunk <- c(chunk,  max(which(cumsum(ns[begin:length(ns)]) <= maxlevels)))
		#     end <- sum(chunk)
		#   }
		#   chunk <- chunk[ chunk!=0 & !is.infinite(chunk) ] # Chunk is how many plots per row
		#   while(sum(chunk)!=length(ns)) chunk[length(chunk)] <- chunk[length(chunk)]+1
		#   while(length(chunk) > nrow){
		#     chunk[length(chunk)-1] <- chunk[length(chunk)-1] + chunk[length(chunk)]
		#     chunk <- chunk[-length(chunk)] 
		#   }
		#   while(length(chunk) < nrow){
		#     chunk[length(chunk)] <- chunk[length(chunk)] - 1
		#     chunk <- c(chunk,1)
		#   }
		#   
		#   pList3 <- vector(mode="list",length=length(chunk))
		#   for(i in 1:length(chunk)){
		#     begin <- ifelse(i==1, 1, end+1)
		#     end <- cumsum(chunk)[i]
		#     buildarg <- paste(paste0("pList2[[",begin:end,"]]"),collapse=",")
		#     pList3[[i]] <- eval(expr=parse(text=paste0("arrangeGrob(",buildarg,",nrow=1,widths=unit(ns[begin:end]/sum(ns[begin:end]), 'null'))")))
		#   }
		# }
		
		p1=datFile%>%dplyr::select_(.dots=c(ID,cats))%>%
		  melt(.,id=ID)%>%
		  count(variable,value)%>%
    		  ggplot(aes(x=paste0(factor(value),'\nn=',n),y=n))+
		          geom_bar(stat='identity',fill='dodgerblue4')+
		          facet_wrap(~variable,scales='free',nrow=nrow)+
		          labs(x='',y='Number of Subjects')
		
		rel=ggplot2:::rel
		themeUpdate=theme(text=              element_text(size=themeTextSize),
		                  axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
		                  axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
		                  plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
		                  panel.background = element_rect(fill = themePanelBackgroundFill),
		                  panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
		)
		
		p1=p1+cleanTheme +themeUpdate
		

		
		p1=list(pList=list(p1),plotCols=1,plotRows=1)
		return(p1)
		

	}
