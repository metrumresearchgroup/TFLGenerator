barchartMult <-
	function(datFile, 
					 catList=list(c("SEX", "Gender"),
					              c("RACE", "Race"),
					              c("DIS", "Disease status")
					 ),
					 nrow=1
	)
					 
		{ 
	 
	  if(class(catList)!="list"){
	    catList <- list(catList)
	  }

		cats=sapply(catList, function(x){x[[1]][1]})
		catLabs=sapply(catList, function(x){x[[2]][1]})
		
		pList <- lapply(cats, function(xBy){
		  
		  tab <- table(datFile[,xBy])
		  datFile[,xBy] <- factor(datFile[,xBy], levels=names(tab), labels=paste0(names(tab), "\nn=", tab))
		  if(length(catLabs)>1) xLab <- catLabs[xBy == cats]

		  p=
		    ggplot(datFile, aes_string(x=xBy))	+
		    cleanScales+
		    geom_histogram(colour="dodgerblue4",fill="dodgerblue4") +
		    cleanTheme + 
		    labs(x=xLab) + ylab("Number of Subjects") + 
		    theme(axis.text=element_text(size=8), axis.title=element_text(size=8))
		  
		  list(p=p, levels=length(tab))
		})
		
		if(length(pList)==1){
		  p1 <- pList[[1]]
		  return(pList[[1]]) 
		}else{
		  for(i in 1:length(pList)){
		      if(any(grepl("ggplot",class(pList[[i]]$p)))){
		        class(pList[[i]]$p) <- "ggplot"
		    }
		  }
		}
		pList2 <- unlist(pList, recursive = F)
		ns <- unlist(pList2[grep("levels",names(pList2))])
		pList2[grep("levels",names(pList2))] <- NULL
		#p1 <- do.call("arrangeGrob", c(pList2, nrow=nrow))


		if(nrow == 1){
		  pList3 <- pList2
		}else{
		  i <- 0
		  maxlevels <- max(max(ns), sum(ns)/nrow)
		  chunk <- NULL
		  for(i in 1:length(ns)){
		    begin <- ifelse(i==1, 1, end+1)
		    chunk <- c(chunk,  max(which(cumsum(ns[begin:length(ns)]) <= maxlevels)))
		    end <- sum(chunk)
		  }
		  chunk <- chunk[ chunk!=0 & !is.infinite(chunk) ] # Chunk is how many plots per row
		  while(sum(chunk)!=length(ns)) chunk[length(chunk)] <- chunk[length(chunk)]+1
		  while(length(chunk) > nrow){
		    chunk[length(chunk)-1] <- chunk[length(chunk)-1] + chunk[length(chunk)]
		    chunk <- chunk[-length(chunk)] 
		  }
		  while(length(chunk) < nrow){
		    chunk[length(chunk)] <- chunk[length(chunk)] - 1
		    chunk <- c(chunk,1)
		  }
		  
		  pList3 <- vector(mode="list",length=length(chunk))
		  for(i in 1:length(chunk)){
		    begin <- ifelse(i==1, 1, end+1)
		    end <- cumsum(chunk)[i]
		    buildarg <- paste(paste0("pList2[[",begin:end,"]]"),collapse=",")
		    pList3[[i]] <- eval(expr=parse(text=paste0("arrangeGrob(",buildarg,",nrow=1,widths=unit(ns[begin:end]/sum(ns[begin:end]), 'null'))")))
		  }
		}

		p <- do.call(arrangeGrob,c(pList3,nrow=nrow))
		return(p)	

	}
