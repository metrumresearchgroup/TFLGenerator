plotDims <- function(grob){
  objectTypes <- 
    c(
      "ConcvTime",
      "ConcvTimeGroup",
      "OBSvPRED",
      "paramDist",
      "covCat",
      "covCon",
      "corPairs",
      "QQplot",
      "NMTab",
      "ConcvTimeMult",
      "demogTabCont",
      "demogTabCat",
      "GOF",
      "inputFigure",
      "inputListing_text",
      "subjectExclusionsTab",
      "observationExclusionsTab",
      "subjectExclusionsSummaryTab",
      "observationExclusionsSummaryTab",
      "VPC",
      "barchartMult"
    )
  squares <- c(
    "OBSvPRED",
    "paramDist",
    "covCat",
    "covCon",
    "corPairs",
    "distMult",
    "barchartMult"
  )
  rectangles <- c(
    "ConcvTime[[:digit:]]",
    "ConcvTimeGroup",
    "VPC"
  )
 
  if(grepl(paste(squares,collapse="|"),names(grob))){
    return(list(height=6,width=6))
  }
  if(grepl(paste(rectangles,collapse="|"),names(grob))){
    return(list(height=4, width= 6))
  }
  if(grepl("Tab|inputFigure|inputListing[[:digit:]]",names(grob))){
    if(!grepl("Exclusions",names(grob))){
      htwdth <- GUI:::.identify(grob[[1]]$Plot)
      ratio <- as.numeric(htwdth["height"]) / as.numeric(htwdth["width"])
      # if(ratio >=1){
      #   if( 6*ratio < 7.5){  widthi <- 6; heighti <- 6 * ratio 
      #   }else{ heighti <- 7.5; widthi <- heighti / ratio }
      # }else{ # ratio < 1
      #   widthi=6; heighti <- 6*ratio
      # }
      heighti <- htwdth["height"]
      widthi <- htwdth["width"]
      if(heighti > 700){
        heighti <- 700; widthi <- heighti / ratio
      }
      if(widthi > 600){
        widthi <- 600; heighti <- widthi * ratio
      }
      return(list(height=heighti/100, width=widthi/100)  )
    }
  }
  if(grepl("GOF|ConcvTimeMult",names(grob))){
    return(list(width=5.4234, height=7))
  }
  # if(grepl("ConcvTimeMult",names(grob))){
  #   htwdth <- GUI:::.identify(grob[[1]]$Plot)
  #   ratio <- as.numeric(htwdth["height"]) / as.numeric(htwdth["width"])
  #   return(list(height=7.5, width= 7.5 / ratio)) # These are full page plots
  # }

  return(list(height=6,width=6)) #default

}