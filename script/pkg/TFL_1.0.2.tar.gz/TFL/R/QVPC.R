QVPC<-
function(datFile,  xBy="TAFD", yBy="PRED", binWidth=.1,
								xLimit=NULL, 
				        yLimit=NULL,
								yForm=waiver(), 
				 				yScale="identity",
								Title="", xLab="sprintf('%s', xBy)", yLab="Percent",
								facetBy="", 
				 				binned=FALSE, binBy=7,
				 				BQLvalue, 
							...)
{
	#limit x prior to plotting
	if(!is.null(xBy) & !is.null(xLimit)){
		datFile=datFile[which(datFile[,xBy]>=xLimit[1] & datFile[,xBy]<=xLimit[2]),]
	}
		
	
if(binned){
		if (length(binBy)==1){breaks=seq(0, max(datFile[,xBy])+binBy, by=binBy)}	
		if (length(binBy)>1) {breaks=unique(as.integer(min(datFile[,xBy])), binBy, as.integer(max(datFile[,xBy])))}
		labels=as.numeric(breaks)
		labels=labels[-length(labels)]
		
		datFile[,xBy]=cut(datFile[,xBy], breaks=breaks, labels=labels, include.lowest=TRUE )
		datFile[,xBy]=as.numeric(as.character(datFile[,xBy]))
	}
	
	#manage BQLs
	if (length(datFile[which(datFile[,yBy]<=BQLvalue), yBy])>0){
		datFile[which(datFile[,yBy]<=BQLvalue), yBy]=NA
}
	
	groupvars=xBy
	if(facetBy!=""){groupvars=c(xBy, facetBy)}

	
	# New version of length which can handle NA's: if na.rm==T, don't count them
	length2 <- function (x, na.rm=FALSE) {
		if (na.rm) sum(!is.na(x))
		else       length(x)
	}
	
	
	
	temp <- ddply(datFile, groupvars, .drop=FALSE,
								 .fun= function(xx, col, na.rm) {
								 	c( 
								 		 A=length(xx[which(xx[,col]>=mean(xx[,col], na.rm=TRUE)),col])/length2(xx[,col],),
                     B=length(xx[which(xx[,col]<mean(xx[,col], na.rm=TRUE)),col])/length2(xx[,col],),
								 		 U=1-(length(xx[which(xx[,col]>=mean(xx[,col], na.rm=TRUE)),col])/length2(xx[,col],)+length(xx[which(xx[,col]<mean(xx[,col], na.rm=TRUE)),col])/length2(xx[,col],)),
								 		 mt=((length(xx[which(xx[,col]>=mean(xx[,col], na.rm=TRUE)),col])/length2(xx[,col],))+(length(xx[which(xx[,col]<mean(xx[,col], na.rm=TRUE)),col])/length2(xx[,col],)))/2+1-(length(xx[which(xx[,col]>=mean(xx[,col], na.rm=TRUE)),col])/length2(xx[,col],)+length(xx[which(xx[,col]<mean(xx[,col], na.rm=TRUE)),col])/length2(xx[,col],))	)
								 },
								 yBy,
								 FALSE)
		
	
	temp=rename(temp, c(A="Above Mean", B=" Below Mean", U="  Unavailable"))
	
	idvars=c(xBy, "mt")
	if(facetBy!=""){idvars=c(xBy, "mt", facetBy)}

	
	temp=melt(temp, id.vars=idvars)
	temp$variable=as.character(temp$variable)
	
	temp=temp[order(temp[,xBy]),]
	temp[,xBy]=factor(temp[,xBy])
	temp=temp[order(temp$variable, decreasing=FALSE),]

	
	p1=
		ggplot(temp, aes_string(x=xBy, group="variable", weight="value", fill="variable"))	+
 		geom_bar(binwidth=binWidth)+
		geom_point(aes_string(y="mt"), color="white")+
	  #cleanScales+
	#	cleanTheme+
		guides(fill = guide_legend(reverse = TRUE))+
		scale_y_continuous(labels=eval(yForm), limits=yLimit)+
		labs(title=Title, x=xLab, y=yLab)
	

	#Add in the faceting if it exists
	if (facetBy!=""){
		p1=p1 +facet_wrap(as.formula(paste("~", facetBy)))
	}
	
	return(p1)
	
}
