ci.mean <-
function(x, ci, conf.interval, type="low") {
	if(type=="low"){n=2}
	if(type=="high"){n=3}

	temp <- tryCatch(
			if(length(unique(x)) > 1) {
				boot.ci(boot(x, f.quantile, R=50, probs=conf.interval), na.rm=TRUE, conf=ci,type=c("norm"))$normal[1,n]
			},
	error=function(e) e,
	warning=function(w) w)
	
	
	
	if(!is.null(temp)){
		if("error" %in% class(temp))
		{
			temp=mean(x)
		}
	}

	
	if(is.null(temp)){temp=mean(x)}

	return(temp)
	
}
