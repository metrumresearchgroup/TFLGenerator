ConcvTimeInd <-
  function(datFile, groupBy="NMID", xBy="TAFD", yBy="DV", 
           markBy="DOSE", preserveMarkByLevels=F, Color=T,
           xLimit=NULL, yLimit=NULL,
           xForm=waiver(), yForm=waiver(),
           xScale="identity", yScale="log10", 
           Title="Individuals", xLab="Time", yLab="Concentration",
           facetBy="", fF="", fnrow=NULL, fncol=NULL,fscales="fixed",
           ...)
  {
    
    if(!is.null(fnrow)){
      if(fnrow==""){ fnrow <- NULL }else{  fnrow=as.numeric(fnrow) }
    }
    if(!is.null(fncol)){
      if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol) }
    }
           
    # Only update in the scope of this function
    if(preserveMarkByLevels){
      if(Color){ 
        cleanScales <- setColorScale(drop=F) 
      }else{ 
          cleanScales <- setGrayScale(drop=F)}
    }
    
    if(facetBy!="" & all(fF!="")){
      datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
    }
    
    var_lvls=length(levels(datFile[[markBy]]))
    pt_aes=if(var_lvls<=6){
      aes_string(shape=markBy) 
    }else{
      aes_string()  
    }
    
    if(any(with(datFile, table(datFile[,groupBy],datFile[,markBy]))>1)){
      p1=ggplot(datFile, aes_string(x=xBy, y=yBy, group=groupBy, color=markBy))
    }else{
      p1=ggplot(datFile, aes_string(x=xBy, y=yBy, group=groupBy, color=markBy, lty=lty))
    }
    
    p1=p1+
      geom_line()+
      geom_point(pt_aes)+
      cleanTheme+
      cleanScales+
      scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
      scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
      labs(title=Title, x=xLab, y=yLab)
    
    #Add in better ticks if the scale is log10
    if ("log-10" %in% as.character(yScale)){
      p1=p1+annotation_logticks(, sides="l", mid=unit(0.1, "cm"))
    }
    
    if ("log-10" %in% as.character(xScale)){
      p1=p1+annotation_logticks(, sides="b", mid=unit(0.1, "cm"))
      
    }
    
    #Add in the faceting if it exists
    if (facetBy!=""){
      p1=p1 +facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,ncol=fncol,scales=fscales)
    }
    
    p1=list(pList=list(p1),plotCols=1,plotRows=1)
    return(p1)
    
  }
