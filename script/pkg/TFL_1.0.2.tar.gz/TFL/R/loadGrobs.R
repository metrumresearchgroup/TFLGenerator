loadGrobs <-
function(file){
#	source("~//AMG386//Base386Functions.R")
	load(file, envir=.GlobalEnv)
	indexGrobs()	
}
