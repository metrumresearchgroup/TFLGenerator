
	
	stat_nDist <- function (mapping = NULL, data = NULL, geom = "line", position = "identity", 
													 distribution = dnorm, dparams = list(), na.rm = FALSE, ...) { 

		StatnDist$new(mapping = mapping, data = data, geom = geom, position = position, 
									 distribution = distribution, dparams = dparams, na.rm = na.rm, ...)
	}
	
