VPC <-
  function(datFile, yByObs="DVobs", predVar="DV", xBy="TAFD",
           markBy="DOSE",
           xLimit=NULL, yLimit=NULL,
           xForm=waiver(), yForm=waiver(),
           xScale="identity", yScale="log10", 
           Title="", xLab="Time", yLab="PK Concentration",
           PI=c(0.1, 0.5, 0.9), 
           facetBy="", 
           doseCol="DOSE", doseCor=FALSE,
           predCol="PRED", predCor=FALSE, lowerBound=0,
           logTrans=FALSE,
           simCol=NULL,
           smoothed=TRUE, binned=TRUE, binBy=7,
           ci=0.95, includeCI=FALSE,
           smoothLevel=.8, tryFormula="y~x",
           BQLlevel=10, BQLmethod="retain",
           shadingType="simulated percentiles",
           ...) 	{
    
    cat(file=stderr(), paste0("LOG: ", Sys.time(), " Running VPC\n"))
    
    VPCfun <- function(){
      # Set up parallel backend
      cl <- makeCluster(8)
      # registerDoParallel(8)
      registerDoParallel(cl)
      lp <- installed.packages()["TFL","LibPath"]
      clusterCall(cl, fun=function(x) .libPaths(lp))
      on.exit(stopCluster(cl))    
      
      if(ci > 1) ci <- as.numeric(ci)/100
      
      BQLlevel <- as.numeric(BQLlevel)
      
      if(tolower(BQLmethod) %in% c("half", "m3")){
        datFile[which(datFile[,yByObs]<=BQLlevel),yByObs]=0.5*BQLlevel
        datFile[which(datFile[,predVar]<=BQLlevel),predVar]=0.5*BQLlevel #doesn't work if I don't do this, but I'm not sure its correct
        datFile[which(datFile[,predCol]<=BQLlevel),predCol]=0.5*BQLlevel
      }
      
      if(tolower(BQLmethod)=="bql"){
        datFile[which(datFile[,yByObs]<=BQLlevel),yByObs]=BQLlevel
        datFile[which(datFile[,predVar]<=BQLlevel),predVar]=BQLlevel
        datFile[which(datFile[,predCol]<=BQLlevel),predCol]=BQLlevel
      }
      
      if(tolower(BQLmethod) %in% c("omit", "remove")){
        
        datFile=datFile[which(datFile[,yByObs]>=BQLlevel),]
        
      }
      
      
      if(doseCor){
        datFile[,yByObs]=datFile[,yByObs]/datFile[,doseCol]
        datFile[,predVar]=datFile[,predVar]/datFile[,doseCol]
        datFile[,predCol]=datFile[,predCol]/datFile[,doseCol]
      }
      
      if(binned){
        breaks=seq(0, max(datFile[,xBy])+binBy, by=binBy)
        labels=as.numeric(breaks)
        labels=labels[-length(labels)]
        
        datFile[,paste(xBy,"bin", sep="")]=cut(unlist(datFile[,xBy]), breaks=breaks, labels=labels, include.lowest=TRUE )
        datFile[,paste(xBy,"bin", sep="")]=as.numeric(as.character(unlist(datFile[,paste(xBy,"bin", sep="")])))
      }
      
      if(predCor & binned){
        for(item in unique(datFile[,paste(xBy,"bin", sep="")])){
          if(!logTrans){
            datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
              lowerBound+
              (datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]- lowerBound)*
              (
                (mean(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol], na.rm=TRUE)-lowerBound)
                /
                  (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]-lowerBound)
              )
          }
          
          
          
          if(logTrans){
            datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
              datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar]=
              (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar])+
              (
                log(mean(exp(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]), na.rm=TRUE))
                /
                  datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]
              )
          }
        }	
      }
      
      groupBy=unique(c(facetBy,xBy, simCol))
      if(binned){groupBy=unique(c(facetBy,paste(xBy,"bin", sep=""), simCol))}
      groupBy=groupBy[nchar(groupBy)>0]
      
      #Create a Summary Table of observed including a loess smooth model
      fooSum=vpcSE(data=datFile[datFile[,simCol]==1,], xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy),  measurevar=yByObs, groupvars=groupBy,
                   na.rm=TRUE, pred.interval=PI/100, ci=ci,.drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                   simCol=simCol, shadingType=shadingType,
                   smoothed=smoothed, smoothLevel=smoothLevel)
      fooSum[,simCol] <- NULL
      

      #Create a Summary Table of the sim data including a loess smooth model
      fooSumPred=vpcSE(data=datFile, xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy), measurevar=predVar, groupvars=groupBy,
                       na.rm=TRUE, pred.interval=PI/100, ci=ci, .drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                       simCol=simCol, shadingType=shadingType,
                       smoothed=smoothed, smoothLevel=smoothLevel)
      
      foo=merge(fooSum, fooSumPred, all=TRUE)
      test=merge(datFile, foo)
      
      #Add in better ticks if the scale is log10
      if (as.character(yScale)[1]=="log-10"){
        test=test[test[,yByObs]>0 & test[,predVar]>0,]
      }
      
      if(!binned){
        p1=
          ggplot(data=test, aes_string(x=xBy))	
      }
      
      if(binned){
        p1=
          ggplot(data=test, aes_string(x=paste(xBy,"bin", sep="")))
      }
      

      p1=p1+
        cleanTheme+
        cleanScales+
        scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
        scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+	
        coord_cartesian(xlim = xLimit, ylim = yLimit)+
        geom_point(data=test[test[,simCol]==1,], aes_string(x=xBy,y=yByObs), color="blue", shape=1, alpha=.3) +
        labs(title=Title, x=xLab, y=yLab)
      
      if(shadingType=="simulated percentiles"){
        p1=p1+
          geom_line(data=test[test[,simCol]==1,], aes_string(y=paste(yByObs, "qMidMid", sep="")), color="red", lty=1,lwd=1)+
          geom_line(data=test[test[,simCol]==1,], aes_string(y=paste(yByObs, "qHighMid", sep="")), color="red", lty=2,lwd=1)+
          geom_line(data=test[test[,simCol]==1,], aes_string(y=paste(yByObs, "qLowMid", sep="")), color="red", lty=2,lwd=1)	

        p1=p1+
          geom_ribbon(aes_string(ymin=paste(predVar, "qMidLow", sep=""), ymax=paste(predVar, "qMidHigh", sep="")), fill="red", alpha=.3)+
          geom_ribbon(aes_string(ymin=paste(predVar, "qHighLow", sep=""), ymax=paste(predVar, "qHighHigh", sep="")), fill="blue", alpha=.3)+
          geom_ribbon(aes_string(ymin=paste(predVar, "qLowLow", sep=""), ymax=paste(predVar, "qLowHigh", sep="")), fill="blue", alpha=.3)
      }
      if(shadingType=="no shading"){
        p1=p1+
          geom_line(data=test[test[,simCol]==1,], aes_string(y=paste(yByObs, "qMidMid", sep="")), color="red", lty=1,lwd=1)+
          geom_line(data=test[test[,simCol]==1,], aes_string(y=paste(yByObs, "qHighMid", sep="")), color="red", lty=2,lwd=1)+
          geom_line(data=test[test[,simCol]==1,], aes_string(y=paste(yByObs, "qLowMid", sep="")), color="red", lty=2,lwd=1)	+

          geom_line( aes_string(y=paste(predVar, "qMidMid", sep="")), color="blue", lty=1,lwd=1)+
          geom_line( aes_string(y=paste(predVar, "qHighMid", sep="")), color="blue", lty=2,lwd=1)+
          geom_line( aes_string(y=paste(predVar, "qLowMid", sep="")), color="blue", lty=2,lwd=1)	
      }
      if(shadingType=="observed and predicted mean"){
        p1=p1+
          geom_line(data=test, aes_string(y=paste0(yByObs, "Mid")), color="red", lty=1,lwd=1)+
          geom_ribbon(data=test, aes_string(ymax=paste0(yByObs, "MidHigh"), ymin=paste0(yByObs, "MidLow")), fill="red", alpha=.3) +
          geom_ribbon(data=test, aes_string(ymax=paste0(predVar, "MidHigh"), ymin=paste0(predVar, "MidLow")), fill="blue", alpha=.3) 
      }
      
      
      
      
      #Add in better ticks if the scale is log10
      if (as.character(yScale)[1]=="log-10"){
        p1=p1+annotation_logticks(, sides="l", mid=unit(0.1, "cm"))
      }
      
      #Add in the faceting if it exists
      if (facetBy!=""){
        p1=p1 +facet_wrap(as.formula(paste("~", facetBy)))
      }
      
      return(p1)
    }

    funframe <- environment()    
    ## Now run either withProgress (in shiny) or not (from "naked" R)
    test <- try(
      withProgress(message="Running",{
        p1 <- VPCfun()
        assign("p",p1,envir=funframe)
      })      
    )
    
    if(class(test)=="try-error"){
      if(grepl("not a ShinySession", attr(test,"condition"))){
        p1 <- VPCfun()
        assign("p",p1,envir=funframe)
      }
    }

    return(p)

  }

