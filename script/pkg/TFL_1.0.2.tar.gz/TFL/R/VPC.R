VPC <-
  function(datFile, yByObs="DVobs", predVar="DV", xBy="TAFD",
           markBy="",
           xLimit=NULL, yLimit=NULL,
           xForm=waiver(), yForm=waiver(),
           xScale="identity", yScale="log10", 
           Title="", xLab="Time", yLab="PK Concentration",
           PI=c(0.1, 0.5, 0.9), 
           facetBy="", fF="",fnrow=NULL,fscales="fixed",
           doseCol="DOSE", doseCor=FALSE,
           predCol="PRED", predCor=FALSE, lowerBound=0,
           logTrans=FALSE,
           simCol=NULL,
           smoothed=TRUE, binned=TRUE, binBy=7,
           ci=0.95, includeCI=FALSE,
           smoothLevel=.8, tryFormula="y~x",
           BQLlevel=10, BQLmethod="retain",
           shadingType="simulated percentiles",
           ...) 	{
    
    cat(file=stderr(), paste0("LOG: ", Sys.time(), " Running VPC\n"))
    
    # Worker function ----
    VPCfun <- function(){
      # Commented out, using dplyr instead
      # # Set up parallel backend
      # cl <- makeCluster(8)
      # # registerDoParallel(8)
      # registerDoParallel(cl)
      # lp <- installed.packages()["TFL","LibPath"]
      # clusterCall(cl, fun=function(x) .libPaths(lp))
      # on.exit(stopCluster(cl))    

      datFile <- as.data.frame(datFile)
      if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
      
      if(facetBy!="" & all(fF!="")){
        datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
      }
      
      if(ci > 1) ci <- as.numeric(ci)/100
      
      BQLlevel <- as.numeric(BQLlevel)

      if(tolower(BQLmethod) %in% c("m3")){
        datFile[which(datFile[,yByObs]<=BQLlevel),yByObs]=0.5*BQLlevel
        datFile[which(datFile[,predVar]<=BQLlevel),predVar]=0.5*BQLlevel #doesn't work if I don't do this, but I'm not sure its correct
        datFile[which(datFile[,predCol]<=BQLlevel),predCol]=0.5*BQLlevel
      }
      
      if(tolower(BQLmethod) %in% c("half")){
        datFile[which(datFile[,yByObs]<=BQLlevel),yByObs]=0.5*BQLlevel
        datFile[which(datFile[,predVar]<=BQLlevel),predVar]=0.5*BQLlevel #doesn't work if I don't do this, but I'm not sure its correct
        datFile[which(datFile[,predCol]<=BQLlevel),predCol]=0.5*BQLlevel
      }
      
      if(tolower(BQLmethod)=="bql"){
        datFile[which(datFile[,yByObs]<=BQLlevel),yByObs]=BQLlevel
        datFile[which(datFile[,predVar]<=BQLlevel),predVar]=BQLlevel
        datFile[which(datFile[,predCol]<=BQLlevel),predCol]=BQLlevel
      }
      
      if(tolower(BQLmethod) %in% c("omit", "remove")){
        
        datFile=datFile[which(datFile[,yByObs]>=BQLlevel),]
        
      }
      
      
      if(doseCor){
        datFile[,yByObs]=datFile[,yByObs]/datFile[,doseCol]
        datFile[,predVar]=datFile[,predVar]/datFile[,doseCol]
        datFile[,predCol]=datFile[,predCol]/datFile[,doseCol]
      }
      
      if(binned){
        breaks=seq(0, max(datFile[,xBy])+binBy, by=binBy)
        labels=as.numeric(breaks)
        labels=labels[-length(labels)]
        
        datFile[,paste(xBy,"bin", sep="")]=cut(unlist(datFile[,xBy]), breaks=breaks, labels=labels, include.lowest=TRUE )
        datFile[,paste(xBy,"bin", sep="")]=as.numeric(as.character(unlist(datFile[,paste(xBy,"bin", sep="")])))
      }
      
      if(predCor & binned){
        for(item in unique(datFile[,paste(xBy,"bin", sep="")])){
          if(!logTrans){
            datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
              lowerBound+
              (datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]- lowerBound)*
              (
                (mean(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol], na.rm=TRUE)-lowerBound)
                /
                  (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]-lowerBound)
              )
          }
          
          
          
          if(logTrans){
            datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
              datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar]=
              (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar])+
              (
                log(mean(exp(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]), na.rm=TRUE))
                /
                  datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]
              )
          }
        }	
      }
      
      if(markBy=="") markBy <- NULL
      groupBy=unique(c(facetBy,markBy,xBy, simCol))
      if(binned){groupBy=unique(c(facetBy,markBy,paste(xBy,"bin", sep=""), simCol))}
      groupBy=groupBy[nchar(groupBy)>0]
      

      #Create a Summary Table of observed including a loess smooth model
      fooSum=vpcSE(data=datFile[datFile[,simCol]==1,], xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy),  measurevar=yByObs, groupvars=groupBy,
                   na.rm=TRUE, pred.interval=PI/100, ci=ci,.drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                   simCol=simCol, shadingType=shadingType,
                   smoothed=smoothed, smoothLevel=smoothLevel)
      fooSum[,simCol] <- NULL
      

      #Create a Summary Table of the sim data including a loess smooth model
      fooSumPred=vpcSE(data=datFile, xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy), measurevar=predVar, groupvars=groupBy,
                       na.rm=TRUE, pred.interval=PI/100, ci=ci, .drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                       simCol=simCol, shadingType=shadingType,
                       smoothed=smoothed, smoothLevel=smoothLevel)
      
      foo=merge(fooSum, fooSumPred, all=TRUE)
      #test=merge(datFile, foo)

      obs <- datFile[datFile[,simCol]==min(datFile[,simCol]),]
      obs <- obs[,c(xBy,groupBy,grep("obs",names(obs),value=T))]
      obs <- melt(obs, id.vars=c(xBy,groupBy))
      obs[,simCol] <- NULL

      summ <- foo[,c(setdiff(groupBy,simCol),
                      setdiff(grep(predVar,names(foo),value=T),
                              c(predVar)
                              ))]
      summ <- melt(summ, id.vars=setdiff(groupBy,simCol))

      #Add in better ticks if the scale is log10
      if (as.character(yScale)[1]=="log-10"){
        obs <- obs[ obs$value>0, ]
        summ <- summ[ summ$value>0, ]
      }
      obs$lab <- "Observed"
      summ$lab <- "Predicted"
      summ$lab[ grep(yByObs,summ$variable) ] <- "Observed"

      if(length(unique(summ[,markBy]))>1){
        obs$lab <- sprintf("%s (%s=%s)",obs$lab,markBy,as.character(obs[,markBy]))
        summ$lab <- sprintf("%s (%s=%s)",summ$lab,markBy,as.character(summ[,markBy]))
      }

      summ$variable <- gsub(paste0(yByObs,"q"),"",summ$variable)
      summ$variable <- gsub(paste0(predVar,"q"),"",summ$variable)
      summ <- cast(summ)
      
      if(!binned){
        p1=
          ggplot(data=obs, aes_string(x=xBy, y="value"))	
      }
      
      if(binned){
        p1=
          ggplot(data=obs, aes_string(x=paste(xBy,"bin", sep=""), y="value"))
      }


      p1=p1+
        cleanTheme+
        cleanScales+
        scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
        scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+	
        coord_cartesian(xlim = xLimit, ylim = yLimit)+
        labs(title=Title, x=xLab, y=yLab)

      # Simulated percentiles ----
      if(shadingType=="simulated percentiles"){
        # Observed ----
        p1=p1+
         geom_point(aes_string(x=xBy, color='lab'), shape=1, alpha=.5) +                    
          geom_line(data=filter(summ, grepl("Observed",lab)), aes(y=MidMid,color=lab), lty=1,lwd=1)+
          geom_line(data=filter(summ, grepl("Observed",lab)), aes(y=HighMid,color=lab), lty=2,lwd=1)+
          geom_line(data=filter(summ, grepl("Observed",lab)), aes(y=LowMid,color=lab), lty=2,lwd=1)	

        # Predicted ----
        p1=p1+
          geom_ribbon(data=filter(summ, grepl("Predicted",lab)),
                      aes(y=NULL,ymin=MidLow, ymax=MidHigh, fill=lab),alpha=.3)+
          geom_ribbon(data=filter(summ, grepl("Predicted",lab)),
                      aes(y=NULL,ymin=HighLow, ymax=HighHigh, fill=lab),alpha=.3)+
          geom_ribbon(data=filter(summ, grepl("Predicted",lab)),
                      aes(y=NULL,ymin=LowLow, ymax=LowHigh, fill=lab),alpha=.3)
        
      }
      # No shading ----
      if(shadingType=="no shading"){
        # Observed ----
        p1=p1+
          geom_point(data=obs, aes_string(x=xBy, y="value", color="lab"),shape=1,alpha=.5)+
          geom_line(data=filter(summ, grepl("Observed",lab)), aes(y=MidMid, color=lab), lty=1,lwd=1)+
          geom_line(data=filter(summ, grepl("Observed",lab)), aes(y=HighMid, color=lab), lty=2,lwd=1)+
          geom_line(data=filter(summ, grepl("Observed",lab)), aes(y=LowMid, color=lab), lty=2,lwd=1)	

        # Predicted ----
        p1=p1+
          geom_line(data=filter(summ, grepl("Predicted",lab)), aes(y=MidMid, color=lab), lty=1,lwd=1)+
          geom_line(data=filter(summ, grepl("Predicted",lab)), aes(y=HighMid, color=lab), lty=1,lwd=1)+
          geom_line(data=filter(summ, grepl("Predicted",lab)), aes(y=LowMid, color=lab), lty=1,lwd=1)	
      }
      # Observed and predicted mean ----
      if(shadingType=="observed and predicted mean"){
        # Observed ----
        p1=p1+
          geom_point(data=obs, aes_string(x=xBy, y="value", color="lab"),shape=1,alpha=.5)+
          geom_line(data=filter(summ,grepl("Observed",lab)), aes(y=Mid, color=lab), lty=1,lwd=1)
        
        # Predicted ----
        p1=p1+geom_ribbon(data=filter(summ,grepl("Predicted",lab)), aes(ymax=MidHigh, ymin=MidLow, y=NULL,fill=lab), alpha=.3)
        
      }
      # Observed and predicted median ----
      if(shadingType=="observed and predicted median"){
        # Observed ----
        p1=p1+
          geom_point(data=obs, aes_string(x=xBy, y="value", color="lab"),shape=1,alpha=.5)+
          geom_line(data=filter(summ,grepl("Observed",lab)), aes(y=MidMid, color=lab), lty=1, lwd=1) 
        
        # Predicted ----
        p1=p1+
          geom_ribbon(data=filter(summ,grepl("Predicted",lab)), aes(ymax=MidHigh, ymin=MidLow, fill=lab,y=NULL), alpha=.3)
      }
      
      
      
      
      #Add in better ticks if the scale is log10
      if (as.character(yScale)[1]=="log-10"){
        p1=p1+annotation_logticks(, sides="l", mid=unit(0.1, "cm"))
      }
      
      #Add in the faceting if it exists
      if (facetBy!=""){
        p1=p1 +facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,scales=fscales)
      }
      
      return(p1)
    }

    # With progress protection ----
    funframe <- environment()    
    ## Run either withProgress (in shiny) or not (from "naked" R)
    test <- tryCatch(
      withProgress(message="Running",{
        p1 <- VPCfun()
        assign("p",p1,envir=funframe)
      }),
      error=function(e){
        p1 <- arrangeGrob(textGrob(sprintf("You broke something\n%s", e)))
        assign("funerror", e, envir=funframe)
        assign("p", p1, envir=funframe)
      }
    )

    if(exists("funerror",envir=funframe)){
      if(grepl("not a ShinySession", funerror)){
        p1 <- VPCfun()
        assign("p",p1,envir=funframe)
      }
    }

    # Return ----
    return(p)

  }

