VPC <-
  function(datFile, yByObs="DVobs", predVar="DV", xBy="TAFD",
           markBy="",
           xLimit=NULL, yLimit=NULL,
           xForm=waiver(), yForm=waiver(),
           xScale="identity", yScale="log10", 
           Title="", xLab="Time", yLab="PK Concentration",
           PI=c(0.1, 0.5, 0.9), 
           facetBy="", fF="",fnrow=NULL,fscales="fixed",
           doseCol="DOSE", doseCor=FALSE,
           predCol="PRED", predCor=FALSE, lowerBound=0,
           simCol=NULL,
           smoothed=TRUE, binned=TRUE, binBy=7,
           ci=0.95, includeCI=FALSE,
           smoothLevel=.8, tryFormula="y~x",
           BQLlevel=10, BQLmethod="retain",
           shadingType="simulated percentiles",
           showObs=T,
           label="", includeAddl_pts=FALSE, includeAddl_trend=FALSE,  addlLabel="",
           themeUpdate=list(),
           themeTextSize=14,
           themePlotTitleSize=1.2,
           themeAxisTxtSize=0.8,
           themeAxisTxtColour='black',
           themeAxisTitleTxtSize=0.9,
           themeAxisTitleColour='black',
           themePanelBackgroundFill='white',
           themePanelGridSize=NULL,
           themePanelGridColour='white',
           themePanelLineType=1,
           themePanelTitleSize=1.2,
           themePlotTitleColour='black',
           ...) 	{
    
    cat(file=stderr(), paste0("LOG: ", Sys.time(), " Running VPC\n"))
    
    # Worker function ----
    VPCfun <- function(){
      # Commented out, using dplyr instead
      # # Set up parallel backend
      # cl <- makeCluster(8)
      # # registerDoParallel(8)
      # registerDoParallel(cl)
      # lp <- installed.packages()["TFL","LibPath"]
      # clusterCall(cl, fun=function(x) .libPaths(lp))
      # on.exit(stopCluster(cl))    
      
      logTrans <- grepl("log",yScale)
      
      if(addlLabel=="") addlLabel <- NULL
      if(label=="") label <- NULL
      addl <- as.data.frame(datFile$addl)
      
      if(!(includeAddl_pts|includeAddl_trend)){
        addLabel <- NULL
        addl <- NULL
      }
      
      datFile <- as.data.frame(datFile$vpc)
      if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
      
      if(facetBy!="" & all(fF!="")){
        datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
        if(!is.null(addl)){
          addl[,facetBy] <- factor(addl[,facetBy],fF[,1],fF[,2])
        }
      }
      
      if(ci > 1) ci <- as.numeric(ci)/100
      
      BQLlevel <- as.numeric(BQLlevel)
      
      if(tolower(BQLmethod) %in% c("drop")){
        datFile[which(datFile[,yByObs]<=BQLlevel),yByObs] <- NA
        datFile[which(datFile[,predVar]<=BQLlevel),predVar]=NA
        if(predCol %in% names(datFile)) datFile[which(datFile[,predCol]<=BQLlevel),predCol]=NA
        if(!is.null(addl)){
          addl[which(addl[,yByObs]<=BQLlevel),yByObs] <- NA
          if(predCol %in% names(addl)) addl[which(addl[,predCol]<=BQLlevel),predCol]=NA
        }
      }
      
      # if(tolower(BQLmethod) %in% c("none")){
      #   datFile=datFile[which(datFile[,yByObs]>=BQLlevel),]
      # }
      
      
      if(doseCor){
        datFile[,yByObs]=datFile[,yByObs]/datFile[,doseCol]
        datFile[,predVar]=datFile[,predVar]/datFile[,doseCol]
        if(predCol %in% names(datFile)) datFile[,predCol]=datFile[,predCol]/datFile[,doseCol]
        if(!is.null(addl)){
          addl[,yByObs]=addl[,yByObs]/addl[,doseCol]
          if(predCol %in% names(addl)) addl[,predCol]=addl[,predCol]/addl[,doseCol]
        }
      }
      
      if(binned){
        if(length(binBy)>1){
          breaks <- binBy
        }else{
          breaks=seq(0, max(datFile[,xBy])+binBy, by=binBy)
        }
        labels=as.numeric(breaks)
        labels=diff(labels)/2 + labels[-length(labels)]
        # labels=labels[-length(labels)]
        
        datFile[,paste(xBy,"bin", sep="")]=cut(unlist(datFile[,xBy]), breaks=breaks, labels=labels, include.lowest=TRUE )
        datFile[,paste(xBy,"bin", sep="")]=as.numeric(as.character(unlist(datFile[,paste(xBy,"bin", sep="")])))
        
        if(!is.null(addl)){
          if(xBy %in% names(addl)){
            addl[,paste(xBy,"bin", sep="")]=cut(unlist(addl[,xBy]), breaks=breaks, labels=labels, include.lowest=TRUE )
            addl[,paste(xBy,"bin", sep="")]=as.numeric(as.character(unlist(addl[,paste(xBy,"bin", sep="")])))
          }
        }
      }
      
      if(predCor & binned){
        for(item in unique(datFile[,paste(xBy,"bin", sep="")])){
          if(!logTrans){
            datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
              lowerBound+
              (datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]- lowerBound)*
              (
                (mean(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol], na.rm=TRUE)-lowerBound)
                /
                  (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]-lowerBound)
              )
            if(!is.null(addl)){
              if(predCol %in% names(addl)){
                addl[addl[,paste(xBy,"bin", sep="")]==item,yByObs]=
                  lowerBound+
                  (addl[addl[,paste(xBy,"bin", sep="")]==item,yByObs]- lowerBound)*
                  (
                    (mean(addl[addl[,paste(xBy,"bin", sep="")]==item,predCol], na.rm=TRUE)-lowerBound)
                    /
                      (addl[addl[,paste(xBy,"bin", sep="")]==item,predCol]-lowerBound)
                  )
              }else{
                cat(file=stderr(), "LOG: No population prediction column for addl data!\n")
                addl <- NULL
              }
            }
          }
          
          
          
          if(logTrans){
            base <- ifelse(yScale=="log10",10,exp(1))
            datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
              datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar]=
              (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar])+
              (
                log(mean(exp(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]), na.rm=TRUE),base=base)
                /
                  datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]
              )
            if(!is.null(addl)){
              if(predCol%in%names(addl)){
                datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
                  datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar]=
                  (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar])+
                  (
                    log(mean(exp(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]), na.rm=TRUE),base=base)
                    /
                      datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]
                  )
              }else{
                cat(file=stderr(), "LOG: No population prediction column for addl data!\n")
                addl <- NULL
              }
            }
          }
        }	
      }
      
      if(markBy=="") markBy <- NULL
      groupBy=unique(c(facetBy,markBy,xBy, simCol))
      if(binned){groupBy=unique(c(facetBy,markBy,paste(xBy,"bin", sep=""), simCol))}
      groupBy=groupBy[nchar(groupBy)>0]
      
      
      #Create a Summary Table of observed including a loess smooth model
      fooSum=vpcSE(data=datFile[datFile[,simCol]==1,], xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy),  measurevar=yByObs, groupvars=groupBy,
                   na.rm=TRUE, pred.interval=PI/100, ci=ci,.drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                   simCol=simCol, shadingType=shadingType,
                   smoothed=smoothed, smoothLevel=smoothLevel)
      fooSum[,simCol] <- NULL
      

      #Create a Summary Table of the sim data including a loess smooth model
      fooSumPred=vpcSE(data=datFile, xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy), measurevar=predVar, groupvars=groupBy,
                       na.rm=TRUE, pred.interval=PI/100, ci=ci, .drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                       simCol=simCol, shadingType=shadingType,
                       smoothed=smoothed, smoothLevel=smoothLevel)
      
      foo=merge(fooSum, fooSumPred, all=TRUE)
      #test=merge(datFile, foo)
      
      browser()
      
      if(!is.null(addl)){
        if(simCol %nin% names(addl)) addl[,simCol] <- 1
        fooSumaddl=vpcSE(data=addl[addl[,simCol]==1,],xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy),  measurevar=yByObs,
                         groupvars=setdiff(groupBy,simCol),
                         na.rm=TRUE, pred.interval=PI/100, ci=ci,.drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                         simCol=simCol, shadingType=shadingType,
                         smoothed=smoothed, smoothLevel=smoothLevel)
        fooSumaddl[,"N"] <- NULL
        fooSumaddl <- melt(as.data.frame(fooSumaddl), id.vars=setdiff(groupBy,simCol))
        fooSumaddl$op <- "observed"
        fooSumaddl$lab <- ifelse(is.null(addlLabel), "additional", addlLabel)
      }
      
      obs <- datFile[datFile[,simCol]==min(datFile[,simCol]),]
      these <- c(xBy,groupBy,yByObs)[c(xBy,groupBy,yByObs) %in% names(obs)]
      obs <- obs[,these]
      obs <- melt(obs, id.vars=setdiff(these,yByObs))
      obs[,simCol] <- NULL
      
      if(!is.null(addl)){
        these <- which(names(addl) %in% c(xBy,groupBy,yByObs))
        addl <- addl[,these]
        addl <- melt(addl, id.vars=setdiff(names(addl),yByObs))
        addl$op <- "observed"
        addl$lab <- ifelse(is.null(addlLabel), "additional", addlLabel)
      }
      
      summ <- foo[,c(setdiff(groupBy,simCol),
                     setdiff(grep(predVar,names(foo),value=T),
                             c(predVar)
                     ))]
      summ <- melt(summ, id.vars=setdiff(groupBy,simCol))
      summ$op <- ifelse(grepl(yByObs,summ$variable),"observed","predicted")
      
      #Add in better ticks if the scale is log10
      if (logTrans){
        obs <- obs[ !is.na(obs$value), ]
        obs <- obs[ obs$value>0, ]
        summ <- summ[ summ$value>0, ]
        if(!is.null(addl)){
          addl <- addl[ !is.na(addl$value), ]
          addl <- addl[ addl$value>0, ]
        }
      }
      obs$op <- "observed"
      obs$lab <- ifelse(is.null(label), "original", label)
      summ$lab <- ifelse(is.null(label), "original", label)
      
      if(length(unique(summ[,markBy]))>1){
        obs$lab <- sprintf("%s (%s=%s)",obs$lab,markBy,as.character(obs[,markBy]))
        summ$lab <- sprintf("%s (%s=%s)",summ$lab,markBy,as.character(summ[,markBy]))
        if(!is.null(addl)){
            fooSumaddl$lab <- sprintf("%s (%s=%s)",fooSumaddl$lab,markBy,as.character(fooSumaddl[,markBy]))
        }
      }
      
      summ$variable <- gsub(paste0(yByObs,"q"),"",summ$variable)
      summ$variable <- gsub(paste0(predVar,"q"),"",summ$variable)
      summ <- cast(summ)
      if(!is.null(addl)){
        fooSumaddl$variable <- gsub(paste0(yByObs,"q"),"",fooSumaddl$variable)
        fooSumaddl$variable <- gsub(paste0(predVar,"q"),"",fooSumaddl$variable)
        addlSum <- cast(fooSumaddl)
      }
      
      
      if(!binned){
        p1=
          ggplot(data=obs, aes_string(x=xBy, y="value"))	
      }
      
      if(binned){
        p1=
          ggplot(data=obs, aes_string(x=paste(xBy,"bin", sep=""), y="value"))
      }
      

      # p1=p1+
      #   cleanScales +
      #   scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
      #   scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+	
      #   coord_cartesian(xlim = xLimit, ylim = yLimit)+
      #   labs(title=Title, x=xLab, y=yLab)
      
      # Simulated percentiles ----
      if(shadingType=="simulated percentiles"){
        # Observed ----
        p1=p1+
          geom_line(data=filter(summ,op=="observed"), aes(y=MidMid,color=lab), lty=2,lwd=1)+
          geom_line(data=filter(summ,op=="observed"), aes(y=HighMid,color=lab), lty=2,lwd=1)+
          geom_line(data=filter(summ,op=="observed"), aes(y=LowMid,color=lab), lty=2,lwd=1)	

        if(showObs){
          p1=p1+
            geom_point(aes_string(x=xBy, color='lab'), shape=1, alpha=.5) 
        }
        
        # Predicted ----
        p1=p1+
          geom_ribbon(data=filter(summ, op=="predicted"),
                      aes(y=NULL,ymin=MidLow, ymax=MidHigh, fill=lab),alpha=.3)+
          geom_ribbon(data=filter(summ, op=="predicted"),
                      aes(y=NULL,ymin=HighLow, ymax=HighHigh, fill=lab),alpha=.3)+
          geom_ribbon(data=filter(summ, op=="predicted"),
                      aes(y=NULL,ymin=LowLow, ymax=LowHigh, fill=lab),alpha=.3)
        
        # Additional (this breaks the color mapping because it places "additional data" in the first level of the color/lty/shape factor)----
        # if(!is.null(addl)){
        #   if(includeAddl_pts) p1=p1+geom_point(data=addl, aes_string(x=xBy, color='lab'), shape=1, alpha=.5)
        #   if(includeAddl_trend) p1=p1+geom_line(data=addlSum, aes(y=MidMid,color=lab), lty=2, lwd=1)
        # }
        
      }
      # No shading ----
      if(shadingType=="no shading"){
        # Observed ----
        p1=p1+
          geom_line(data=filter(summ, grepl("Observed",lab)), aes(y=MidMid, color=lab), lty=2,lwd=1)+
          geom_line(data=filter(summ, grepl("Observed",lab)), aes(y=HighMid, color=lab), lty=2,lwd=1)+
          geom_line(data=filter(summ, grepl("Observed",lab)), aes(y=LowMid, color=lab), lty=2,lwd=1)	
        if(showObs){
          p1=p1+
            geom_point(data=obs, aes_string(x=xBy, y="value", color="lab"),shape=1,alpha=.5)
        }
        # Predicted ----
        p1=p1+
          geom_line(data=filter(summ, grepl("Predicted",lab)), aes(y=MidMid, color=lab), lty=1,lwd=1)+
          geom_line(data=filter(summ, grepl("Predicted",lab)), aes(y=HighMid, color=lab), lty=1,lwd=1)+
          geom_line(data=filter(summ, grepl("Predicted",lab)), aes(y=LowMid, color=lab), lty=1,lwd=1)	
        
        # Additional ----
        if(!is.null(addl)){
          if(includeAddl_pts) p1=p1+geom_point(data=addl, aes_string(x=xBy, y="value", color='lab'), shape=1, alpha=.5)
          if(includeAddl_trend) p1=p1+geom_line(data=addlSum, aes(y=MidMid,color=lab), lty=2, lwd=1)
        }
      }

      # Observed and predicted median ----
      if(shadingType=="predicted median"){
        # Observed ----
        p1=p1+
          geom_line(data=filter(summ,grepl("Observed",lab)), aes(y=MidMid, color=lab), lty=2, lwd=1) 
        if(showObs){
          p1=p1+
            geom_point(data=obs, aes_string(x=xBy, y="value", color="lab"),shape=1,alpha=.5)
        }
        
        # Predicted ----
        p1=p1+
          geom_ribbon(data=filter(summ,grepl("Predicted",lab)), aes(ymax=MidHigh, ymin=MidLow, fill=lab,y=NULL), alpha=.3)

        # Additional ----
        if(!is.null(addl)){
          if(includeAddl_pts) p1=p1+geom_point(data=addl, aes_string(x=xBy, y="value", color='lab'), shape=1, alpha=.5)
          if(includeAddl_trend) p1=p1+geom_line(data=addlSum, aes(y=MidMid,color=lab), lty=2, lwd=1)
        }
        
      }
      
      
      #Add in better ticks if the scale is log10
      if (as.character(yScale)[1]=="log10"){
        p1=p1+annotation_logticks(, sides="l", mid=unit(0.1, "cm"))
      }
      
      #Add in the faceting if it exists
      if (facetBy!=""){
        p1=p1 +facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,scales=fscales)
      }
      
      
      p1=p1+
        cleanScales +
        scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
        scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+	
        coord_cartesian(xlim = xLimit, ylim = yLimit)+
        labs(title=Title, x=xLab, y=yLab)
      
      rel=ggplot2:::rel
      themeUpdate=theme(text=              element_text(size=themeTextSize),
                        axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                        axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                        plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                        panel.background = element_rect(fill = themePanelBackgroundFill),
                        panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
      )
      
      p1=p1+cleanTheme+themeUpdate+guides(fill=guide_legend(title=""), 
                                          colour=guide_legend(title=""), 
                                          shape=guide_legend(title=""))
      
      return(p1)
    }
    
    # With progress protection ----
    funframe <- environment()    
    ## Run either withProgress (in shiny) or not (from "naked" R)
    test <- tryCatch(
      withProgress(message="Running",{
        p1 <- VPCfun()
        assign("p",p1,envir=funframe)
      }),
      error=function(e){
        p1 <- arrangeGrob(textGrob(sprintf("You broke something\n%s", e)))
        assign("funerror", e, envir=funframe)
        assign("p", p1, envir=funframe)
      }
    )
    
    if(exists("funerror",envir=funframe)){
      if(grepl("not a ShinySession", funerror)){
        p1 <- VPCfun()
        assign("p",p1,envir=funframe)
      }
    }
    
    return(list(pList=list(p),plotRows=1,plotCols=1))
    
  }

