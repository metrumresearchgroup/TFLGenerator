vpcSE <-
  function(data=NULL, xBy="TAFD", measurevar, groupvars=NULL, na.rm=FALSE, 
           pred.interval=c(.1,.5, .9), ci=.95, .drop=TRUE, includeCI=FALSE, tryFormula,
           simCol=NULL, shadingType="simulated percentiles",
           smoothed, smoothLevel) {
    
    require(dplyr)
    
    # New version of length which can handle NA's: if na.rm==T, don't count them
    length2 <- function (x, na.rm=FALSE) {
      if (na.rm) sum(!is.na(x))
      else       length(x)
    }
    
    if(shadingType=="observed and predicted mean"){
      dots <- list(
        interp( ~length2(unlist(x),na.rm=na.rm), x=as.name(measurevar)),
        interp( ~mean(unlist(x),na.rm=na.rm), x=as.name(measurevar)),
        interp( ~sd(unlist(x),na.rm=na.rm), x=as.name(measurevar))
      )
      dots.group <- lapply(groupvars, as.symbol)
      # Like a posterior predictive check: plot obs mean, CI for mean, and percentiles of simulated mean
      datac <- data[,c(groupvars,measurevar)] %>% 
        group_by_(.dots=dots.group) %>% 
        dplyr::summarise_(.dots=setNames(dots,c("N","mid","sd")))

      datac$se <- with(datac, se <- sd/sqrt(N))
      datac$high <- with(datac, mid + se*qt(ci,N))
      datac$low <- with(datac, mid - se*qt(ci,N))
      datac$se <- datac$sd <- NULL
      
      datac <- rename(datac, c(mid=sprintf("%sqMid", measurevar)))
      datac <- rename(datac, c(high=sprintf("%sqMidHigh", measurevar)))
      datac <- rename(datac, c(low=sprintf("%sqMidLow", measurevar)))
      
      # For observed, stop here.  For predicted, get quantiles of mean over reps
      
      if((simCol %in% groupvars) & (length(unique(unlist(data[,simCol])))>1)) {
        dots <- list(
          interp( ~ci.meanSim(unlist(x), ci=ci, type="low"), x=as.name(sprintf("%sqMid", measurevar))) ,
          interp( ~ci.meanSim(unlist(x), ci=ci, type="high"), x=as.name(sprintf("%sqMid", measurevar)))
        )
        newgroup=groupvars[which(groupvars!=simCol)]
        dots.group <- lapply(newgroup, as.symbol)
        
        datac1 <- group_by_(datac, .dots=dots.group) %>% 
          dplyr:::summarise_(.dots=setNames(dots,c("qMidLow","qMidHigh")))
        
        datac1 <- rename(datac1, c(qMidLow=sprintf("%sqMidLow", measurevar)))
        datac1 <- rename(datac1, c(qMidHigh=sprintf("%sqMidHigh", measurevar)))
        
        datac=datac1
      }
      
    }else{
      # shadingType is either:
      # simulated percentiles -- find the percentiles (PI) of observed and simulated.  Regions are uncertainty in predictions only
      # no shading -- a line for each of the observed and predicted percentiles (PI)
      # observed and predicted median -- show the line and band for the predicted median
      dots.group <- lapply(groupvars, as.symbol)
      dots <- list(interp(~length2(x), x=as.name(measurevar)),
                   interp(~f.quantile(x,probs=pred.interval[1],na.rm=na.rm),x=as.name(measurevar)),
                   interp(~f.quantile(x,probs=pred.interval[2],na.rm=na.rm),x=as.name(measurevar)),
                   interp(~f.quantile(x,probs=pred.interval[3],na.rm=na.rm),x=as.name(measurevar)))

      datac <- data[,c(groupvars,measurevar)] %>% 
        group_by_(.dots=dots.group) %>%
        dplyr:::summarise_(.dots = setNames(dots,c("N","qLowMid","qMidMid","qHighMid")))
      
      
      datac <- rename(datac, c(qLowMid=sprintf("%sqLowMid", measurevar)))
      datac <- rename(datac, c(qMidMid=sprintf("%sqMidMid", measurevar)))
      datac <- rename(datac, c(qHighMid=sprintf("%sqHighMid", measurevar)))
      
      if((simCol %in% groupvars) & (length(unique(unlist(data[,simCol])))>1)){

        newgroup=groupvars[which(groupvars!=simCol)]
        datac1 <- ddply(datac, newgroup, .drop=.drop,
                        .fun= function(xx, col, na.rm) {
                          c(
                            qLowLow=ci.meanSim(xx[,sprintf("%sqLowMid", measurevar)], ci=ci,  "low"),
                            qLowMid=quantile(xx[,sprintf("%sqLowMid", measurevar)], probs=.5, na.rm=na.rm, names=F),
                            qLowHigh=ci.meanSim(xx[,sprintf("%sqLowMid", measurevar)], ci=ci,  "high"),
                            qMidLow=ci.meanSim(xx[,sprintf("%sqMidMid", measurevar)], ci=ci,  "low"),
                            qMidMid=quantile(xx[,sprintf("%sqMidMid", measurevar)], probs=.5, na.rm=na.rm, names=F),
                            qMidHigh=ci.meanSim(xx[,sprintf("%sqMidMid", measurevar)], ci=ci,  "high"),
                            qHighLow=ci.meanSim(xx[,sprintf("%sqHighMid", measurevar)], ci=ci,  "low"),
                            qHighMid=quantile(xx[,sprintf("%sqHighMid", measurevar)], probs=.5, na.rm=na.rm, names=F),
                            qHighHigh=ci.meanSim(xx[,sprintf("%sqHighMid", measurevar)], ci=ci,  "high")
                          )
                        },
                        measurevar,
                        na.rm)
        datac1 <- rename(datac1, c(qLowLow=sprintf("%sqLowLow", measurevar)))
        datac1 <- rename(datac1, c(qLowMid=sprintf("%sqLowMid", measurevar)))
        datac1 <- rename(datac1, c(qLowHigh=sprintf("%sqLowHigh", measurevar)))
        datac1 <- rename(datac1, c(qMidLow=sprintf("%sqMidLow", measurevar)))
        datac1 <- rename(datac1, c(qMidMid=sprintf("%sqMidMid", measurevar)))
        datac1 <- rename(datac1, c(qMidHigh=sprintf("%sqMidHigh", measurevar)))
        datac1 <- rename(datac1, c(qHighLow=sprintf("%sqHighLow", measurevar)))
        datac1 <- rename(datac1, c(qHighMid=sprintf("%sqHighMid", measurevar)))
        datac1 <- rename(datac1, c(qHighHigh=sprintf("%sqHighHigh", measurevar)))
        
        datac <- datac[,c(newgroup,"N")]
        datac <- datac[!duplicated(datac),]
        datac <- merge(datac,datac1)
        # if(shadingType=="simulated percentiles") datac=merge(datac, datac1, all=TRUE)
        # if(shadingType=="no shading") datac <- datac1
      }
      
    }
    
    
    
    
    # if(smoothed){
    #   #smooth all confidence intervals around prediction intervals
    #   for (qNames in paste(measurevar, c("qLowLow", "qLowMid", "qLowHigh", "qMidLow", "qMidMid", "qMidHigh", "qHighLow", "qHighMid", "qHighHigh"), sep="")){
    #     if(qNames %in% names(datac)){
    #       y.loess = loess(formula=as.formula(tryFormula), span=smoothLevel, data=data.frame(x=datac[,xBy], y=datac[,qNames]))
    #       datac[,qNames]=predict(y.loess, data.frame(x=datac[,xBy]))
    #     }
    #   }	
    # }
    
    if("N" %in% names(datac))  datac=datac[which(datac$N!=0),]
    
    return(datac)
  }
