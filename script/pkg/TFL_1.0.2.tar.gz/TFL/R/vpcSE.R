vpcSE <-
function(data=NULL, xBy="TAFD", measurevar, groupvars=NULL, na.rm=FALSE, 
				 pred.interval=c(.1,.5, .9), ci=.95, .drop=TRUE, includeCI=FALSE, tryFormula,
				 simCol=NULL,
				 smoothed, smoothLevel) {
	
	require(plyr)

	# New version of length which can handle NA's: if na.rm==T, don't count them
	length2 <- function (x, na.rm=FALSE) {
		if (na.rm) sum(!is.na(x))
		else       length(x)
	}
	

	datac <- ddply(data, groupvars, .drop=.drop,
								 .fun= function(xx, col, na.rm) {
								 	c( N     	= length2(xx[,col], na.rm=na.rm),
								 		 qLowMid= as.vector(f.quantile(xx[,col], probs=pred.interval[1], na.rm=na.rm)),
								 		 qMidMid = as.vector(f.quantile(xx[,col], probs=pred.interval[2], na.rm=na.rm)),
								 		 qHighMid= as.vector(f.quantile(xx[,col], probs=pred.interval[3], na.rm=na.rm))
								 	)
								 	
								 },
								 measurevar,
								 na.rm )
	
	datac <- rename(datac, c(qLowMid=sprintf("%sqLowMid", measurevar)))
	datac <- rename(datac, c(qMidMid=sprintf("%sqMidMid", measurevar)))
	datac <- rename(datac, c(qHighMid=sprintf("%sqHighMid", measurevar)))
		
	
	if(includeCI){
    newgroup=groupvars[which(groupvars!=simCol)]
		datac1 <- ddply(datac, newgroup, .drop=.drop,
										.fun= function(xx, col, na.rm) {
											c(
												qLowLow=ci.meanSim(xx[,sprintf("%sqLowMid", measurevar)], ci=ci,  "low"),
												qLowHigh=ci.meanSim(xx[,sprintf("%sqLowMid", measurevar)], ci=ci,  "high"),
												qMidLow=ci.meanSim(xx[,sprintf("%sqMidMid", measurevar)], ci=ci,  "low"),
												qMidHigh=ci.meanSim(xx[,sprintf("%sqMidMid", measurevar)], ci=ci,  "high"),
												qHighLow=ci.meanSim(xx[,sprintf("%sqHighMid", measurevar)], ci=ci,  "low"),
												qHighHigh=ci.meanSim(xx[,sprintf("%sqHighMid", measurevar)], ci=ci,  "high")
											)
											
										},
										measurevar,
										na.rm )

		datac1 <- rename(datac1, c(qLowLow=sprintf("%sqLowLow", measurevar)))
		datac1 <- rename(datac1, c(qMidLow=sprintf("%sqMidLow", measurevar)))
		datac1 <- rename(datac1, c(qHighLow=sprintf("%sqHighLow", measurevar)))
		datac1 <- rename(datac1, c(qLowHigh=sprintf("%sqLowHigh", measurevar)))
		datac1 <- rename(datac1, c(qMidHigh=sprintf("%sqMidHigh", measurevar)))
		datac1 <- rename(datac1, c(qHighHigh=sprintf("%sqHighHigh", measurevar)))

		datac=merge(datac, datac1, all=TRUE)

	}

	if(smoothed){
		#smooth all confidence intervals around prediction intervals
			for (qNames in paste(measurevar, c("qLowLow", "qLowMid", "qLowHigh", "qMidLow", "qMidMid", "qMidHigh", "qHighLow", "qHighMid", "qHighHigh"), sep="")){
					if(qNames %in% names(datac)){
					y.loess = loess(formula=as.formula(tryFormula), span=smoothLevel, data=data.frame(x=datac[,xBy], y=datac[,qNames]))
					datac[,qNames]=predict(y.loess, data.frame(x=datac[,xBy]))
				}
			}	
	}
	
	datac=datac[which(datac$N!=0),]
	
	return(datac)
}
