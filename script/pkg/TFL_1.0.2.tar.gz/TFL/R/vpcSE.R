vpcSE <-
  function(data=NULL, xBy="TAFD", measurevar, groupvars=NULL, na.rm=FALSE, 
           pred.interval=c(.1,.5, .9), ci=.95, .drop=TRUE, includeCI=FALSE, tryFormula,
           simCol=NULL, shadingType="simulated percentiles",
           smoothed, smoothLevel) {
    
    require(plyr)
    
    # New version of length which can handle NA's: if na.rm==T, don't count them
    length2 <- function (x, na.rm=FALSE) {
      if (na.rm) sum(!is.na(x))
      else       length(x)
    }
    
    if(shadingType=="observed and predicted mean"){
      # Like a posterior predictive check: plot obs mean, CI for mean, and percentiles of simulated mean
      datac <- ddply(data[,c(groupvars,measurevar)], groupvars, .drop=.drop,
                     .fun= function(xx, col, na.rm) {
                       c( N     	= length2(xx[,col], na.rm=na.rm),
                          mid = as.vector(mean(xx[,col], na.rm=na.rm)),
                          sd = as.vector(sd(xx[,col],na.rm=na.rm))
                       )
                     },
                     measurevar,
                     na.rm ,
                     .parallel=T, .paropts=list(.packages=c("TFL")))
      datac$se <- with(datac, se <- sd/sqrt(N))
      datac$high <- with(datac, mid + se*qt(ci,N))
      datac$low <- with(datac, mid - se*qt(ci,N))
      datac$se <- datac$sd <- NULL
      
      datac <- rename(datac, c(mid=sprintf("%sMid", measurevar)))
      datac <- rename(datac, c(high=sprintf("%sMidHigh", measurevar)))
      datac <- rename(datac, c(low=sprintf("%sMidLow", measurevar)))
      
      # For observed, stop here.  For predicted, get quantiles of mean over reps
      
      if((simCol %in% groupvars) & (length(unique(unlist(data[,simCol])))>1)) {
        newgroup=groupvars[which(groupvars!=simCol)]
        datac1 <- ddply(datac, newgroup, .drop=.drop,
                        .fun= function(xx, col, na.rm) {
                          c(
                            qMidLow=ci.meanSim(unlist(xx[,sprintf("%sMid", measurevar)]), ci=ci, type="low"),
                            qMidHigh=ci.meanSim(unlist(xx[,sprintf("%sMid", measurevar)]), ci=ci,  type="high")
                          )
                          
                        },
                        measurevar,
                        na.rm,
                       .parallel=T, .paropts=list(.packages=c("TFL")))
        
        datac1 <- rename(datac1, c(qMidLow=sprintf("%sqMidLow", measurevar)))
        datac1 <- rename(datac1, c(qMidHigh=sprintf("%sqMidHigh", measurevar)))
        
        datac=merge(datac, datac1, all=TRUE) 
      }
      
    }else{
      # shadingType is either:
      # simulated percentiles -- find the percentiles (PI) of observed and simulated.  Regions are uncertainty in predictions only
      # no shading -- a line for each of the observed and predicted percentiles (PI)
      
      datac <- ddply(data[,c(groupvars,measurevar)], groupvars, .drop=.drop,
                     .fun= function(xx, col, na.rm) {
                       c( N     	= length2(xx[,col], na.rm=na.rm),
                          qLowMid= as.vector(TFL:::f.quantile(xx[,col], probs=pred.interval[1], na.rm=na.rm)),
                          qMidMid = as.vector(TFL:::f.quantile(xx[,col], probs=pred.interval[2], na.rm=na.rm)),
                          qHighMid= as.vector(TFL:::f.quantile(xx[,col], probs=pred.interval[3], na.rm=na.rm))
                       )
                       
                     },
                     measurevar,
                     na.rm ,
                     .parallel=T, .paropts=list(.packages=c("TFL")))
      
      
      datac <- rename(datac, c(qLowMid=sprintf("%sqLowMid", measurevar)))
      datac <- rename(datac, c(qMidMid=sprintf("%sqMidMid", measurevar)))
      datac <- rename(datac, c(qHighMid=sprintf("%sqHighMid", measurevar)))
      
      if((simCol %in% groupvars) & (length(unique(unlist(data[,simCol])))>1)){

        newgroup=groupvars[which(groupvars!=simCol)]
        datac1 <- ddply(datac, newgroup, .drop=.drop,
                        .fun= function(xx, col, na.rm) {
                          c(
                            qLowLow=ci.meanSim(xx[,sprintf("%sqLowMid", measurevar)], ci=ci,  "low"),
                            qLowMid=quantile(xx[,sprintf("%sqLowMid", measurevar)], probs=.5, na.rm=na.rm, names=F),
                            qLowHigh=ci.meanSim(xx[,sprintf("%sqLowMid", measurevar)], ci=ci,  "high"),
                            qMidLow=ci.meanSim(xx[,sprintf("%sqMidMid", measurevar)], ci=ci,  "low"),
                            qMidMid=quantile(xx[,sprintf("%sqMidMid", measurevar)], probs=.5, na.rm=na.rm, names=F),
                            qMidHigh=ci.meanSim(xx[,sprintf("%sqMidMid", measurevar)], ci=ci,  "high"),
                            qHighLow=ci.meanSim(xx[,sprintf("%sqHighMid", measurevar)], ci=ci,  "low"),
                            qHighMid=quantile(xx[,sprintf("%sqHighMid", measurevar)], probs=.5, na.rm=na.rm, names=F),
                            qHighHigh=ci.meanSim(xx[,sprintf("%sqHighMid", measurevar)], ci=ci,  "high")
                          )
                          
                        },
                        measurevar,
                        na.rm,
                        .parallel=T, .paropts=list(.packages=c("TFL")))
        
        datac1 <- rename(datac1, c(qLowLow=sprintf("%sqLowLow", measurevar)))
        datac1 <- rename(datac1, c(qLowMid=sprintf("%sqLowMid", measurevar)))
        datac1 <- rename(datac1, c(qLowHigh=sprintf("%sqLowHigh", measurevar)))
        datac1 <- rename(datac1, c(qMidLow=sprintf("%sqMidLow", measurevar)))
        datac1 <- rename(datac1, c(qMidMid=sprintf("%sqMidMid", measurevar)))
        datac1 <- rename(datac1, c(qMidHigh=sprintf("%sqMidHigh", measurevar)))
        datac1 <- rename(datac1, c(qHighLow=sprintf("%sqHighLow", measurevar)))
        datac1 <- rename(datac1, c(qHighMid=sprintf("%sqHighMid", measurevar)))
        datac1 <- rename(datac1, c(qHighHigh=sprintf("%sqHighHigh", measurevar)))
        
        datac <- datac[,c(newgroup,"N")]
        datac <- datac[!duplicated(datac),]
        datac <- merge(datac,datac1)
        # if(shadingType=="simulated percentiles") datac=merge(datac, datac1, all=TRUE)
        # if(shadingType=="no shading") datac <- datac1
      }
      
    }
    
    
    
    
    # if(smoothed){
    #   #smooth all confidence intervals around prediction intervals
    #   for (qNames in paste(measurevar, c("qLowLow", "qLowMid", "qLowHigh", "qMidLow", "qMidMid", "qMidHigh", "qHighLow", "qHighMid", "qHighHigh"), sep="")){
    #     if(qNames %in% names(datac)){
    #       y.loess = loess(formula=as.formula(tryFormula), span=smoothLevel, data=data.frame(x=datac[,xBy], y=datac[,qNames]))
    #       datac[,qNames]=predict(y.loess, data.frame(x=datac[,xBy]))
    #     }
    #   }	
    # }
    
    datac=datac[which(datac$N!=0),]
    
    return(datac)
  }
