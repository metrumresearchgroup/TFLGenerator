#require(proto)

StatnDist <- ggproto(ggplot2:::Stat, expr = {
  objname <- "nDist"
  
  default_geom <- function(.) GeomLine
  default_aes <- function(.) aes(x= ..newx.., y = ..newy..)
  required_aes <- c("sample")
  
  calculate <- function(., data, scales, quantiles = NULL, distribution = fnorm, dparams = list(), na.rm = FALSE) {
    data <- remove_missing(data, na.rm, "sample", name = "stat_nDist")
    
    sample <- sort(data$sample)
    padding=(max(sample)-min(sample))/5
    newx=seq(from=min(sample)-padding, to=max(sample)+padding, length.out=1000)
    newy <- safe.call(distribution, c(list(x = newx, mean=mean(sample), sd=sd(sample)), dparams))
    
    data.frame(newx, newy)
  }
  
})