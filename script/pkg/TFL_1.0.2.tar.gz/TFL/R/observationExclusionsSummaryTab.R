observationExclusionsSummaryTab <-
	function(
	  tmpDir = NULL
	)
		{ 
	  if(is.null(tmpDir)){
	    tmpDir <- tempdir()
	    dir.create(tmpDir,recursive = T)
	  }else{
	    if(!dir.exists(tmpDir)){
	      return()
	    }
	  }
	  
		datFile <- try(observationExclusions)
		if(class(datFile)=="try-error") datFile <-  get("observationExclusions",.GlobalEnv)
		
		datFile0 <- datFile
		datFile <- group_by(datFile0,excl_reasons) %>% 
		  dplyr:::summarise(N=length(NMID), perc=round(length(NMID)/nrow(datFile0)*100,1))
		datFile <- rbind(datFile, c("Total",nrow(datFile0),"100.0"))
		
		
		names(datFile) <- map(names(datFile), 
		                      from=c("excl_reasons","perc"),
		                      to=c("Reason for exclusion", "% of Exclusions"),
		                      strict=F)
		
		nms <- names(datFile)
		datFile <- as.data.frame(datFile)
		names(datFile) <- nms
		

		f <- file.path(tmpDir,"observationExclusionsSummary.doc")
		rtf <- RTF(f,font.size=11)
		addTable(rtf,datFile)
		done(rtf)
		p1 <- datFile
		return(list(preview=datFile, file=f))
	}
