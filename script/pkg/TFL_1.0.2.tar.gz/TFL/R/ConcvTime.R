ConcvTime <-
function(datFile, xBy="TAFD", yBy="DV", 
									    idVar="NMID",
									 		ID=unique(datFile[,idVar])[1],
									 		predVar="PRED", ipredVar="IPRE", 
											xLimit=NULL, yLimit=NULL,
											xForm=waiver(), yForm=waiver(),
											xScale="identity", yScale="log10", 
									 		Title=sprintf("Subject %s", ID), xLab="Time", yLab="Concentration",
											...)
{
	datFile=datFile[datFile[,idVar]==ID,]
	datFile=melt(datFile, id.vars=c(idVar, xBy), measure.vars=c(yBy, predVar, ipredVar))
	datFile$variable=factor(datFile$variable, levels=c(yBy, predVar, ipredVar), labels=c("Observed", "Population Predicted", "Individual"))
	
	p1=ggplot(data=datFile, aes_string(x=xBy, y="value", color="variable", shape="variable", lty="variable"))+
		geom_line()+
		geom_point()+
		cleanTheme+
		scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
		scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
		labs(title=Title, x=xLab, y=yLab, shape=NULL, lty=NULL, color=NULL) +
		scale_shape_manual( values = c("O", ".", "."))+
		scale_colour_manual(values = c('black', 'black','blue'))+
		scale_linetype_manual( values=c(0,1,3))
 		

	#Add in better ticks if the scale is log10
	if (as.character(yScale)[1]=="log-10"){
		p1=p1+annotation_logticks(, sides="l", mid=unit(0.1, "cm"))
	}
	
	if (as.character(xScale)[1]=="log-10"){
		p1=p1+annotation_logticks(, sides="b", mid=unit(0.1, "cm"))
		
	}
	
	p1=list(pList=list(p1),plotCols=1,plotRows=1)
	return(p1)
	
}
