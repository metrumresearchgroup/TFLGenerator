ConcvTimeMult <-
  function(datFile, item, n, 
           groupBy="NMID", xBy="TAFD", yBy="DV", ipredVar="IPRE", predVar="PRED", doseVar="DOSE", doseLab="mg/kg",
           markBy="DOSE", preserveMarkByLevels=F, Color=T,
           xLimit=NULL, yLimit=NULL,
           xForm=waiver(), yForm=waiver(),
           xScale="identity", yScale="log10", 
           Title="Individuals", xLab="Time", yLab="Concentration",
           ncol=3, nrow=3, ID=NULL,
           tmpDir=NULL, regenPlots=T, page=1,
           ...)
  {
    
    if(is.null(tmpDir)){
      tmpDir <- tempdir()
      dir.create(tmpDir,recursive = T,showWarnings=F)
      if(regenPlots){
        preexisting <- grep(paste0(item,n),list.files(tmpDir),value=T)
        unlink(file.path(tmpDir,preexisting))
      }
    }else{
      if(!dir.exists(tmpDir)){ 
        return() 
        }
    }
    filename <- file.path(tmpDir,paste0(item,n,"_%1d.png"))
    
    #if(regenPlots){
      
      # Delete old files first
      sapply(grep(paste0(item,n,"*.png"),list.files(tmpDir),value=T),unlink)
      
      # Only update in the scope of this function
      if(preserveMarkByLevels){
        if(Color){ cleanScales <- setColorScale(drop=F,shapeList = shape_pal()(6)) }else{ cleanScales <- setGrayScale(drop=F,shapeList = shape_pal()(6))}
      }
      
      if(!is.null(ID)) datFile <- datFile[datFile[,groupBy]%in%ID,]
      
      datFile$groupBy <- datFile[,groupBy]
      
     n.tot=as.numeric(nrow)*as.numeric(ncol)
     d=sort(unique(datFile[,groupBy]))
     plotIdx=split(d, ceiling(seq_along(d)/n.tot))
     
     if(page!=0) plotIdx=plotIdx[page]
     
      pList=llply(plotIdx,function(idx){
        df=datFile[datFile[,groupBy]%in%idx,]
        df=melt(df, id.vars=c(groupBy, xBy, doseVar), measure.vars=c(yBy, predVar, ipredVar))
        df$variable=factor(df$variable, levels=c(yBy, predVar, ipredVar), labels=c("Observed", "Population Predicted", "Individual"))
        
        df$facet_id=paste0("ID=",df[,groupBy],", ",df[,doseVar]," ",doseLab)
        df$facet_id=factor(df$facet_id,levels=unique(df$facet_id))
        var_lvls=length(levels(df[['variable']]))
        pt_aes=if(var_lvls<=6){
          aes_string(shape="variable") 
        }else{
          aes_string()  
        }
        
        ggplot(data=df, aes_string(x=xBy, y="value", color="variable"))+
          geom_line(aes_string(lty="variable"),show.legend = F)+
          geom_point(pt_aes,show.legend = F)+
          scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
          scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
          labs(x=xLab, y=yLab, shape=NULL, lty=NULL, color=NULL) +
          scale_shape_manual( values = c("O", ".", "."))+
          scale_colour_manual(values = c('black', 'black','blue'))+
          scale_linetype_manual( values=c(0,1,3))+
          facet_wrap(~facet_id,scales='free')+
          cleanTheme
        
        #pidx=which(lapply(plotIdx,function(x) all.equal(x,idx))==T)
        
        #p1
        # #Add in better ticks if the scale is log10
        # if (as.character(yScale)[1]=="log-10"){
        #   p1=p1+annotation_logticks(, sides="l", mid=unit(0.1, "cm"))
        # }
        # 
        # if (as.character(xScale)[1]=="log-10"){
        #   p1=p1+annotation_logticks(, sides="b", mid=unit(0.1, "cm"))
        #   
        # }
        # 
        
        
      })
      
     
      
      p1=lapply(1:length(pList),function(i) list(pList=pList[i],plotCols=1,plotRows=1))
      
      return(p1)
      
      
      
      ## Now run either withProgress (in shiny) or not (from "naked" R)
      # test <- try(
      #   withProgress(message="Running",{
      #     pList <- pList.fun()
      #   })      
      # )
      # 
      # 
      # if(class(test)=="try-error"){
      #   if(grepl("not a ShinySession", attr(test,"condition"))){
      #     pList <- pList.fun()
      #   }
      # }
      
         
      #for(i in 1:length(pList)) class(pList[[i]]) <- "ggplot"
      
      # png(filename = file.path(tmpDir,paste0(item,n,"_%1d.png")), width=637.5, height=825, units="px")
      #     do.call(marrangeGrob,list(grobs=pList[1:24],
      #                                 top=textGrob(Title,gp=gpar(fontsize=14)),
      #                                 left=textGrob(yLab,rot=90,gp=gpar(fontsize=16,fontface="bold")),
      #                                 bottom=textGrob(xLab,gp=gpar(fontsize=16,fontface="bold")),
      #                                 ncol=as.numeric(ncol),
      #                                 nrow=as.numeric(nrow)))
      #              
      # 
      # dev.off()
    #}
    #p1 <- list(src=sprintf(filename,page),width=637.5,height=825)
    #return(list(src=sprintf(filename,page),width=637.5,height=825))
  
  }
