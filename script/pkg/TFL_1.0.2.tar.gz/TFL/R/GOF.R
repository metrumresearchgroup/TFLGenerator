GOF <-
	function(datFile, 
	         markBy=NULL, smooth=T, preserveMarkByLevels=F,
	         timeBy="TAFD", timeLimit=NULL, timeScale="identity", timeLab="Time (weeks)", timeFmt="comma",
	         concBy="DV", concLimit=NULL, concScale="log10", concLab="Observed Serum Concentration (ug/mL)", concFmt="comma",
	         predBy="PRED", predLimit=NULL, predScale="log10", predLab="Population Prediction (ug/mL)", predFmt="comma",
	         ipredBy="IPRED", ipredLimit=NULL, ipredScale="log10", ipredLab="Individual Prediction (ug/mL)", ipredFmt="comma",
	         cwresBy="CWRES", cwresLimit=NULL, cwresScale="identity", cwresLab="Conditional Weighted Residuals", cwresFmt="comma",
	         npdeBy="NPDE", npdeLimit=NULL, npdeScale="identity", npdeLab="NPDE", npdeFmt="comma",
					 Title="Goodness of Fit Plots", 
					 ...)
	{
		

	  drops <- sum(datFile$DV==0)
	  droplab <- paste(drops,"observations dropped with concentration of 0")
	  datFile <- datFile[datFile[,concBy]!=0,]
	  
	  if(!is.null(markBy)){
	    if(class(datFile[,markBy])!="factor") datFile[,markBy] <- factor(datFile[,markBy], sort(unique(datFile[,markBy])))
	  }
	  if(preserveMarkByLevels & !is.null(markBy)){
	    #if(Color){ cleanScales <- setColorScale(drop=F)} else {cleanScales <- setGrayScale(drop=F)}
	    cleanScales <- setColorScale(drop=F) 
	  }
	  
	  
	  
	  if(all(is.null(c(concLimit,predLimit,ipredLimit)))){
	    minc <- min(datFile[,c(concBy,predBy,ipredBy)])
	    maxc <- max(datFile[,c(concBy,predBy,ipredBy)])
	    predLimit <- concLimit <- ipredLimit <- c(minc,maxc)
	  }
	  
	  pList <- list()
	  
	  multiTheme <- theme(legend.position="none",plot.margin=unit(c(.5,1,.5,.5),units="cm"),
	                      axis.title.x=element_text(size=8),axis.title.y=element_text(size=8),
	                      axis.text=element_text(size=8))
	  
	  # Retry this when we move to new gridExtra
	  # if(is.null(markBy)){
	  #   multiTheme <- theme(legend.position="none",plot.margin=unit(c(.5,1,.5,.5),units="cm"),
	  #                       axis.title.x=element_text(size=10),axis.title.y=element_text(size=10))
	  # }else{
	  #   multiTheme <- theme(legend.position="top",plot.margin=unit(c(.5,1,.5,.5),units="cm"),
	  #                       axis.title.x=element_text(size=10),axis.title.y=element_text(size=10))
	  # }
	  
	  if(is.null(markBy)){
	    datFile$foo <- 1
	    markBy <- "foo"
	  }else{
	    if(class(datFile[,markBy])!="factor") datFile[,markBy] <- factor(datFile[,markBy])
	  }
	  
	  pList[[1]] <- ggplot(datFile, aes_string(x=predBy,y=concBy))+
	    geom_abline(aes(slope=1,intercept=0),colour="black") +
	    cleanTheme+
	    cleanScales+
	    scale_y_continuous(limits=concLimit, trans=concScale, labels=get(concFmt))+
	    scale_x_continuous(limits=predLimit, trans=predScale, labels=get(predFmt))+
	    labs(x=predLab,y=concLab)+
	    multiTheme

	  pList[[2]] <- ggplot(datFile, aes_string(x=ipredBy,y=concBy))+
	    geom_abline(aes(slope=1,intercept=0),colour="black")+
	    cleanTheme+
	    cleanScales+
	    scale_y_continuous(limits=concLimit, trans=concScale, labels=get(concFmt))+
	    scale_x_continuous(limits=ipredLimit, trans=ipredScale, labels=get(ipredFmt))+
	    labs(x=ipredLab,y=concLab)+
	    multiTheme
	  
	  pList[[3]] <- ggplot(datFile, aes_string(x=predBy,y=cwresBy))+
	    geom_hline(aes(yintercept=0),colour="black")+
	    cleanTheme+
	    cleanScales+
	    scale_x_continuous(limits=predLimit, trans=predScale, labels=get(predFmt))+
	    scale_y_continuous(limits=cwresLimit, trans=cwresScale, labels=get(cwresFmt))+
	    labs(x=predLab,y=cwresLab)+
	    multiTheme
	  
	  pList[[4]] <- ggplot(datFile, aes_string(x=timeBy,y=cwresBy))+
	    geom_hline(aes(yintercept=0),colour="black")+
	    cleanTheme+
	    cleanScales+
	    scale_x_continuous(limits=timeLimit, trans=timeScale, labels=get(timeFmt))+
	    scale_y_continuous(limits=cwresLimit, trans=cwresScale, labels=get(cwresFmt))+
	    labs(x=timeLab,y=cwresLab)+
	    multiTheme
	  
	  if(npdeBy %in% names(datFile)){
	    
	    pList[[5]] <- ggplot(datFile, aes_string(x=predBy,y=npdeBy))+
	      geom_hline(aes(yintercept=0),colour="black")+
	      cleanTheme+
	      cleanScales+
	      scale_y_continuous(limits=npdeLimit, trans=npdeScale, labels=get(npdeFmt))+
	      scale_x_continuous(limits=predLimit, trans=predScale, labels=get(predFmt))+
	      labs(y=npdeLab,x=predLab)+
	      multiTheme

	    pList[[6]] <- ggplot(datFile, aes_string(y=npdeBy,x=timeBy))+
	      geom_hline(aes(yintercept=0),colour="black")+
	      cleanTheme+
	      cleanScales+
	      scale_x_continuous(limits=timeLimit, trans=timeScale, labels=get(timeFmt))+
	      scale_y_continuous(limits=npdeLimit, trans=npdeScale, labels=get(npdeFmt))+
	      labs(x=timeLab,y=npdeLab)+
	      multiTheme
	    
	    
	  }
	  
	  if(markBy=="foo"){
	    for(i in 1:length(pList)) pList[[i]] <- pList[[i]] + geom_point(colour="grey40",shape=79)
	  }else{
	    for(i in 1:length(pList)) pList[[i]] <- pList[[i]] + geom_point(aes_string(colour=markBy,fill=markBy),shape=79)
	  }
	  if(smooth){
	    for(i in 1:length(pList)) pList[[i]] <- pList[[i]] + geom_smooth(method="loess",colour="red",se=F,lwd=1.5)
	  }	
	    

		# #Add in better ticks if the scale is log10.  This breaks it!!!
		# if ("log10" %in% as.character(concScale,predScale,ipredScale)){
		# 	p11=p11+annotation_logticks(, sides="lb", mid=unit(0.1, "cm"))
		# 	p12=p12+annotation_logticks(, sides="lb", mid=unit(0.1, "cm"))
		# 	p21=p21+annotation_logticks(, sides="b", mid=unit(0.1, "cm"))
		# }
	  
	  # for(i in 1:length(pList)) class(pList[[i]]) <- "ggplot"
	  # 
	  # if(length(pList)==6){
	  #   p1 <- arrangeGrob(pList[[1]],pList[[2]],pList[[3]],pList[[4]],pList[[5]],pList[[6]],ncol=2)
	  #   return(arrangeGrob(pList[[1]],pList[[2]],pList[[3]],pList[[4]],pList[[5]],pList[[6]],ncol=2))
	  # }
	  # if(length(pList)==4){
	  #   p1 <- arrangeGrob(pList[[1]],pList[[2]],pList[[3]],pList[[4]],ncol=2)
	  #   return(arrangeGrob(pList[[1]],pList[[2]],pList[[3]],pList[[4]],ncol=2))
	  # }
	  
	  
	  p1=list(pList,plotCols = 2,plotRows = 3)
	  return(p1)
	}
