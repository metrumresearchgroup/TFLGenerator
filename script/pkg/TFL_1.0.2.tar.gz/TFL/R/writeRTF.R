writeRTF=function(grobPath, ordering=NULL)
{
  library(rtf)

  fileName=gsub("Grob(s)*\\.rda", "Figures.doc", grobPath)
  # Get the versions of TFL and GUI
  guiv <- sessionInfo()$other[["GUI"]]$Version
  tflv <- sessionInfo()$other[["TFL"]]$Version

  rtf=RTF(fileName, width=8.5, height=11, font.size=12, omi=c(1,1,1,1))
  addHeader(rtf, title="Amgen GUI TFL Output", subtitle=sprintf("Produced on %s using the Pharmacometrics TFL Generator (R::GUI %s, R::TFL %s)",
                                                                Sys.Date(),guiv,tflv))

  addHeader(rtf, title="Preliminary Population Pharmacokinetic Analysis of <<matrix>>\nin <<subjects>> from Amgen Phase <<#>> Studies",
            subtitle="Authors:\n\nContributing Scientists:")

  if(!exists("guiGrobs")){
    loadGrobs(sprintf("%s_Grobs.rda", fileHead))
  }

  if(!is.null(ordering)) guiGrobs <- guiGrobs[ordering]

  for (n in c(1:length(guiGrobs))){
    htwd <- plotDims(guiGrobs[n])
    cat(file=stderr(), sprintf("LOG: Writing %s in RTF\n",names(guiGrobs)[n]))
    suppressWarnings(rm("f","file"))
    addPageBreak(rtf)
    if(n==1 | (guiGrobs[[n]]$Type!=guiGrobs[[max(n-1,1)]]$Type)){
      addHeader(rtf,guiGrobs[[n]]$Type,bold=TRUE,TOC.level=1,font.size=18)
      addPageBreak(rtf)
    }
    addHeader(rtf,guiGrobs[[n]]$LegendTitle,bold=TRUE,TOC.level=2)
    addNewLine(rtf, n=1)
    if("Legend" %in% names(guiGrobs[[n]])){
      if(str_trim(guiGrobs[[n]]$Legend)!="") addParagraph(rtf, guiGrobs[[n]]$Legend)
    }
    addNewLine(rtf, n=1)
    if(grepl("ExclusionsTab|ExclusionsSummaryTab",names(guiGrobs)[[n]])){
      if(!is.null(guiGrobs[[n]]$Plot$preview)){
        obj <- guiGrobs[[n]]$Plot$preview
      }else{
        obj <- guiGrobs[[n]]$Plot
      }

      if("message" %in% names(guiGrobs[[n]]$Plot)){
        # Observation and Exclusion listings
        if(guiGrobs[[n]]$Plot$message != "SUCCESS"){
          addText(rtf,guiGrobs[[n]]$Plot$message)
        }else{
          addTable(rtf, obj, col.justify="L",header.col.justify="C",
                   font.size=11,row.names=F,NA.string="")
        }
      }else{
        addTable(rtf, obj, col.justify="L",header.col.justify="C",
                 font.size=11,row.names=F,NA.string="")
      }
      if("Footnote" %in% names(guiGrobs[[n]])){
        addText(rtf,"Note:",bold=T,italic=T)
        addText(rtf,guiGrobs[[n]]$Footnote, italic=T)
      }
    }else if(grepl("Tab|inputFigure|inputListing[[:digit:]]",names(guiGrobs)[n])){
      file <- ifelse(grepl("inputTab|inputFigure|inputListing[[:digit:]]",names(guiGrobs)[n]), guiGrobs[[n]]$Plot, guiGrobs[[n]]$Plot$src)
      addPng(rtf, file, width=htwd$width, height=htwd$height, res=300)
      if(grepl("inputFigure|inputListing|inputTable[[:digit:]]",names(guiGrobs[n]))){
        # Here we use plain text footnotes
        if("Footnote" %in% names(guiGrobs[[n]])){
          addText(rtf,"Note:",bold=T,italic=T)
          addText(rtf,guiGrobs[[n]]$Footnote, italic=T)
        }
      }
    # }else if (grepl("ConcvTimeMult",names(guiGrobs)[n])){
    #   for(f in 1:length(guiGrobs[n][[1]]$Plot)){
    #     addPlot(rtf, plot.fun=pListPrint,width=htwd$width,height=htwd$height,res=300, guiGrobs[n][[1]]$Plot[[f]])
    #     if("Footnote" %in% names(guiGrobs[[n]])){
    #       addText(rtf,"Note:",bold=T,italic=T)
    #       addText(rtf,guiGrobs[[n]]$Footnote, italic=T)
    #     }
    #     addPageBreak(rtf)
    #   }
    } else if(grepl('inputListing|inputFile',names(guiGrobs)[n])){
      if("longText"%in%names(guiGrobs[[n]])){
        startParagraph(rtf)
        for(i in 1:length(guiGrobs[[n]]$longText)){
          addText(rtf, guiGrobs[[n]]$longText[i])
          addNewLine(rtf)
        }
        endParagraph(rtf)
        if("Footnote" %in% names(guiGrobs[[n]])){
          addText(rtf,"Note:",bold=T,italic=T)
          addText(rtf,guiGrobs[[n]]$Footnote, italic=T)
        }
      }
    } else{
      # if(length(setdiff(c("pList", "plotCols", "plotRows"),names(guiGrobs[[n]]$Plot)))==0){
      #   # browser()
      #   p <- grid.grabExpr(pListPrint(guiGrobs[[n]]$Plot),wrap=T)
      #   addPlot(rtf, plot.fun=grid.draw,width=htwd$width,height=htwd$height,res=300, p)
      # }
      # addPlot(rtf, plot.fun=pListPrint,width=htwd$width,height=htwd$height,res=300, guiGrobs[[n]]$Plot[[1]])
      file <- grep(names(guiGrobs)[n],list.files(file.path(dirname(grobPath),"PNG"),full.names=T),value=T)
      for(f in file){
        addPng(rtf, f, width=htwd$width, height=htwd$height, res=300)
        if("Footnote" %in% names(guiGrobs[[n]])){
          addText(rtf,"Note: ",bold=T,italic=T)
          addText(rtf,guiGrobs[[n]]$Footnote, italic=T)
        }
      }
    }
    #addPageBreak(rtf)
    rm(htwd)
    cat(file=stderr(), sprintf("LOG: Done writing %s in RTF\n",names(guiGrobs)[n]))

  }
  done(rtf)
  cat(file=stderr(), "LOG: Exiting WriteRTF function\n")
}
