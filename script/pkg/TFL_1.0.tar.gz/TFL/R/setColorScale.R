setColorScale <-
	function(fillList=NULL, shapeList=NULL, lineList=NULL, colourList=NULL){
	
		fillList=fillList %||% colorPalette
		shapeList=shapeList %||% shapesPalette
		lineList=lineList %||% colorlinePalette
		colourList=colourList	%||% colorPalette
		
		return(list(scale_fill_manual(values=fillList), 
								scale_shape_manual(values=shapeList), 
								scale_linetype_manual(values=lineList),
								scale_colour_manual(values=colourList))					 
	)
}
