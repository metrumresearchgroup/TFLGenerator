QQplot=function(
					datFile,  xBy="ETA1",
					 groupBy=NULL,
					 markBy=NULL,
					 xLimit=NULL, yLimit=NULL,
					 xForm=waiver(), yForm=waiver(),
					 xScale="identity", yScale="identity", 
						Title="",
						xLab='sprintf("Theoretical %s", xBy)',
						yLab='sprintf("Observed %s", xBy)',
					 facetBy="",
					 ...)
	{
	
	
		p1=
			ggplot(datFile, aes_string(sample=xBy, group=groupBy, color=markBy, lty=markBy))	+
			cleanScales+
			cleanTheme+
			scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
			scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
			stat_qq(na.rm=TRUE)+
			stat_qqline()+
			labs(title=eval(parse(text=Title)), x=eval(parse(text=xLab)), y=eval(parse(text=yLab)))
		
		#Add in the faceting if it exists
		if (facetBy!=""){
			p1=p1 +facet_wrap(as.formula(paste("~", facetBy)))
		}
		
		return(p1)
		
	}