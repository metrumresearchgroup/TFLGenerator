library(testit)
test_pkg('animation')
