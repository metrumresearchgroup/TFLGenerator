#' @title qqplot line
#' @description given data and a theoretical quantile function, find the comparison
#' line between quantiles of theoretical and data
#' @param data data.frame, contains data needed to output a quantile line
#' @param qf function, quantiles for a probability
#' @param na.rm boolean, remove missing
#' @export
#' @importFrom stats quantile

qq_line <- function(data, qf, na.rm) {
  # from stackoverflow.com/a/4357932/1346276
  q.sample <- stats::quantile(data, c(0.25, 0.75), na.rm = na.rm)
  q.theory <- qf(c(0.25, 0.75))
  slope <- diff(q.sample) / diff(q.theory)
  intercept <- q.sample[1] - slope * q.theory[1]
  
  list(slope = slope, intercept = intercept)
}