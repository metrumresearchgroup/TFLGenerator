#' @title Creates a confidence interval around a prediction interval
#' @param ciVar numeric, numerical vector to predict confidence interval
#' @param ci numeric, confidence around the prediction intervals
#' @param type character, Returns the upper or lower value c("high","low"), Default: 'low'
#' @details This function serves as an internal bootstrap function for VPC() and requires f.quantile()
#' @export
#' @importFrom stats quantile
#' 
ci.meanSim <-
function(ciVar, ci, type="low") {
	if(type=="low"){n=ci+(1-ci)/2}
	if(type=="high"){n=(1-ci)/2}
	temp=stats::quantile(ciVar, probs=n, na.rm=TRUE, names=FALSE)
	if(is.null(temp)){temp=mean(ciVar)}
	return(temp)
}
