#' @title mrgFootnote
#' @description \code{mrgFootnote} concatonates a caption to a ggplot
#' @param p gg, ggplot object
#' @param srcName character, source script name, Default: 'script'
#' @param srcPath character, source script path, Default: '.'
#' @param figName character, Output figure name, Default: 'Rplot'
#' @param figPath character, Output figure path, Default: '../deliv/figure'
#' @examples
#' data("twoCmt")
#' p=ggplot(twoCmt,aes(x=DV,y=IPRED))+geom_point()
#' p%>%mrgFootnote()
#' @return A barchart ggplot2 object of class \code{TFL} which can be plotted or 
#' printed with the corresponding method. 
#' @export
#' @import ggplot2
mrgFootnote=function(p,srcName='script',srcPath='.',figName="Rplot",figPath="../deliv/figure"){
  
  figSplit=unlist(strsplit(figName,'[.]'))
  figName=figSplit[1]
  figExt='pdf'
  if(length(figSplit)==2) figExt=figSplit[2]
  
  srcLab=sprintf('Source code: %s/%s.R',srcPath,srcName)
  figLab=sprintf('Source graphic: %s/%s.%s',figPath,figName,figExt)
  
  p=p+ggplot2::labs(caption=paste('',srcLab,figLab,sep='\n'))+
    ggplot2::theme (plot.caption=ggplot2::element_text(hjust=0, #horizontal position
                                     vjust=0.5, #vertical position
                                     margin=ggplot2::margin(t=10,r=10,b=10,l=10) #padding around text
    )
    )
  p
}