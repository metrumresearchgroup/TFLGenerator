#' @title print method for most TFL package generated plots
#' @description arrange x into plots and columns using the print method
#' @param x ggplot object or list of ggplot objects
#' @param ... parameters to pass to grid (see details)
#' @details srcAdd, plotCols, plotRows, srcPath, srcName, figPath, figName
#' @export
#' @importFrom grid grid.newpage pushViewport viewport grid.layout


print.TFL=function(x,...){

  dots=list(...)
  list2env(dots,envir = environment())
  if(!exists('srcAdd')) srcAdd=FALSE
  if(!exists('plotCols')) plotCols=NULL
  if(!exists('plotRows')) plotRows=NULL
  if(!exists('srcPath')) srcPath='.'
  if(!exists('srcName')) srcName='script'
  if(!exists('figPath')) figPath="../deliv/figure"
  if(!exists('figName')) figName="Rplot.pdf"
  
  list2env(x,envir = environment())

  numPlots = length(pList)
  if(is.null(plotCols)||is.null(plotRows)){
    cols=min(numPlots,2)
    plotCols = cols                      
    plotRows = ceiling(numPlots/plotCols)
  }
  if(numPlots > plotCols*plotRows){
    if(plotCols<plotRows){
      plotCols <- ceiling(numPlots/plotRows)
    }else{
      plotRows <- ceiling(numPlots/plotCols)
    }
  }

  grid::grid.newpage()
  grid::pushViewport(grid::viewport(layout = grid::grid.layout(plotRows,plotCols)))
  for (i in 1:numPlots) {
    curRow = ceiling(i/plotCols)
    curCol = (i-1) %% plotCols + 1
    if(srcAdd){
      if(curRow==plotRows&curCol==1){
        pList[[i]]=pList[[i]]%>%mrgFootnote(srcName,srcPath,figName,figPath)
      }else{
        pList[[i]]=pList[[i]]+labs(caption=" \n \n \n")
        }
    }
    print(pList[[i]], vp = vplayout(curRow, curCol ))
  }
}