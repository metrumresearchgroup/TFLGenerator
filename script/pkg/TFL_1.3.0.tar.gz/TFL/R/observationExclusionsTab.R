#' @title Listing of excluded observations
#' @description Listing of excluded observations
#' @param catList list of two element vectors giving the column name and rename
#' of variables to list in the table
#' @details Requires presence of an "observationExclusions" table in the global
#' environment, as done by the GUI. Not intended (at the moment) to be run from
#' outside of the GUI.
#' @export
#' @importFrom rtf RTF addTable done
#' @importFrom metrumrg reapply map
#' @importFrom utils write.csv

observationExclusionsTab <-
	function(
	  catList=list(c("STUDY","Study"),c("DOSE","Dose")),
	  tmpDir = NULL
	)
		{ 
	  if(is.null(tmpDir)){
	    tmpDir <- tempdir()
	    dir.create(tmpDir,recursive = T)
	  }else{
	    if(!dir.exists(tmpDir)){
	      return()
	    }
	  }
	  
	  if(catList!=""){
	    if(class(catList)!="list"){
	      catList <- list(catList)
	    }
	    
	    cats=sapply(catList, function(x){x[[1]][1]})
	    catlabs=sapply(catList, function(x){x[[2]][1]})
	  }else{
	    cats <- NULL
	    catlabs <- NULL
	  }

		datFile <- try(observationExclusions)
		if(class(datFile)=="try-error") get("observationExclusions",.GlobalEnv)
		datFile <- datFile[,unique(c("excl_reasons","NMID","TAFD",cats))]
		datFile <- datFile[!duplicated(datFile),]
		datFile <- sort_df(datFile)
		N <- metrumrg::reapply(datFile$TAFD,
		             datFile[,"excl_reasons"],
		             length
		)

		datFile$excl_reasons <- paste(datFile$excl_reasons, paste0("(N=",N,")"))
		datFile$excl_reasons <- metrumrg::reapply(datFile$excl_reasons,
		                               datFile[,"excl_reasons"],
		                               function(x) c(x[1],rep("",length(x)-1))
		)
		names(datFile) <- metrumrg::map(names(datFile), 
		                      from=c("excl_reasons",cats,"NMID","TAFD"),
		                      to=c("Reason for exclusion", catlabs, "ID","TIME"))

		if(nrow(datFile) <= 500){
		  f <- file.path(tmpDir,"observationExclusions.doc")
		  rtf <- rtf::RTF(f,font.size=11)
		  rtf::addTable(rtf,datFile)
		  rtf::done(rtf)
		  message <- "SUCCESS"
		}else{
		  f <- file.path(tmpDir,"observationExclusions.csv")
		  utils::write.csv(datFile,file=f,row.names=F)
		  message <- paste0("Too many exclusions (n=", nrow(datFile), ") to create doc file.  Data dumped to PNG/",basename(f))
		}

		p1 <- datFile
		return(list(preview=datFile, file=f, message=message))
		
	}
