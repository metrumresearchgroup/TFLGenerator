#' @title Parses the ouptut XML from Nonmem 
#' @description Simplified version of stripXML(), does not require proper control stream documentation
#' @usage presentXML(run, type = "covariance_information", project = getwd(), visualize = FALSE)
#' @param run character run number
#' @param type character indicating the type of information to be accessed
#' @param project string indicating home directory of the Nonmem Run defaults to the current working directory
#' @details type can be: 
#' "parallel_est"                  "table_series"             "estimation_method"              "estimation_title" 
#' "monitor"            "termination_status"       "termination_information"                        "etabar" 
#'  "etabarse"                    "etabarpval"                     "etashrink"                     "epsshrink" 
#' "estimation_elapsed_time"        "covariance_information"             "covariance_status"       "covariance_elapsed_time" 
#' "final_objective_function_text"      "final_objective_function"                         "theta"                         "omega" 
#' "sigma"                        "omegac"                        "sigmac"                       "thetase" 
#' "omegase"                       "sigmase"                      "omegacse"                      "sigmacse" 
#' "covariance"                   "correlation"                 "invcovariance"                   "eigenvalues" 
#' @return Output returns a data.frame and a grob
#' @examples 
#' writeLines(presentXML(run = '0069',type="final_objective_function",project=system.file('external',package = 'TFL')))
#' @export
#' @importFrom XML xmlTreeParse xmlValue
#' @importFrom Hmisc capitalize
#' @importFrom gridExtra grid.arrange tableGrob
#' @importFrom grid gpar
#' 
presentXML=function(run, type="covariance_information", project=getwd(), visualize=FALSE, est="max"){
	#Written by vplatt 12/1/2013
	#Function parses the ouptut XML from nonmem.  Output _returns_ a data.frame and prints a grob table
	#est can be "max" (for only the last run) or, "all" for all estimation steps, or the number of the estimation step
	# type can be:
	# "parallel_est"                  "table_series"             "estimation_method"              "estimation_title" 
	# "monitor"            "termination_status"       "termination_information"                        "etabar" 
	#  "etabarse"                    "etabarpval"                     "etashrink"                     "epsshrink" 
	# "estimation_elapsed_time"        "covariance_information"             "covariance_status"       "covariance_elapsed_time" 
	# "final_objective_function_text"      "final_objective_function"                         "theta"                         "omega" 
	# "sigma"                        "omegac"                        "sigmac"                       "thetase" 
	# "omegase"                       "sigmase"                      "omegacse"                      "sigmacse" 
	# "covariance"                   "correlation"                 "invcovariance"                   "eigenvalues" 
	
	
	

	foo=XML::xmlTreeParse(sprintf("%s/%s/%s.xml", project, run, run), useInternalNodes=FALSE)
	foo=foo$doc$children[["output"]]

	
	
	#A way to parse the nonmem output
	nm=foo[["nonmem"]][["problem"]]
	#choose the last estimation step
	if(est=="max") {nm=nm[[max(grep("estimation", names(nm)))]]}
	if(suppressWarnings(!is.na(as.numeric(est)))){nm=nm[[est]]}
	if(est=="all") {nm=nm[grep("estimation", names(nm))]}
	prob=XML::xmlValue(nm[["problem_title"]])
	
	intTab=nm[[type]]
	namesForRows=sapply(c(1:length(intTab)), FUN=function(i) intTab[[i]]$attr)
	test=unique(names(namesForRows))
	
	if(length(test)==0 & !type %in% c("start_datetime", "stop_datetime", "nmtran")){return(XML::xmlValue(intTab))}
	
	if(length(test)>0){
	if(!test %in% c("rname", "name")){fooMat=intTab}
	
	if (test=="name"){
		fooMat=data.frame(matrix(nrow=length(namesForRows), ncol=1), row.names=paste(capitalize(type), namesForRows))
		names(fooMat)=Hmisc::capitalize(type)
		for (j in c(1:length(intTab))){
			nowVal=signif(as.numeric(xmlValue(intTab[j]$val)), digits=3)
			name=as.character(intTab[j]$val)[2]
			fooMat[paste(Hmisc::capitalize(type), name),1]=nowVal	
		}
	}
	
	if (test=="rname") {
		
		fooMat=data.frame(matrix(nrow=length(namesForRows), ncol=length(namesForRows)), row.names=namesForRows) 
		names(fooMat)=namesForRows
		
		for (i in c(1:length(intTab))){
			foo=intTab[[i]]
			rname=foo$attr
			for (j in c(1:length(foo))){
				nowVal=signif(as.numeric(xmlValue(foo[j]$col)), digits=3)
				cname=as.character(foo[j]$col)[2]
				fooMat[rname, cname]=nowVal
			}
		}
		
		fooMat=data.frame(apply(fooMat, c(1,2), as.numeric),stringsAsFactors=FALSE, check.names=FALSE)
		
		idx=rowSums(fooMat, na.rm=TRUE)!=0
		idn=colSums(fooMat, na.rm=TRUE)!=0
		
		fooMat=fooMat[which(idx),which(idn)]
		fooMat[is.na(fooMat)]=""
		
		#check if the row names are numeric only
		if (length(grep("^[[:digit:]]*$", namesForRows))==length(namesForRows)) {
			row.names(fooMat)=paste(Hmisc::capitalize(type), row.names(fooMat))
			colnames(fooMat)=paste(Hmisc::capitalize(type), colnames(fooMat))
		}
		
		fooMat=data.frame(fooMat, check.names=FALSE)
		if (dim(fooMat)[2]==1) {names(fooMat)=type}
	}
	
	if(row.names(fooMat)[1]=="SUBPOP1"){row.names(fooMat)=type}
	
	if(visualize){
	  gridExtra::grid.arrange(gridExtra::tableGrob(fooMat, show.rownames=TRUE, show.colnames=TRUE, show.namesep=TRUE, 
													 gpar.coltext=grid::gpar(fontsize=16), 
													 gpar.corefill = grid::gpar(fill = "dodgerblue2", col = "white"),
													 gpar.rowfill=grid::gpar(fill = "dodgerblue2", col = "white"), 
													 gpar.colfill=grid::gpar(fill = "dodgerblue2", col = "white"),
													 h.odd.alpha=.1,
													 h.even.alpha=.4,
													 separator="black"), main=type)
	}
	return(fooMat)
	}
	
	if(type %in% c("start_datetime", "stop_datetime", "nmtran")){
		
		return(XML::xmlValue(foo[[type]]))
		
	}
}
