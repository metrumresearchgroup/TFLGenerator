#' @title VPC plot
#' @description Plot a VPC, allowing for prediction correction as well as a 
#' variety of types
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param yByObs character, Column name in \code{datFile} corresponding to the observed DV, Default: 'DVobs'
#' @param predVar character, Column name containing the conditional prediction, Default: 'DV'
#' @param xBy character, Column name for X-axis, Default: 'TAFD'
#' @param markBy character, column name on which to mark by different colors, Default: ''
#' @param xLimit numeric, Two element vector giving the lower and upper limits of the X-axis, Default: NULL
#' @param yLimit numeric, Two element vector giving the lower and upper limits of the Y-axis, Default: NULL
#' @param xForm function|character,  Format of the X-axis variable tick label, Default: ggplot2::waiver()
#' @param yForm function|character,  Format of the Y-axis variable tick label, Default: ggplot2::waiver()
#' @param xScale function|character,  Scale transformtion for the X-axis variable, Default: 'identity'
#' @param yScale function|character,  Scale transformtion for the Y-axis variable, Default: 'log10'
#' @param minorTicks character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created, Default: NULL
#' @param minorTickNum integer, number of minor ticks between major ticks, Default: 10
#' @param Title character, Figure title, Default: ''
#' @param xLab character, Label of X-axis, Default: 'Time'
#' @param yLab character, Label of Y-axis, Default: 'PK Concentration'
#' @param PI numeric, prediction interval quantiles, Default: c(0.1, 0.5, 0.9)
#' @param ci numeric, confidence around the prediction intervals, Default: 0.95
#' @param PIns numeric, prediction interval quantiles when using "no shading" for shading type, Default: c(0.1, 0.5, 0.9)
#' @param ciPM numeric, confidence interval when using predicted median CI for shading, Default: 0.95
#' @param includeCI boolean, Adds confidence interval ribbon to the plot, Default: FALSE
#' @param facetBy character, column name for figure faceting, Default: ''
#' @param fF character, Labels for the facet levels in the form "Level1,Label1;Level2,Label2", Default: ''
#' @param fnrow integer, Number of rows passed to facet_wrap, Default: NULL
#' @param fscales character, Scale type for facet_wrap c("fixed","free","free_y","free_x"), Default: 'fixed'
#' @param doseCol character, column name of dosing information, used if doseCol=TRUE, Default: 'DOSE'
#' @param doseCor boolean, apply dose correction, Default: FALSE
#' @param predCol character, Column name containing population prediction, Default: 'PRED'
#' @param predCor boolean, Population prediction correction, Default: FALSE
#' @param lowerBound numeric, lower bound for y axis, Default: 0
#' @param simCol character, column name that holds the simulation replicate number, Default: NULL
#' @param smoothed boolean, apply smooth interpolation Default: TRUE
#' @param binned boolean, bins the x axis values, Default: TRUE
#' @param binBy integer, how many bins to split by, Default: 7
#' @param smoothLevel numeric, confidence level in smoother ci, Default: 0.8
#' @param tryFormula PARAM_DESCRIPTION, Default: 'y~x'
#' @param BQLlevel numeric, level of BQL from which to remove, Default: 10
#' @param BQLmethod character, method to apply BQL, Default: 'retain'
#' @param shadingType character, Shading type to create c("predicted median", "simulated percentiles", "no shading"), Default: 'simulated percentiles'
#' @param shadingTypeShape character, Shading shape to create c("Each Percentile",NULL), Default: 'Each Percentile'
#' @param showObs boolean, show observations, Default: TRUE
#' @param label character, PARAM_DESCRIPTION, Default: ''
#' @param includeAddl_pts boolean, add geom_point layer from addl data.frame, Default: FALSE
#' @param includeAddl_trend boolean, add trendline from Addl data.frame, Default: FALSE
#' @param addlLabel character, PARAM_DESCRIPTION, Default: ''
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param themePlotLegendPosition character, legend position, Default: 'right'
#' @param ... 
#' @export
#' @import dplyr
#' @import ggplot2
#' @importFrom plyr dlply
#' @importFrom reshape2 melt dcast
VPC <-
  function(datFile, yByObs="DVobs", predVar="DV", xBy="TAFD",
           markBy="",
           xLimit=NULL, yLimit=NULL,
           xForm=ggplot2::waiver(), yForm=ggplot2::waiver(),
           xScale="identity", yScale="log10", 
           minorTicks=NULL,minorTickNum=10,
           Title="", xLab="Time", yLab="PK Concentration",
           PI=c(0.1, 0.5, 0.9), 
           ci=0.95, 
           PIns=c(0.1, 0.5, 0.9), 
           ciPM=0.95, 
           includeCI=FALSE,
           facetBy="", fF="",fnrow=NULL,fscales="fixed",
           doseCol="DOSE", doseCor=FALSE,
           predCol="PRED", predCor=FALSE, lowerBound=0,
           simCol=NULL,
           smoothed=TRUE, binned=TRUE, binBy=7,
           smoothLevel=.8, tryFormula="y~x",
           BQLlevel=10, BQLmethod="retain",
           shadingType="simulated percentiles",
           shadingTypeShape="Each Percentile",
           showObs=TRUE,
           label="", includeAddl_pts=FALSE, includeAddl_trend=FALSE,  addlLabel="",
           themeUpdate=list(),
           themeTextSize=14,
           themePlotTitleSize=1.2,
           themeAxisTxtSize=0.8,
           themeAxisTxtColour='black',
           themeAxisTitleTxtSize=0.9,
           themeAxisTitleColour='black',
           themePanelBackgroundFill='white',
           themePanelGridSize=NULL,
           themePanelGridColour='white',
           themePanelLineType=1,
           themePanelTitleSize=1.2,
           themePlotTitleColour='black',
           themePlotLegendPosition='right',
           ...) 	{
    
    cat(file=stderr(), paste0("LOG: ", Sys.time(), " Running VPC\n"))
    
    # Worker function ----
    VPCfun <- function(){
      # Commented out, using dplyr instead
      # # Set up parallel backend
      # cl <- makeCluster(8)
      # # registerDoParallel(8)
      # registerDoParallel(cl)
      # lp <- installed.packages()["TFL","LibPath"]
      # clusterCall(cl, fun=function(x) .libPaths(lp))
      # on.exit(stopCluster(cl))    
      logTrans <- grepl("log",yScale)
      
      if(addlLabel=="") addlLabel <- NULL
      if(label=="") label <- NULL
      if("addl" %in% names(datFile)){
        if(class(datFile$addl)!="try-error") addl <- as.data.frame(datFile$addl)
      }
      
      if(!(includeAddl_pts|includeAddl_trend)){
        addLabel <- NULL
        addl <- NULL
      }
      
      if("vpc" %in% names(datFile)) datFile <- as.data.frame(datFile$vpc)
      if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
      
      if(facetBy!="" & all(fF!="")){
        datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
        if(!is.null(addl)){
          addl[,facetBy] <- factor(addl[,facetBy],fF[,1],fF[,2])
        }
      }

      if(shadingType=='predicted median') ci=ciPM
      if(shadingType=='no shading') PI=PIns
      
      
      
      if(ci > 1) ci <- as.numeric(ci)/100
      
      BQLlevel <- as.numeric(BQLlevel)
      
      if(tolower(BQLmethod) %in% c("drop")){
        datFile[which(datFile[,yByObs]<=BQLlevel),yByObs] <- NA
        datFile[which(datFile[,predVar]<=BQLlevel),predVar]=NA
        if(predCol %in% names(datFile)) datFile[which(datFile[,predCol]<=BQLlevel),predCol]=NA
        if(!is.null(addl)){
          addl[which(addl[,yByObs]<=BQLlevel),yByObs] <- NA
          if(predCol %in% names(addl)) addl[which(addl[,predCol]<=BQLlevel),predCol]=NA
        }
      }
      
      # if(tolower(BQLmethod) %in% c("none")){
      #   datFile=datFile[which(datFile[,yByObs]>=BQLlevel),]
      # }
      
      
      if(doseCor){
        datFile[,yByObs]=datFile[,yByObs]/datFile[,doseCol]
        datFile[,predVar]=datFile[,predVar]/datFile[,doseCol]
        if(predCol %in% names(datFile)) datFile[,predCol]=datFile[,predCol]/datFile[,doseCol]
        if(!is.null(addl)){
          addl[,yByObs]=addl[,yByObs]/addl[,doseCol]
          if(predCol %in% names(addl)) addl[,predCol]=addl[,predCol]/addl[,doseCol]
        }
      }
      
      if(binned){
        if(length(binBy)>1){
          breaks <- binBy
        }else{
          breaks=seq(0, max(datFile[,xBy])+binBy, by=binBy)
        }
        labels=as.numeric(breaks)
        labels=diff(labels)/2 + labels[-length(labels)]
        # labels=labels[-length(labels)]
        
        datFile[,paste(xBy,"bin", sep="")]=cut(unlist(datFile[,xBy]), breaks=breaks, labels=labels, include.lowest=TRUE )
        datFile[,paste(xBy,"bin", sep="")]=as.numeric(as.character(unlist(datFile[,paste(xBy,"bin", sep="")])))
        
        if(!is.null(addl)){
          if(xBy %in% names(addl)){
            addl[,paste(xBy,"bin", sep="")]=cut(unlist(addl[,xBy]), breaks=breaks, labels=labels, include.lowest=TRUE )
            addl[,paste(xBy,"bin", sep="")]=as.numeric(as.character(unlist(addl[,paste(xBy,"bin", sep="")])))
          }
        }
      }
      
      if(predCor & binned){
        for(item in unique(datFile[,paste(xBy,"bin", sep="")])){
          if(!logTrans){
            datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
              lowerBound+
              (datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]- lowerBound)*
              (
                (mean(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol], na.rm=TRUE)-lowerBound)
                /
                  (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]-lowerBound)
              )
            if(!is.null(addl)){
              if(predCol %in% names(addl)){
                addl[addl[,paste(xBy,"bin", sep="")]==item,yByObs]=
                  lowerBound+
                  (addl[addl[,paste(xBy,"bin", sep="")]==item,yByObs]- lowerBound)*
                  (
                    (mean(addl[addl[,paste(xBy,"bin", sep="")]==item,predCol], na.rm=TRUE)-lowerBound)
                    /
                      (addl[addl[,paste(xBy,"bin", sep="")]==item,predCol]-lowerBound)
                  )
              }else{
                cat(file=stderr(), "LOG: No population prediction column for addl data!\n")
                addl <- NULL
              }
            }
          }
          
          
          
          if(logTrans){
            base <- ifelse(yScale=="log10",10,exp(1))
            datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
              datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar]=
              (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar])+
              (
                log(mean(exp(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]), na.rm=TRUE),base=base)
                /
                  datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]
              )
            if(!is.null(addl)){
              if(predCol%in%names(addl)){
                datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
                  datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar]=
                  (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar])+
                  (
                    log(mean(exp(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]), na.rm=TRUE),base=base)
                    /
                      datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]
                  )
              }else{
                cat(file=stderr(), "LOG: No population prediction column for addl data!\n")
                addl <- NULL
              }
            }
          }
        }	
      }
      
      if(markBy=="") markBy <- NULL
      groupBy=unique(c(facetBy,markBy,xBy, simCol))
      if(binned){groupBy=unique(c(facetBy,markBy,paste(xBy,"bin", sep=""), simCol))}
      groupBy=groupBy[nchar(groupBy)>0]
      
      
      
      #Create a Summary Table of observed including a loess smooth model
      fooSum=vpcSE(data=datFile[datFile[,simCol]==1,], xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy),  measurevar=yByObs, groupvars=groupBy,
                   na.rm=TRUE, pred.interval=PI/100, ci=ci,.drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                   simCol=simCol, shadingType=shadingType,
                   smoothed=smoothed, smoothLevel=smoothLevel)
      fooSum[,simCol] <- NULL
      

      #Create a Summary Table of the sim data including a loess smooth model
      fooSumPred=vpcSE(data=datFile, xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy), measurevar=predVar, groupvars=groupBy,
                       na.rm=TRUE, pred.interval=PI/100, ci=ci, .drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                       simCol=simCol, shadingType=shadingType,
                       smoothed=smoothed, smoothLevel=smoothLevel)
      
      foo=merge(fooSum, fooSumPred, all=TRUE)
      #test=merge(datFile, foo)
      
      if(!is.null(addl)){
        if(!simCol %in% names(addl)) addl[,simCol] <- 1
        fooSumaddl=vpcSE(data=addl[addl[,simCol]==1,],xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy),  measurevar=yByObs,
                         groupvars=setdiff(groupBy,simCol),
                         na.rm=TRUE, pred.interval=PI/100, ci=ci,.drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                         simCol=simCol, shadingType=shadingType,
                         smoothed=smoothed, smoothLevel=smoothLevel)
        fooSumaddl[,"N"] <- NULL
        fooSumaddl <- reshape2::melt(as.data.frame(fooSumaddl), id.vars=setdiff(groupBy,simCol))
        fooSumaddl$op <- "observed"
        fooSumaddl$lab <- ifelse(is.null(addlLabel), "additional", addlLabel)
      }
      
      obs <- datFile[datFile[,simCol]==min(datFile[,simCol]),]
      these <- c(xBy,groupBy,yByObs)[c(xBy,groupBy,yByObs) %in% names(obs)]
      obs <- obs[,these]
      obs <- reshape2::melt(obs, id.vars=setdiff(these,yByObs))
      obs[,simCol] <- NULL
      
      if(!is.null(addl)){
        these <- which(names(addl) %in% c(xBy,groupBy,yByObs))
        addl <- addl[,these]
        addl <- reshape2::melt(addl, id.vars=setdiff(names(addl),yByObs))
        addl$op <- "observed"
        addl$lab <- ifelse(is.null(addlLabel), "additional", addlLabel)
      }
      
      summ <- foo[,c(setdiff(groupBy,simCol),
                     setdiff(grep(predVar,names(foo),value=T),
                             c(predVar)
                     ))]
      summ <- reshape2::melt(summ, id.vars=setdiff(groupBy,simCol))
      summ$op <- ifelse(grepl(yByObs,summ$variable),"observed","predicted")
      
      #Add in better ticks if the scale is log10
      if (logTrans){
        obs <- obs[ !is.na(obs$value), ]
        obs <- obs[ obs$value>0, ]
        summ <- summ[ summ$value>0, ]
        if(!is.null(addl)){
          addl <- addl[ !is.na(addl$value), ]
          addl <- addl[ addl$value>0, ]
        }
      }
      obs$op <- "observed"
      obs$lab <- ifelse(is.null(label), "original", label)
      summ$lab <- ifelse(is.null(label), "original", label)
      
      if(length(unique(summ[,markBy]))>1){
        obs$lab <- sprintf("%s (%s=%s)",obs$lab,markBy,as.character(obs[,markBy]))
        summ$lab <- sprintf("%s (%s=%s)",summ$lab,markBy,as.character(summ[,markBy]))
        if(!is.null(addl)){
            fooSumaddl$lab <- sprintf("%s (%s=%s)",fooSumaddl$lab,markBy,as.character(fooSumaddl[,markBy]))
        }
      }
      
      summ$variable <- gsub(paste0(yByObs,"q"),"",summ$variable)
      summ$variable <- gsub(paste0(predVar,"q"),"",summ$variable)
      summ <- cast(summ)
      if(!is.null(addl)){
        fooSumaddl$variable <- gsub(paste0(yByObs,"q"),"",fooSumaddl$variable)
        fooSumaddl$variable <- gsub(paste0(predVar,"q"),"",fooSumaddl$variable)
        addlSum <- reshape2::dcast(fooSumaddl)
      }
      
      
      
      summ1=summ%>%
        reshape2::melt(.id=1:(which(names(summ)=="HighHigh")-1))%>%
        dplyr::filter(!is.na(value))%>%dplyr::rename(summ.val=value,summ.var=variable)
      summ2=summ1%>%dplyr::select(summ.var)%>%dplyr::distinct()
      summ2$idx2=unlist(lapply(gregexpr('[A-Z]',summ2$summ.var),function(x) as.numeric(x)[2]-1))
      summ2$RibbonType=substr(summ2$summ.var,start = 1,stop=summ2$idx2)
      summ2$RibbonVal=substr(summ2$summ.var,start=summ2$idx2+1,stop = 10)
      
      summ3=summ1%>%dplyr::left_join(summ2%>%dplyr::select(-idx2),by=c('summ.var'))
      
      obs1=obs%>%dplyr::rename(yobs=value)
      
      eqRibb=as.formula(paste(paste0(names(summ3)[!names(summ3)%in%c('summ.var','summ.val','RibbonVal')],collapse='+'),'RibbonVal',sep="~"))
      eqRibbBetween=as.formula(paste(paste0(names(summ3)[!names(summ3)%in%c('RibbonType','summ.val','RibbonVal','summ.var')],collapse='+'),'summ.var',sep="~"))
      
     
      
      ribb=summ3%>%
        dplyr::filter(op=='predicted')%>%
        reshape2::dcast(eqRibb,value.var = 'summ.val')%>%
        dplyr::rename(variable=RibbonType,ymax=High,ymin=Low,ymid=Mid)
      
      ribbBetween=summ3%>%
        dplyr::filter(op=='predicted'&summ.var%in%c('HighLow','LowHigh'))%>%
        reshape2::dcast(eqRibbBetween,value.var = 'summ.val')%>%
        dplyr::rename(ymin=HighLow,ymax=LowHigh)%>%mutate(variable='1')
      
      pts=summ3%>%
        dplyr::filter(RibbonVal=='Mid')%>%
        dplyr::select(-c(RibbonVal,summ.var))%>%
        dplyr::rename(variable=RibbonType,y=summ.val)
      
      
      if(shadingTypeShape=="Each Percentile"){
        df=dplyr::bind_rows(list(obs1,ribb,pts))
      }else{
        df=dplyr::bind_rows(list(obs1,ribbBetween,pts)) 
      }
      
      if(!is.null(addl)){
        if(includeAddl_pts){
          addlPts=addl%>%
            dplyr::rename(yADDPts=value)%>%
            dplyr::mutate(variable='DVobsExtra')%>%
            dplyr::select(-c(IREP,TAFD))
          df=dplyr::bind_rows(list(df,addlPts))
        } 
        if(includeAddl_trend){
          addlTrend=addlSum%>%
            dplyr::rename(yADDTrend=MidMid)%>%
            dplyr::mutate(variable='DVobsExtra')%>%
            dplyr::select(-c(HighMid,LowMid))
          df=dplyr::bind_rows(list(df,addlTrend))
        } 
      }
      
      
      
      
      
      df$op=factor(df$op,levels=c("predicted",'observed'))
      
      
      
      
      if(!binned){
        p1=
          ggplot2::ggplot(data=df,ggplot2::aes_string(x=xBy))	
      }
      
      if(binned){
        p1=ggplot2::ggplot(data=df, ggplot2::aes_string(x=paste(xBy,"bin", sep="")))
      }
      
      p1=p1+
        #cleanScales +
        ggplot2::scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
        ggplot2::scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+	
        ggplot2::coord_cartesian(xlim = xLimit, ylim = yLimit)+
        ggplot2::labs(title=Title, x=xLab, y=yLab)
      
        aesLine=ggplot2::aes(y=y,colour=lab)
        aesPoint=ggplot2::aes(y=yobs,colour=lab)
        aesRibbon=ggplot2::aes(ymin=ymin,ymax=ymax,fill=lab)
        scaleCol=ggplot2::scale_colour_discrete(name="Observed")
        scaleShape=ggplot2::scale_shape_discrete(name="Observed")
        scaleLine=ggplot2::scale_linetype_discrete(name="Observed")
        scaleFill=ggplot2::scale_fill_discrete(name="Predicted")

# Simulated percentiles ----
      if(shadingType=="simulated percentiles"){
        
        # Observed ---
        p1=p1+df%>%
          dplyr::filter(!is.na(y)&op=='observed')%>%
          plyr::dlply(.(variable),.fun=function(x) ggplot2::geom_line(data=x,aesLine,linetype=2))
        
        if(showObs){
          p1=p1+df%>%
            dplyr::filter(!is.na(yobs))%>%
            plyr::dlply(.(variable),.fun=function(x) ggplot2::geom_point(data=x,aesPoint, alpha=.5))
        }
        
        # Predicted ---
        p1=p1+df%>%
          dplyr::filter(!is.na(ymin))%>%
          plyr::dlply(.(variable),.fun=function(x) ggplot2::geom_ribbon(data=x,aesRibbon,alpha=.2))
        

        
      }
      
# No shading ----
      if(shadingType=="no shading"){
        scaleLine=ggplot2::scale_linetype_discrete(name="LineType")
        # Observed ---
        p1=p1+df%>%
          dplyr::filter(!is.na(y))%>%
          plyr::dlply(.(variable),.fun=function(x) ggplot2::geom_line(data=x,aes(y=y,colour=lab,linetype=op)))
        
        
        if(showObs){
          p1=p1+df%>%
            dplyr::filter(!is.na(yobs))%>%
            plyr::dlply(.(variable),.fun=function(x) ggplot2::geom_point(data=x,aes(y=yobs, color=lab),shape=1, alpha=.5))
        }
       
        # Predicted ---
        p1=p1+df%>%dplyr::filter(!is.na(ymid))%>%
          plyr::dlply(.(variable),.fun=function(x) ggplot2::geom_line(data=x,aes(y=ymid,colour=lab,linetype=op)))
         
      } 
        

      

#Observed and predicted median ----
      
      if(shadingType=="predicted median"){
        
        scaleFill=ggplot2::scale_fill_discrete(name=paste0(round(ci*100,2),"% Conf Interval"))
        scaleCol=ggplot2::scale_colour_discrete(name=" ")
# Observed ---
        p1=p1+df%>%
          dplyr::filter(!is.na(ymid)&variable=='Mid')%>%
          plyr::dlply(.(variable),.fun=function(x) ggplot2::geom_line(data=x,aes(y=ymid, color=lab),linetype=1))
        
        if(showObs){
          p1=p1+df%>%
            dplyr::filter(!is.na(yobs))%>%
            plyr::dlply(.(variable),.fun=function(x) ggplot2::geom_point(data=x,aesPoint,alpha=0.5,shape=1))
        }
# Predicted ---
        p1=p1+df%>%
          dplyr::filter(!is.na(ymid)&variable=='Mid')%>%
          plyr::dlply(.(variable),.fun=function(x) ggplot2::geom_ribbon(data=x,aesRibbon, alpha=0.3))

        }

      # Additional ----
      if(!is.null(addl)){
        if(includeAddl_pts) p1=p1+df%>%
            dplyr::filter(!is.na(yADDPts))%>%
            plyr::dlply(.(variable),.fun=function(x) ggplot2::geom_point(data=x,aes(y=yADDPts, color=lab),shape=1, alpha=.5))
        if(includeAddl_trend) p1=p1+df%>%
            dplyr::filter(!is.na(yADDTrend))%>%
            plyr::dlply(.(variable),.fun=function(x) ggplot2::geom_line(data=x,aes(y=yADDTrend, color=lab),linetype=2))
      }
    
      p1=p1+scaleCol+scaleFill+scaleLine+scaleShape

      if (!is.null(minorTicks)) p1=p1+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
      
      #Add in the faceting if it exists
      if (facetBy!=""){
        p1=p1 +ggplot2::facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,scales=fscales)
      }
      
      themeUpdate=ggplot2::theme(text=     ggplot2::element_text(size=themeTextSize),
                        axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                        axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                        plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                        panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
                        legend.title = ggplot2::theme_bw()$legend.title,
                        panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
                        legend.position =  themePlotLegendPosition
      )
      p1=p1+cleanTheme+themeUpdate
      # +guides(fill=guide_legend(title=""), 
      #                                     colour=guide_legend(title=""), 
      #                                     shape=guide_legend(title=""))
      
      return(p1)
    }
    
    return(list(pList=list(p),plotRows=1,plotCols=1))
    
  }

