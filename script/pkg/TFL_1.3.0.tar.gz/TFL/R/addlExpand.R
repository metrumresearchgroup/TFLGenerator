#' @title addlExpand
#' @description Transpose NONMEM input from wide format that uses II and ADDL to long format with TIME and EVID.
#' @param tab connection||data.frame, Tab file from NONMEM run
#' @param demog data.frame, contains demographic varaibles
#' @param idVar character, Column name for ID, Default: 'ID'
#' @param EVID character, Column name of event id, Default: 'EVID'
#' @param AMT character, Column name of Dose Amount, Default: 'AMT'
#' @param II character, Column name of Interdosing Interval, Default: 'II'
#' @param ADDL character, Column name of Additional Implicit Doses , Default: 'ADDL'
#' @param group.vars character, vector of id variables to transpose data object, Default: NULL
#' @param demog.fillVars character, vector of variables in demog to fill (Last Observation Carried Forward), Default: NULL
#' @param demog.keepVars character, vector of variables in demog to keep without filling NAs, Default: NULL
#' 
#' @examples 
#' 
#' addlExpand( tab =file.path(find.package('TFL'),'external/mi210/510/510.tab'),
#'             demog = file.path(find.package('TFL'),'external/mi210/poppk_wcovs.csv'),
#'             group.vars = c('ID','EVID','AMT'),
#'             demog.fillVars = c('HT','WT','CLCR','SEX','AGE'),
#'             demog.keepVars = c('RATE')
#' )
#' 
#' @export
#' @import dplyr
#' @importFrom utils read.table read.csv
addlExpand=function(tab,
                    demog,
                    idVar='ID',
                    EVID='EVID',
                    AMT='AMT',
                    II='II',
                    ADDL='ADDL',
                    group.vars=NULL,
                    demog.fillVars=NULL,
                    demog.keepVars=NULL)
{
  
  if(is.character(tab)) tab=utils::read.table(tab,header=TRUE, skip=1, stringsAsFactors=F, fill=TRUE)
  if(is.character(demog)) demog=utils::read.csv(demog,stringsAsFactors=F)
  
  if(!'TIME'%in%names(tab)) stop("TIME column missing from tab")
  if(!EVID%in%names(tab)) stop(sprintf("%s column missing from tab",EVID))
  
  if(!II%in%names(demog)) stop(sprintf("%s column missing from demog",II))
  if(!ADDL%in%names(demog)) stop(sprintf("%s column missing from demog",ADDL))
  if(!AMT%in%names(demog)) stop(sprintf("%s column missing from demog",AMT))
  
  #join tab and demographic data
  data<-tab%>%dplyr::left_join(demog)
  
  #filter data to include only EVID==1 and AMT!=0
  df<-data%>%
    dplyr::select_(.dots=c(group.vars,demog.keepVars,c(II,ADDL)))%>%
    dplyr::filter_(.dots = sprintf('%s==1&%s!=0',EVID,AMT))
  
  #Calculate DOSE TIME from II and ADDL (WIDE to LONG)
  x<-df%>%
    dplyr::group_by_(.dots=c(group.vars,demog.keepVars))%>%
    dplyr::do(.,data.frame(TIME=seq.int(0,by = .[[II]],length.out = (.[[ADDL]]+1))))
  
  #Append DOSE TIME with PK TIME (keep distinct)
  
  long=rbind(x%>%
               dplyr::ungroup()%>%
               dplyr::select_(.dots=c(idVar,EVID,'TIME'))%>%
               dplyr::distinct(),data%>%dplyr::select_(.dots=c(idVar,EVID,'TIME'))%>%dplyr::distinct())%>%
    dplyr::distinct()%>%dplyr::arrange_(.dots=c(idVar,'TIME',EVID))
  
  #left join tab columns  
  out=long%>%dplyr::left_join(tab)
  
  #left join demog columns for only EVID==1 rows
  out=out%>%dplyr::left_join(demog%>%dplyr::filter_(sprintf('%s!=0',AMT))%>%
                               dplyr::mutate_(EVID=1)%>%
                               dplyr::select_(.dots=c(group.vars,demog.keepVars)))
  
  #left join demog columns for all rows
  out=out%>%dplyr::left_join(demog%>%dplyr::filter_(sprintf('%s!=0',AMT))%>%dplyr::select_(.dots=c(idVar,demog.fillVars)))
  
  out%>%as.data.frame
}