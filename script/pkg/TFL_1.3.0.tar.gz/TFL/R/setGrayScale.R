#' @title Set the entire project color scale to GRAY SCALE
#' @description Sets the value of cleanScales (a theme set often used in internal Amgen ggplot construction) to appropriate gray scales (and line, shape scales)
#' @usage setGrayScale()
#' @details Utilizes grayPalette, shapesPalette, graylinePalette
#' @return list of ggplot scale objects
#' @export
#' @import ggplot2
#' @importFrom scales shape_pal
setGrayScale <-
function(fillList=NULL, shapeList=NULL, lineList=NULL, colourList=NULL, drop=T){
	
	fillList=fillList %||% grayPalette
	shapeList=shapeList %||% scales::shape_pal()(6)
	lineList=lineList %||% graylinePalette
	colourList=colourList	%||% grayPalette
	
	return(list(ggplot2::scale_fill_manual(values=fillList,drop=drop), 
	            ggplot2::scale_shape_manual(values=shapeList,drop=drop), 
	            ggplot2::scale_linetype_manual(values=lineList,drop=drop),
	            ggplot2::scale_colour_manual(values=colourList,drop=drop))
	)
}
