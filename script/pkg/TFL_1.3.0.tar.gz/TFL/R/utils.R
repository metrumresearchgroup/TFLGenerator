#' @importFrom magrittr %>%
#' @export
magrittr::'%>%'

#' @export
'%||%'=function(a, b){
  if (!is.null(a)) 
    a
  else b
}

#' @export
'%+%'=function(item1, item2){
  ifelse ("ggplot" %in% class(item1) & "ggplot" %in% class(item2), 
          stop("You can't add two ggplot grobs", call.=FALSE),
          ifelse("ggplot" %in% class(item1) & class(item2) %in% c("data.frame", "matrix"), 
                 return(ggplot2::'%+%'(item1, item2)),
                 ifelse("ggplot" %in% class(item2) & class(item1) %in% c("data.frame", "matrix"), 
                        return(ggplot2::'%+%'(item2, item1)),
                        ifelse(class(item2) %in% c("data.frame", "matrix")  & class(item1) %in% c("data.frame", "matrix"), 
                               return(metrumrg::'%+%'(item2, item1)),
                               stop("You can't add these class objects together; check object class and specify package with - package::'function'(args)", call.=FALSE)))))
  
}

is_date=function (x) inherits(x, c("POSIXt", "POSIXct", "POSIXlt", "Date"))

rel=function (x) 
{
  structure(x, class = "rel")
}

#' @title as.gglist
#' @description Creates structure of lists of ggplots.
#' @param p gg
#' @return gg
#' @export
#' @keywords internal
as.gglist=function(p) structure(p, class=c("gglist", "ggplot"))

#' @importFrom stats quantile
f.quantile <- function(x, ind, ...) stats::quantile(x[ind], ...)

#' @importFrom grid grobName
ggname=function (prefix, grob) 
{
  grob$name <- grid::grobName(grob, prefix)
  grob
}

#' @title Creates a ln (log) based sequence
#' @description Used in creating appropriate plot legend breaks
#' @param x numeric vector
#' @return  numeric vector

lnseq <- function(x) signif(2.718282^(seq(from=floor(log(range(x, na.rm=TRUE)[1])), 
                                          to=ceiling(log(range(x, na.rm=TRUE)[2])), 
                                          by=1)), 
                            digits=3)

#' @title Plain format
#' @description Bring in a plain, non-scientific format
#' @param x numeric vector
#' @export

plain <- function(x,...){
  format(x,..., scientific=F)
}

pretty_breaks<-function (n = 5, ...){
  function(x) {
    breaks <- pretty(x, n, ...)
    names(breaks) <- attr(breaks, "labels")
    breaks
  }
}



