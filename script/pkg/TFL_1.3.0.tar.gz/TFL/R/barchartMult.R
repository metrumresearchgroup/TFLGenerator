#' @title Bar charts
#' @concept figure
#' @description \code{barchartMult} returns a barchart for each categorical variable listed.
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param ID numeric, vector of the patient IDs to plot, Default: 'NMID'
#' @param catList list, list of two element vectors giving the column name and rename, 
#' Default: list(c("SEX", "Gender"), c("RACE", "Race"), c("DIS", "Disease status"))
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param fnrow integer, Number of rows passed to facet_wrap, Default: 1
#' @param srcAdd boolean, add source caption to output Default: TRUE, Default: TRUE
#' @param srcPath character, source script path, Default: '.'
#' @param srcName character, source script name, Default: 'script'
#' @param figPath character, Output figure path, Default: '../deliv/figure'
#' @param figName character, Output figure name, Default: 'Rplot.pdf'
#' @param ... 
#' @examples
#' data("twoCmt")
#' barchartMult(datFile = twoCmt)
#' barchartMult(datFile = twoCmt,catList = list(c('SEX','Gender')))
#' barchartMult(datFile = twoCmt,fnrow=2)
#' @return A barchart ggplot2 object of class \code{TFL} which can be plotted or 
#' printed with the corresponding method.  
#' @export
#' @import ggplot2 dplyr
#' @importFrom reshape2 melt
barchartMult <-
	function(datFile,
	         ID='NMID',
					 catList=list(c("SEX", "Gender"),
					              c("RACE", "Race"),
					              c("DIS", "Disease status")),
            themeUpdate=list(),
            themeTextSize=14,
            themePlotTitleSize=1.2,
            themeAxisTxtSize=0.8,
            themeAxisTxtColour='black',
            themeAxisTitleTxtSize=0.9,
            themeAxisTitleColour='black',
            themePanelBackgroundFill='white',
            themePanelGridSize=NULL,
            themePanelGridColour='white',
            themePanelLineType=1,
            themePanelTitleSize=1.2,
            themePlotTitleColour='black',
					  fnrow=1,
					  srcAdd=TRUE,
					  srcPath='.',
					  srcName='script',
					  figPath="../deliv/figure",
					  figName="Rplot.pdf",
					  ...
	){ 
	 
	  if(class(catList)!="list"){
	    catList <- list(catList)
	  }

          cats=sapply(catList, function(x){x[[1]][1]})
          catLabs=sapply(catList, function(x){x[[2]][1]})
		

	for(cat in cats){
	  if(!class(datFile[,cat])%in%c("factor","character")){
	    datFile[,cat] <- as.character(datFile[,cat])
	  }
	}
	pDat=datFile%>%dplyr::select_(.dots=c(ID,cats))%>%
	  reshape2::melt(.,id=ID)%>%
	  dplyr::count(variable,value)
	
	pDat$variableLab=factor(pDat$variable,labels=catLabs)
	
	
	p= pDat%>%ggplot2::ggplot(ggplot2::aes(x=paste0(factor(value),'\nn=',n),y=n))+
	  ggplot2::geom_bar(stat='identity',fill='dodgerblue4')+
	  ggplot2::facet_wrap(~variableLab,scales='free',nrow=fnrow)+
	  ggplot2::labs(x='',y='Number of Subjects')

	themeUpdate=ggplot2::theme(text=     ggplot2::element_text(size=themeTextSize),
	                  axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
	                  axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
	                  plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
	                  panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
	                  panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
	)
	
	p=p+cleanTheme +themeUpdate

		p1=list(pList=list(p),plotCols=1,plotRows=1,srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
		class(p1)<-c(class(p1),'TFL')
		return(p1)

	}
