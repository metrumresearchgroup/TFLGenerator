#' @title Set the entire project color scale to COLOR
#' @description Sets the value of cleanScales (a theme set often used in internal Amgen ggplot construction) to appropriate color scales (and line, shape scales)
#' @usage setColorScale()
#' @details Utilizes colorPalette, shapesPalette, colorlinePalette
#' @return list of ggplot scale objects
#' @export
#' @import ggplot2
#' @importFrom scales shape_pal
setColorScale <-
	function(fillList=NULL, shapeList=NULL, lineList=NULL, colourList=NULL, drop=T){

		fillList=fillList %||% colorPalette
		shapeList=shapeList %||% scales::shape_pal()(6)
		lineList=lineList %||% colorlinePalette
		colourList=colourList	%||% colorPalette
		
		return(list(ggplot2::scale_fill_manual(values=fillList,drop=drop), 
		            ggplot2::scale_shape_manual(values=shapeList,drop=drop), 
		            ggplot2::scale_linetype_manual(values=lineList,drop=drop),
		            ggplot2::scale_colour_manual(values=colourList,drop=drop))					 
	)
}
