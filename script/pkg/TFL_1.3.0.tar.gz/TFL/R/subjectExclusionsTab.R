#' @export
#' @import dplyr
#' @importFrom metrumrg reapply map
#' @importFrom reshape2 melt dcast
#' @importFrom rtf RTF addTable done
#' @importFrom utils write.csv
subjectExclusionsTab <-
	function(
	  catList=list(c("STUDY","Study"),c("DOSE","Dose")),
	  nidpercol=5,
	  tmpDir = NULL
	)
		{ 
	  if(is.null(tmpDir)){
	    tmpDir <- tempdir()
	    dir.create(tmpDir,recursive = T)
	  }else{
	    if(!dir.exists(tmpDir)){
	      return()
	    }
	  }
	  
	  if(catList!=""){
	    if(class(catList)!="list"){
	      catList <- list(catList)
	    }
	    
	    cats=sapply(catList, function(x){x[[1]][1]})
	    catlabs=sapply(catList, function(x){x[[2]][1]})
	  }else{
	    cats <- NULL
	    catlabs <- NULL
	  }

		datFile <- try(subjectExclusions)
		if(class(datFile)=="try-error") get("subjectExclusions",.GlobalEnv)
		
		datFile <- datFile[,unique(c("excl_reasons",cats,"NMID"))]
		datFile <- datFile[!duplicated(datFile),]
		datFile <- reshape2::melt(datFile, measure.vars="NMID")
		datFile <- datFile%>%dplyr::arrange_(.dots = names(datFile))
		N <- metrumrg::reapply(datFile$value,
		             datFile[,"excl_reasons"],
		             length
		)
		datFile$grp_ <- metrumrg::reapply(datFile$value,
		        datFile[,setdiff(names(datFile),c("variable","value"))],
		        function(x){
		          rep(1:(ceiling(length(x)/nidpercol)), each=nidpercol)[seq_along(x)]
		        }
		)

		datFile$excl_reasons <- paste(datFile$excl_reasons, paste0("(N=",N,")"))
		datFile <- reshape2::dcast(datFile, ... ~ variable, value="value",
		                fun.aggregate=function(x)paste(x,collapse=", "))
		datFile$grp_ <- NULL
		datFile$excl_reasons <- metrumrg::reapply(datFile$excl_reasons,
		                               datFile[,"excl_reasons"],
		                               function(x) c(x[1],rep("",length(x)-1))
		)
		names(datFile) <- metrumrg::map(names(datFile), 
		                      from=c("excl_reasons",cats,"NMID"),
		                      to=c("Reason for exclusion", catlabs, "ID"))
		
		if(nrow(datFile) <= 500){
		  f <- file.path(tmpDir,"subjectExclusions.doc")
		  rtf <- rtf::RTF(f,font.size=11)
		  rtf::addTable(rtf,datFile)
		  rtf::done(rtf)
		  message <- "SUCCESS"
		}else{
		  f <- file.path(tmpDir,"subjectExclusions.csv")
		  utils::write.csv(datFile,file=f,row.names=F)
		  message <- paste0("Too many exclusions (N=", nrow(datFile), ") to create doc file.  Data dumped to PNG/",basename(f))
		}

		p1 <- datFile
		return(list(preview=datFile, file=f, message=message))
	}
