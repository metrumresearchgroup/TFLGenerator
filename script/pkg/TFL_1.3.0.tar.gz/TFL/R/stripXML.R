#' @title Parses the ouptut XML from Nonmem including documented names
#' @description Allows users to access XML internal Nonmem run information.  
#'  Character documentation after theta, omega, and sigma blocks in the control file will be translated as follows:
#'    Comment trings within the first set of brackets will be included in the output "notes" either directly or as a converstion. [P] yeilds CV, [A] yeilds sd, and [F] yeilds r as appropriate
#'  Comment strings within subsequent brackets will be omitted from the output table
#'  All other comment strings will be included in the parameter description title.  
#'  Ex:
#'    
#'    $THETA
#'  (.001,.08,2) ; [KDEG]
#'  (7,18,40)     ; [BL]
#'  
#'  $OMEGA BLOCK(2)
#'  .6    ;[P]  ;KDEG
#'  .3    ;[F]  ;KDEG-BL
#'  .3 8  ;[A]  ;BL 
#'  
#'  Will give KDEG, BL CV, r, and sd for each theta and omega in the notes 
#'  the Omega will also be defined in the title column as KDEG, KDEG-BL, BL
#'  
#'  $OMEGA
#'  .6; KDEG [P] [Extra Info]
#'  
#'  Would show the CV for Omega in the "notes" column, KDEG in the Title Column and the Extra Info would be ommitted
#'  
#' @usage stripXML(run, type = "theta", project = getwd())
#' @param run character run number
#' @param type character indicating the type of information to be accessed
#' @param project string indicating home directory of the Nonmem Run defaults to the current working directory
#' @details type can be:
#' "parallel_est"                  "table_series"             "estimation_method"              "estimation_title" 
#' "monitor"            "termination_status"       "termination_information"                        "etabar" 
#'  "etabarse"                    "etabarpval"                     "etashrink"                     "epsshrink" 
#' "estimation_elapsed_time"        "covariance_information"             "covariance_status"       "covariance_elapsed_time" 
#' "final_objective_function_text"      "final_objective_function"                         "theta"                         "omega" 
#' "sigma"                        "omegac"                        "sigmac"                       "thetase" 
#' "omegase"                       "sigmase"                      "omegacse"                      "sigmacse" 
#' "covariance"                   "correlation"                 "invcovariance"                   "eigenvalues" 
#' @return Output returns a data.frame and prints a grob table
#' @export
#' @importFrom stringr str_split str_sub str_extract
#' @importFrom XML xmlTreeParse xmlValue
#' 
stripXML=function(run, type="theta", project=getwd()){	

	readIn=XML::xmlTreeParse(sprintf("%s/%s/%s.xml", project, run, run), useInternalNodes=FALSE)
	readIn=readIn$doc$children[["output"]]
	
	
	#set up ctl
	ctl=XML::xmlValue(readIn[["control_stream"]])
	ctl=unlist(ctl)
	ctl=unlist(stringr::str_split(ctl, "[$]"))
	idx=grep(paste("^", toupper(stringr::str_sub(type, end=5)),sep=""), ctl)
	
	if(length(idx)==0){

		return(sprintf("%s is not available option", type))

	}
	
	if(length(idx)>0){
		prev=0
		foo=data.frame(matrix(,1, 6))
		for (j in idx){
			
			ctl1=ctl[j]
			ctl1=unlist(stringr::str_split(ctl1, "\n"))[-1]
			if(length(ctl1)==1 & any(ctl1=="")) ctl1=gsub(paste0("^",toupper(type)),"",ctl[j])
			#remove lines beginning with comments
			idn=grep("^\\;",ctl1)
			if(length(idn)>0){ctl1=ctl1[-idn]}
			ctl1=ctl1[ctl1!=""]
			
		
			Desc=as.list(ctl1)
			if(length(Desc)==0){Desc=NULL}
			
			if(length(Desc)>0){
			#convert Desc to a 3 column data frame
			
			
			if(length(grep(paste(toupper(stringr::str_sub(type, end=5)),"BLOCK"),ctl[j]))==0){
				descTab=matrix(,length(Desc), 6)
				nn=length(Desc)
				descTab[,4]=descTab[,5]=(c(1:nn)+prev)			
				prev=prev+nn
			}
			
			if(length(grep(paste(toupper(stringr::str_sub(type, end=5)),"BLOCK"),ctl[j]))>0){
				num=as.numeric(stringr::str_extract(ctl[j], "\\d+"))
				numsA=t(combn(num,2))
				numsB=matrix(rep(c(1:num), 2),num,2)
				nums=data.frame(rbind(numsA, numsB))
				nums=nums+prev
				nums=nums[order(nums[,1], nums[,2]),]	
				descTab=matrix(,length(nums[,1]), 6)
				nn=length(Desc)
				descTab[,4]=nums[,1]
				descTab[,5]=nums[,2]
				prev=num
			}
			descTab=data.frame(descTab)
			descTab=descTab[order(descTab[,5], descTab[,4]),]

			
			for(i in c(1:length(Desc))){
			  #see if the value is fixed
				test=grep("FIX.*", Desc[[i]][1])
				descTab[i,6]=ifelse(length(test)>0, 1, 0)
				# see if a set of brackets contains the error calculations
					test=stringr::str_extract(Desc[[i]][1], "\\[([[:space:]]*P[[:space:]]*|[[:space:]]*F[[:space:]]*|[[:space:]]*A[[:space:]]*)\\]")
					test=gsub("\\[|\\]", "", test)
					descTab[i,3]=""
					if(length(test)==1){
						if(!is.na(test)){
						descTab[i,3]=test
						Desc[[i]][1]=gsub("\\[(.*)\\]+?", "", Desc[[i]][1]) #remove the first set of parenthesis
						}
					}
					if(descTab[i,3]==""){
						# If the first set of brackets doesn't contain the error calculation, use it as a description (notes)
						test=stringr::str_extract(Desc[[i]][1], "\\[(.*)\\]+?") #take the first set of parenthesis
						test=gsub("\\[([[:space:]]*P[[:space:]]*|[[:space:]]*F[[:space:]]*|[[:space:]]*A[[:space:]]*)\\]", "",test)
						test=gsub("\\[|\\]", "", test)
						descTab[i,1]=""
						if(length(test)==1){
							if(!is.na(test)){
								descTab[i,1]=test
								Desc[[i]][1]=gsub("\\[(.*)\\]+?", "", Desc[[i]][1]) #remove the first set of parenthesis
							}
						}
					}
					#next put the remainder in the Title, anything left in brackets will be removed
					test=ifelse(length(grep(";", Desc[[i]][1]))>0,Desc[[i]][1],"")
					test=gsub("^[^;]*;", "", test)
					test=gsub(";", "", test)
					descTab[i,2]=""
					if(length(test)==1){
						if(!is.na(test)){
							descTab[i,2]=test
						}
					}
			
				}	
			
			
			foo=merge(foo,descTab, all=TRUE)
		}
	
		}
		
		names(foo)=c("Desc", "Title", "Calc", "type1", "type2", "FIX")	
		descTab=foo[!is.na(foo$type1),]
		
	}
	
	#A way to parse the nonmem output
	nm=readIn[["nonmem"]][["problem"]]
	#choose the last estimation step
	nm=nm[[max(grep("estimation", names(nm)))]]
	prob=XML::xmlValue(nm[["problem_title"]])
	
	intTab=nm[[type]]
	namesForRows=sapply(c(1:length(intTab)), FUN=function(i) intTab[[i]]$attr)
	test=unique(names(namesForRows))

if(!is.null(test)){	
	if (test=="name"){
		fooMat=data.frame(matrix(nrow=length(namesForRows), ncol=4))
		names(fooMat)=c("value", "type1", "type2", "class")
		
		for (j in c(1:length(intTab))){
			nowVal=signif(as.numeric(xmlValue(intTab[j]$val)), digits=3)
			name=as.character(xmlAttrs(intTab[j]$val))
			fooMat$value[j]=nowVal
			fooMat$type1[j]=fooMat$type2[j]=name
			fooMat$class[j]=stringr::str_sub(type, end=5)
		}
	}
	

	if (test=="rname") {
		
		N=length(intTab[[length(intTab)]])
		dims=(N*(N + 1))/2
		fooMat=data.frame(matrix(nrow=dims, ncol=4)) 
		names(fooMat)=c("value", "type1", "type2", "class")
		
		m=1
		for (i in c(1:length(intTab))){
			foo=intTab[[i]]
			rname=as.character(foo$attr)
			for (j in c(1:length(foo))){
				nowVal=signif(as.numeric(xmlValue(foo[j]$col)), digits=3)
				cname=as.character(xmlAttrs(foo[j]$col))
				fooMat$value[m]=nowVal
				fooMat$type2[m]=rname
				fooMat$type1[m]=cname
				fooMat$class[m]=stringr::str_sub(type, end=5)
				m=m+1
			}
		}	
	}
}	
	if(exists("descTab")){
		
		fooMat=merge(descTab, fooMat, all=TRUE)
		
	}
	
	fooMat=fooMat[!is.na(fooMat$value),]
	fooMat$Desc=ifelse(is.na(fooMat$Desc), "",fooMat$Desc)
	fooMat$Title=ifelse(is.na(fooMat$Title), "",fooMat$Title)

	fooMat=fooMat[fooMat$Title!="" & fooMat$Desc!="" & fooMat$type1==fooMat$type2 | !is.na(fooMat$Calc) | !is.na(fooMat$FIX),]
	
	return(fooMat)
}


