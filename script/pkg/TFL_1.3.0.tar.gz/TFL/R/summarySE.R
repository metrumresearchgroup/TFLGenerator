#' @title Summarize data sets with subsetting
#' @description Utilize ddply to summarize data sets
#' @usage summarySE(data = NULL, measurevar, groupvars = NULL, na.rm = FALSE, conf.interval = 0.95, .drop = TRUE)
#' @param data data.frame output of a NM run containing ER-SSAP standard column names and numeric-only columns
#' @param measurevar character column name of dependent variable
#' @param groupvars character vector of column names of recorded variables (these are the only columns that will be kept)
#' @param na.rm logical indicating whether to ignore na (TRUE) or return NA if NA exists anywhere in the column (FALSE)
#' @param conf.interval numeric indicating confidence interval to be reported
#' @param .drop logical indicating dropping of columns
#' @details A ddply wrapper which summarizes a common nonmem output format to create mean, median, sd, se and ci columns
#' @return exports summary data frame
#' @examples 
#' data('twoCmt')
#' summarySE(twoCmt, measurevar="DV", groupvars=c("TAFD", "DOSE"))
#' @export
#' @importFrom plyr ddply
#' @importFrom stats qt
#' 
summarySE <-
function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE,
											conf.interval=.95, .drop=TRUE) {
	# New version of length which can handle NA's: if na.rm==T, don't count them
	length2 <- function (x, na.rm=FALSE) {
		if (na.rm) sum(!is.na(x))
		else       length(x)
	}
	
	#ddply to create columns containing median, mean and sd
	datac <- plyr::ddply(data, groupvars, .drop=.drop,
								 .fun= function(xx, col, na.rm) {
								 	c( N   		= length2(xx[,col], na.rm=na.rm),
								 		 median	=median (xx[,col], na.rm=na.rm),
								 		 mean 		= mean  (xx[,col], na.rm=na.rm),
								 		 sd  		 = signif(sd   (xx[,col], na.rm=na.rm), digits=4)
								 	)
								 },
								 measurevar,
								 na.rm
	)
	
	# Calculate standard error of the mean
	datac$se <-signif(datac$sd / sqrt(datac$N-1), digits=4)  
	
	
	# Confidence interval multiplier for standard error
	# Calculate t-statistic for confidence interval: 
	# e.g., if conf.interval is .95, use .975 (above/below), and use df=N-1
	if(any(datac$N==1)) warning(sprintf('ci returning NaNs due to group size of N=1 in rows:%s',paste(which(datac$N==1),collapse=',')))
	ciMult <- suppressWarnings(stats::qt(conf.interval/2 + .5, datac$N-1))
	datac$ci <- signif(datac$se * ciMult, digits=4)

	datac=datac[which(datac$N!=0),]
	
	return(datac)
}
