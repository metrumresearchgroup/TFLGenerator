#' @title Scatterplots
#' @concept figure
#' @description Scatterplots comparing (multiple) continuous variables
#' 
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param conList_x list, list of two element vectors giving the column name and rename (x-axis)
#' @param conList_y list, list of two element vectors giving the column name and rename (y-axis)
#' @param plotCols integer, Number of columns to arrange plots into grid output, Default: 2
#' @param xLimit numeric, Two element vector giving the lower and upper limits of the x-axis, Default: NULL
#' @param yLimit numeric, Two element vector giving the lower and upper limits of the y-axis, Default: NULL
#' @param xForm function|character,  Format of the x-axis variable tick label, Default: waiver()
#' @param yForm function|character,  Format of the y-axis variable tick label, Default: waiver()
#' @param xScale function|character,  Scale transformtion for the x-axis variable, Default: 'identity'
#' @param yScale function|character,  Scale transformtion for the y-axis variable, Default: 'identity'
#' @param facetBy character, column name for figure faceting, Default: ''
#' @param fF character, Labels for the facet levels in the form "Level1,Label1;Level2,Label2", Default: ''
#' @param fnrow integer, Number of rows passed to facet_wrap, Default: NULL
#' @param fncol integer, Number of columns passed to facet_wrap, Default: NULL
#' @param fscales character, Scale type for facet_wrap c("fixed","free","free_y","free_x"), Default: 'fixed'
#' @param minorTicks character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created, Default: NULL
#' @param minorTickNum integer, number of minor ticks between major ticks, Default: 10
#' @param corstat character, "R2" for adjusted R^2 or "r" for Pearson correlation, Default: NULL
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param srcAdd boolean, add source caption to output, Default: TRUE
#' @param srcPath character, source script path, Default: '.'
#' @param srcName character, source script name, Default: 'script'
#' @param figPath character, Output figure path, Default: '../deliv/figure'
#' @param figName character, Output figure name, Default: 'Rplot.pdf'
#' @param ... 
#' @examples
#' data("twoCmt")
#' covCon(twoCmt,conList_x = 'IPRED',conList_y = 'ETA1',plotCols=1)
#' covCon(twoCmt,
#' conList_x = list(
#' list('IPRED','Individual Prediction'),
#' list('IRES','Individual Residual')
#' ),
#' conList_y = list(
#' list('ETA1',expression(eta[1]))
#' )
#' )
#' 
#' @return  A "TFL" object consisting of a list of plots and the intended layout for 
#' their display.  The figure can be rendered with the \code{print} or \code{plot} 
#' methods.
#' 
#' @details In addition to reporting either the correlation coefficient or adjusted
#' R^2, the significance of the coefficient in a linear regression of y on x is 
#' reported as well (i.e., testing whether the coefficient is non-zero).  All observations
#' are shown on the plot as well as both a linear fit and loess smooth to the data.
#' @export
#' @import dplyr ggplot2
#' @importFrom plyr ddply dlply
#' @importFrom stats lm cor
covCon <-
function(datFile, conList_x, conList_y, plotCols=2,
								xLimit=NULL, yLimit=NULL,
								xForm=waiver(), yForm=waiver(),
								xScale="identity", yScale="identity",
								facetBy="", fF="", fnrow=NULL, fncol=NULL,fscales="fixed",
         minorTicks=NULL,minorTickNum=10,
         corstat=NULL,
         themeUpdate=list(),
         themeTextSize=14,
         themePlotTitleSize=1.2,
         themeAxisTxtSize=0.8,
         themeAxisTxtColour='black',
         themeAxisTitleTxtSize=0.9,
         themeAxisTitleColour='black',
         themePanelBackgroundFill='white',
         themePanelGridSize=NULL,
         themePanelGridColour='white',
         themePanelLineType=1,
         themePanelTitleSize=1.2,
         themePlotTitleColour='black',
         srcAdd=TRUE,
         srcPath='.',
         srcName='script',
         figPath="../deliv/figure",
         figName="Rplot.pdf",
								...){
	
  # if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
  # if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
  
	#for individual plots, plotCols=1, xBy and yBy is a single column name (such as "RACE" and "ETA1)
	#for a multiple plot object

  if(facetBy!="" & all(fF!="")){
    datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
  }

  if(class(conList_x)!="list"){
    conList_x <- list(conList_x)
  }
  if(class(conList_y)!="list"){
    conList_y <- list(conList_y)
  }
  
  if(xScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',xBy))
  if(yScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',yBy))
  
  yCols=sapply(conList_y, function(x){x[[1]][1]})
  yLabs=sapply(conList_y, function(x){if(length(x)==2) x[[2]][1] else x[[1]][1]})
  xCols=sapply(conList_x, function(x){x[[1]][1]})
  xLabs=sapply(conList_x, function(x){if(length(x)==2) x[[2]][1] else x[[1]][1]})

  themeUpdate=ggplot2::theme(text=     ggplot2::element_text(size=themeTextSize),
                    axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                    axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                    plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                    panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
                    panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
  )
  
  mod.grid=expand.grid(y=yCols,x=xCols, stringsAsFactors = F)%>%do(.,cbind(modId=1:nrow(.),.))
  if(facetBy!='') mod.grid=expand.grid(y=yCols,
                                       x=xCols,
                                       facetBy=facetBy,
                                       facetByVal=unique(datFile[,facetBy]),
                                       stringsAsFactors = F)%>%dplyr::do(.,cbind(modId=1:nrow(.),.))

    
  facetLbl=plyr::ddply(mod.grid,.variables = c('modId'),.fun=function(mod){
    y=mod$y
    x=mod$x
    df=datFile
  
    if(facetBy!='') df=df%>%  dplyr::filter_(.dots = list(paste0(mod$facetBy,"%in%",mod$facetByVal)))%>%
      dplyr::select_(.dots=list(y,x,facetBy))
    mod1 = stats::lm(df[,y]~df[,x], data = df)
    modsum = summary(mod1)
    r2 = ifelse("adj.r.squared" %in% names(modsum), paste("R^2=",signif(modsum$adj.r.squared, digits=3)), "")
    r = paste0("r=", signif(stats::cor(df[,x],df[,y],use="pairwise.complete.obs",method="pearson"),digits=3))
    
    my.p =ifelse(((dim(modsum$coefficients)[1]>=2) & dim(modsum$coefficients)[2]>=4), 
                 ifelse(modsum$coefficients[2,4]>0.001,
                        paste("p=",signif(modsum$coefficients[2,4],digits=3)),
                        "p<0.001"),
                 "")
    if(!is.null(corstat))mod$lbl=ifelse(corstat=="R2", sprintf("%s : %s",r2, my.p), sprintf("%s : %s",r, my.p))
    
    mod
  })
  
  
  
  pList=	plyr::dlply(facetLbl,.variables = c('x','y'),.fun=function(mod){
    x=unique(mod$x)
    y=unique(mod$y)
    p1=ggplot2::ggplot(datFile, aes_string(x=x, y=y))+
      ggplot2::geom_smooth(method="loess", se=FALSE, colour="red", lty=2)+
      ggplot2::geom_smooth(method="lm", se=FALSE, colour="red")+
      ggplot2::geom_point(shape=1)+
      ggplot2::geom_hline(yintercept=0, lty=2)+
      ggplot2::labs(x=xLabs[which(x==xCols)], y=yLabs[which(y==yCols)])+
      ggplot2::scale_x_continuous(breaks=pretty_breaks(), limits=xLimit, labels=eval(xForm), trans=xScale)+
      ggplot2::scale_y_continuous(breaks=pretty_breaks(), limits=yLimit, labels=eval(yForm), trans=yScale)
  
    if (!is.null(minorTicks)) p1=p1+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
    
  if(facetBy==''&!is.null(corstat)) p1=p1+ggplot2::labs(title=mod$lbl)  
    
  if (facetBy!=""){
    lbl='label_value'
    if(!is.null(corstat)){
      lbl <- paste(levels(factor(datFile[,facetBy])),mod$lbl,sep='\n')
      names(lbl)=levels(factor(datFile[,facetBy]))
      lbl=ggplot2::as_labeller(lbl)
    }
    p1=p1 +ggplot2::facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,ncol=fncol,scales=fscales,labeller = lbl)
    themeUpdate=themeUpdate+ggplot2::theme(strip.text = ggplot2::element_text(size=rel(.65)))
  }
  
  p1=p1+cleanTheme +themeUpdate
    })

  names(pList)=unique(paste("plot",mod.grid$x, "vs",mod.grid$y, sep=""))

	p1=list(pList=pList,plotCols = as.numeric(plotCols),plotRows = 1,srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
	class(p1)<-c(class(p1),'TFL')
	
	return(p1)
}
