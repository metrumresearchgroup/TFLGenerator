#' @title Parameter Distribution Plots
#' @concept figure
#' @description Produces a single parameter distribution plot with density and normal distrubution overlays
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param xCols character, Column name(s) for X-axis variable(s), Default: 'ETA1'
#' @param binWidth numeric, histogram bin width, Default: 0.1
#' @param groupBy character, column name for groupings within the output, Default: NULL
#' @param xLimit numeric, Two element vector giving the lower and upper limits of the X-axis, Default: NULL
#' @param yLimit numeric, Two element vector giving the lower and upper limits of the Y-axis, Default: NULL
#' @param xForm function|character,  Format of the X-axis variable tick label, Default: ggplot2::waiver()
#' @param yForm function|character,  Format of the Y-axis variable tick label, Default: ggplot2::waiver()
#' @param xScale function|character,  Scale transformtion for the X-axis variable, Default: 'identity'
#' @param yScale function|character,  Scale transformtion for the Y-axis variable, Default: 'identity'
#' @param Title character, Figure title, Default: ''
#' @param xLab character, Label of X-axis, Default: 'xCols'
#' @param yLab character, Label of Y-axis, Default: 'Percent'
#' @param facetBy character, column name for figure faceting, Default: ''
#' @param fF character, Labels for the facet levels in the form "Level1,Label1;Level2,Label2", Default: ''
#' @param fnrow integer, Number of rows passed to facet_wrap, Default: ''
#' @param fncol integer, Number of columns passed to facet_wrap, Default: ''
#' @param fscales character, Scale type for facet_wrap c("fixed","free","free_y","free_x"), Default: 'fixed'
#' @param runno character, Vector of run NONMEM numbers, Default: ''
#' @param project character, Home directory of the NONMEM Run, Default: getwd()
#' @param plotCols integer, Number of columns to arrange plots into grid output, Default: 1
#' @param plotRows integer, Number of rows to arrange plots into grid output, Default: 1
#' @param minorTicks character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created, Default: 'bl'
#' @param minorTickNum integer, number of minor ticks between major ticks, Default: 10
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param ... 
#' @details Standard Eta distribution histogram plot for showing density and normal distribution of ETA
#' @examples 
#' data("twoCmt")
#' paramDist(twoCmt)
#' paramDist(twoCmt,xCols=c('ETA1','ETA2'),xLab=c(expression(eta[1]),expression(eta[2])))
#' @return returns ggplot object (grob) that must be saved or printed
#' @export
#' @import ggplot2
#' @importFrom stats dnorm

paramDist<-function(datFile, xCols = "ETA1", binWidth = 0.1, groupBy = NULL,
           xLimit = NULL, yLimit = NULL, xForm = ggplot2::waiver(), 
           yForm = ggplot2::waiver(), xScale = "identity", yScale = "identity", 
           Title = "", xLab = "xCols",
           yLab = "Percent", facetBy = "", fF="", fnrow='', fncol='',fscales="fixed",
           runno = "", project = getwd(),
           plotCols = 1, plotRows = 1,
           minorTicks='bl',minorTickNum=10,
           themeUpdate=list(),
           themeTextSize=14,
           themePlotTitleSize=1.2,
           themeAxisTxtSize=0.8,
           themeAxisTxtColour='black',
           themeAxisTitleTxtSize=0.9,
           themeAxisTitleColour='black',
           themePanelBackgroundFill='white',
           themePanelGridSize=NULL,
           themePanelGridColour='white',
           themePanelLineType=1,
           themePanelTitleSize=1.2,
           themePlotTitleColour='black',
           ...){
    if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
    if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
    
    if(facetBy!="" & all(fF!="")){
      datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
    }

    plotCols <- as.numeric(plotCols); plotRows <- as.numeric(plotRows)
    if(plotCols*plotRows < length(plotCols)){
      plotCols <- 1
      plotRows <- length(plotCols)
    }

    themeUpdate=ggplot2::theme(text=     ggplot2::element_text(size=themeTextSize),
                      axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                      axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                      plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                      panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
                      panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
    )
    
    
    
    pList <- lapply(xCols, function(xBy){
      
      if (facetBy != "") {
        
        newDat=data.frame(matrix(,ncol=4))
        names(newDat)=c(xBy, "normFit", "meanCol", facetBy)
        for (facet in unique(datFile[, facetBy])) {
          xx=	datFile[datFile[,facetBy] == facet, xBy]
          padx=c(
            seq(from=min(xx, na.rm=TRUE)-abs(min(xx, na.rm=TRUE)), to=min(xx, na.rm=TRUE), length.out=10),
            xx,
            seq(from=max(xx,na.rm=TRUE), to=max(xx,na.rm=TRUE)+abs(max(xx,na.rm=TRUE)), length.out=10)
          )
          normFit=stats::dnorm(x=padx, mean=mean(xx, na.rm=TRUE), sd=sd(xx, na.rm=TRUE))
          meanCol=rep(mean(xx, na.rm=TRUE), times=length(padx))
          f=rep(facet, times=length(padx))
          foo=data.frame(cbind(padx, normFit, meanCol,f))
          names(foo)=c(xBy, "normFit", "meanCol", facetBy)
          newDat=rbind(newDat, foo)
          newDat=newDat[!is.na(newDat$normFit),]
          newDat=unique(newDat)
        }
        
        
        datFile=merge(datFile,newDat, all=TRUE)
      }
      
      if (facetBy == "") {
        newDat=data.frame(matrix(,ncol=3))
        names(newDat)=c(xBy, "normFit", "meanCol")
        
        xx=	datFile[, xBy]
        padx=c(
          seq(from=min(xx, na.rm=TRUE)-abs(min(xx, na.rm=TRUE)), to=min(xx, na.rm=TRUE), length.out=10),
          xx,
          seq(from=max(xx,na.rm=TRUE), to=max(xx,na.rm=TRUE)+abs(max(xx,na.rm=TRUE)), length.out=10)
        )
        normFit=stats::dnorm(x=padx, mean=mean(xx, na.rm=TRUE), sd=sd(xx, na.rm=TRUE))
        meanCol=rep(mean(xx, na.rm=TRUE), times=length(padx))
        foo=data.frame(cbind(padx, normFit, meanCol))
        names(foo)=c(xBy, "normFit", "meanCol")
        newDat=rbind(newDat, foo)
        newDat=newDat[!is.na(newDat$normFit),]
        newDat=unique(newDat)
        datFile=merge(datFile, newDat, all=TRUE)
      }	

      
      if (!runno %in% c(""," ","#")) {
        shrink = presentXML(runno, type = "etashrink", project = project)
        Title = ifelse(xBy %in% names(shrink), paste(Title, "\n", "Shrinkage=", 
                                                     shrink[xBy], "%", sep = ""), "")
      }
      
      datFile[,xBy]=as.numeric(datFile[,xBy])
      datFile$normFit=as.numeric(datFile$normFit)
      datFile$meanCol=as.numeric(datFile$meanCol)
      
      xLabsVar=xCols[xBy == xCols]
      xLabs=xLab[xBy == xCols]
      xLabs[xLabs%in%c('',NA)]=xLabsVar[xLabs%in%c('',NA)]
      
      if(length(yLab)>1) yLab <- yLab[xBy == xCols]

      p=
        ggplot2::ggplot(datFile, ggplot2::aes_string(x=xBy, group=groupBy))	+
        ggplot2::geom_density(colour="dodgerblue3", adjust=3, kernel="gaussian",lwd=1.25)+
        ggplot2::geom_histogram(ggplot2::aes(y=..density..),colour="white", fill="deepskyblue", binwidth=binWidth, alpha=.4)+
        ggplot2::scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
        ggplot2::scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
        ggplot2::geom_line(ggplot2::aes(y=normFit), col="red", lty="dotted",lwd=1.25)+	
        ggplot2::geom_vline(ggplot2::aes(xintercept=meanCol), colour="red")+	
        ggplot2::labs(title=Title, x=xLabs, y=yLab)+
        cleanScales
      
      if (!is.null(minorTicks)) p=p+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
      
      #Add in the faceting if it exists
      if (facetBy!=""){
        p=p +ggplot2::facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,ncol=fncol,scales=fscales)
      }
      
      p=p+cleanTheme +themeUpdate
      
      p
    })
    names(pList)=xCols
    p1=list(pList=pList,plotCols = as.numeric(plotCols),plotRows = as.numeric(plotRows))
    class(p1)<-c(class(p1),'TFL')
    return(p1)
  }