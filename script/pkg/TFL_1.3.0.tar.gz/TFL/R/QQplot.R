#' @title Create a standard Quantile-Quantile plot
#' @concept figure
#' @description Creates a standard quantile-quantile plot using a qnorm estimation of the data. 
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param xBy character, Column name for X-axis, Default: 'ETA1'
#' @param groupBy character, column name for groupings within the output, Default: NULL
#' @param markBy character, column name on which to mark by different colors, Default: NULL
#' @param markByType character, controls the type of variable expected mapped to markBy c("Discrete", "Continuous"), Default: 'Discrete'
#' @param qqDist function, distribution of theoretical quantiles passed to the QQ plot, Default: stats::qnorm
#' @param xLimit numeric, Two element vector giving the lower and upper limits of the X-axis, Default: NULL
#' @param yLimit numeric, Two element vector giving the lower and upper limits of the Y-axis, Default: NULL
#' @param xForm function|character,  Format of the X-axis variable tick label, Default: waiver()
#' @param yForm function|character,  Format of the Y-axis variable tick label, Default: waiver()
#' @param xScale function|character,  Scale transformtion for the X-axis variable, Default: 'identity'
#' @param yScale function|character,  Scale transformtion for the Y-axis variable, Default: 'identity'
#' @param Title character, Figure title, Default: ''
#' @param xLab character, Label of X-axis, Default: 'sprintf("Theoretical \%s", xBy)'
#' @param yLab character, Label of Y-axis, Default: 'sprintf("Observed \%s", xBy)'
#' @param facetBy character, column name for figure faceting, Default: ''
#' @param fF character, Labels for the facet levels in the form "Level1,Label1;Level2,Label2", Default: ''
#' @param fnrow integer, Number of rows passed to facet_wrap, Default: ''
#' @param fncol integer, Number of columns passed to facet_wrap, Default: ''
#' @param fscales character, Scale type for facet_wrap c("fixed","free","free_y","free_x"), Default: 'fixed'
#' @param minorTicks character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created, Default: NULL
#' @param minorTickNum integer, number of minor ticks between major ticks, Default: 10
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param ... 
#' @details Standard post-analysis qq plot.
#' @examples data("twoCmt")
#' QQplot(twoCmt)
#' QQplot(twoCmt,markBy = 'SEX')
#' QQplot(twoCmt,facetBy = 'DOSE')
#' @return returns ggplot object (grob) that must be saved or printed
#' @export
#' @import ggplot2
#' @importFrom stats qnorm

QQplot=function(
  datFile,  xBy="ETA1",
  groupBy=NULL,
  markBy=NULL,
  markByType="Discrete",
  qqDist=stats::qnorm,
  xLimit=NULL, yLimit=NULL,
  xForm=waiver(), yForm=waiver(),
  xScale="identity", yScale="identity", 
  Title="",
  xLab='sprintf("Theoretical %s", xBy)',
  yLab='sprintf("Observed %s", xBy)',
  facetBy="", fF="",fnrow='', fncol='',fscales="fixed",
  minorTicks=NULL,minorTickNum=10,
  themeUpdate=list(),
  themeTextSize=14,
  themePlotTitleSize=1.2,
  themeAxisTxtSize=0.8,
  themeAxisTxtColour='black',
  themeAxisTitleTxtSize=0.9,
  themeAxisTitleColour='black',
  themePanelBackgroundFill='white',
  themePanelGridSize=NULL,
  themePanelGridColour='white',
  themePanelLineType=1,
  themePanelTitleSize=1.2,
  themePlotTitleColour='black',
  ...){
  

  
  if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
  if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
  
  if(facetBy!="" & all(fF!="")){
    datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
  }
  
  if(!is.null(markBy)&markByType=='Discrete'){
    if(class(datFile[,markBy])!="factor") datFile[,markBy] <- factor(datFile[,markBy], sort(unique(datFile[,markBy])))
  }

  shp_aes=ggplot2::aes_string()
  
  if(!is.null(markBy)&markByType=="Discrete"){
    var_lvls=length(levels(datFile[[markBy]]))
    if(var_lvls<=6) shp_aes=ggplot2::aes_string(shape=markBy)
  }
  
  aes_base=ggplot2::aes_string(sample=xBy, group=groupBy, color=markBy)
  
  p1=
    ggplot2::ggplot(datFile, aes_base)	+
    ggplot2::scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
    ggplot2::scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
    ggplot2::stat_qq(shp_aes,distribution = qqDist,na.rm=TRUE)+
    stat_qqline(shp_aes,distribution = qqDist)+
    ggplot2::labs(title=Title, x=eval(parse(text=xLab)), y=eval(parse(text=yLab)))
  
  if (!is.null(minorTicks)) p1=p1+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
  
  #Add in the faceting if it exists
  if (facetBy!=""){
    p1=p1 +ggplot2::facet_wrap(as.formula(paste("~", facetBy)), nrow=fnrow,ncol=fncol,scales=fscales)
  }

  themeUpdate=ggplot2::theme(text=     ggplot2::element_text(size=themeTextSize),
                    axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                    axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                    plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                    panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
                    panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
  )
  
  if(markByType=='Discrete') p1=p1+cleanScales
  p1=p1+cleanTheme +themeUpdate
  
  p1=list(pList=list(p1),plotCols=1,plotRows=1)
  class(p1)<-c(class(p1),'TFL')
  return(p1)
  
}