#' @title Concentration vs time profiles for groups of patients (summary plot)
#' @concept generator
#' @description Longitundinal plot showing summaries of concentration vs time
#' profiles
#' 
#' @param datFile A \code{data.frame} containing the necessary variables for the
#' figure
#' @param groupBy Character, name of the column of \code{datFile} on which to 
#' group the summaries by
#' @param xBy Name of the variable denoting the x axis (typically time) in 
#' \code{datFile}
#' @param yBy Ignored
#' @param sumType The summarized response variable in \code{datFile}; this function assumes
#' the summary has already been performed
#' @param sumVar Ignored
#' @param markBy Character, name of the column of \code{datFile} on which to add
#' a color scale
#' @param markByType "Discrete" or "Continuous" for the type of color scale to use 
#' on \code{markBy}
#' @param preserveMarkByLevels Logical, matches the call to \code{\link{manipDat}}
#' that generated \code{datFile} when using the GUI.  Can be ignored when running
#' outside of the GUI
#' @param Color Logical, colored or greyscale?
#' @param xLimit Two element numeric vector giving the lower and upper limits of 
#' \code{xBy}
#' @param yLimit Two element numeric vector giving the lower and upper limits of
#'  the concentration axis (y)
#' @param minorTicks Character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created
#' @param minorTickNum Integer, number of minor ticks between major ticks
#' @param xForm One of "percent", "comma", "none", or "scientific" denoting the
#' labeling to be used for the x-axis
#' @param yForm One of "percent", "comma", "none", or "scientific" denoting the
#' labeling to be used for the y-axis
#' @param xScale One of "identity", "log", or "log-10"
#' @param yScale One of "identity", "log", or "log-10"
#' @param Title A title for the plot
#' @param xLab Label for the x axis
#' @param yLab Label for the y axis
#' @param facetBy Column in \code{datFile} on which to facet by
#' @param fF A character string acting as a key for re-labeling the facet values.  
#' Takes the form "value1,value2;label1,label2"
#' @param fnrow Number of rows in faceted layout
#' @param fncol Number of columns in faceted layout
#' @param fscales "fixed", "free", "free_y", or "free_x" as seen in the argument
#' to \code{facet_wrap}
#' @param Title String, the title for the plot
#' @param theme* Various controls for the ggplot2 theme
#' @examples 
#' data("twoCmt")
#' twoCmt=twoCmt%>%dplyr::mutate_each(funs(factor),DOSE,SEX)
#' ConcvTimeSum_generator(datFile = manipDat(twoCmt,groupBy = 'SEX',sumThis = T))
#' @return  A concentration vs time ggplot2 object of class \code{TFL} which
#' can be plotted or printed with the corresponding method.  
#' 
#' @details This function relies upon the user (or the TFL generator app) to 
#' provide sumamrized data in \code{datFile}.  The TFL generator itself uses the
#' \code{\link{manipDat}} function to perform these summaries, for example.
#' @export

ConcvTimeSum_generator <-
function(datFile, groupBy="DOSE", xBy="TAFD", yBy="DV",
         sumType="mean", sumVar="sd", 
         markBy="DOSE", markByType="Discrete",preserveMarkByLevels=F, 
         Color=T,
         xLimit=NULL,yLimit=NULL,
         minorTicks=NULL,minorTickNum=10,
         xForm=waiver(), yForm=waiver(),
         xScale="identity", yScale="log10", 
         Title="Individuals by Dose Cohort", xLab="Time", yLab="Concentration",
         fF="",facetByRow=".",facetByCol=".",
         fnrow=NULL, fncol=NULL,fscales="fixed",facetType='wrap',
         themeUpdate=list(),
         themeTextSize=14,
         themePlotTitleSize=1.2,
         themeAxisTxtSize=0.8,
         themeAxisTxtColour='black',
         themeAxisTitleTxtSize=0.9,
         themeAxisTitleColour='black',
         themePanelBackgroundFill='white',
         themePanelGridSize=NULL,
         themePanelGridColour='white',
         themePanelLineType=1,
         themePanelTitleSize=1.2,
         themePlotTitleColour='black',
         themePlotLegendPosition='right',
         srcAdd=TRUE,
         srcPath='.',
         srcName='script',
         figPath="../deliv/figure",
         figName="Rplot.pdf",
         ...)
{
  # if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
  # if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
  
                                        # Only update in the scope of this function
  if(preserveMarkByLevels){
    if(Color){ cleanScales <- setColorScale(shapeList = shape_pal()(6),drop=F) }else{ cleanScales <- setGrayScale(shapeList = shape_pal()(6),drop=F)}
  }
  
  if(facetByRow!="." & all(fF!="")){
    datFile[,facetByRow] <- factor(datFile[,facetByRow],fF[,1],fF[,2])
  }
  
  
  var_lvls=length(levels(datFile[[markBy]]))
  shp_aes=if(var_lvls<=6&markByType=="Discrete"){
    aes_string(shape=markBy) 
  }else{
    aes_string()  
  }
  
  aes_base=aes_string(x=xBy, y=sumType, group=groupBy, color=markBy, ymax="Max", ymin="Min")
  
  if(xScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',xBy))
  if(yScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',yBy))
  
  p1=
    ggplot(datFile, aes_base)+
      geom_line(shp_aes)+
        geom_point(shp_aes)+
          geom_errorbar()+
		scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
                  scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
                    labs(title=Title, x=xLab, y=yLab)
  
  if (!is.null(minorTicks)) p1=p1+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
  
                                        #Add in the faceting if it exists
  
  p1=p1%>%addFacet(facetType,facetByRow,facetByCol,fnrow,fncol,fscales)

  themeUpdate=theme(text=              element_text(size=themeTextSize),
                    axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                    axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                    plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                    panel.background = element_rect(fill = themePanelBackgroundFill),
                    panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
                    legend.position =  themePlotLegendPosition
  )
  
  if(markByType=='Discrete') p1=p1+cleanScales
  
  p1=p1+cleanTheme +themeUpdate
  
  p1 <- list(pList=list(p1),plotCols=1,plotRows=1,srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
  class(p1)<-c(class(p1),'TFL')
  return(p1)
  
  
}
