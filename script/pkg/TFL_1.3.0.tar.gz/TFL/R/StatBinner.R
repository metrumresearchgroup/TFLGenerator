#' @export
StatSummaryBinner <- ggproto("StatSummaryBinner", Stat,
                             required_aes = c("x", "y"),
                             
                             compute_group = function(data, scales, fun.data = NULL, fun.y = NULL,
                                                      fun.ymax = NULL, fun.ymin = NULL, fun.args = list(),
                                                      breaks_man=NULL,bins = 30, binwidth = NULL, origin = NULL,
                                                      right = FALSE,na.rm = FALSE) {
                               
                               fun <- make_summary_fun(fun.data, fun.y, fun.ymax, fun.ymin, fun.args)
                               
                               breaks <- bin2d_breaks(scales$x, breaks=breaks_man, origin, binwidth, bins, right = right)
                               
                               data$bin <- cut(data$x, breaks, include.lowest = TRUE, labels = FALSE)
                               out <- plyr::ddply(data, "bin", fun)
                               
                               locs <- bin_loc(breaks, out$bin)
                               out$x <- locs$mid
                               out$width <- if (scales$x$is_discrete()) 0.9 else locs$length
                               out
                             }
)

make_summary_fun <- function(fun.data, fun.y, fun.ymax, fun.ymin, fun.args) {
  if (!is.null(fun.data)) {
    # Function that takes complete data frame as input
    fun.data <- match.fun(fun.data)
    function(df) {
      do.call(fun.data, c(list(quote(df$y)), fun.args))
    }
  } else if (!is.null(fun.y) || !is.null(fun.ymax) || !is.null(fun.ymin)) {
    # Three functions that take vectors as inputs
    
    call_f <- function(fun, x) {
      if (is.null(fun)) return(NA_real_)
      do.call(fun, c(list(quote(x)), fun.args))
    }
    
    function(df, ...) {
      data.frame(
        ymin = call_f(fun.ymin, df$y),
        y = call_f(fun.y, df$y),
        ymax = call_f(fun.ymax, df$y)
      )
    }
  } else {
    message("No summary function supplied, defaulting to `mean_se()")
    function(df) {
      mean_se(df$y)
    }
  }
}

bin2d_breaks=function (scale, breaks = NULL, origin = NULL, binwidth = NULL, bins = 30, right = TRUE) 
{
  if (scale$is_discrete()) {
    breaks <- scale$get_breaks()
    return(-0.5 + seq_len(length(breaks) + 1))
  }
  if (!is.null(breaks)) 
    return(breaks)
  range <- scale$get_limits()
  if (is.null(binwidth) || identical(binwidth, NA)) {
    binwidth <- diff(range)/bins
  }
  stopifnot(is.numeric(binwidth), length(binwidth) == 1)
  if (is.null(origin) || identical(origin, NA)) {
    origin <- plyr::round_any(range[1], binwidth, floor)
  }
  stopifnot(is.numeric(origin), length(origin) == 1)
  breaks <- seq(origin, range[2] + binwidth, binwidth)
  adjust_breaks(breaks, right)
}

bin_loc=function (x, id) 
{
  left <- x[-length(x)]
  right <- x[-1]
  list(left = left[id], right = right[id], mid = ((left + right)/2)[id], 
       length = diff(x)[id])
}

adjust_breaks=function (x, right = TRUE) 
{
  diddle <- 1e-07 * stats::median(diff(x))
  if (right) {
    fuzz <- c(-diddle, rep.int(diddle, length(x) - 1))
  }
  else {
    fuzz <- c(rep.int(-diddle, length(x) - 1), diddle)
  }
  sort(x) + fuzz
}