#' @title Boxplots
#' @concept figure
#' @description Boxplot comparing (multiple) categorical variables to (multiple) 
#' continuous variables
#' 
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param catList list, list of two element vectors giving the column name and rename
#' @param conList list, list of two element vectors giving the column name and rename
#' @param plotCols integer, Number of columns to arrange plots into grid output, Default: 2
#' @param idVar character, Column name for ID, Default: 'NMID'
#' @param yLimit numeric, Two element vector giving the lower and upper limits of the y-axis, Default: NULL
#' @param yForm function|character,  Format of the y-axis variable tick label, Default: waiver()
#' @param yScale function|character,  Scale transformtion for the y-axis variable, Default: 'identity'
#' @param facetBy character, column name for figure faceting, Default: ''
#' @param notches boolean, should the boxplots be notched or not , Default: TRUE
#' @param minorTicks character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created, Default: NULL
#' @param minorTickNum integer, number of minor ticks between major ticks, Default: 10
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param srcAdd boolean, add source caption to output, Default: TRUE
#' @param srcPath character, source script path, Default: '.'
#' @param srcName character, source script name, Default: 'script'
#' @param figPath character, Output figure path, Default: '../deliv/figure'
#' @param figName character, Output figure name, Default: 'Rplot.pdf'
#' @param href numeric, location of horizontal reference line
#' @examples
#' data("twoCmt")
#' covCat(twoCmt,catList = list(c("SEX","Gender")), conList=list(c("DOSE","Dose")))
#' covCat(twoCmt,catList = list(c('SEX','Gender'),c('DOSE',"Dose")),conList = list(c("AGE","Age"),c('ETA1',expression(eta[1]))))
#' @return  A "TFL" object consisting of a list of plots and the intended layout for 
#' their display.  The figure can be rendered with the \code{print} or \code{plot} 
#' methods.
#' 
#' @details Most calculations are passed through to \link{boxplot.stats} with a few
#' important exceptions.  Each plot includes the adjusted R squared value and p-value
#' associated with an analysis of variance of the continuous variable on the categorical
#' variable.  Additionally, the inner 20% (i.e., the 40th and 60th percentiles)
#' of the continuous variable is shown as a shaded box overlayed on the traditional boxplot.
#' @export
#' @import dplyr ggplot2
#' @importFrom stats quantile aov lm
#' 
covCat <-
function(datFile, catList, conList, plotCols=2, idVar="NMID",
								yLimit=NULL,
							  yForm=waiver(),
							  yScale="identity",
								facetBy="", notches=TRUE,
         minorTicks=NULL,minorTickNum=10,
         themeUpdate=list(),
         themeTextSize=14,
         themePlotTitleSize=1.2,
         themeAxisTxtSize=0.8,
         themeAxisTxtColour='black',
         themeAxisTitleTxtSize=0.9,
         themeAxisTitleColour='black',
         themePanelBackgroundFill='white',
         themePanelGridSize=NULL,
         themePanelGridColour='white',
         themePanelLineType=1,
         themePanelTitleSize=1.2,
         themePlotTitleColour='black',
         srcAdd=TRUE,
         srcPath='.',
         srcName='script',
         figPath="../deliv/figure",
         figName="Rplot.pdf",
         href=0,
								...){
	
	#for individual plots, nCols=1, xBy and yBy is a single column name (such as "RACE" and "ETA1)
	#for a multiple plot object
	
	#set a new quantil function to show the middle 10%, normal boxplot does 5% 95% for whiskers, 25 and 75% for box, and 50% for inner line.
	f = function(x) {
		r = stats::quantile(x, probs = c(0.4, 0.4,0.5, 0.6, 0.6))
		names(r) <- c("ymin", "lower", "middle", "upper", "ymax")
		r
	}

	if(class(catList)!="list"){
	  catList <- list(catList)
	}
	if(class(conList)!="list"){
	  conList <- list(conList)
	}
	


	cats=sapply(catList, function(x){x[[1]][1]})
	catlabs=sapply(catList, function(x){if(length(x)==2) x[[2]][1] else x[[1]][1]})
	covs=sapply(conList, function(x){x[[1]][1]})
	covlabs=sapply(conList, function(x){if(length(x)==2) x[[2]][1] else x[[1]][1]})
	
	themeUpdate=ggplot2::theme(text=              ggplot2::element_text(size=themeTextSize),
	                  axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
	                  axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
	                  plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
	                  panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
	                  panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
	)
	
	if(yScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',yBy))
	
	pList=list()
	for (x in cats){
		for (y in covs){	
			#perform a one way analysis of variance
			mod1= stats::aov(as.formula(paste(y,"~",x)), data = datFile)
			modsum1 <- summary(mod1)
			my.p = ifelse(unlist(modsum1)["Pr(>F)1"] < 0.001, "p<.001", paste0("p=",signif(unlist(modsum1)["Pr(>F)1"], digits=3)))

			mod2 = stats::lm(datFile[,y]~factor(datFile[,x]), data = datFile)
			modsum2 <- summary(mod2)
			r2 = ifelse("adj.r.squared" %in% names(modsum2), paste("R^2=",signif(modsum2$adj.r.squared, digits=3)), "")

			temp=unique(datFile[,c(idVar,x)])
			numbers=data.frame(table(temp[,c(x)]))
			numbers <- numbers %>% dplyr::rename_(.dots = setNames('Var1', x))

			tempFile=merge(numbers, datFile, all=TRUE)
			tempFile[,x]=sprintf("%s\nn=%s", tempFile[,x], tempFile$Freq)
			
			tempFile[,x]=factor(tempFile[,x])
			p1=
			  ggplot2::ggplot(tempFile, aes_string(x=x, y=y))+
			  ggplot2::stat_boxplot(geom ='errorbar') +	
			  ggplot2::stat_summary(fun.data = f, geom="boxplot", fill="grey", alpha=.2, lty=2)+
			  ggplot2::geom_boxplot(notch=notches, fill="cadetblue3", alpha=0.6)+
			  ggplot2::labs(x=catlabs[[which(cats==x)]], y=covlabs[[which(covs==y)]], title=paste(r2,my.p,sep="  "))+
			  ggplot2::scale_y_continuous(breaks=pretty_breaks(),  limits=yLimit, labels=eval(yForm), trans=yScale)

			
			if(!is.null(href)) if(!is.na(href)) p1 = p1 + ggplot2::geom_hline(yintercept=href, lty=2)
			  
			if (!is.null(minorTicks)) p1=p1+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
			
			pList[[paste("plot",x, "vs", y, sep="")]]=p1+cleanTheme +themeUpdate
			
			}
	}
	
	p1=list(pList=pList,plotCols = as.numeric(plotCols),plotRows = 1,srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
	class(p1)<-c(class(p1),'TFL')
	
  return(p1)	
}
