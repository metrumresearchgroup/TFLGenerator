#' @title Concentration vs time profiles for groups of patients (spaghetti plot)
#' @concept figure
#' @description Longitundinal plot showing individual concentration vs time
#' profiles, including observed, conditional, and unconditional (on random effects)
#'  values of concentration
#' 
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param groupBy character, column name for groupings within the output, Default: 'NMID'
#' @param xBy character, Column name for x-axis, Default: 'TAFD'
#' @param yBy character, Column name for Y-axis, Default: 'DV'
#' @param markBy character, column name on which to mark by different colors, Default: 'DOSE'
#' @param markByType character, controls the type of variable expected mapped to markBy c("Discrete", "Continuous"), Default: 'Discrete'
#' @param preserveMarkByLevels boolean, to preserve the levels of the markBy variable, Default: F
#' @param Color boolean, controls if the plot has color aesthetic, Default: T
#' @param xLimit numeric, Two element vector giving the lower and upper limits of the x-axis, Default: NULL
#' @param yLimit numeric, Two element vector giving the lower and upper limits of the y-axis, Default: NULL
#' @param xForm function|character,  Format of the x-axis variable tick label, Default: waiver()
#' @param yForm function|character,  Format of the y-axis variable tick label, Default: waiver()
#' @param minorTicks character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created, Default: NULL
#' @param minorTickNum integer, number of minor ticks between major ticks, Default: 10
#' @param xScale function|character,  Scale transformtion for the x-axis variable, Default: 'identity'
#' @param yScale function|character,  Scale transformtion for the y-axis variable, Default: 'log10'
#' @param Title character, Figure title, Default: 'Individuals'
#' @param xLab character, Label of X-axis, Default: 'Time'
#' @param yLab character, Label of Y-axis, Default: 'Concentration'
#' @param fF character, Labels for the facet levels in the form "Level1,Label1;Level2,Label2", Default: ''
#' @param facetByRow character, Column names to use in row of facetType, Default: '.'
#' @param facetByCol character, Column names to use in column of facetType, Default: '.'
#' @param fnrow integer, Number of rows passed to facet_wrap, Default: NULL
#' @param fncol integer, Number of columns passed to facet_wrap, Default: NULL
#' @param fscales character, Scale type for facet_wrap c("fixed","free","free_y","free_x"), Default: 'fixed'
#' @param facetType character, type of faceting to use c(none='.','facet_wrap','facet_grid'), Default: 'wrap'
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param themePlotLegendPosition character, legend position, Default: 'right'
#' @param srcAdd boolean, add source caption to output, Default: TRUE
#' @param srcPath character, source script path, Default: '.'
#' @param srcName character, source script name, Default: 'script'
#' @param figPath character, Output figure path, Default: '../deliv/figure'
#' @param figName character, Output figure name, Default: 'Rplot.pdf'
#' @param ... 
#' @examples 
#' data("twoCmt")
#' twoCmt=twoCmt%>%dplyr::mutate(DOSE=factor(DOSE))
#' ConcvTimeInd(datFile = twoCmt)
#' ConcvTimeInd(datFile = twoCmt,facetByRow = 'SEX')
#' @return  A concentration vs time ggplot2 object of class \code{TFL} which
#' can be plotted or printed with the corresponding method.  
#' @export
#' @import ggplot2 dplyr

ConcvTimeInd <-
  function(datFile, groupBy="NMID", xBy="TAFD", yBy="DV", 
           markBy="DOSE", markByType="Discrete",preserveMarkByLevels=F,
           Color=T,
           xLimit=NULL, yLimit=NULL,
           xForm=waiver(), yForm=waiver(),
           minorTicks=NULL,minorTickNum=10,
           xScale="identity", yScale="log10", 
           Title="Individuals", xLab="Time", yLab="Concentration",fF="",
           facetByRow=".",facetByCol=".",
           fnrow=NULL, fncol=NULL,fscales="fixed",facetType='wrap',
           themeUpdate=list(),
           themeTextSize=14,
           themePlotTitleSize=1.2,
           themeAxisTxtSize=0.8,
           themeAxisTxtColour='black',
           themeAxisTitleTxtSize=0.9,
           themeAxisTitleColour='black',
           themePanelBackgroundFill='white',
           themePanelGridSize=NULL,
           themePanelGridColour='white',
           themePanelLineType=1,
           themePanelTitleSize=1.2,
           themePlotTitleColour='black',
           themePlotLegendPosition='right',
           srcAdd=TRUE,
           srcPath='.',
           srcName='script',
           figPath="../deliv/figure",
           figName="Rplot.pdf",
           ...)
  {
    
    if(!is.null(fnrow)){
      if(fnrow==""){ fnrow <- NULL }else{  fnrow=as.numeric(fnrow) }
    }
    if(!is.null(fncol)){
      if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol) }
    }
   
    # Only update in the scope of this function
    if(preserveMarkByLevels){
      if(Color){ 
        cleanScales <- setColorScale(shapeList = shape_pal()(6),drop=F) 
      }else{ 
          cleanScales <- setGrayScale(shapeList = shape_pal()(6),drop=F)}
    }
    
    if(facetByRow!="." & all(fF!="")){
      datFile[,facetByRow] <- factor(datFile[,facetByRow],fF[,1],fF[,2])
    }
    
    var_lvls=length(levels(datFile[[markBy]]))
    shp_aes=if(var_lvls<=6&markByType=="Discrete"){
      ggplot2::aes_string(shape=markBy) 
    }else{
      ggplot2::aes_string()  
    }
    
    aes_base=ggplot2::aes_string(x=xBy, y=yBy, group=groupBy, color=markBy)

    if(xScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',xBy))
    if(yScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',yBy))

    p1=ggplot2::ggplot(datFile, aes_base)+
      ggplot2::geom_line(shp_aes)+
      ggplot2::geom_point(shp_aes)+
      ggplot2::scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
      ggplot2::scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
      ggplot2::labs(title=Title, x=xLab, y=yLab)
    
    if (!is.null(minorTicks)) p1=p1+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
    
    #Add in the faceting
    p1=p1%>%addFacet(facetType,facetByRow,facetByCol,fnrow,fncol,fscales)
    
    themeUpdate=ggplot2::theme(text=     ggplot2::element_text(size=themeTextSize),
                      axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                      axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                      plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                      panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
                      panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
                      legend.position =  themePlotLegendPosition
    )
    if(markByType=='Discrete') p1=p1+cleanScales
    
    p1=p1+cleanTheme +themeUpdate

    p1=list(pList=list(p1),plotCols=1,plotRows=1,srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
    class(p1)<-c(class(p1),'TFL')
    return(p1)
    
  }
