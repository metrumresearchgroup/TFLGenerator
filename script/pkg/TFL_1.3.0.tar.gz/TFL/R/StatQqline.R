#' @export
#' @import ggplot2
#' @importFrom stats ppoints
StatQqLine <- ggplot2::ggproto("StatQQLine", ggplot2:::Stat,
                      # http://docs.ggplot2.org/current/vignettes/extending-ggplot2.html
                      # https://github.com/hadley/ggplot2/blob/master/R/stat-qq.r
                      
                      required_aes = c('sample'),
                      
                      compute_group = function(data, scales,
                                               distribution = stats::qnorm,
                                               dparams = list(),
                                               na.rm = FALSE) {
                        
                        qf <- function(p) do.call(distribution, c(list(p = p), dparams))
                        
                        n <- length(data$sample)
                        theoretical <- qf(stats::ppoints(n))
                        qq <- qq_line(data$sample, qf = qf, na.rm = na.rm)
                        line <- qq$intercept + theoretical * qq$slope
                        
                        data.frame(x = theoretical, y = line)
                      } 
)
