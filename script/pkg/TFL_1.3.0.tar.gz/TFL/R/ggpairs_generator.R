#' @title Correlation Comparison plot
#' @concept generator
#' @description Creates a grid ggplot object with R-squared and p-values indicated in corresponding upper trianges
#' @usage ggpairs_generator(datFile, xCols = grep("ETA", names(datFile), value = TRUE), xLimit = NULL, yLimit = NULL, xForm = waiver(), yForm = waiver(), xScale = "identity", yScale = "identity", facetBy = "", ...)
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param xCols character, Column name(s) for x-axis variable(s), Default: grep("ETA", names(datFile), value = TRUE)
#' @param xLab character, Label of X-axis, Default: xCols
#' @param xLimit numeric, Two element vector giving the lower and upper limits of the x-axis, Default: NULL
#' @param yLimit numeric, Two element vector giving the lower and upper limits of the y-axis, Default: NULL
#' @param xForm function|character,  Format of the x-axis variable tick label, Default: waiver()
#' @param yForm function|character,  Format of the y-axis variable tick label, Default: waiver()
#' @param xScale function|character,  Scale transformtion for the x-axis variable, Default: 'identity'
#' @param yScale function|character,  Scale transformtion for the y-axis variable, Default: 'identity'
#' @param facetBy character, column name for figure faceting, Default: ''
#' @param corstat character, "R2" for adjusted R^2 or "r" for Pearson correlation, Default: 'R2'
#' @param minorTicks character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created, Default: NULL
#' @param minorTickNum integer, number of minor ticks between major ticks, Default: 10
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param srcAdd boolean, add source caption to output, Default: TRUE
#' @param srcPath character, source script path, Default: '.'
#' @param srcName character, source script name, Default: 'script'
#' @param figPath character, Output figure path, Default: '../deliv/figure'
#' @param figName character, Output figure name, Default: 'Rplot.pdf'
#' @details Lower triangle shows comparison plots of diagonal values with line of best fit, upper triangle shows R squared and p values for these comparisons
#' @examples 
#' data("twoCmt")
#' ggpairs(twoCmt,xCols=c('ETA1','ETA2'))
#' ggpairs(twoCmt,xCols=c('ETA1','ETA2','ETA5'))
#' @return  returns ggplot object (grob) that must be saved or printed
#' @import ggplot2
#' @importFrom grid unit
#' @importFrom stats cor lm 
#' 
ggpairs_generator <-
function(datFile, xCols=grep("ETA", names(datFile), value=TRUE),
         xLab=xCols,
								 xLimit=NULL, yLimit=NULL,
								 xForm=waiver(), yForm=waiver(),
								 xScale="identity", yScale="identity",
								facetBy="", corstat="R2",
         minorTicks=NULL,minorTickNum=10,
         themeUpdate=list(),
         themeTextSize=14,
         themePlotTitleSize=1.2,
         themeAxisTxtSize=0.8,
         themeAxisTxtColour='black',
         themeAxisTitleTxtSize=0.9,
         themeAxisTitleColour='black',
         themePanelBackgroundFill='white',
         themePanelGridSize=NULL,
         themePanelGridColour='white',
         themePanelLineType=1,
         themePanelTitleSize=1.2,
         themePlotTitleColour='black',
         srcAdd=TRUE,
         srcPath='.',
         srcName='script',
         figPath="../deliv/figure",
         figName="Rplot.pdf",
								 ...){
	
	if(all(xCols=="") | is.null(xCols)) xCols <- grep("ETA", names(datFile), value=TRUE)
	names=factor(xCols, levels=xCols, labels=c(1:length(xCols)))

	themeUpdate=ggplot2::theme(text=     ggplot2::element_text(size=themeTextSize),
	                  axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
	                  axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
	                  plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
	                  panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
	                  panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
	)
	
	pList=list() #create an empty list
	
	for (i in names){
		i=as.numeric(i)
		for (j in names){	
			j=as.numeric(j)
			#fit the linear regression line
			mod1 = stats::lm(datFile[,xCols[i]]~datFile[,xCols[j]], data = datFile)
			modsum = summary(mod1)
			r2 = ifelse("adj.r.squared" %in% names(modsum), paste("R^2=",signif(modsum$adj.r.squared, digits=3)), "")
			r <- paste0("r=",
			            signif(stats::cor(datFile[,xCols[i]],datFile[,xCols[j]],use="pairwise.complete.obs",method="pearson"),digits=3))
			my.p =ifelse(((dim(modsum$coefficients)[1]>=2) & dim(modsum$coefficients)[2]>=4), 
			             {
			               ifelse(modsum$coefficients[2,4]>0.001, paste("p=",signif(modsum$coefficients[2,4],digits=3)), paste("p<0.001"))
			             },
			             "")
			
			if(i==j){
				pList[[paste("plot",i,j, sep="")]]=
				  ggplot2::ggplot() + 
				  ggplot2::annotate("text", x=.5, y=.5, label=xLab[i],size=as.numeric(themeTextSize)/2) + #7+(2-length(names))
				  ggplot2::theme(axis.text=ggplot2::element_blank(),
				                 axis.line=ggplot2::element_line(size=0),
				                 axis.title=ggplot2::element_blank(), 
				                 axis.ticks=ggplot2::element_line(size=0),
				                 plot.background=ggplot2::element_rect(fill='white',colour="black",size=1.15),
				                 panel.background=ggplot2::element_rect(fill='white',size=0),
				                 panel.grid.major = ggplot2::element_blank(), 
				                 panel.grid.minor = ggplot2::element_blank(),
				                 plot.margin=grid::unit(c(.1,.1,.1,0), "cm"))
				
			}
			if(j>i){
			  label <- ifelse(corstat=="R2", sprintf("%s\n%s",r2, my.p), sprintf("%s\n%s",r, my.p))
				pList[[paste("plot",i,j, sep="")]] <-
				  ggplot2::ggplot() + 
				  ggplot2::annotate("text", x=.5, y=.5, label=label, size=as.numeric(themeTextSize)/2 ) + #7+(2-length(names))
				  ggplot2::theme(axis.text=ggplot2::element_blank(),	
				                 axis.line=ggplot2::element_line(size=0),
				                 axis.title=ggplot2::element_blank(), 
				                 axis.ticks=ggplot2::element_line(size=0),
				                 plot.background=ggplot2::element_rect(fill='white',colour="black",size=1.15),
				                 panel.background=ggplot2::element_rect(fill='white',size=0),
				                 panel.grid.major = ggplot2::element_blank(),
				                 panel.grid.minor = ggplot2::element_blank(),
				                 plot.margin=grid::unit(c(.1,.1,.1,0), "cm"))
			}
			
			if(i>j){
				pList[[paste("plot",i,j, sep="")]]=
				  ggplot2::ggplot(datFile, aes_string(x=xCols[j], y=xCols[i]))+
				  ggplot2::geom_point(shape=79)+
				  ggplot2::geom_smooth(method="loess", se=FALSE, colour="red")+
				  ggplot2::labs(x=NULL, y=NULL)+
				  ggplot2::scale_x_continuous(breaks=pretty_breaks(), limits=xLimit, labels=eval(xForm), trans=xScale)+
				  ggplot2::scale_y_continuous(breaks=pretty_breaks(), limits=yLimit, labels=eval(yForm), trans=yScale)+
				  cleanTheme +themeUpdate +
				  ggplot2::theme(plot.background=ggplot2::element_rect(fill='white',colour='black',size=1.15))

				if (!is.null(minorTicks)) pList[[paste("plot",i,j, sep="")]]=pList[[paste("plot",i,j, sep="")]]+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
				
				if(j==1 & i!=as.numeric(names)[length(names)]) pList[[paste("plot",i,j,sep="")]] <- 
				    pList[[paste("plot",i,j,sep="")]] + 
				    ggplot2::theme(axis.text.x=ggplot2::element_text(size=0),axis.ticks=ggplot2::element_line(size=0))

				if(j>1 & i==as.numeric(names)[length(names)]) pList[[paste("plot",i,j,sep="")]] <- 
				    pList[[paste("plot",i,j,sep="")]] + 
				    ggplot2::theme(axis.text.y=ggplot2::element_text(size=0), axis.ticks.y=ggplot2::element_line(size=0))
				
				
			}
			
		}
	}

	p1=list(pList=pList,plotCols = length(xCols),plotRows = length(xCols),srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
	class(p1)<-c(class(p1),'TFL')
	return(p1)
	
}
