#' mi210 Data
#'
#' The mi210 data.frame has 600 rows and 23 columns. The data represents a one compartment full model with IV administration that has been post processed through the TFL generator.
#'
#' @docType data
#'
#' @usage data(mi210)
#'
#' @format An object of class \code{"data.frame"}
#'
#' @keywords datasets
#'
#' @references Metrum Research Group
#'
#'
#' @examples
#' data(mi210)
"mi210"