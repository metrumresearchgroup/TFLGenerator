#' @title Demographics table for continuous variables
#' @concept table
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param groupBy character, column name for groupings within the output, Default: list(c("STUDY", "Study"))
#' @param idVar character, Column name for ID, Default: 'NMID'
#' @param conList list, list of two element vectors giving the column name and rename, Default: list(c("AGE", "Age (years)"), c("HGTB", "Height (cm)"), c("WGTB", 
#'    "Weight (kg)"))
#' @param catList list, list of two element vectors giving the column name and rename, Default: list(c("DIS", "Disease"))
#' @param sigDig integer, number of significant digits, Default: 3
#' @param srcAdd boolean, add source caption to output, Default: TRUE
#' @param srcPath character, source script path, Default: '.'
#' @param srcName character, source script name, Default: 'script'
#' @param tblPath character, Output table path, Default: '../deliv/table'
#' @param tblName character, Output table name, Default: 'table.tex'
#' @seealso \code{\link[texPreview]{texPreview}}
#' @examples 
#'  require(texPreview)
#'  Knit<-!is.null(knitr::opts_knit$get('rmarkdown.pandoc.to')) #Check if in knit environment
#'  Chk<-interactive()||Knit #Check for Rstudio and knit environment
#' 
#' data("twoCmt")
#' 
#' if(!Knit) 
#' demogTabCont(twoCmt)
#' 
#' #Show Table in Viewer
#' Args=list(obj = demogTabCont(twoCmt),stem = paste0('demogTabContEx1'),imgFormat = 'png',ignore.stdout=TRUE)
#' if(Knit) Args=list(rt=rt,fd=fd)
#' if(Chk) do.call(texPreview,Args)
#'                     
#' @return LaTex table
#' @export
#' @import dplyr
#' @importFrom reshape2 melt dcast
#' @importFrom metrumrg map tabular
#' @importFrom plyr ddply dlply

demogTabCont <-
	function(datFile, 
	         groupBy=list(c("STUDY","Study")),
	         idVar="NMID",
					 conList=list(c("AGE", "Age (years)"), c("HGTB", "Height (cm)"), c("WGTB", "Weight (kg)")),
					 catList=list(c("DIS","Disease")),
					 sigDig=3,
					 srcAdd=TRUE,
					 srcPath='.',
					 srcName='script',
					 tblPath="../deliv/table",
					 tblName="table.tex")
		{ 
		
	  if(class(groupBy)!="list"){
	    groupBy <- list(groupBy)
	  }
	  if(class(catList)!="list"){
	    catList <- list(catList)
	  }
	  if(class(conList)!="list"){
	    conList <- list(conList)
	  }
	  grp=sapply(groupBy,function(x)x[[1]][1])
	  grplabs=sapply(groupBy,function(x)x[[2]][1])
		cons=sapply(conList, function(x){x[[1]][1]})
		conlabs=sapply(conList, function(x){x[[2]][1]})
		subData=datFile[!duplicated(datFile[c(idVar, grp)]),]
		
		cats=sapply(catList, function(x){x[[1]][1]})
		if(catList!=""){
		  catlabs=sapply(catList,function(x){if(length(x)==2) x[[2]][1] else x[[1]][1]}) 
		}else{
		  cats <- "whole"
		  catlabs=""
		  subData$whole <- ""
		}
		
		# New version of length which can handle NA's: if na.rm==T, don't count them
		length2 <- function (x, na.rm=TRUE) {
			if (na.rm){ sum(!is.na(x))}	else {length(x)}
		}
		
		subDataCon=plyr::dlply(subData, cats, function(statData){
		  
		  statData <- reshape2::melt(statData[,c(grp,cons)], id.vars=c(grp), variable.name="Parameter")
		  ###Analyze the continuous variables
		  statData <- plyr::ddply(statData, .variables=c(grp, "Parameter"),
		        .fun= function(xx) {
		          c( n     	= as.character(length2(xx[,"value"], na.rm=TRUE)),
		             Mean= signif(mean(xx[,"value"], na.rm=TRUE), digits=sigDig),
		             Median=signif(median(xx[,"value"], na.rm=TRUE), digits=sigDig),
		             sd=signif(sd(xx[,"value"], na.rm=TRUE), digits=sigDig),
		             CV=signif((sd(xx[,"value"], na.rm=TRUE)/mean(xx[,"value"], na.rm=TRUE)*100),digits=sigDig),
		             Min=signif(min(xx[,"value"], na.rm=TRUE),digits=sigDig),
		             Max=signif(max(xx[,"value"], na.rm=TRUE),digits=sigDig)
		          )
		        } )
		  statData[,grp] <- paste("\\quad", statData[,grp])
		  statData$value <- with(statData, sprintf("%s (%s) [%s-%s]",as.character(Mean),as.character(sd),as.character(Min),as.character(Max)))
		  statData=statData[,c(grp, "n","value", "Parameter")]
		  statData=reshape2::melt(statData, id.vars=c("Parameter", grp, "n"), measure.vars=c("value"))
		  reshape2::dcast(statData, formula=as.formula(sprintf("%s + n~ Parameter", grp)), value.var="value")
		  
		})
		

		wholeData=apply(as.data.frame(subData[,cons]),2,function(xx){
		  data.frame(n=as.character(length2(xx,na.rm=T)), 
		             Mean= signif(mean(xx, na.rm=TRUE), digits=sigDig),
		             Median=signif(median(xx, na.rm=TRUE), digits=sigDig),
		             sd=signif(sd(xx, na.rm=TRUE), digits=sigDig),
		             CV=signif((sd(xx, na.rm=TRUE)/mean(xx, na.rm=TRUE)*100),digits=sigDig),
		             Min=signif(min(xx, na.rm=TRUE),digits=sigDig),
		             Max=signif(max(xx, na.rm=TRUE),digits=sigDig)
		  )
		})
		names(wholeData) <- cons
		wholeDataval <- lapply(wholeData, 
		                       function(xx) sprintf("%s (%s) [%s-%s]",as.character(xx$Mean),
		                                            as.character(xx$sd),as.character(xx$Min),as.character(xx$Max)))
		
		wholeData <- cbind(n=wholeData[[1]]$n,as.data.frame(wholeDataval,stringsAsFactors = F))
		wholeData[grp] <- "{\\bfseries Total}"
		
		subDataCon[["Total"]] <- wholeData
		names(subDataCon) <- paste0(catlabs,": ", names(subDataCon))
		
		ltab <- do.call(rbind,subDataCon)
		names(ltab) <- metrumrg::map(names(ltab),from=c(grp,cons),to=c(grplabs,conlabs),strict = F)
		names(ltab) <- paste("{\\bfseries", names(ltab), "}")
		ltabi <- within(ltab, grp <- rep(1:length(subDataCon), times=sapply(subDataCon,nrow)))
		tex <- metrumrg::tabular(ltab,rules=c(1,1,1),
		        rowgroups=ltabi$grp,grid=T,
		        colgroups=rep(1,ncol(ltab)),
		        rowgrouprule=2)
		if(cats!="whole"){
		  mc <- sapply(names(subDataCon), function(xx) sprintf("\\multicolumn{%i}{c}{}\\\\ \\multicolumn{%i}{c}{{\\bfseries %s}}\\\\ \\hline", 
		                                                       ncol(ltab), ncol(ltab), xx))
		  index <- grep("\\\\ \\hline",tex,fixed=T)
		  index <- index[-length(index)]
		  neworder <- c(1:length(tex),index+.5)
		  tex <- c(tex,mc)[order(neworder)]      
		}
		
		if(srcAdd){
		  tblSplit=unlist(strsplit(tblName,'[.]'))
		  tblName=tblSplit[1]
		  tblExt='tex'
		  if(length(tblSplit)==2) tblExt=tblSplit[2]
		  
		  srcLab=sprintf('{\\raggedleft \\tiny Source code: %s/%s.R}',srcPath,srcName)
		  tblLab=sprintf('{\\raggedleft \\tiny Source file: %s/%s.%s}',tblPath,tblName,tblExt)
		  
		  tex=c(tex,' ',srcLab,' ','\\vspace{-5pt}',tblLab)
		}
		
		return(tex)
	}
