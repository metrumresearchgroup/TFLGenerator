#' @title Multipanel concentration vs time profiles for individual patients
#' @concept figure
#' @description Longitundinal plot showing individual concentration vs time
#' profile, including observed, conditional, and unconditional (on random effects)
#'  values of concentration
#' 
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param groupBy character, column name for groupings within the output, Default: 'NMID'
#' @param xBy character, Column name for x-axis, Default: 'TAFD'
#' @param yBy character, Column name for Y-axis, Default: 'DV'
#' @param ipredVar character, Column name of the individual prediction variable, Default: 'IPRE'
#' @param predVar character, Column name containing the conditional prediction, Default: 'PRED'
#' @param doseVar character, Column name of dosing variable  , Default: 'DOSE'
#' @param doseLab character, Column name of labels for the dosing variable, Default: 'mg/kg'
#' @param markBy character, column name on which to mark by different colors, Default: 'DOSE'
#' @param preserveMarkByLevels boolean, to preserve the levels of the markBy variable, Default: FALSE
#' @param Color boolean, controls if the plot has color aesthetic, Default: TRUE
#' @param rugVar character, Column name of variable to create rug layer (Default NULL), Default: NULL
#' @param rugVals numeric, vector of values rugVar is displayed, Default: 1
#' @param rugCols character, Color of rug ticks, Default: 'red'
#' @param blqVal numeric, defines the 'Below Level of Quantification (BLQ)' horizontal reference line, 
#' DEFAULT: NULL, Default: NULL
#' @param xLimit numeric, Two element vector giving the lower and upper limits of the x-axis, Default: NULL
#' @param yLimit numeric, Two element vector giving the lower and upper limits of the y-axis, Default: NULL
#' @param xForm function|character,  Format of the x-axis variable tick label, Default: waiver()
#' @param yForm function|character,  Format of the y-axis variable tick label, Default: waiver()
#' @param xScale function|character,  Scale transformtion for the x-axis variable, Default: 'identity'
#' @param yScale function|character,  Scale transformtion for the y-axis variable, Default: 'log10'
#' @param Title character, Figure title, Default: 'Individuals'
#' @param xLab character, Label of X-axis, Default: 'Time'
#' @param yLab character, Label of Y-axis, Default: 'Concentration'
#' @param fncol integer, Number of columns passed to facet_wrap, Default: 3
#' @param fnrow integer, Number of rows passed to facet_wrap, Default: 3
#' @param ID numeric, vector of the patient IDs to plot, Default: NULL
#' @param minorTicks character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created, 
#' Default: NULL
#' @param minorTickNum integer, number of minor ticks between major ticks, Default: 10
#' @param genAll boolean, generate all pages Default: TRUE
#' @param page numeric, vector of pages to output Default: 1
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param srcAdd boolean, add source caption to output, Default: TRUE
#' @param srcPath character, source script path, Default: '.'
#' @param srcName character, source script name, Default: 'script'
#' @param figPath character, Output figure path, Default: '../deliv/figure'
#' @param figName character, Output figure name, Default: 'Rplot.pdf'
#' @param ... 
#' @examples
#' data("twoCmt")
#' twoCmt=twoCmt%>%dplyr::mutate(DOSE=factor(DOSE))
#' \dontrun{ConcvTimeMult(datFile = twoCmt,ipredVar='IPRED')}
#' ConcvTimeMult(datFile = twoCmt,ipredVar='IPRED',genAll=FALSE,page=1)
#' ConcvTimeMult(datFile = twoCmt,ipredVar='IPRED',genAll=FALSE,page=2,fnrow =5,fncol=4)
#' 
#' rug.data=addlExpand( tab =file.path(find.package('TFL'),'external/mi210/510/510.tab'),
#' demog = file.path(find.package('TFL'),'external/mi210/poppk_wcovs.csv'),
#' group.vars = c('ID','EVID','AMT'),
#' demog.fillVars = c('HT','WT','CLCR','SEX','AGE'),
#' demog.keepVars = c('RATE')
#' )
#' 
#' ConcvTimeMult(datFile = rug.data,
#'               groupBy='ID',
#'               xBy = 'TIME',
#'               ipredVar = 'IPRED',
#'               genAll = FALSE,
#'               ID=1:9,
#'               rugVar = 'EVID',
#'               rugVals = 1)
#'
#' @return  A concentration vs time ggplot2 object of class \code{TFL} which
#' can be plotted or printed with the corresponding method.
#' @seealso \code{\link{addlExpand}}
#' @export
#' @import dplyr
#' @importFrom plyr llply
#' @importFrom reshape2 melt

ConcvTimeMult <-
  function(datFile,
           groupBy="NMID", xBy="TAFD", yBy="DV", ipredVar="IPRE", predVar="PRED", doseVar="DOSE", doseLab="mg/kg",
           markBy="DOSE", preserveMarkByLevels=FALSE, Color=TRUE,rugVar=NULL,rugVals=1,rugCols='red',blqVal=NULL,
           xLimit=NULL, yLimit=NULL,
           xForm=waiver(), yForm=waiver(),
           xScale="identity", yScale="log10", 
           Title="Individuals", xLab="Time", yLab="Concentration",
           fncol=3, fnrow=3, ID=NULL,
           minorTicks=NULL,minorTickNum=10,
           genAll=TRUE, page=1,
           themeUpdate=list(),
           themeTextSize=14,
           themePlotTitleSize=1.2,
           themeAxisTxtSize=0.8,
           themeAxisTxtColour='black',
           themeAxisTitleTxtSize=0.9,
           themeAxisTitleColour='black',
           themePanelBackgroundFill='white',
           themePanelGridSize=NULL,
           themePanelGridColour='white',
           themePanelLineType=1,
           themePanelTitleSize=1.2,
           themePlotTitleColour='black',
           srcAdd=TRUE,
           srcPath='.',
           srcName='script',
           figPath="../deliv/figure",
           figName="Rplot.pdf",
           ...)
  {
    
    if(any(ID%in%names(datFile))) stop('ID input must be unique values of the groupBy variable and not the column name (keep ID=NULL to include all IDs)')
    if(!all(ID %in% unique(datFile[,groupBy]))) stop('All ID values must be a subset of argument set in groupBy (keep ID=NULL to include all IDs)')
  
 
    if(class(yForm)=="character") yForm <- as.name(yForm)
    if(class(xForm)=="character") xForm <- as.name(xForm)
    if(doseVar=="" | (!doseVar%in%names(datFile))) doseVar <- NULL
    if(doseLab=="" | is.null(doseVar)) doseLab <- NULL

      # Only update in the scope of this function
      if(preserveMarkByLevels){
        if(Color){ cleanScales <- setColorScale(drop=FALSE,shapeList = shape_pal()(6)) }else{ cleanScales <- setGrayScale(drop=FALSE,shapeList = shape_pal()(6))}
      }

      if(!is.null(ID)) datFile <- datFile[datFile[,groupBy]%in%ID,]
      
      datFile$groupBy <- datFile[,groupBy]
      
     n.tot=as.numeric(fnrow)*as.numeric(fncol)
    
     d=sort(unique(datFile[,groupBy]))
     plotIdx=split(d, ceiling(seq_along(d)/n.tot))

     if((!genAll) & (!any(page%in%0))) plotIdx=plotIdx[page]

     if(xScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',xBy))
     if(yScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',yBy))
     
      pList=plyr::llply(plotIdx,function(idx){

        df=datFile[datFile[,groupBy]%in%idx,]
        df=reshape2::melt(df, id.vars=c(groupBy, xBy, doseVar,'EVID'), measure.vars=c(yBy, predVar, ipredVar))
        df$variable=factor(df$variable, levels=c(yBy, predVar, ipredVar), labels=c("Observed", "Population Predicted", "Individual Predicted"))
        df$facet_id=paste0("ID=",df[,groupBy],", ",df[,doseVar]," ",doseLab)
        df$facet_id=gsub('[ \t]+$','',df$facet_id)
        if(grepl("^.+?,$",df$facet_id[1])) df$facet_id=gsub(',','',df$facet_id)
        facetLvl=unique(df$facet_id)
        if(length(facetLvl)<n.tot) {
          facetLvlTemp=sapply(1:n.tot,function(x) paste0(rep(' ',x),collapse=''))
          facetLvlTemp[1:length(facetLvl)]=facetLvl
          facetLvl=facetLvlTemp
        }

        df$facet_id=factor(df$facet_id,levels=facetLvl)
        var_lvls=length(levels(df[['variable']]))
        pt_aes=if(var_lvls<=6){
          ggplot2::aes_string(shape="variable") 
        }else{
          ggplot2::aes_string()  
        }

        g=is.null(rugVar)

        p1=ggplot2::ggplot(data=df%>%dplyr::filter(!is.na(value)), ggplot2::aes_string(x=xBy, y="value", color="variable"))+
          ggplot2::geom_line(aes_string(lty="variable"),show.legend = g)+
          ggplot2::geom_point(pt_aes,show.legend = g)+
          ggplot2::scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
          ggplot2::scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
          ggplot2::labs(x=xLab, y=yLab, shape=NULL, lty=NULL, color=NULL) +
          ggplot2::scale_shape_manual( values = c("O", ".", "."))+
          ggplot2::scale_colour_manual(values = c('black', 'black','blue'))+
          ggplot2::scale_linetype_manual( values=c(0,1,3))+
          ggplot2::facet_wrap(~facet_id,scales='free',dir='v',nrow=as.numeric(fnrow),ncol=as.numeric(fncol),drop=FALSE)

        if(!g){
          rug.filter=ifelse(is.null(doseVar),sprintf('%s%%in%%%s',rugVar,rugVals),sprintf('%s%%in%%%s&%s!=0',rugVar,rugVals,doseVar))
          p1=p1+ggplot2::geom_rug(sides='b',data=df%>%dplyr::filter_(.dots=rug.filter),colour=rugCols)
        }
        
        if(!is.null(blqVal)){
          p1=p1+ggplot2::geom_hline(yintercept=blqVal,linetype=2,size=0.5,alpha=0.35) 
        }
                
        if (!is.null(minorTicks)) p1=p1+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
        
        themeUpdate=ggplot2::theme(text=              ggplot2::element_text(size=themeTextSize),
                          axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                          axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                          plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                          panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
                          panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
                          strip.background = ggplot2::element_rect(colour='white')
        )
        
        p1=p1+cleanTheme +themeUpdate + ggplot2::theme(plot.margin=unit(c(0,0.5,0.25,0.25),"cm"),
                                                       legend.position = 'bottom',
                                                       legend.background = ggplot2::element_rect(colour='black'))
      
        p1
      })
    
      p1=lapply(pList,function(p){
        pout=list(pList=list(p),plotCols=1,plotRows=1,srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath) 
        class(pout)<-c(class(pout),'TFL')
        pout
      })
      
      return(p1)
      
  
  }
