#' @name addMinMax
#' @title Add additional plotting columns
#' @description Add on function for summarySE
#' @param data_se data.frame, output from the summarySE() function
#' @param measurevar character, column name of dependent variable, Default: 'DVmean'
#' @param devvar character, deviation variable c("sd","se"), Default: 'sd'
#' @param na.rm boolean, remove missing, Default: TRUE
#' @examples 
#' newFile=summarySE(twoCmt, measurevar="DV", groupvars=c("TAFD", "DOSE"))
#' addMinMax(newFile, measurevar="mean", devvar="sd")
#' @keywords summarize
#' @export

addMinMax <-
function(data_se, measurevar="DVmean", devvar="sd", na.rm=TRUE) {	
	
  if (na.rm) data_se=data_se[!is.na(data_se[,measurevar]),]
	
	data_se$Max=data_se[,measurevar] + abs(data_se[,devvar])
	data_se$Max[is.na(data_se[,devvar])]=data_se[is.na(data_se[,devvar]), measurevar]
	data_se$Min=data_se[,measurevar] -abs(data_se[,devvar])
	data_se$Min[is.na(data_se[,devvar])]=data_se[is.na(data_se[,devvar]), measurevar]
	
	return(data_se)
}
