#' Two Compartment Model
#'
#' The twoCmt data.frame has 1901 rows and 45 columns. The data represents a two compartment model that has been post processed through the TFL generator.
#'
#' @docType data
#'
#' @usage data(twoCmt)
#'
#' @format An object of class \code{"data.frame"}
#'
#' @keywords datasets
#'
#' @references Metrum Research Group
#'
#'
#' @examples
#' data(twoCmt)
"twoCmt"