#' @title Saves a graphic object to a plot file (or creates a new file and saves it)
#' @description Saves the current graphic object as a png to a file of pngs
#' @usage savePlot(plotName, directory, saveName = as.character(plotName))
#' @param plotName name (not character) of the plot object to save
#' @param directory character path to the project directory in which the PNG folder should exists
#' @param saveName character name by which to record the grob
#' @return returns nothing, saves grob as png and returns the "active" window back to rStudio
#' @export

savePlots <-
function(plotName, directory, saveName=as.character(plotName)){
	dir.create(directory,showWarning=FALSE)
	dir.create(sprintf("%s/PNG/", directory),showWarning=FALSE)
	
	height=ifelse(grepl("GOF",plotName), 11*7.5/8.5, 4.5)
	
	png(file=sprintf("%s/PNG/%s.png", directory, saveName), width = 7.5, height = height, units="in", res=150)
	print(plotName)
	dev.off()
	
}
