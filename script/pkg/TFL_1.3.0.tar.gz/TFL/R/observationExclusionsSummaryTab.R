#' @title Summary table for excluded observations
#' @description Expects the presence of a dataframe call "observationExclusions" 
#' in the global environment.  Typically this is created by the GUI.
#' @export
#' @import dplyr
#' @importFrom rtf RTF addTable done

observationExclusionsSummaryTab <-
	function(
	  tmpDir = NULL
	)
		{ 
	  if(is.null(tmpDir)){
	    tmpDir <- tempdir()
	    dir.create(tmpDir,recursive = T)
	  }else{
	    if(!dir.exists(tmpDir)){
	      return()
	    }
	  }
	  
		datFile <- try(observationExclusions)
		if(class(datFile)=="try-error") datFile <-  get("observationExclusions",.GlobalEnv)
		
		datFile0 <- datFile
		
		datFile <- datFile0%>%
		                  dplyr::group_by(excl_reasons) %>% 
		                  dplyr::summarise(N=length(NMID), 
		                                   perc=round(length(NMID)/nrow(datFile0)*100,1))
		
		datFile <- rbind(datFile, c("Total",nrow(datFile0),"100.0"))
		
		
		names(datFile) <- metrumrg::map(names(datFile), 
		                      from=c("excl_reasons","perc"),
		                      to=c("Reason for exclusion", "% of Exclusions"),
		                      strict=F)
		
		nms <- names(datFile)
		datFile <- as.data.frame(datFile)
		names(datFile) <- nms
		

		f <- file.path(tmpDir,"observationExclusionsSummary.doc")
		rtf <- rtf::RTF(f,font.size=11)
		rtf::addTable(rtf,datFile)
		rtf::done(rtf)
		p1 <- datFile
		return(list(preview=datFile, file=f))
	}
