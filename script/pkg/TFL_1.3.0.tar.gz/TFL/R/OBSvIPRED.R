#' @title Standard goodness of fit plots for observed versus predicted values
#' @concept figure
#' @description Yields a ggplot object comparing observed values to predicted values
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param xBy character, Column name for X-axis, Default: 'IPRE'
#' @param yBy character, Column name for Y-axis, Default: 'DV'
#' @param groupBy character, column name for groupings within the output, Default: NULL
#' @param markBy character, column name on which to mark by different colors, Default: NULL
#' @param markByType character, controls the type of variable expected mapped to markBy c("Discrete", "Continuous"), Default: 'Discrete'
#' @param obsLabel character, if set to a column name annotation of text is used instead of points, Default: NULL
#' @param smoothType function|character, function used for interpolation, Default: ifelse(nrow(datFile) <= 1000,"loess","gam")
#' @param xLimit numeric, Two element vector giving the lower and upper limits of the X-axis, Default: ''
#' @param xBreaks numeric, Vector input for X-axis breaks, Default: waiver()
#' @param xForm function|character,  Format of the X-axis variable tick label, Default: waiver()
#' @param xScale function|character,  Scale transformtion for the X-axis variable, Default: scales::log10_trans()
#' @param Title character, Figure title, Default: ''
#' @param xLab character, Label of X-axis, Default: 'Individiual Prediction'
#' @param yLab character, Label of Y-axis, Default: 'Observed Plasma Concentration'
#' @param facetBy character, column name for figure faceting, Default: ''
#' @param fF character, Labels for the facet levels in the form "Level1,Label1;Level2,Label2", Default: ''
#' @param fnrow integer, Number of rows passed to facet_wrap, Default: ''
#' @param fncol integer, Number of columns passed to facet_wrap, Default: ''
#' @param fscales character, Scale type for facet_wrap c("fixed","free","free_y","free_x"), Default: 'fixed'
#' @param minorTicks character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created, Default: NULL
#' @param minorTickNum integer, number of minor ticks between major ticks, Default: 10
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param themePlotLegendPosition character, legend position, Default: 'right'
#' @param ... 
#' @details Standard goodness of fit showing DV versus population prediction or individual prediction.
#' @examples 
#' data("twoCmt")
#' OBSvIPRED(twoCmt%>%dplyr::filter(DV>0),xBy='IPRED')
#' OBSvIPRED(twoCmt,xBy='IPRED',xScale = 'identity',markBy = 'SEX')
#' @return  returns ggplot object (grob) that must be saved or printed
#' @export
#' @import ggplot2
#' @import dplyr
#' @importFrom scales log10_trans log_trans
#' 
OBSvIPRED <-
function(datFile, xBy="IPRE", yBy="DV", 
									 groupBy=NULL, markBy=NULL, 
                   markByType="Discrete",
                   obsLabel=NULL,
                   smoothType=ifelse(nrow(datFile) <= 1000,"loess","gam"),
									 xLimit="", 
				 					 xBreaks=waiver(), 
									 xForm=waiver(), 
									 xScale=scales::log10_trans(), 
									 Title="", xLab="Individiual Prediction", yLab="Observed Plasma Concentration",
									 facetBy="", fF="",fnrow="", fncol="",fscales="fixed",
         minorTicks=NULL,minorTickNum=10,
         themeUpdate=list(),
         themeTextSize=14,
         themePlotTitleSize=1.2,
         themeAxisTxtSize=0.8,
         themeAxisTxtColour='black',
         themeAxisTitleTxtSize=0.9,
         themeAxisTitleColour='black',
         themePanelBackgroundFill='white',
         themePanelGridSize=NULL,
         themePanelGridColour='white',
         themePanelLineType=1,
         themePanelTitleSize=1.2,
         themePlotTitleColour='black',
         themePlotLegendPosition='right',
									 ...)
{
  if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
  if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
  
  if(facetBy!="" & all(fF!="")){
    datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
  }
  
  # if(fscales=="fixed"){
    if(xLimit==""){
      xLimit=range(datFile[,c(xBy,yBy)], na.rm=TRUE)		
      if("log10" %in% paste0('scales::',as.character(xScale))){
        xLimit[1]=max(
          floor(min(datFile[which(datFile[,xBy]>0 & datFile[,yBy]>0),c(xBy,yBy)], na.rm=TRUE)/10)*10,
          1E-6)
      }
    }
    if("log" %in% paste0('scales::',as.character(xScale))){
      datFile=datFile[datFile[,xBy]>0,]
      datFile=datFile[datFile[,yBy]>0,]
      xBreaks=lnseq(datFile[c(xBy,yBy)])
      if(!is.null(xLimit)){xBreaks=xBreaks[xBreaks>=xLimit[1] & xBreaks<=xLimit[2]]}
      yBreaks=xBreaks
    }
    if("log10" %in% as.character(xScale)){
      datFile=datFile[datFile[,xBy]>0,]
      datFile=datFile[datFile[,yBy]>0,]
      xBreaks=lseq(datFile[c(xBy,yBy)])
      if(!is.null(xLimit)){xBreaks=xBreaks[xBreaks>=xLimit[1] & xBreaks<=xLimit[2]]}
      yBreaks=xBreaks
    }
  # }
	
  if(!is.null(markBy)&markByType=='Discrete'){
    if(class(datFile[,markBy])!="factor") datFile[,markBy] <- factor(datFile[,markBy], sort(unique(datFile[,markBy])))
  }
  
	p1=
		ggplot2::ggplot(datFile, ggplot2::aes_string(x=xBy, y=yBy, colour=markBy))+
	  ggplot2::stat_smooth(formula = y ~ x, se=FALSE, na.rm=TRUE, color="red", lty=2, lwd=2, method=smoothType)+
	  ggplot2::scale_y_continuous(limits=xLimit, breaks=xBreaks, labels=eval(xForm), trans=xScale)+
	  ggplot2::scale_x_continuous(labels=eval(xForm), breaks=xBreaks, limits=xLimit, trans=xScale)+		
	  ggplot2::geom_abline(intercept=0, slope=1)+
	  ggplot2::coord_fixed(ratio = 1, xlim = xLimit, ylim = xLimit)+
	  ggplot2::labs(title=Title, x=xLab, y=yLab)
	
	if(is.null(obsLabel)) p1=p1+ggplot2::geom_point(shape=1)
	if(!is.null(obsLabel)) p1=p1+ggplot2::geom_text(ggplot2::aes_string(label=obsLabel))
	
	#Add in better ticks if the scale is log10
	if (!is.null(minorTicks)) p1=p1+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
	
	
	#Add in the faceting if it exists
	if (facetBy!=""){
		p1=p1 +ggplot2::facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,ncol=fncol,scales=fscales)
	}
	
	themeUpdate=ggplot2::theme(text=     ggplot2::element_text(size=themeTextSize),
	                  axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
	                  axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
	                  plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
	                  panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
	                  panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
	                  legend.position =  themePlotLegendPosition
	)
	
	if(!is.null(markBy)&markByType=='Discrete'){
	  p2=try(p1+cleanScales)
	  if(!"try-error"%in%class(p2)) p1 <- p2
	}
	  	
	p1=p1+cleanTheme +themeUpdate
	
	p1=list(pList=list(OBSvIPRED=p1),plotCols=1,plotRows=1)
	class(p1)<-c(class(p1),'TFL')
	return(p1)
	
}
