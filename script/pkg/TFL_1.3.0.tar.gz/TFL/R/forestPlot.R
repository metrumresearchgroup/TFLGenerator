#' @title FUNCTION_TITLE
#' @description FUNCTION_DESCRIPTION
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param annotDF data.frame, contains the necessary variables to annotate plot (see details)
#' @param xBy character, Column name for x-axis, Default: 'GRP'
#' @param yBy character, Column name for Y-axis, Default: 'med'
#' @param PtRng character, vector of column names in annotDF that corresond to point ranges,
#'  Default: c(Min = "lo", Max = "hi", Col = "Covariate")
#' @param HLine numeric, value of horizontal line reference line intercept, Default: 'exp(X1)'
#' @param Rect list, list that contains data for the boundaries of the shaded area,
#' Default: list(MinY = "exp(X1)*0.8", MaxY = "exp(X1)*1.25", MinX = -Inf, MaxX = Inf, Alpha = 0.15)
#' @param Title character, Figure title, Default: ''
#' @param yLab character, Label of Y-axis, Default: ''
#' @param xLab character, Label of X-axis, Default: ''
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param themePlotLegendPosition character, legend position, Default: 'right'
#' @param srcAdd boolean, add source caption to output, Default: TRUE
#' @param srcPath character, source script path, Default: '.'
#' @param srcName character, source script name, Default: 'script'
#' @param figPath character, Output figure path, Default: '../deliv/figure'
#' @param figName character, Output figure name, Default: 'Rplot.pdf'
#' @param ... 
#' @return OUTPUT_DESCRIPTION
#' @details DETAILS
#' @examples 
#' EXAMPLE1 
#'
#' @import ggplot2
forestPlot=function(
  datFile,annotDF,
  xBy="GRP",yBy="med",
  PtRng=c(Min="lo",Max="hi",Col="Covariate"),
  HLine="exp(X1)",
  Rect=list(MinY="exp(X1)*0.8",MaxY="exp(X1)*1.25",MinX=-Inf,MaxX=Inf,Alpha=.15),
  Title="", yLab="", xLab="",
  themeUpdate=list(),
  themeTextSize=14,
  themePlotTitleSize=1.2,
  themeAxisTxtSize=0.8,
  themeAxisTxtColour='black',
  themeAxisTitleTxtSize=0.9,
  themeAxisTitleColour='black',
  themePanelBackgroundFill='white',
  themePanelGridSize=NULL,
  themePanelGridColour='white',
  themePanelLineType=1,
  themePanelTitleSize=1.2,
  themePlotTitleColour='black',
  themePlotLegendPosition='right',
  srcAdd=TRUE,
  srcPath='.',
  srcName='script',
  figPath="../deliv/figure",
  figName="Rplot.pdf",
  ...){
  
  p1=ggplot2::ggplot(data=datFile) +
    ggplot2::geom_pointrange(aes_string(x=xBy,y=yBy, ymin=PtRng$Min, ymax=PtRng$Max, colour=PtRng$Col), lwd=1) + 
    ggplot2::geom_hline(aes_string(yintercept=HLine), lty=2,data=annotDF) + 
    ggplot2::geom_rect(aes_string(ymin = Rect$MinY, 
                         ymax = Rect$MaxY, 
                         xmin = Rect$MinX, 
                         xmax = Rect$MaxX),
                         alpha=Rect$Alpha,
                        data=annotDF)+
    ggplot2::coord_flip() +
    ggplot2::labs(title=Title,y=yLab,x=xLab) +
    .colSet1(name="Covariate")
  
  if (!is.null(minorTicks)) p1=p1+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
  
  themeUpdate=ggplot2::theme(text=     ggplot2::element_text(size=themeTextSize),
                    axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                    axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                    plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                    panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
                    panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
                    legend.position =  themePlotLegendPosition
  )
  
  p1=p1+cleanTheme +themeUpdate
  p1=list(pList=list(forestPlot=p1),plotCols=1,plotRows=1,srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
  
  class(p1)<-c(class(p1),'TFL')

  return(p)
}