#' @title Creates a confidence interval around a prediction interval
#' @description Using an internal bootstrapping algorithm, creates a confidence estimate of the prediction interval line (used in VPC development)
#' @param ciVar numeric, numerical vector to predict confidence interval
#' @param ci numeric, confidence around the prediction intervals
#' @param ConfInt numeric, defines confidence intervals to display
#' @param type character, Returns the upper or lower value c("high","low"), Default: 'low'
#' @details Utilizes quantile for basic calculation
#' @examples 
#' qLowLow=ci.mean(ciVar=xx[,col], ci=ci, ConfInt[1], "low") #where xx[,col] is a ddply internal call
#' @export
#' @importFrom boot boot boot.ci

ci.mean <-
function(x, ci, ConfInt, type="low") {
	if(type=="low"){n=2}
	if(type=="high"){n=3}

	temp <- tryCatch(
			if(length(unique(x)) > 1) {
				boot::boot.ci(boot::boot(x, f.quantile, R=50, probs=ConfInt), na.rm=TRUE, conf=ci,type=c("norm"))$normal[1,n]
			},
	error=function(e) e,
	warning=function(w) w)

	if(!is.null(temp)){
		if("error" %in% class(temp))
		{
			temp=mean(x)
		}
	}
	
	if(is.null(temp)){temp=mean(x)}

	return(temp)
	
}
