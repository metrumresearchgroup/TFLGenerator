#' @title Add facets to ggplot object
#' @description Add faceting to a ggplot2 object
#' @param p gg, ggplot object
#' @param facetType character, type of faceting to use c('facet_wrap','facet_grid')
#' @param facetByRow character, Column names to use in row of facetType, Default: '.'
#' @param facetByCol character, Column names to use in column of facetType, Default: '.'
#' @param fnrow integer,  Number of rows passed to facet_wrap, Default: NULL
#' @param fncol integer,  Number of columns passed to facet_wrap, Default: NULL
#' @param fscales character,  Scale type for facet_wrap c("fixed","free","free_y","free_x"), Default: 'fixed'
#' @return gg
#' @export 
#' @import ggplot2
addFacet=function(p,facetType,facetByRow='.',facetByCol='.',fnrow=NULL,fncol=NULL,fscales='fixed'){
  if(facetByRow!="."||facetByCol!="."){
    eval(parse(text=paste('pF<-',facetByRow,'~',facetByCol)))
    if(facetType=='wrap'){
      if(facetByRow!="."&facetByCol==".") eval(parse(text=paste('pF<-~',facetByRow)))
      if(facetByRow=="."&facetByCol!=".") eval(parse(text=paste('pF<-~',facetByCol)))
      p=p +ggplot2::facet_wrap(pF,nrow=fnrow,ncol=fncol,scales=fscales)
    } 
    if(facetType=='grid') p=p +ggplot2::facet_grid(pF,scales=fscales)
  }
  p
}
