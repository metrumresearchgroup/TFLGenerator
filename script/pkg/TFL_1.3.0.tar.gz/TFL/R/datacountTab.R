#' @title datacountTab
#' @concept table
#' @description Table that depicts the frequency by groups and exclusion criteria
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param groupBy list, list of two element vectors giving the column name and rename, Default: list(c("STUDY", "Study Phase"))
#' @param idVar character, Column name for ID, Default: 'NMID'
#' @param exclVar list, named list of two element vectors giving the column label and flag to indicate what the 
#' value of the column is associated with exclusion, Default: list(BLQ = list(label = "BLQ", flag = TRUE))
#' @param srcAdd boolean, add source caption to output, Default: TRUE
#' @param srcPath character, source script path, Default: '.'
#' @param srcName character, source script name, Default: 'script'
#' @param tblPath character, Output table path, Default: '../deliv/table'
#' @param tblName character, Output table name, Default: 'table.tex'
#' @seealso \code{\link[texPreview]{texPreview}}
#' @examples
#'  require(texPreview)
#'  Knit<-!is.null(knitr::opts_knit$get('rmarkdown.pandoc.to')) #Check if in knit environment
#'  Chk<-interactive()||Knit #Check for Rstudio and knit environment
#' 
#'  datFile=twoCmt%>%dplyr::mutate(BLQ=(DV<=100&DV>0))
#'  datFile$rndGroup=sample(1:5,size = nrow(datFile),replace = T)
#'  datFile$NODOSE=datFile$DV==0
#'  out=datacountTab(datFile,
#'          groupBy = list(c("STUDY","Study Phase"),c('rndGroup','Randomization Group')),
#'          exclVar=list(BLQ=list(label='BLQ',flag=TRUE),NODOSE=list(label='No Dose',flag=TRUE))
#'  )
#'  
#' if(!Knit) 
#' 
#' out
#' 
#' #Show Table in Viewer
#' Args=list(obj = out,stem = paste0('datacountTabEx1'),imgFormat = 'png',ignore.stdout=TRUE)
#' if(Knit) Args=list(rt=rt,fd=fd)
#' if(Chk) do.call(texPreview,Args)
#' 
#' @export
#' @import dplyr
#' @importFrom reshape2 melt dcast
#' @importFrom metrumrg map tabular
#' 
datacountTab=function(datFile,
                 groupBy=list(c("STUDY","Study Phase")),
                 idVar="NMID",
                 exclVar=list(BLQ=list(label='BLQ',flag=TRUE)),
                 srcAdd=TRUE,
                 srcPath='.',
                 srcName='script',
                 tblPath="../deliv/table",
                 tblName="table.tex"
                 ){
   
   grpBy=sapply(groupBy,'[',1)
   grpLbl=sapply(groupBy,'[',2)
   
   out=datFile%>%
     dplyr::select_(.dots = c(grpBy,idVar))%>%
     dplyr::distinct()%>%
     dplyr::count_(grpBy)%>%
     dplyr::rename(N=n)%>%
     dplyr::left_join(datFile%>%dplyr::count_(grpBy),by=grpBy)
   
   if(!is.null(exclVar)){
     eVar=names(exclVar)
     eVal=data.frame(flag=eVar,value=sapply(exclVar,function(x) x$flag))
     eLbl=sapply(exclVar,function(x) x$label)
     
     eForm=as.formula(paste0(paste0(grpBy,collapse='+'),'~flag'))
     eOut=eVal%>%
       dplyr::left_join(
         datFile%>%
           dplyr::select_(.dots=c(grpBy,eVar))%>%
           reshape2::melt(.,id=grpBy,variable='flag'),by=c('flag','value'))%>%
       dplyr::count_(c(grpBy,'flag'))%>%
       reshape2::dcast(.,eForm,value.var='n',fill = 0)
     
     out=out%>%left_join(eOut,by=grpBy)
   } 
   names(out)[which(names(out)%in%grpBy)]=grpLbl
   if(!is.null(exclVar)) names(out)[which(names(out)%in%names(eLbl))]=eLbl
   tex=metrumrg::tabular(out)
   
   if(srcAdd){
     tblSplit=unlist(strsplit(tblName,'[.]'))
     tblName=tblSplit[1]
     tblExt='tex'
     if(length(tblSplit)==2) tblExt=tblSplit[2]
     
     srcLab=sprintf('{\\raggedleft \\tiny Source code: %s/%s.R}',srcPath,srcName)
     tblLab=sprintf('{\\raggedleft \\tiny Source file: %s/%s.%s}',tblPath,tblName,tblExt)
     
     tex=c(tex,' ',srcLab,' ','\\vspace{-5pt}',tblLab)
   }
   
   return(tex)
 }