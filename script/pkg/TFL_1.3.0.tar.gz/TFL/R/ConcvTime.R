#' @title Concentration vs time profiles for individuals
#' @concept figure
#' @description Longitundinal plot showing individual concentration vs time
#' profiles, including observed, conditional, and unconditional (on random effects)
#'  values of concentration
#' 
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param xBy character, Column name for x-axis, Default: 'TAFD'
#' @param yBy character, Column name for Y-axis, Default: 'DV'
#' @param idVar character, Column name for ID, Default: 'NMID'
#' @param ID numeric, vector of the patient IDs to plot, Default: unique(datFile[, idVar])[1]
#' @param predVar character, Column name containing the conditional prediction, Default: 'PRED'
#' @param ipredVar character, Column name of the individual prediction variable, Default: 'IPRE'
#' @param xLimit numeric, Two element vector giving the lower and upper limits of the x-axis, Default: NULL
#' @param yLimit numeric, Two element vector giving the lower and upper limits of the y-axis, Default: NULL
#' @param xForm function|character,  Format of the x-axis variable tick label, Default: waiver()
#' @param yForm function|character,  Format of the y-axis variable tick label, Default: waiver()
#' @param xScale function|character,  Scale transformtion for the x-axis variable, Default: 'identity'
#' @param yScale function|character,  Scale transformtion for the y-axis variable, Default: 'log10'
#' @param minorTicks character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created, Default: NULL
#' @param minorTickNum integer, number of minor ticks between major ticks, Default: 10
#' @param Title character, Figure title, Default: sprintf("Subject \%s", ID)
#' @param xLab character, Label of X-axis, Default: 'Time'
#' @param yLab character, Label of Y-axis, Default: 'Concentration'
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param themePlotLegendPosition character, legend position, Default: 'right'
#' @param srcAdd boolean, add source caption to output, Default: TRUE
#' @param srcPath character, source script path, Default: '.'
#' @param srcName character, source script name, Default: 'script'
#' @param figPath character, Output figure path, Default: '../deliv/figure'
#' @param figName character, Output figure name, Default: 'Rplot.pdf'
#' @param ... 
#' @examples 
#' data("twoCmt")
#' ConcvTime(datFile = twoCmt,ID = '1',ipredVar = 'IPRED')
#' ConcvTime(datFile = twoCmt,ID = '1',ipredVar = 'IPRED',minorTicks = 'b')
#' @return  A concentration vs time ggplot2 object of class \code{TFL} which
#' can be plotted or printed with the corresponding method 
#' @export
#' @import ggplot2 dplyr
#' @importFrom reshape2 melt

ConcvTime <-
function(datFile, xBy="TAFD", yBy="DV", 
  									    idVar="NMID",
  									 	  ID=unique(datFile[,idVar])[1],
  									 	  predVar="PRED", ipredVar="IPRE", 
  										  xLimit=NULL, yLimit=NULL,
  										  xForm=waiver(), yForm=waiver(),
  										  xScale="identity", yScale="log10", 
                       minorTicks=NULL,minorTickNum=10,
  									 	 Title=sprintf("Subject %s", ID), xLab="Time", yLab="Concentration",
                       themeUpdate=list(),
                       themeTextSize=14,
                       themePlotTitleSize=1.2,
                       themeAxisTxtSize=0.8,
                       themeAxisTxtColour='black',
                       themeAxisTitleTxtSize=0.9,
                       themeAxisTitleColour='black',
                       themePanelBackgroundFill='white',
                       themePanelGridSize=NULL,
                       themePanelGridColour='white',
                       themePanelLineType=1,
                       themePanelTitleSize=1.2,
                       themePlotTitleColour='black',
                       themePlotLegendPosition='right',
                       srcAdd=TRUE,
                       srcPath='.',
                       srcName='script',
                       figPath="../deliv/figure",
                       figName="Rplot.pdf",
											...)
{
  
 
	datFile=datFile[datFile[,idVar]==ID,]
	
	if(xScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',xBy))
	if(yScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',yBy))	
	
	datFile=reshape2::melt(datFile, id.vars=c(idVar, xBy), measure.vars=c(yBy, predVar, ipredVar))
	datFile$variable=factor(datFile$variable, levels=c(yBy, predVar, ipredVar), labels=c("Observed", "Population Predicted", "Individual"))

	p1=ggplot2::ggplot(data=datFile, ggplot2::aes_string(x=xBy, y="value", color="variable", shape="variable", lty="variable"))+
	  ggplot2::geom_line()+
	  ggplot2::geom_point()+
	  ggplot2::scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
	  ggplot2::scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
	  ggplot2::labs(title=Title, x=xLab, y=yLab, shape=NULL, lty=NULL, color=NULL) +
	  ggplot2::scale_shape_manual( values = c("O", ".", "."))+
	  ggplot2::scale_colour_manual(values = c('black', 'black','blue'))+
	  ggplot2::scale_linetype_manual( values=c(0,1,3))

	if (!is.null(minorTicks)) p1=p1+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
	
	themeUpdate=ggplot2::theme(text=     ggplot2::element_text(size=themeTextSize),
	                  axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
	                  axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
	                  plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
	                  panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
	                  panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
	                  legend.position =  themePlotLegendPosition
	                  )

	p1=p1+cleanTheme +themeUpdate
	p1=list(pList=list(ConcvTime=p1),plotCols=1,plotRows=1,srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
	
	class(p1)<-c(class(p1),'TFL')
	
	return(p1)
	
}
