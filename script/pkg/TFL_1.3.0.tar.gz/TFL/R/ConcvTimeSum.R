#' @title Concentration vs time profiles for groups of patients (summary plot)
#' @description Longitundinal plot showing summaries of concentration vs time profiles,
#'  in which both the x (binning) and y axis transformation may be specified.
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param xBy character, Column name for x-axis, Default: 'TAFD'
#' @param yBy character, Column name for Y-axis, Default: 'DV'
#' @param markBy character, column name on which to mark by different colors, Default: 'DOSE'
#' @param markByType character, controls the type of variable expected mapped to markBy c("Discrete", "Continuous"), 
#' Default: 'Discrete'
#' @param preserveMarkByLevels boolean, to preserve the levels of the markBy variable, Default: FALSE
#' @param geoms character, vector of geom layers to overlay on plot, Default: c("point", "line", "errorbar")
#' @param xcut numeric|function, numeric vector, function that returns bin limits for x axis variable 
#' or NULL then ggplot2:::bin2d_breaks is used, Default: NULL
#' @param sumFn function, summary function for the y axis variable Default: mean_se
#' @param xLimit numeric, Two element vector giving the lower and upper limits of the x-axis, Default: NULL
#' @param yLimit numeric, Two element vector giving the lower and upper limits of the y-axis, Default: NULL
#' @param xForm function|character,  Format of the x-axis variable tick label, Default: waiver()
#' @param yForm function|character,  Format of the y-axis variable tick label, Default: waiver()
#' @param minorTicks character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created, Default: NULL
#' @param minorTickNum integer, number of minor ticks between major ticks, Default: 10
#' @param xScale function|character,  Scale transformtion for the x-axis variable, Default: 'identity'
#' @param yScale function|character,  Scale transformtion for the y-axis variable, Default: 'log10'
#' @param Title character, Figure title, Default: 'Individuals'
#' @param xLab character, Label of X-axis, Default: 'Time'
#' @param yLab character, Label of Y-axis, Default: 'Concentration'
#' @param fF character, Labels for the facet levels in the form "Level1,Label1;Level2,Label2", Default: ''
#' @param facetByRow character, Column names to use in row of facetType, Default: '.'
#' @param facetByCol character, Column names to use in column of facetType, Default: '.'
#' @param fnrow integer, Number of rows passed to facet_wrap, Default: NULL
#' @param fncol integer, Number of columns passed to facet_wrap, Default: NULL
#' @param fscales character, Scale type for facet_wrap c("fixed","free","free_y","free_x"), Default: 'fixed'
#' @param facetType character, type of faceting to use c(none='.','facet_wrap','facet_grid'), Default: 'wrap'
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param themePlotLegendPosition character, legend position, Default: 'right'
#' @param srcAdd boolean, add source caption to output, Default: TRUE
#' @param srcPath character, source script path, Default: '.'
#' @param srcName character, source script name, Default: 'script'
#' @param figPath character, Output figure path, Default: '../deliv/figure'
#' @param figName character, Output figure name, Default: 'Rplot.pdf'
#' @param ... 
#' @return gg
#' @examples 
#' ConcvTimeSum(twoCmt)
#' twoCmt=twoCmt%>%dplyr::mutate_each(funs(factor),SEX,DOSE)
#' qc=quantile(twoCmt$TAFD,probs = seq(0,1,.1)) 
#' 
#' #bin:bin2d_breaks, summary:mean_se
#'   ConcvTimeSum(twoCmt,xcut = c(0,10,100,130,190))
#'
#' #bin:bin2d_breaks, summary:mean_se, colour:SEX
#'   ConcvTimeSum(twoCmt,markBy = 'SEX')
#'  
#' #bin:c(0,10,100,130,190), summary:mean_se, colour:SEX
#'   ConcvTimeSum(twoCmt,xcut = c(0,10,100,130,190))
#'
#' #bin:deciles, summary:mean_se
#'   ConcvTimeSum(twoCmt,xcut = qc)
#' 
#' #bin:deciles, summary:mean_cl_boot
#'   ConcvTimeSum(twoCmt,sumFn = mean_cl_boot)
#'
#' #bin:deciles, summary:mean_cl_boot, colour:DOSE
#'   ConcvTimeSum(twoCmt,markBy = 'DOSE',xcut = qc,sumFn = mean_cl_boot)
#' 
#' #bin:deciles, summary:mean_cl_boot, colour:DOSE, facet:SEX
#'   ConcvTimeSum(twoCmt,markBy = 'DOSE',xcut = qc,sumFn = mean_cl_boot,facetByRow = 'SEX')
#'   
#' @export
#' @import ggplot2
ConcvTimeSum <-
  function(datFile, xBy="TAFD", yBy="DV", 
           markBy="DOSE", markByType="Discrete",preserveMarkByLevels=FALSE,
           geoms=c('point','line','errorbar'),xcut=NULL,sumFn=mean_se,
           xLimit=NULL, yLimit=NULL,
           xForm=waiver(), yForm=waiver(),
           minorTicks=NULL,minorTickNum=10,
           xScale="identity", yScale="log10", 
           Title="Individuals", xLab="Time", yLab="Concentration",fF="",
           facetByRow=".",facetByCol=".",
           fnrow=NULL, fncol=NULL,fscales="fixed",facetType='wrap',
           themeUpdate=list(),
           themeTextSize=14,
           themePlotTitleSize=1.2,
           themeAxisTxtSize=0.8,
           themeAxisTxtColour='black',
           themeAxisTitleTxtSize=0.9,
           themeAxisTitleColour='black',
           themePanelBackgroundFill='white',
           themePanelGridSize=NULL,
           themePanelGridColour='white',
           themePanelLineType=1,
           themePanelTitleSize=1.2,
           themePlotTitleColour='black',
           themePlotLegendPosition='right',
           srcAdd=TRUE,
           srcPath='.',
           srcName='script',
           figPath="../deliv/figure",
           figName="Rplot.pdf",
           ...)
  {
    
    if(!is.null(fnrow)){
      if(fnrow==""){ fnrow <- NULL }else{  fnrow=as.numeric(fnrow) }
    }
    if(!is.null(fncol)){
      if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol) }
    }
    
    if(facetByRow!="." & all(fF!="")){
      datFile[,facetByRow] <- factor(datFile[,facetByRow],fF[,1],fF[,2])
    }
    
    var_lvls=length(levels(datFile[[markBy]]))
    shp_aes=if(var_lvls<=6&markByType=="Discrete"){
      ggplot2::aes_string(shape=markBy) 
    }else{
      ggplot2::aes_string()  
    }
    
    aes_base=ggplot2::aes_string(x=xBy, y=yBy, colour=markBy)

    if(xScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',xBy))
    if(yScale%in%c('log','log10')) datFile=datFile%>%dplyr::filter_(.dots=sprintf('%s>0',yBy))
    
    p1=ggplot2::ggplot(datFile, aes_base)+
      lapply(geoms,function(g) {
        stat_summary_binner(fun.data=sumFn,mapping=shp_aes,geom=g,breaks_man=xcut)
        }) +
      ggplot2::scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
      ggplot2::scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
      ggplot2::labs(title=Title, x=xLab, y=yLab)

    if (!is.null(minorTicks)) p1=p1+annotation_ticks(ticks_per_base = minorTickNum,sides = minorTicks)
    
    #Add in the faceting
    p1=p1%>%addFacet(facetType,facetByRow,facetByCol,fnrow,fncol,fscales)
    
    rel=ggplot2:::rel
    themeUpdate=theme(text=              element_text(size=themeTextSize),
                      axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                      axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                      plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                      panel.background = element_rect(fill = themePanelBackgroundFill),
                      panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
                      legend.position =  themePlotLegendPosition
    )
    
    if(markByType=='Discrete') p1=p1+cleanScales
    
    p1=p1+cleanTheme +themeUpdate
    
    p1 <- list(pList=list(p1),plotCols=1,plotRows=1,srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
    class(p1)<-c(class(p1),'TFL')
    
    return(p1)
  }
