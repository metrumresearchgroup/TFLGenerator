#' @title Multipanel distribution
#' @concept generator
#' @param datFile data.frame, contains the necessary variables to produce the output
#' @param idVar character, Column name for ID, Default: 'NMID'
#' @param conList list, list of two element vectors giving the column name and rename, 
#' Default: list(c("WGTB", "Weight (kg)"), c("AGE", "Age (years)"), c("CL", "Creatinine Clearance (mL/min)"))
#' @param notches boolean, should the boxplots be notched or not , Default: T
#' @param order character, Some permutation of "Density", "QQ", and "Boxplot", Default: c("Density", "QQ", "Boxplot")
#' @param qqDist function, distribution of theoretical quantiles passed to the QQ plot, Default: stats::qnorm
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param srcAdd boolean, add source caption to output, Default: TRUE
#' @param srcPath character, source script path, Default: '.'
#' @param srcName character, source script name, Default: 'script'
#' @param figPath character, Output figure path, Default: '../deliv/figure'
#' @param figName character, Output figure name, Default: 'Rplot.pdf'
#' @param ... 
#' @examples 
#' data("twoCmt")
#' distMult(twoCmt)
#' distMult(twoCmt,order = c("Boxplot","Density","QQ"))
#' @export
#' @import dplyr ggplot2
#' @importFrom stats quantile dnorm
#' @importFrom grid unit
distMult <-
	function(datFile, 
	         idVar="NMID",
					 conList=list(c("WGTB","Weight (kg)"),
					              c("AGE", "Age (years)"),
					              c("CL",  "Creatinine Clearance (mL/min)")
					 ),
					 notches=T,
					 order=c("Density","QQ","Boxplot"),
					 qqDist=stats::qnorm,
					 themeUpdate=list(),
					 themeTextSize=14,
					 themePlotTitleSize=1.2,
					 themeAxisTxtSize=0.8,
					 themeAxisTxtColour='black',
					 themeAxisTitleTxtSize=0.9,
					 themeAxisTitleColour='black',
					 themePanelBackgroundFill='white',
					 themePanelGridSize=NULL,
					 themePanelGridColour='white',
					 themePanelLineType=1,
					 themePanelTitleSize=1.2,
					 themePlotTitleColour='black',
					 srcAdd=TRUE,
					 srcPath='.',
					 srcName='script',
					 figPath="../deliv/figure",
					 figName="Rplot.pdf",
					 ...
	)
					 
		{ 
	  f = function(x) {
	    r = stats::quantile(x, probs = c(0.4, 0.4,0.5, 0.6, 0.6))
	    names(r) <- c("ymin", "lower", "middle", "upper", "ymax")
	    r
	  }
	  if(class(conList)!="list"){
	    catList <- list(catList)
	  }

		cons=sapply(conList, function(x){x[[1]][1]})
		conLabs=sapply(conList, function(x){x[[2]][1]})

		themeUpdate=ggplot2::theme(text=     ggplot2::element_text(size=themeTextSize),
		                  axis.text =        ggplot2::element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
		                  axis.title =       ggplot2::element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
		                  plot.title =       ggplot2::element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
		                  panel.background = ggplot2::element_rect(fill = themePanelBackgroundFill),
		                  panel.grid.major=  ggplot2::element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
		)

		pList <- lapply(cons, function(xBy){
		  
		  newDat=data.frame(matrix(,ncol=3))
		  names(newDat)=c(xBy, "normFit", "meanCol")
		  
		  xx=	datFile[, xBy]
		  if(length(xx)>200){
		    padx=c(
		      seq(from=min(xx, na.rm=TRUE)-abs(min(xx, na.rm=TRUE)), to=min(xx, na.rm=TRUE), length.out=10),
		      xx,
		      seq(from=max(xx,na.rm=TRUE), to=max(xx,na.rm=TRUE)+abs(max(xx,na.rm=TRUE)), length.out=10)
		    )
		  }else{
		    padx <- xx
		  }
		  normFit=stats::dnorm(x=padx, mean=mean(xx, na.rm=TRUE), sd=sd(xx, na.rm=TRUE))
		  meanCol=rep(mean(xx, na.rm=TRUE), times=length(padx))
		  foo=data.frame(cbind(padx, normFit, meanCol))
		  names(foo)=c(xBy, "normFit", "meanCol")
		  newDat=rbind(newDat, foo)
		  newDat=newDat[!is.na(newDat$normFit),]
		  newDat=unique(newDat)
		  datFile=merge(datFile, newDat, all=TRUE)

		  datFile[,xBy]=as.numeric(datFile[,xBy])
		  datFile$normFit=as.numeric(datFile$normFit)
		  datFile$meanCol=as.numeric(datFile$meanCol)
		  
		  if(length(conLabs)>1) xLab <- conLabs[xBy == cons]

		  dens=
		    ggplot2::ggplot(datFile, ggplot2::aes_string(x=xBy))	+
		    cleanScales+
		    ggplot2::geom_density(colour="dodgerblue3", adjust=3, kernel="gaussian",lwd=1.25)+
		    ggplot2::geom_histogram(aes(y=..density..),colour="white", fill="deepskyblue", alpha=.4)+
		    ggplot2::geom_vline(aes(xintercept=meanCol), colour="red")+	
		    ggplot2::labs(x=xLab) + 
		    cleanTheme +themeUpdate
		  
		  box=				
		    ggplot2::ggplot(datFile, ggplot2::aes_string(y=xBy, x=1))+
		    ggplot2::stat_boxplot(geom ='errorbar') +	
		    ggplot2::geom_boxplot(notch=notches, fill="dodgerblue3", alpha=0.4, outlier.shape=20)+
		    # stat_summary(fun.data = f, geom="boxplot", fill="grey", alpha=.2, lty=2)+
		    ggplot2::geom_hline(data=data.frame(med=median(datFile[,xBy])), aes(yintercept=med), colour="darkgrey", lty=2)+
		    labs(x="", y=xLab)+
		    ggplot2::scale_y_continuous(breaks=pretty_breaks())+
		    ggplot2::xlim(c(0,2)) + 
		    ggplot2::theme(panel.background = ggplot2::element_blank(),
		          axis.line=ggplot2::element_line(),
		          axis.text.x=ggplot2::element_blank(),
		          axis.ticks.x=ggplot2::element_blank(),
		          panel.border=ggplot2::element_blank(), 
		          plot.margin=grid::unit(c(.1,0,.1,0), "cm"))+
		    cleanTheme +themeUpdate
		    
		  qq =
		    ggplot2::ggplot(datFile, ggplot2::aes_string(sample=xBy))	+
		    cleanScales+
		    ggplot2::stat_qq(distribution = qqDist,na.rm=TRUE)+
		    stat_qqline(distribution = qqDist)+
		    ggplot2::labs(x="Quantiles of Standard Normal", y=xLab)+
		    cleanTheme +themeUpdate
		  
		  
		  list(dens=dens, qq=qq, box=box)[match(order,c("Density","QQ","Boxplot"))]
		})

		pList2=unlist(pList,recursive = F)
		p1=list(pList=pList2,plotCols = 3,plotRows = length(pList),srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
		class(p1)<-c(class(p1),'TFL')
		return(p1)

	}
