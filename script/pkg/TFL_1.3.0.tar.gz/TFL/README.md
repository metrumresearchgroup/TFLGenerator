# TFL

The MetrumRG TFL generator R package

## GitBook

Documentation plus executed examples:

https://metrumresearchgroup.github.io/TFL/

## Installation

The simplest way to do this is to use `devtools::install_github`.  
As this is a private repository, you'll need to use a git token (https://github.com/settings/tokens).  
Generate the token, copy the token value, and then add the "GITHUB_PAT" environment variable to your session:

`Sys.getenv(GITHUB_PAT=<token id>)`

Alternatively, you can set this in .Renviron to persist across sessions.  Once you've done this, install with:

`devtools::install_github("metrumresearchgroup/TFL")`


## Metworx-v2.1 libmagick depenency:


Metworx-v2.1 is missing a dependency at the AMI level (`libmagick++-dev`).  You can install this dependency with:

`sudo apt-get install -y libmagick++-dev`

The current `pkgSetup.R` (`svn+ssh://mc1.metrumrg.com/common/repo/svn-mrg-packageManagment`) should address this for you.

## Shiny app

This package does have an accompanying shiny application for report generation; for setup instructions see the TFLGenerator repository:

https://github.com/metrumresearchgroup/TFLGenerator





