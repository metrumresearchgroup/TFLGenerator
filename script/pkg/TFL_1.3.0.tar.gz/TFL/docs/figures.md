# TFL book guide
Metrum Research Group  
`r Sys.Date()`  

# Preface {-}

<!--chapter:end:index.Rmd-->


# Tables

<!--chapter:end:01-Tables.Rmd-->

# Figures

## ConcvTime
        


        


```
## Scale for 'x' is already present. Adding another scale for 'x', which
## will replace the existing scale.
```

<!--html_preserve--><div id="htmlwidget-4c200e35147eb0c98ecd" style="width:672px;height:100px;" class="slickR html-widget"></div>
<script type="application/json" data-for="htmlwidget-4c200e35147eb0c98ecd">{"x":[{"divName":"ConcvTime-up","divType":"img","obj":[null],"slickOpts":{"slidesToShow":1,"slidesToScroll":1}},{"divName":"ConcvTime-down","divType":"img","obj":[null],"slickOpts":{"dots":true,"slidesToScroll":1,"slidesToShow":0,"centerMode":true,"focusOnSelect":true}}],"evals":[],"jsHooks":[]}</script><!--/html_preserve-->


<!--chapter:end:02-Figures.Rmd-->

