#' @param minorTickNum Integer, number of minor ticks between major ticks
#' @param minorTicks Character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created
#' @param theme* Various controls for the ggplot2 theme
