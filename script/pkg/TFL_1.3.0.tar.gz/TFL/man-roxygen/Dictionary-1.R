#' @param ... 
#' @param .drop                boolean, indicates dropping of columns
#' @param ADDL                 character, Column name of Additional Implicit Doses 
#' @param AMT                  character, Column name of Dose Amount
#' @param binBy                numeric|function, either a single numeric vector or a function that defines bins
#' @param binned               boolean, bins the x axis values
#' @param binWidth             numeric, histogram bin width
#' @param blqVal               numeric, defines the 'Below Level of Quantification (BLQ)' horizontal reference line, DEFAULT: NULL
#' @param catList              list, list of two element vectors giving the column name and rename
#' @param ci                   numeric, confidence around the prediction intervals
#' @param ciPM                 numeric, confidence interval when using predicted median CI for shading
#' @param ciVar                numeric, numerical vector to predict confidence interval
# @param Color Logical, colored or greyscale?
#' @param Color                boolean, controls if the plot has color aesthetic
#' @param ConfInt              numeric, defines confidence intervals to display
#' @param conList              list, list of two element vectors giving the column name and rename
#' @param conList_x            list, list of two element vectors giving the column name and rename (X-axis)
#' @param conList_y            list, list of two element vectors giving the column name and rename (Y-axis)
#' @param corstat              character, "R2" for adjusted R^2 or "r" for Pearson correlation
# @param data                  data.frame, output of a NM run containing ER-SSAP standard column names and numeric-only columns
#' @param data_se              data.frame, output from the summarySE() function
#' @param dataLimits           list, data parsing list as returned by \code{\link{cleanparse}}
#' @param dataTrans            character, Not used outside of the app
#' @param datFile              data.frame, contains the necessary variables to produce the output
#' @param demog                data.frame, contains demographic varaibles
#' @param demog.fillVars       character, vector of variables in demog to fill (Last Observation Carried Forward)
#' @param demog.keepVars       character, vector of variables in demog to keep without filling NAs
#' @param devvar               character, deviation variable c("sd","se")
#' @param directory            character, path to the project directory in which the PNG folder should exists
#' @param doseCol              character, column name of dosing information, used if doseCol=TRUE
#' @param doseCor              boolean, apply dose correction
#' @param doseLab              character, Column name of labels for the dosing variable
#' @param doseVar              character, Column name of dosing variable  
#' @param EVID                 character, Column name of event id
#' @param facetBy              character, column name for figure faceting
#' @param facetFact            character, Labels for the facet levels in the form "Level1,Label1;Level2,Label2"
#' @param fF                   character, Labels for the facet levels in the form "Level1,Label1;Level2,Label2"
#' @param figName              character, Output figure name
#' @param figPath              character, Output figure path
#' @param file                 character, Path to file location
#' @param filename             character, File name for output
#' @param fname                character, File name for output
#' @param facetType            character, type of faceting to use c(none='.','facet_wrap','facet_grid')
#' @param facetByRow           character, Column names to use in row of facetType
#' @param facetByCol           character, Column names to use in column of facetType
#' @param fncol                integer, Number of columns passed to facet_wrap
#' @param fnrow                integer, Number of rows passed to facet_wrap
#' @param fscales              character, Scale type for facet_wrap c("fixed","free","free_y","free_x")
#' @param grobPath             character, string path name to the file containing grobs
#' @param group.vars           character, vector of id variables to transpose data object
#' @param groupBy              character, column name for groupings within the output
#' @param groupvars            character, vector of column names of recorded variables
# (these are the only columns that will be kept)
#' @param height               numeric, indicates the height of *png output (inches)
#' @param ID                   numeric, vector of the patient IDs to plot
#' @param idVar                character, Column name for ID
#' @param II                   character, Column name of Interdosing Interval
#' @param includeCI            boolean, Adds confidence interval ribbon to the plot
#' @param ipredVar             character, Column name of the individual prediction variable
#' @param lowerBound           numeric, lower bound for y axis
#' @param markBy               character, column name on which to mark by different colors
#' @param markByAdd            character, a label to be appended to all levels of the mark factor
#' @param markByType           character, controls the type of variable expected mapped to markBy c("Discrete", "Continuous")
#' @param measurevar           character, column name of dependent variable
# @param measurevardependent variable
#' @param minorTickNum         integer, number of minor ticks between major ticks
#' @param minorTicks           character, sides to add minorticks, t,b,l,r; if NULL (default) no minor ticks are created
#' @param na.rm                boolean, remove missing
#' @param notches              boolean, should the boxplots be notched or not 
#' @param OffDiagonals         boolean, include the off diagonal values in the table presentation
#' @param order                character, Some permutation of "Density", "QQ", and "Boxplot"
#' @param p                    gg, ggplot object
#' @param PI                   numeric, prediction interval quantiles
#' @param PIns                 numeric, prediction interval quantiles when using "no shading" for shading type
#' @param pList                list, list of plots
#' @param plot                 gg|list, ggplot or list of ggplots to save, DEFAULT: ggplot2::last_plot()
#' @param plotCols             integer, Number of columns to arrange plots into grid output
#' @param plotName             name, object name of the plot object to save
# @param plotRow integer; number of rows
#' @param plotRows             integer, Number of rows to arrange plots into grid output
#' @param predCol              character, Column name containing population prediction
#' @param predCor              boolean, Population prediction correction
#' @param predVar              character, Column name containing the conditional prediction
#' @param preserveMarkByLevels boolean, to preserve the levels of the markBy variable
#' @param project              character, Home directory of the NONMEM Run, Default: setwd()
#' @param qf                   function, quantiles for a probability
#' @param qqDist               function, distribution of theoretical quantiles passed to the QQ plot, Default: stats::qnorm
#' @param removeFixed          boolean, Remove all fixed values (nonzero) from the output table
#' @param rugCols              character, Color of rug ticks, Default: 'red'
#' @param rugVals              numeric, vector of values rugVar is displayed, Default: 1
#' @param rugVar               character, Column name of variable to create rug layer (Default NULL)
#' @param runno                character, Vector of run NONMEM numbers
#' @param saveCSV              character, Save the output table as a *.csv file within the parent directory
#' @param saveFig              character, The output table as a *.png within the parent directory
#' @param saveName             character, Name by which to record the grob
#' @param shadingType          character, Shading type to create c("predicted median", "simulated percentiles", "no shading")
#' @param shadingTypeShape     character, Shading shape to create c("Each Percentile",NULL)
#' @param shape                character, shape of plot output c("squares", "rectangles", "panel")
# @param Sig numeric significant figures to display in the table
#' @param sigDig               integer, number of significant digits
#' @param simCol               character, column name that holds the simulation replicate number
#' @param smooth               boolean, generate a loess curve
#' @param srcName              character, source script name
#' @param srcPath              character, source script path
#' @param stratBy              list, single two element vector giving the stratification variable and its label
#' @param sumThis              boolean, summarize this data on \code{sumType} (\code{sumVar})
#' @param sumType              character, One of "N", "median", "mean", "sd", "se", or "ci" as calculated
#' @param sumVar               character, Column name used to create intervals around \code{sumType}
#' @param tab                  connection|data.frame, Tab file from NONMEM run
#' @param tblName              character, Output table name
#' @param tblPath              character, Output table path
#' @param timeBy               character, Column name for the time variable
#' @param timeFmt              character, format for time axis tick labels
#' @param timeLab              character, label for the time axis title
#' @param timeLimit            numeric, Two element vector giving the lower and upper limits of the time axis
#' @param timeScale            function|character,  Scale transformtion for the time-axis variable
#' @param Title                character, Figure title
# @param type character indicating the type of information to be accessed
#' @param type                 character, Returns the upper or lower value c("high","low")
#' @param unTransform          boolean, Indicates whether to revert transformed parameter estimates
# Looks for "LOGD" in the title feild, without this defaults to all thetas
#' @param View                 boolean, View the output table in the Rstudio interface
#' @param width                numeric, Indicates the width of *png output (inches)
# @param x ggplot object or list of ggplot objects
# @param x numerical vector (or data.frame column) to predict confidence interval
#' @param xBreaks              numeric, Vector input for X-axis breaks
#' @param xBy                  character, Column name for X-axis
#' @param xCols                character, Column name(s) for X-axis variable(s)
#' @param xForm                function|character,  Format of the X-axis variable tick label
#' @param xLab                 character, Label of X-axis
#' @param xLimit               numeric, Two element vector giving the lower and upper limits of the X-axis
#' @param xScale               function|character,  Scale transformtion for the X-axis variable
#' @param yBreaks              numeric, Vector input for Y-axis breaks
#' @param yBy                  character, Column name for Y-axis
#' @param yByObs               character, Column name in \code{datFile} corresponding to the observed DV
#' @param yForm                function|character,  Format of the Y-axis variable tick label
#' @param yLab                 character, Label of Y-axis
#' @param yLimit               numeric, Two element vector giving the lower and upper limits of the Y-axis
#' @param yScale               function|character,  Scale transformtion for the Y-axis variable
#' @param themeUpdate list, with theme elements to replace session theme, Default: list()
#' @param themeTextSize numeric, overall plot text size, Default: 14
#' @param themePlotTitleSize numeric, plot title text size relative to themeTextSize, Default: 1.2
#' @param themeAxisTxtSize numeric, plot axis text size relative to themeTextSize, Default: 0.8
#' @param themeAxisTxtColour character, axis text colour, Default: 'black'
#' @param themeAxisTitleTxtSize numeric, plot axis title text size relative to themeTextSize, Default: 0.9
#' @param themeAxisTitleColour character, axis title text colour, Default: 'black'
#' @param themePanelBackgroundFill character, plot background colour, Default: 'white'
#' @param themePanelGridSize numeric, grid line size, Default: NULL
#' @param themePanelGridColour character, grid lines colour, Default: 'white'
#' @param themePanelLineType numeric, grid line type, Default: 1
#' @param themePanelTitleSize numeric, panel title text size relative to themeTextSize, Default: 1.2
#' @param themePlotTitleColour character, panel title text colour, Default: 'black'
#' @param themePlotLegendPosition character, legend position, Default: 'right'
#' @param srcAdd boolean, add source caption to output, Default: TRUE
#' @param srcPath character, path/to/source_file, Default: '.'
#' @param srcName character, name of source_file, Default: 'script'
#' @param figPath character, path/to/figure_file, Default: '../deliv/figure'
#' @param figName character, name of figure_file, Default: 'Rplot.pdf'
#' @param genAll boolean, generate all pages Default: TRUE
#' @param page numeric, vector of pages to output Default: 1
#' @param geoms character, vector of geom layers to overlay on plot, Default: c("point", "line", "errorbar")
#' @param xcut numeric|function, numeric vector, function that returns bin limits for x axis variable or NULL then ggplot2:::bin2d_breaks is used, Default: NULL
#' @param sumFn function, summary function for the y axis variable Default: mean_se
#' @param obsLabel character, if set to a column name annotation of text is used instead of points
#' @param smoothType function|character, function used for interpolation
#' 