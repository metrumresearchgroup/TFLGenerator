#CovariatesProblem.R
#
######################################
# Population PK with covariates

# clears R working environment
rm(list=ls())

# load packages
library(metrumrg)
getwd()#covariates/solution
command <- '/opt/NONMEM/nm72gf/nmqual/autolog.pl'

data<-read.table("poppk_wcovs.csv",   header=T, sep=",",as.is=T)

names(data)
#[1] "C"    "ID"   "DV"   "AMT"  "II"   "ADDL" "TIME" "RATE" "HT"   "WT"  
#[11] "CLCR" "SEX"  "AGE" 

# view data
pdf("exploratoryGraphs.pdf")
par(mfrow=c(2,1))
plot(data$TIME,data$DV)
plot(data$TIME,log(data$DV))

#index plots
par(mfrow=c(1,1))
pairs(data[,c("ID","DV","AMT","II","ADDL","TIME","RATE")], 
        panel=function(x,y) { points(x,y); lines(lowess(x,y))} )

# more index plots
par(mfrow=c(1,1))
pairs(data[,c("ID", "HT", "WT", "CLCR", "SEX", "AGE" )], 
        panel=function(x,y) { points(x,y); lines(lowess(x,y))} )
dev.off()

# edit control stream and run NONMEM

NONR72(
  run = 500,
  command=command,
  grid=TRUE,
  diag=TRUE,
  cont.cov=c("HT","WT","CLCR","AGE"),
  cat.cov=c("SEX"),
  par.list=c("CL","V"),
  eta.list=c("ETA1","ETA2")
)
# first ran with maxeval=0 then ran full estimation

# removed addit residual error component
NONR72(
  run=501,
  command=command,
  grid=TRUE,
  diag=TRUE,
  cont.cov=c("HT","WT","CLCR","AGE"),
  cat.cov=c("SEX"),
  par.list=c("CL","V"),
  eta.list=c("ETA1","ETA2")
)

#run a full covariate model
NONR72(
  run=510,
  command,
  grid=TRUE,
  diag=TRUE,
  cont.cov=c("HT","WT","CLCR","AGE"),
  cat.cov=c("SEX"),
  par.list=c("CL","V"),
  eta.list=c("ETA1","ETA2")
)
PopPars<-rlog(run=510,file=NULL,tool='nm7')
PopPars <- PopPars[PopPars$moment=='estimate',]
PopPars$value <- as.numeric(PopPars$value)
FinalPars <- PopPars$value
names(FinalPars) <- PopPars$parameter
FinalPars
# effect of 50 and 100 ml/min creat clearance on CL
(50/80)^FinalPars['THETA3']
(100/80)^FinalPars['THETA3']