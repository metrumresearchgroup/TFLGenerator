#' @title Goodness of fit plots
#' @concept figure
#' @description NONMEM goodness of fit plots for a model
#' @param datFile data.frame
#' @param markBy character; column name on which to mark by different colors
#' @param markByType "Discrete" or "Continuous" for the markby scale
#' @param smooth logical; include a loess?
#' @param preserveMarkByLevels logical; not used outside of the GUI
#' @param timeBy character; column name for the time variable
#' @param timeLimit limits for time, of the form "t1,t2" or "t1-t2"
#' @param timeScale "identity", "log10", or "log"
#' @param timeLab label for the time axis
#' @param timeFmt format for time, one of "comma", "plain", "scientific"
#' @details Only arguments for time are described here, but the same definitions
#' apply to each of pred (population prediction), ipred (individual prediction),
#' cwres (residuals), npde (NPDE values)
#' @examples 
#' data("twoCmt")
#' GOF(twoCmt,cwresBy = 'IRES')
#' @export

GOF <-
	function(datFile, 
	         markBy=NULL, markByType="Discrete",smooth=T, preserveMarkByLevels=F,
	         timeBy="TAFD", timeLimit=NULL, timeScale="identity", timeLab="Time (weeks)", timeFmt="comma",
	         concBy="DV", concLimit=NULL, concScale="log10", concLab="Observed Serum Concentration (ug/mL)", concFmt="comma",
	         predBy="PRED", predLimit=NULL, predScale="log10", predLab="Population Prediction (ug/mL)", predFmt="comma",
	         ipredBy="IPRED", ipredLimit=NULL, ipredScale="log10", ipredLab="Individual Prediction (ug/mL)", ipredFmt="comma",
	         cwresBy="CWRES", cwresLimit=NULL, cwresScale="identity", cwresLab="Conditional Weighted Residuals", cwresFmt="comma",
	         npdeBy="NPDE", npdeLimit=NULL, npdeScale="identity", npdeLab="NPDE", npdeFmt="comma",
					 Title="Goodness of Fit Plots",
					 themeUpdate=list(),
					 themeTextSize=14,
					 themePlotTitleSize=1.2,
					 themeAxisTxtSize=0.5,
					 themeAxisTxtColour='black',
					 themeAxisTitleTxtSize=0.5,
					 themeAxisTitleColour='black',
					 themePanelBackgroundFill='white',
					 themePanelGridSize=NULL,
					 themePanelGridColour='white',
					 themePanelLineType=1,
					 themePanelTitleSize=1.2,
					 themePlotTitleColour='black',
					 ...)
	{
		

	  drops <- sum(datFile$DV==0)
	  droplab <- paste(drops,"observations dropped with concentration of 0")
	  datFile <- datFile[datFile[,concBy]!=0,]
	  
	  if(!is.null(markBy)&markByType=='Discrete'){
	    if(class(datFile[,markBy])!="factor") datFile[,markBy] <- factor(datFile[,markBy], sort(unique(datFile[,markBy])))
	  }
	  if(preserveMarkByLevels & !is.null(markBy)&markByType=='Discrete'){
	    #if(Color){ cleanScales <- setColorScale(drop=F)} else {cleanScales <- setGrayScale(drop=F)}
	    cleanScales <- setColorScale(drop=F) 
	  }
	  
	  
	  
	  if(all(is.null(c(concLimit,predLimit,ipredLimit)))){
	    minc <- min(datFile[,c(concBy,predBy,ipredBy)])
	    maxc <- max(datFile[,c(concBy,predBy,ipredBy)])
	    predLimit <- concLimit <- ipredLimit <- c(minc,maxc)
	  }
	  
	  pList <- list()

	  rel=ggplot2:::rel
	  themeUpdate=theme(text=              element_text(size=themeTextSize),
	                    axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
	                    axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
	                    plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
	                    panel.background = element_rect(fill = themePanelBackgroundFill),
	                    panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
	                    plot.margin=unit(c(.5,1,.5,.5),units="cm")
	  )
	  

	  if(is.null(markBy)){
	    datFile$foo <- 1
	    markBy <- "foo"
	  }else{
	    if(class(datFile[,markBy])!="factor"&markByType=='Discrete') datFile[,markBy] <- factor(datFile[,markBy])
	  }
	  
	  pList[[1]] <- ggplot(datFile, aes_string(x=predBy,y=concBy))+
	    geom_abline(aes(slope=1,intercept=0),colour="black") +
	    scale_y_continuous(limits=concLimit, trans=concScale, labels=get(concFmt))+
	    scale_x_continuous(limits=predLimit, trans=predScale, labels=get(predFmt))+
	    labs(x=predLab,y=concLab)+
	    cleanTheme+themeUpdate

	  pList[[2]] <- ggplot(datFile, aes_string(x=ipredBy,y=concBy))+
	    geom_abline(aes(slope=1,intercept=0),colour="black")+
	    scale_y_continuous(limits=concLimit, trans=concScale, labels=get(concFmt))+
	    scale_x_continuous(limits=ipredLimit, trans=ipredScale, labels=get(ipredFmt))+
	    labs(x=ipredLab,y=concLab)+
	    cleanTheme+themeUpdate
	  
	  pList[[3]] <- ggplot(datFile, aes_string(x=predBy,y=cwresBy))+
	    geom_hline(aes(yintercept=0),colour="black")+
	    scale_x_continuous(limits=predLimit, trans=predScale, labels=get(predFmt))+
	    scale_y_continuous(limits=cwresLimit, trans=cwresScale, labels=get(cwresFmt))+
	    labs(x=predLab,y=cwresLab)+
	    cleanTheme+themeUpdate
	  
	  pList[[4]] <- ggplot(datFile, aes_string(x=timeBy,y=cwresBy))+
	    geom_hline(aes(yintercept=0),colour="black")+
	    scale_x_continuous(limits=timeLimit, trans=timeScale, labels=get(timeFmt))+
	    scale_y_continuous(limits=cwresLimit, trans=cwresScale, labels=get(cwresFmt))+
	    labs(x=timeLab,y=cwresLab)+
	    cleanTheme+themeUpdate
	  
	  if(npdeBy %in% names(datFile)){
	    
	    pList[[5]] <- ggplot(datFile, aes_string(x=predBy,y=npdeBy))+
	      geom_hline(aes(yintercept=0),colour="black")+
	      scale_y_continuous(limits=npdeLimit, trans=npdeScale, labels=get(npdeFmt))+
	      scale_x_continuous(limits=predLimit, trans=predScale, labels=get(predFmt))+
	      labs(y=npdeLab,x=predLab)+
	      cleanTheme+themeUpdate

	    pList[[6]] <- ggplot(datFile, aes_string(y=npdeBy,x=timeBy))+
	      geom_hline(aes(yintercept=0),colour="black")+
	      scale_x_continuous(limits=timeLimit, trans=timeScale, labels=get(timeFmt))+
	      scale_y_continuous(limits=npdeLimit, trans=npdeScale, labels=get(npdeFmt))+
	      labs(x=timeLab,y=npdeLab)+
	      cleanTheme+themeUpdate
	    
	    
	  }
	  
	  for(i in 1:length(pList)){
	  
	    if(markBy=="foo"){
	      pList[[i]] <- pList[[i]] + geom_point(colour="grey40",shape=79)
	    }else{
	      pList[[i]] <- pList[[i]] + geom_point(aes_string(colour=markBy,fill=markBy),shape=79)
	    }

	    if(smooth){
	      pList[[i]] <- pList[[i]] + geom_smooth(method="loess",colour="red",se=F,lwd=1.5)
	    }	
	    
	    if(markByType=='Discrete') pList[[i]]<-pList[[i]]+cleanScales
	    	      
	  }

	  p1=list(pList=pList,plotCols = 2,plotRows = ifelse(length(pList)==6,3,2))
	  class(p1)<-c(class(p1),'TFL')
	  return(p1)
	}
