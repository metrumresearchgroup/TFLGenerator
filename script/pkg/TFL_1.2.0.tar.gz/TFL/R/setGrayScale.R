#' @title Set the entire project color scale to GRAY SCALE
#' @description Sets the value of cleanScales (a theme set often used in internal Amgen ggplot construction) to appropriate gray scales (and line, shape scales)
#' @usage setGrayScale()
#' @details Utilizes grayPalette, shapesPalette, graylinePalette
#' @return list of ggplot scale objects
#' @export

setGrayScale <-
function(fillList=NULL, shapeList=NULL, lineList=NULL, colourList=NULL, drop=T){
	
	fillList=fillList %||% grayPalette
	shapeList=shapeList %||% shape_pal()(6)
	lineList=lineList %||% graylinePalette
	colourList=colourList	%||% grayPalette
	
	return(list(scale_fill_manual(values=fillList,drop=drop), 
							scale_shape_manual(values=shapeList,drop=drop), 
							scale_linetype_manual(values=lineList,drop=drop),
							scale_colour_manual(values=colourList,drop=drop))
	)
}
