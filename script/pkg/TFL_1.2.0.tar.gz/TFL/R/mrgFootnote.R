#' @title mrgFootnote
#' @description \code{mrgFootnote} concatonates a caption to a ggplot
#' 
#' @param p ggplot object
#' @param srcName character, source script name
#' @param srcPath character, source script path
#' @param figName character, output figure name
#' @param figPath character, output figure path

#' @examples
#' data("twoCmt")
#' p=ggplot(twoCmt,aes(x=DV,y=IPRED))+geom_point()
#' p%>%mrgFootnote()
#' @return A barchart ggplot2 object of class \code{TFL} which can be plotted or 
#' printed with the corresponding method. 
#' @export
mrgFootnote=function(p,srcName='script',srcPath='.',figName="Rplot",figPath="../deliv/figure"){
  
  figSplit=unlist(strsplit(figName,'[.]'))
  figName=figSplit[1]
  figExt='pdf'
  if(length(figSplit)==2) figExt=figSplit[2]
  
  srcLab=sprintf('Source code: %s/%s.R',srcPath,srcName)
  figLab=sprintf('Source graphic: %s/%s.%s',figPath,figName,figExt)
  
  p=p+labs(caption=paste('',srcLab,figLab,sep='\n'))+
    theme (plot.caption=element_text(hjust=0, #horizontal position
                                     vjust=0.5, #vertical position
                                     margin=margin(t=10,r=10,b=10,l=10) #padding around text
    )
    )
  p
}