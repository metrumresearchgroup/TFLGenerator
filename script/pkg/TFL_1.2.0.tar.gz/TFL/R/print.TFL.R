#' @title print method for most TFL package generated plots
#' @description arrange pList into plots and columns using the print method
#' @export

print.TFL=function(pList,srcAdd=FALSE,
                   plotCols=NULL,plotRows=NULL,
                   srcPath='.',
                   srcName='script',
                   figPath="../deliv/figure",
                   figName="Rplot.pdf",...){

  list2env(pList,envir = environment())
  numPlots = length(pList)

  if(is.null(plotCols)||is.null(plotRows)){
    cols=min(numPlots,2)
    plotCols = cols                      
    plotRows = ceiling(numPlots/plotCols)
  }
  if(numPlots > plotCols*plotRows){
    if(plotCols<plotRows){
      plotCols <- ceiling(numPlots/plotRows)
    }else{
      plotRows <- ceiling(numPlots/plotCols)
    }
  }
  
  grid.newpage()
  pushViewport(viewport(layout = grid.layout(plotRows,plotCols)))
  for (i in 1:numPlots) {
    curRow = ceiling(i/plotCols)
    curCol = (i-1) %% plotCols + 1
    if(srcAdd){
      if(curRow==plotRows&curCol==1){
        pList[[i]]=pList[[i]]%>%mrgFootnote(srcName,srcPath,figName,figPath)
      }else{
          pList[[i]]=pList[[i]]+labs(caption=" \n \n \n")
        }
    }
    print(pList[[i]], vp = vplayout(curRow, curCol ))
  }
  
}