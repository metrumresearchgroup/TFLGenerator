#' The TFL package is an R package for creating tables, figures, 
#' and listings in a reproducible manner.  
#' @section Tables:
#' 
#' \itemize{
#' \item \code{\link{demogTabCat}}: Demographics table for categorical
#' variables
#' \item \code{\link{demogTabCont}}: Demographics table for continuous 
#' variables
#' \item \code{\link{RNM}}: NONMEM model summary table
#' }
#' 
#' @section Figures:
#' 
#' \itemize{
#' \item \code{\link{barchartMult}}: Bar charts for frequency reporting
#' \item \code{\link{ConcvTimeInd}}: Concentration-time profile for a 
#' single patient
#' \item \code{\link{ConcvTimeMult}}: Multipanel concentration-time profiles
#' of individuals
#' \item \code{\link{ConcvTimeSum}}: Summarized concentration-time profiles
#' \item \code{\link{covCat}}: Continuous vs categorical boxplots
#' \item \code{\link{covCon}}: Conintuous vs continuous scatterplots
#' \item \code{\link{distMult}}: Multipanel distribution summary, including 
#' density, boxplot, and qq
#' \item \code{\link{ggpairs}}: Scatter plot matrix to compare continuous variables
#' \item \code{\link{GOF}}: Multipanel goodness-of-fit plot for a mixed effects model
#' \item \code{\link{OBSvIPRED}}: Observed vs predicted plots
#' \item \code{\link{paramDist}}: Distribution plot with standard normal overlay
#' \item \code{\link{QQplot}}: Quantile-quantile plots
#' \item \code{\link{VPC}}: Visual predictive checks summarizing the ability of the 
#' model to replicate the observed data
#' }
#' 
"_PACKAGE"
