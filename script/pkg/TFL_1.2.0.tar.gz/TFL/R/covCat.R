#' @title Boxplots
#' 
#' @description Boxplot comparing (multiple) categorical variables to (multiple) 
#' continuous variables
#' 
#' @param datFile A \code{data.frame} containing the necessary variables for the
#' figure
#' @param catList A list of two objects.  The first object is a vector of the categorical
#' variables in \code{datFile} to be plotted, the second object is a list of matching length
#' containing "pretty" labels for each of the categorical variables
#' @param conList A list of two objects.  The first object is a vector of the continuous
#' variables in \code{datFile} to be plotted, the second object is a list of matching length
#' containing "pretty" labels for each of the continuous variables
#' @param nCols Integer, how many columns to arrange the plots into
#' @param idVar Column name for ID, used to report the number of patients at each level
#' of the categorical variables
#' @param yLimit Two element numeric vector giving the lower and upper limits of
#'  the y axis, recycled for all continuous variables if multiple
#' @param yForm One of "percent", "comma", "none", or "scientific" denoting the
#' labeling to be used for the y-axis
#' @param yScale One of "identity", "log", "log10"; passed to scale_[xy]_continuous
#' @param facetBy Variable name in \code{datFile} on which to facet_wrap by
#' @param notches Logical, should the boxplots be notched or not 
#' (see \link{boxplot.stats} for details)
#' 
#' @param minorTicks Logical, include minor ticks?
#' @param minorTickNum Integer, number of minor ticks between major ticks
#' @param Title String, the title for the plot
#' @param theme* Various controls for the ggplot2 theme
#' 
#' @return  A "TFL" object consisting of a list of plots and the intended layout for 
#' their display.  The figure can be rendered with the \code{print} or \code{plot} 
#' methods.
#' 
#' @details Most calculations are passed through to \link{boxplot.stats} with a few
#' important exceptions.  Each plot includes the adjusted R squared value and p-value
#' associated with an analysis of variance of the continuous variable on the categorical
#' variable.  Additionally, the inner 20% (i.e., the 40th and 60th percentiles)
#' of the continuous variable is shown as a shaded box overlayed on the traditional boxplot.

covCat <-
function(datFile, catList, conList, nCols=2, idVar="NMID",
								yLimit=NULL,
							  yForm=waiver(),
							  yScale="identity",
								facetBy="", notches=TRUE,
         minorTicks=FALSE,
         minorTickNum=10,
         themeUpdate=list(),
         themeTextSize=14,
         themePlotTitleSize=1.2,
         themeAxisTxtSize=0.8,
         themeAxisTxtColour='black',
         themeAxisTitleTxtSize=0.9,
         themeAxisTitleColour='black',
         themePanelBackgroundFill='white',
         themePanelGridSize=NULL,
         themePanelGridColour='white',
         themePanelLineType=1,
         themePanelTitleSize=1.2,
         themePlotTitleColour='black',
								...){
	
	#for individual plots, nCols=1, xBy and yBy is a single column name (such as "RACE" and "ETA1)
	#for a multiple plot object
	
	#set a new quantil function to show the middle 10%, normal boxplot does 5% 95% for whiskers, 25 and 75% for box, and 50% for inner line.
	f = function(x) {
		r = quantile(x, probs = c(0.4, 0.4,0.5, 0.6, 0.6))
		names(r) <- c("ymin", "lower", "middle", "upper", "ymax")
		r
	}

	if(class(catList)!="list"){
	  catList <- list(catList)
	}
	if(class(conList)!="list"){
	  conList <- list(conList)
	}
	

	cats=sapply(catList, function(x){x[[1]][1]})
	catlabs=sapply(catList, function(x){if(length(x)==2) x[[2]][1] else x[[1]][1]})
	covs=sapply(conList, function(x){x[[1]][1]})
	covlabs=sapply(conList, function(x){if(length(x)==2) x[[2]][1] else x[[1]][1]})
	
	rel=ggplot2:::rel
	themeUpdate=theme(text=              element_text(size=themeTextSize),
	                  axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
	                  axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
	                  plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
	                  panel.background = element_rect(fill = themePanelBackgroundFill),
	                  panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
	)
	
	pList=list()
	for (x in cats){
		for (y in covs){	
			#perform a one way analysis of variance
			mod1= aov(as.formula(paste(y,"~",x)), data = datFile)
			modsum1 <- summary(mod1)
			my.p = ifelse(unlist(modsum1)["Pr(>F)1"] < 0.001, "p<.001", paste0("p=",signif(unlist(modsum1)["Pr(>F)1"], digits=3)))

			mod2 = lm(datFile[,y]~factor(datFile[,x]), data = datFile)
			modsum2 <- summary(mod2)
			r2 = ifelse("adj.r.squared" %in% names(modsum2), paste("R^2=",signif(modsum2$adj.r.squared, digits=3)), "")

			temp=unique(datFile[,c(idVar,x)])
			numbers=data.frame(table(temp[,c(x)]))
			numbers=plyr:::rename(numbers,c(Var1=x))
			
			tempFile=merge(numbers, datFile, all=TRUE)
			tempFile[,x]=sprintf("%s\nn=%s", tempFile[,x], tempFile$Freq)
			
			tempFile[,x]=factor(tempFile[,x])
			
			p1=
				ggplot(tempFile, aes_string(x=x, y=y))+
				geom_hline(yintercept=0, lty=2)+	
				stat_boxplot(geom ='errorbar') +	
				stat_summary(fun.data = f, geom="boxplot", fill="grey", alpha=.2, lty=2)+
				geom_boxplot(notch=notches, fill="cadetblue3", alpha=0.6)+
				labs(x=catlabs[which(cats==x)], y=covlabs[which(covs==y)], title=paste(r2,my.p,sep="  "))+
				scale_y_continuous(breaks=pretty_breaks(),  limits=yLimit, labels=eval(yForm), trans=yScale)

			if (minorTicks) p1=p1%>%addMinorTicks(yScale = yScale,yForm = yForm,xLimit = yLimit,minorTickNum=minorTickNum)
			
			pList[[paste("plot",x, "vs", y, sep="")]]=p1+cleanTheme +themeUpdate
			
			}
	}
	
	p1=list(pList=pList,plotCols = as.numeric(nCols),plotRows = 1)
	class(p1)<-c(class(p1),'TFL')
	
  return(p1)	
}
