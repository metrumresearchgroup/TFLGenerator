#' @title Plain format
#' @description Pring in a plain, non-scientific format
#' @param x numeric vector
#' @export

plain <- function(x,...){
  format(x,..., scientific=F)
}