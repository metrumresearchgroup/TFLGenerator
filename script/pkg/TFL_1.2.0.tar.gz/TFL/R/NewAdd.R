#' @export
'%+%'=function(item1, item2){
	
	library(metrumrg)
	library(ggplot2)
	
	ifelse ("ggplot" %in% class(item1) & "ggplot" %in% class(item2), stop("You can't add two ggplot grobs", call.=FALSE),
					ifelse("ggplot" %in% class(item1) & class(item2) %in% c("data.frame", "matrix"), return(ggplot2::'%+%'(item1, item2)),
								 ifelse("ggplot" %in% class(item2) & class(item1) %in% c("data.frame", "matrix"), return(ggplot2::'%+%'(item2, item1)),
								 			 ifelse(class(item2) %in% c("data.frame", "matrix")  & class(item1) %in% c("data.frame", "matrix"), return(metrumrg::'%+%'(item2, item1)),
								 			 			 stop("You can't add these class objects together; check object class and specify package with - package::'function'(args)", call.=FALSE)))))
	
}

