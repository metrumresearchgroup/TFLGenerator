remove_geom <-
function(grob, geom_type=c("line")) {
	layers <- lapply(grob$layers, function(x) if(x$geom$objname %in% geom_type) NULL else x)
	layers <- layers[!sapply(layers, is.null)]
	
	grob$layers <- layers
	return(grob)
}


'%-%'=function(grob, geom_type){
	layers <- lapply(grob$layers, function(x) if(x$geom$objname %in% geom_type) NULL else x)
	layers <- layers[!sapply(layers, is.null)]
	
	grob$layers <- layers
	return(grob)
}
