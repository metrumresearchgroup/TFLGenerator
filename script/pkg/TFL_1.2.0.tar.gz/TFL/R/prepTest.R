prepTest=function(funName){

	for(x in names(formals(funName))){
		if(!is.null(formals(funName)[[x]]) & class(formals(funName)[[x]])=="call"){assign(x, as.character(eval(formals(funName)[[x]])), envir=.GlobalEnv)}
		if(!is.null(formals(funName)[[x]]) & class(formals(funName)[[x]])!="call"){(assign(x, formals(funName)[[x]], envir=.GlobalEnv))}
		if(is.null(formals(funName)[[x]])){assign(x, readline(sprintf("Assign %s", x)), envir=.GlobalEnv)}
	}

}
