#' @title Parameter Distribution Plots
#' @description Produces a single parameter distribution plot with density and normal distrubution overlays
#' @usage paramDist(datFile, xBy = "ETA1", binWidth = 0.1, groupBy = NULL, markBy = NULL, xLimit = NULL, yLimit = NULL, xForm = waiver(), yForm = waiver(), xScale = "identity", yScale = "identity", Title = "", xLab = "ETA1", yLab = "Percent", facetBy = "", runno = "", project = getwd(), ...)
#' @param datFile data.frame output of a NM run containing ER-SSAP standard column names and numeric-only columns
#' @param xBy character column name for x-axis, likely an ETA
#' @param binWidth numeric describing the histogram bin width
#' @param groupBy character colum name to group data within the plot (likely not used)
#' @param markBy character column name for characteristic groupings within the plot (such as color and shape, likely not used
#' @param xLimit vector input for x-axis limits example: c(0,10)
#' @param yLimit vector input for y-axis limits example: c(.1,100000)
#' @param xForm function format of the x-axis (options: comma, scientific, percent or waiver() for no formatting)
#' @param yForm function format of the y-axis (options: comma, scientific, percent or waiver() for no formatting)
#' @param xScale function format for the x-axis (options, "identity", log10_trans(), log_trans())
#' @param yScale function format for the y-axis (options, "identity", log10_trans(), log_trans())
#' @param Title character figure title
#' @param xLab character x-axis title
#' @param yLab character y-axis title
#' @param facetBy character column name for optional faceting
#' @param runno character run number ("0068") to obtain eta shrinkage values
#' @param project character project path to obtain eta shrinkage values from *.xml nonmem output
#' @details Standard Eta distribution histogram plot for showing density and normal distribution of ETA
#' @return returns ggplot object (grob) that must be saved or printed
#' @export

paramDist<-function(datFile, xCols = "ETA1", binWidth = 0.1, groupBy = NULL,
           xLimit = NULL, yLimit = NULL, xForm = waiver(), 
           yForm = waiver(), xScale = "identity", yScale = "identity", 
           Title = "", xLab = "xCols",
           yLab = "Percent", facetBy = "", fF="", fnrow=NULL, fncol=NULL,fscales="fixed",
           runno = "", project = getwd(),
           ncol = 1, nrow = 1,
           minorTicks=FALSE,
           minorTickNum=10,
           themeUpdate=list(),
           themeTextSize=14,
           themePlotTitleSize=1.2,
           themeAxisTxtSize=0.8,
           themeAxisTxtColour='black',
           themeAxisTitleTxtSize=0.9,
           themeAxisTitleColour='black',
           themePanelBackgroundFill='white',
           themePanelGridSize=NULL,
           themePanelGridColour='white',
           themePanelLineType=1,
           themePanelTitleSize=1.2,
           themePlotTitleColour='black',
           ...){
    if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
    if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
    
    if(facetBy!="" & all(fF!="")){
      datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
    }

    ncol <- as.numeric(ncol); nrow <- as.numeric(nrow)
    if(ncol*nrow < length(xCols)){
      ncol <- 1
      nrow <- length(xCols)
    }

    rel=ggplot2:::rel
    themeUpdate=theme(text=              element_text(size=themeTextSize),
                      axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                      axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                      plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                      panel.background = element_rect(fill = themePanelBackgroundFill),
                      panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
    )
    
    
    
    pList <- lapply(xCols, function(xBy){
      
      if (facetBy != "") {
        
        newDat=data.frame(matrix(,ncol=4))
        names(newDat)=c(xBy, "normFit", "meanCol", facetBy)
        for (facet in unique(datFile[, facetBy])) {
          xx=	datFile[datFile[,facetBy] == facet, xBy]
          padx=c(
            seq(from=min(xx, na.rm=TRUE)-abs(min(xx, na.rm=TRUE)), to=min(xx, na.rm=TRUE), length.out=10),
            xx,
            seq(from=max(xx,na.rm=TRUE), to=max(xx,na.rm=TRUE)+abs(max(xx,na.rm=TRUE)), length.out=10)
          )
          normFit=dnorm(x=padx, mean=mean(xx, na.rm=TRUE), sd=sd(xx, na.rm=TRUE))
          meanCol=rep(mean(xx, na.rm=TRUE), times=length(padx))
          f=rep(facet, times=length(padx))
          foo=data.frame(cbind(padx, normFit, meanCol,f))
          names(foo)=c(xBy, "normFit", "meanCol", facetBy)
          newDat=rbind(newDat, foo)
          newDat=newDat[!is.na(newDat$normFit),]
          newDat=unique(newDat)
        }
        
        
        datFile=merge(datFile,newDat, all=TRUE)
      }
      
      if (facetBy == "") {
        newDat=data.frame(matrix(,ncol=3))
        names(newDat)=c(xBy, "normFit", "meanCol")
        
        xx=	datFile[, xBy]
        padx=c(
          seq(from=min(xx, na.rm=TRUE)-abs(min(xx, na.rm=TRUE)), to=min(xx, na.rm=TRUE), length.out=10),
          xx,
          seq(from=max(xx,na.rm=TRUE), to=max(xx,na.rm=TRUE)+abs(max(xx,na.rm=TRUE)), length.out=10)
        )
        normFit=dnorm(x=padx, mean=mean(xx, na.rm=TRUE), sd=sd(xx, na.rm=TRUE))
        meanCol=rep(mean(xx, na.rm=TRUE), times=length(padx))
        foo=data.frame(cbind(padx, normFit, meanCol))
        names(foo)=c(xBy, "normFit", "meanCol")
        newDat=rbind(newDat, foo)
        newDat=newDat[!is.na(newDat$normFit),]
        newDat=unique(newDat)
        datFile=merge(datFile, newDat, all=TRUE)
      }	

      
      if (runno %nin% c(""," ","#")) {
        shrink = presentXML(runno, type = "etashrink", project = project)
        Title = ifelse(xBy %in% names(shrink), paste(Title, "\n", "Shrinkage=", 
                                                     shrink[xBy], "%", sep = ""), "")
      }
      
      datFile[,xBy]=as.numeric(datFile[,xBy])
      datFile$normFit=as.numeric(datFile$normFit)
      datFile$meanCol=as.numeric(datFile$meanCol)
      
      xLabsVar=xCols[xBy == xCols]
      xLabs=xLab[xBy == xCols]
      xLabs[xLabs%in%c('',NA)]=xLabsVar[xLabs%in%c('',NA)]
      
      if(length(yLab)>1) yLab <- yLab[xBy == xCols]

      p=
        ggplot(datFile, aes_string(x=xBy, group=groupBy))	+
        cleanScales+
        geom_density(colour="dodgerblue3", adjust=3, kernel="gaussian",lwd=1.25)+
        geom_histogram(aes(y=..density..),colour="white", fill="deepskyblue", binwidth=binWidth, alpha=.4)+
        scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
        scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
        geom_line(aes(y=normFit), col="red", lty="dotted",lwd=1.25)+	
        geom_vline(aes(xintercept=meanCol), colour="red")+	
        labs(title=Title, x=xLabs, y=yLab)
      
      if (minorTicks) p=p%>%addMinorTicks(xScale,yScale,xForm,yForm,xLimit,yLimit,minorTickNum)
      
      #Add in the faceting if it exists
      if (facetBy!=""){
        p=p +facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,ncol=fncol,scales=fscales)
      }
      
      p=p+cleanTheme +themeUpdate
      
      p
    })
    names(pList)=xCols
    p1=list(pList=pList,plotCols = as.numeric(ncol),plotRows = as.numeric(nrow))
    class(p1)<-c(class(p1),'TFL')
    return(p1)
  }