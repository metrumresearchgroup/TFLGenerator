#' @title Save a list of plots
#' @param pList list of plots
#' @param plotCols number of columns to arrange plots into
#' @param plotRows number of rows to arrange plots into
#' @param fname File name for output
#' @param height height (inches) for output png
#' @param shape "squares", "rectangles", or "panel"
#' @export

pListSave=function(pList,plotCols=NULL,plotRows=NULL,fname=NULL,height=NULL,shape=NULL){
  
  numPlots = length(pList)
  if(is.null(plotCols)||is.null(plotRows)){
    cols=min(numPlots,2)
    plotCols = cols                      
    plotRows = ceiling(numPlots/plotCols)
  }
  
  if(numPlots > plotCols*plotRows){
    if(plotCols<plotRows){
      plotCols <- ceiling(numPlots/plotRows)
    }else{
      plotRows <- ceiling(numPlots/plotCols)
    }
  }

  dummyList=vector('list',1)
  names(dummyList)=basename(fname)
  pSize<-plotDims(grob = dummyList,height = height,shape = shape)
  
  fixScale=6/pSize$width[[1]]
  if(fixScale<1){
    currScale=pSize$height[[1]]/pSize$width[[1]]
    pSize$width=6
    pSize$height=6*currScale
    
  } 
  
  
  
  png(filename = paste0(fname,'.png'),height=pSize$height[[1]],width=pSize$width[[1]],units="in",res=150)
  pushViewport(viewport(layout = grid.layout(plotRows,plotCols)))
  for (i in 1:numPlots) {
    curRow = ceiling(i/plotCols)
    curCol = (i-1) %% plotCols + 1
    print(pList[[i]], vp = vplayout(curRow, curCol ))
  }
  dev.off()
}

