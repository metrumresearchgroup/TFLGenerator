#' @title Concentration vs time profiles for individuals
#' @concept figure
#' @description Longitundinal plot showing individual concentration vs time
#' profiles, including observed, conditional, and unconditional (on random effects)
#'  values of concentration
#' 
#' @param datFile A \code{data.frame} containing the necessary variables for the
#' figure
#' @param xBy Name of the variable denoting the x axis (typically time) in 
#' \code{datFile}
#' @param yBy Name of the variable containing the observed concentration values
#' @param idVar Name of the variable containing the patient number identifier
#' @param ID The ID in \code{datFile[,idVar]} you wish to plot 
#' @param predVar Population prediction column
#' @param ipredVar Individual prediction column
#' @param xLimit Two element numeric vector giving the lower and upper limits of 
#' \code{xBy}
#' @param yLimit Two element numeric vector giving the lower and upper limits of
#'  the concentration axis (y)
#' @param xForm One of "percent", "comma", "none", or "scientific" denoting the
#' labeling to be used for the x-axis
#' @param yForm One of "percent", "comma", "none", or "scientific" denoting the
#' labeling to be used for the y-axis
#' @param yScale One of "identity", "log", "log10"; passed to scale_[xy]_continuous
#' @param minorTicks Logical, include minor ticks?
#' @param minorTickNum Integer, number of minor ticks between major ticks
#' @param Title String, the title for the plot
#' @param theme* Various controls for the ggplot2 theme
#' @examples 
#' data("twoCmt")
#' ex1=ConcvTime(datFile = twoCmt,ID = '1',ipredVar = 'IPRED')
#' ex2=ConcvTime(datFile = twoCmt,ID = '1',ipredVar = 'IPRED',minorTicks = T)
#' list(ex1,ex2)
#' @return  A concentration vs time ggplot2 object of class \code{TFL} which
#' can be plotted or printed with the corresponding method.  
#' @export

ConcvTime <-
function(datFile, xBy="TAFD", yBy="DV", 
									    idVar="NMID",
									 		ID=unique(datFile[,idVar])[1],
									 		predVar="PRED", ipredVar="IPRE", 
											xLimit=NULL, yLimit=NULL,
											xForm=waiver(), yForm=waiver(),
											xScale="identity", yScale="log10", 
                      minorTicks=FALSE,
                      minorTickNum=10,
									 		Title=sprintf("Subject %s", ID), xLab="Time", yLab="Concentration",
                      themeUpdate=list(),
                      themeTextSize=14,
                      themePlotTitleSize=1.2,
                      themeAxisTxtSize=0.8,
                      themeAxisTxtColour='black',
                      themeAxisTitleTxtSize=0.9,
                      themeAxisTitleColour='black',
                      themePanelBackgroundFill='white',
                      themePanelGridSize=NULL,
                      themePanelGridColour='white',
                      themePanelLineType=1,
                      themePanelTitleSize=1.2,
                      themePlotTitleColour='black',
                      themePlotLegendPosition='right',
											...)
{
  
 
  
	datFile=datFile[datFile[,idVar]==ID,]
	datFile=melt(datFile, id.vars=c(idVar, xBy), measure.vars=c(yBy, predVar, ipredVar))
	datFile$variable=factor(datFile$variable, levels=c(yBy, predVar, ipredVar), labels=c("Observed", "Population Predicted", "Individual"))
	

	p1=ggplot(data=datFile, aes_string(x=xBy, y="value", color="variable", shape="variable", lty="variable"))+
		geom_line()+
		geom_point()+
		scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
		scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
		labs(title=Title, x=xLab, y=yLab, shape=NULL, lty=NULL, color=NULL) +
		scale_shape_manual( values = c("O", ".", "."))+
		scale_colour_manual(values = c('black', 'black','blue'))+
		scale_linetype_manual( values=c(0,1,3))

	if (minorTicks) p1=p1%>%addMinorTicks(xScale,yScale,xForm,yForm,xLimit,yLimit,minorTickNum)

	
	rel=ggplot2:::rel
	themeUpdate=theme(text=              element_text(size=themeTextSize),
	                  axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
	                  axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
	                  plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
	                  panel.background = element_rect(fill = themePanelBackgroundFill),
	                  panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
	                  legend.position =  themePlotLegendPosition
	                  )

	p1=p1+cleanTheme +themeUpdate
	p1=list(pList=list(ConcvTime=p1),plotCols=1,plotRows=1)
	class(p1)<-c(class(p1),'TFL')
	
	return(p1)
	
}
