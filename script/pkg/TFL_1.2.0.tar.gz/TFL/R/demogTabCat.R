#' @title Demographics table for categorical variables
#' @concept table
#' @param datFile data.frame
#' @param groupBy a list of (multiple) two element vectors; the first element is the column 
#' of \code{datFile} on which the table is grouped and the second element is the
#' "pretty" name for printing
#' @param idVar ID variable in \code{datFile}
#' @param catList a list of (multiple) two element vectors (like \code{groupBy})
#' that denote the list of categorical variables you wish to summarize
#' @param stratBy a list of a single two element vector giving the variable on which
#' to stratify by.  Pass an empty string for no stratification
#' @param sigDig number of significant digits
#' @examples 
#' data("twoCmt")
#' ex1=demogTabCat(twoCmt)
#' ex2=demogTabCat(twoCmt,stratBy = '')
#' list(ex1,ex2)
#' @return LaTex table
#' @export


demogTabCat <-
	function(datFile, 
	         groupBy=list(c("STUDY","Study")),
	         idVar="NMID",
					 catList=list(c("SEX","Sex"),c("RACE","Race")),
					 stratBy=list(c("DIS","Disease")),
					 sigDig=3)
		{ 
		
	  if(class(groupBy)!="list"){
	    groupBy <- list(groupBy)
	  }
	  if(class(catList)!="list"){
	    catList <- list(catList)
	  }
	  if(class(stratBy)!="list"){
	    stratBy <- list(stratBy)
	  }
	  
	  grp=sapply(groupBy,function(x)x[[1]][1])
	  grplabs=sapply(groupBy,function(x)x[[2]][1])
		cats=sapply(catList, function(x){x[[1]][1]})
		catlabs=sapply(catList, function(x){x[[2]][1]})
		subData=datFile[!duplicated(datFile[c(idVar, grp)]),]
		subData[,grp]=as.character(subData[,grp])
		
		
		strat=sapply(stratBy, function(x){x[[1]][1]})
		if(stratBy!="" & !is.null(stratBy))  stratlabs=sapply(stratBy,function(x)x[[2]][1]) else{
		  strat <- "whole"
		  stratlabs=""
		  subData$whole <- ""
		}
		
		# New version of length which can handle NA's: if na.rm==T, don't count them
		length2 <- function (x, na.rm=TRUE) {
			if (na.rm){ 
			  sum(!is.na(x))
			}else{
			    length(x)
			}
		}
		
		for(catsi in cats){
		  if(class(subData[,catsi]) != "factor") subData[,catsi] <- as.factor(subData[,catsi]) 
		}

		wholeData=melt(subData, id.vars=idVar, measure.vars=cats)
		wholeData_freq <- plyr:::count(wholeData[,c("variable","value")])
		wholeData_prop <- prop.table(table(wholeData[,c("variable","value")],useNA="always"),margin=1)
		colnames(wholeData_prop)[is.na(colnames(wholeData_prop))] <- "NA"
		for(j in 1:nrow(wholeData_freq)){
		  thisvalue <- as.character(wholeData_freq$value[j])
		  if(is.na(thisvalue)) thisvalue <- "NA"
		  wholeData_freq[j,"prop"] <- 
		    paste0("(",
		           signif(wholeData_prop[wholeData_freq$variable[j],thisvalue]*100, sigDig),
		           "\\%)")
		}
		wholeData_freq <- plyr:::rename(wholeData_freq,c(value="level"))
		wholeData <- rbind(cast(wholeData_freq, ~ variable + level, value="freq"),
		      cast(wholeData_freq, ~ variable + level, value="prop"))
		wholeData <- plyr:::rename(wholeData, c("value"=grp))
		wholeData[,grp] <- c("{\\bfseries Total}","\\quad\\%")

		subDataCat=dlply(subData, strat, function(statData){
		  statData <- melt(statData[,c(grp,cats)], id.vars=c(grp), variable_name="Parameter")
		  ###Analyze the categorical variables
		  statData <- ddply(statData, .variables=c(grp, "Parameter"), plyr:::count)
		  statData <- plyr:::rename(statData, c(value="level", freq="value"))
		  statData <- cast(statData, formula=as.formula(sprintf("%s ~ Parameter + level", grp)), value="value")
		  statData[is.na(statData)] <- 0
		  template <- do.call(rbind,replicate(nrow(statData),wholeData[1,],simplify=F))
		  template[,] <- 0
		  for(i in 1:nrow(statData)) template[i,names(statData)] <- statData[i,]
		  template
		})

		subDataCat <- lapply(subDataCat, function(x){
		  x[,1] <- paste("\\quad",x[,1])
		  x
		})
		subDataCat[["Total"]] <- wholeData
		names(subDataCat) <- paste0("{\\bfseries ", stratlabs,": ", names(subDataCat), "}")
		
		ltab <- do.call(rbind,subDataCat)

		ltab <- rbind( sapply(strsplit(names(ltab),"_"),function(x) x[2]), ltab)
		namerep <- sapply(strsplit(names(ltab),"_"),function(x) x[1])
		namerep <- map(namerep,from=c(grp,cats),to=c(grplabs,catlabs),strict = F)
		
		ltabi <- within(ltab, grp <- c(0,rep(1:length(subDataCat), times=sapply(subDataCat,nrow))))
		ltab[ltabi$grp==0,grp] <- namerep[1]
		colnames(ltab) <- NULL
		ltab[1,] <- paste0("{\\bfseries ",ltab[1,],"}")
		
		tex <- tabular(ltab,rules=c(0,1,1),
		        rowgroups=ltabi$grp,grid=T,
		        colgroups=namerep,
		        rowgrouprule=2)

		if(strat!="whole"){
		  mc <- sapply(names(subDataCat), function(xx) sprintf("\\multicolumn{%i}{c}{}\\\\ \\multicolumn{%i}{c}{\\bfseries %s}\\\\ \\hline", 
		                                                       ncol(ltab), ncol(ltab), xx))
		  index <- grep("\\\\ \\hline",tex,fixed=T)
		  index <- index[-c(1,length(index))]
		  neworder <- c(1:length(tex),index+.5)
		  tex <- c(tex,mc)[order(neworder)]      
		}
		
		# Header
		factorTable <- plyr:::count(namerep)
		factorTable$x <- as.character(factorTable$x)
		factorTable <- factorTable[match(unique(namerep),factorTable$x),]
		factorTable$x[ factorTable$x==grplabs ] <- ""
	  header <- apply(factorTable,1,function(r) 
		  sprintf("\\multicolumn{%s}{c}{{\\bfseries %s}}", r["freq"],r["x"])
		  )
		header <- paste(paste(header,collapse="&"), "\\\\ \\hline ")
		tex <- c( tex[c(1,2)], header, tex[4:length(tex)] )  # Skipping 3 intentionally, just blank space

		return(tex)
	}
