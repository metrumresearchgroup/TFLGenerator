#' @title Arrange a list of plots
#' @description Given a list of plots and a number of columns and rows, arrange the 
#' the plots for pretty printing.
#' @param pList a list of plots
#' @param plotCols integer; number of columns
#' @param plotRow integer; number of rows
#' @export

pListPrint=function(pList,plotCols=NULL,plotRows=NULL){
  numPlots = length(pList)
  if(numPlots==3 & is.null(plotCols) & is.null(plotRows)){
    plotCols <- pList$plotCols
    plotRows <- pList$plotRows
    pList <- pList$pList
    numPlots <- length(pList)
  }
  if(is.null(plotCols)||is.null(plotRows)){
    cols=min(numPlots,2)
    plotCols = cols                      
    plotRows = ceiling(numPlots/plotCols)
  }
  if(numPlots > plotCols*plotRows){
    if(plotCols<plotRows){
      plotCols <- ceiling(numPlots/plotRows)
    }else{
      plotRows <- ceiling(numPlots/plotCols)
    }
  }
  
  grid.newpage()
  pushViewport(viewport(layout = grid.layout(plotRows,plotCols)))
  for (i in 1:numPlots) {
    curRow = ceiling(i/plotCols)
    curCol = (i-1) %% plotCols + 1
    print(pList[[i]], vp = vplayout(curRow, curCol ))
  }
  
}