#' @export
addFacet=function(p1,facetType,facetByRow='.',facetByCol='.',fnrow=NULL,fncol=NULL,fscales='fixed'){
  if(facetByRow!="."||facetByCol!="."){
    eval(parse(text=paste('pF<-',facetByRow,'~',facetByCol)))
    if(facetType=='wrap'){
      if(facetByRow!="."&facetByCol==".") eval(parse(text=paste('pF<-~',facetByRow)))
      if(facetByRow=="."&facetByCol!=".") eval(parse(text=paste('pF<-~',facetByCol)))
      p1=p1 +facet_wrap(pF,nrow=fnrow,ncol=fncol,scales=fscales)
    } 
    if(facetType=='grid') p1=p1 +facet_grid(pF,scales=fscales)
  }
  p1
}
