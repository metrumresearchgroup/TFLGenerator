#' @title qqplot line
#' @description given data and a theoretical quantile function, find the comparison
#' line between quantiles of theoretical and data
#' @param qf function returning quantiles for a probability
#' @param na.rm remove missing
#' @export

qq_line <- function(data, qf, na.rm) {
  # from stackoverflow.com/a/4357932/1346276
  q.sample <- quantile(data, c(0.25, 0.75), na.rm = na.rm)
  q.theory <- qf(c(0.25, 0.75))
  slope <- diff(q.sample) / diff(q.theory)
  intercept <- q.sample[1] - slope * q.theory[1]
  
  list(slope = slope, intercept = intercept)
}