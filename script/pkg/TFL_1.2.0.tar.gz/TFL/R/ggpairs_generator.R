#' @title Correlation Comparison plot
#' @concept figure
#' @description Creates a grid ggplot object with R-squared and p-values indicated in corresponding upper trianges
#' @usage ggpairs_generator(datFile, xCols = grep("ETA", names(datFile), value = TRUE), xLimit = NULL, yLimit = NULL, xForm = waiver(), yForm = waiver(), xScale = "identity", yScale = "identity", facetBy = "", ...)
#' @param datFile data.frame output of a NM run containing ER-SSAP standard column names and numeric-only columns
#' @param xCols character column names 
#' @param xLimit vector input for x-axis limits example: c(0,10) of lower triangle plots
#' @param yLimit vector input for y-axis limits example: c(.1,100000) of lower triangle plots
#' @param xForm function format of the x-axis (options: comma, scientific, percent or waiver() for no formatting) of lower triangle plots
#' @param yForm function format of the y-axis (options: comma, scientific, percent or waiver() for no formatting) of lower triangle plots
#' @param xScale function format for the x-axis (options, "identity", log10_trans(), log_trans()) of lower triangle plots
#' @param yScale function format for the y-axis (options, "identity", log10_trans(), log_trans()) of lower triangle plots
#' @param facetBy character column name for optional faceting
#' @details Lower triangle shows comparison plots of diagonal values with line of best fit, upper triangle shows R squared and p values for these comparisons
#' @examples 
#' data("twoCmt")
#' ggpairs(twoCmt,xCols=c('ETA1','ETA2'))
#' ggpairs(twoCmt,xCols=c('ETA1','ETA2','ETA5'))
#' @return  returns ggplot object (grob) that must be saved or printed

ggpairs_generator <-
function(datFile, xCols=grep("ETA", names(datFile), value=TRUE),
         xLab=xCols,
								 xLimit=NULL, yLimit=NULL,
								 xForm=waiver(), yForm=waiver(),
								 xScale="identity", yScale="identity",
								facetBy="", corstat="R2",
         minorTicks=FALSE,
         minorTickNum=10,
         themeUpdate=list(),
         themeTextSize=14,
         themePlotTitleSize=1.2,
         themeAxisTxtSize=0.8,
         themeAxisTxtColour='black',
         themeAxisTitleTxtSize=0.9,
         themeAxisTitleColour='black',
         themePanelBackgroundFill='white',
         themePanelGridSize=NULL,
         themePanelGridColour='white',
         themePanelLineType=1,
         themePanelTitleSize=1.2,
         themePlotTitleColour='black',
         srcAdd=TRUE,
         srcPath='.',
         srcName='script',
         figPath="../deliv/figure",
         figName="Rplot.pdf",
								 ...){
	
	if(all(xCols=="") | is.null(xCols)) xCols <- grep("ETA", names(datFile), value=TRUE)
	names=factor(xCols, levels=xCols, labels=c(1:length(xCols)))
	
	rel=ggplot2:::rel
	themeUpdate=theme(text=              element_text(size=themeTextSize),
	                  axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
	                  axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
	                  plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
	                  panel.background = element_rect(fill = themePanelBackgroundFill),
	                  panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
	)
	
	pList=list() #create an empty list
	
	for (i in names){
		i=as.numeric(i)
		for (j in names){	
			j=as.numeric(j)
			#fit the linear regression line
			mod1 = lm(datFile[,xCols[i]]~datFile[,xCols[j]], data = datFile)
			modsum = summary(mod1)
			r2 = ifelse("adj.r.squared" %in% names(modsum), paste("R^2=",signif(modsum$adj.r.squared, digits=3)), "")
			r <- paste0("r=",
			            signif(cor(datFile[,xCols[i]],datFile[,xCols[j]],use="pairwise.complete.obs",method="pearson"),digits=3))
			my.p =ifelse(((dim(modsum$coefficients)[1]>=2) & dim(modsum$coefficients)[2]>=4), 
			             {
			               ifelse(modsum$coefficients[2,4]>0.001, paste("p=",signif(modsum$coefficients[2,4],digits=3)), paste("p<0.001"))
			             },
			             "")
			
			if(i==j){
				pList[[paste("plot",i,j, sep="")]]=
				  ggplot() + annotate("text", x=.5, y=.5, label=xLab[i],size=as.numeric(themeTextSize)/2) + #7+(2-length(names))
				  theme(axis.text=element_blank(),	axis.line=element_line(size=0),
				        axis.title=element_blank(), axis.ticks=element_line(size=0),
				        plot.background=element_rect(fill='white',colour="black",size=1.15),
				        panel.background=element_rect(fill='white',size=0),
				        panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
				        plot.margin=unit(c(.1,.1,.1,0), "cm"))
				
			}
			if(j>i){
			  label <- ifelse(corstat=="R2", sprintf("%s\n%s",r2, my.p), sprintf("%s\n%s",r, my.p))
				pList[[paste("plot",i,j, sep="")]] <-
				  ggplot() + annotate("text", x=.5, y=.5, label=label, size=as.numeric(themeTextSize)/2 ) + #7+(2-length(names))
				  theme(axis.text=element_blank(),	axis.line=element_line(size=0),
				        axis.title=element_blank(), axis.ticks=element_line(size=0),
				        plot.background=element_rect(fill='white',colour="black",size=1.15),
				        panel.background=element_rect(fill='white',size=0),
				        panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
				        plot.margin=unit(c(.1,.1,.1,0), "cm"))
				
				  #   rect <- rectGrob(.5,.5,width=unit(.99,"npc"), height=unit(0.99,"npc"), 
				  #             gp=gpar(lwd=3, fill=NA, col="black"),vp=vp)
				  # 	text <- textGrob(sprintf("%s\n%s",eval(r2), eval(my.p)), gp=gpar(fontsize=10),vp=vp)
				
			}
			
			if(i>j){
				pList[[paste("plot",i,j, sep="")]]=
					ggplot(datFile, aes_string(x=xCols[j], y=xCols[i]))+
					geom_point(shape=79)+
					geom_smooth(method="loess", se=FALSE, colour="red")+
					# geom_hline(yintercept=0, lty=2)+
					# geom_vline(xintercept=0, lty=2)+
					labs(x=NULL, y=NULL)+
					scale_x_continuous(breaks=pretty_breaks(), limits=xLimit, labels=eval(xForm), trans=xScale)+
					scale_y_continuous(breaks=pretty_breaks(), limits=yLimit, labels=eval(yForm), trans=yScale)+
				  cleanTheme +themeUpdate +
				  theme(plot.background=element_rect(fill='white',colour='black',size=1.15))

				if (minorTicks) pList[[paste("plot",i,j, sep="")]]=pList[[paste("plot",i,j, sep="")]]%>%addMinorTicks(xScale,yScale,xForm,yForm,xLimit,yLimit,minorTickNum)
				
				if(j==1 & i!=as.numeric(names)[length(names)]) pList[[paste("plot",i,j,sep="")]] <- 
				    pList[[paste("plot",i,j,sep="")]] + 
				    theme(axis.text.x=element_text(size=0),axis.ticks=element_line(size=0))

				if(j>1 & i==as.numeric(names)[length(names)]) pList[[paste("plot",i,j,sep="")]] <- 
				    pList[[paste("plot",i,j,sep="")]] + 
				    theme(axis.text.y=element_text(size=0), axis.ticks.y=element_line(size=0))
				
				
			}
			
		}
	}

	p1=list(pList=pList,plotCols = length(xCols),plotRows = length(xCols),srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
	class(p1)<-c(class(p1),'TFL')
	return(p1)
	
}
