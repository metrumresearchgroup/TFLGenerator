#' @title pkTab
#' @concept table
#' @description Table that depicts the frequency by groups and exclusion criteria
#' @examples
#'  datFile=twoCmt%>%mutate(BLQ=(DV<=100&DV>0))
#'  datFile$rndGroup=sample(1:5,size = nrow(datFile),replace = T)
#'  datFile$NODOSE=datFile$DV==0
#'  out=pkTab(datFile,
#'          groupBy = list(c("STUDY","Study Phase"),c('rndGroup','Randomization Group')),
#'          exclVar=list(BLQ=list(label='BLQ',flag=T),NODOSE=list(label='No Dose',flag=T))
#'  )
#' out
#' #texPreview(print(xtable(out,digits=0),include.rownames=FALSE),stem='test',imgFormat = 'svg')
#' @export
#' 
 pkTab=function(datFile,
                 groupBy=list(c("STUDY","Study Phase")),
                 idVar="NMID",
                 exclVar=list(BLQ=list(label='BLQ',flag=T))
                 ){
   
   grpBy=sapply(groupBy,'[',1)
   grpLbl=sapply(groupBy,'[',2)
   
   out=datFile%>%select_(.dots = c(grpBy,idVar))%>%distinct%>%count_(grpBy)%>%rename(N=n)
   out=out%>%left_join(datFile%>%count_(grpBy),by=grpBy)
   if(!is.null(exclVar)){
     eVar=names(exclVar)
     eVal=data.frame(flag=eVar,value=sapply(exclVar,function(x) x$flag))
     eLbl=sapply(exclVar,function(x) x$label)
     
     eForm=as.formula(paste0(paste0(grpBy,collapse='+'),'~flag'))
     eOut=eVal%>%
       left_join(
         datFile%>%
           select_(.dots=c(grpBy,eVar))%>%
           reshape2::melt(.,id=grpBy,variable='flag'),by=c('flag','value'))%>%
       count_(c(grpBy,'flag'))%>%
       reshape2::dcast(.,eForm,value.var='n',fill = 0)
     
     out=out%>%left_join(eOut,by=grpBy)
   } 
   names(out)[which(names(out)%in%grpBy)]=grpLbl
   if(!is.null(exclVar)) names(out)[which(names(out)%in%names(eLbl))]=eLbl
   return(out)
 }