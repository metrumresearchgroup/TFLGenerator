#' @title Listing of excluded observations
#' @param catList list of two element vectors giving the column name and rename
#' of variables to list in the table
#' @details Requires presence of an "observationExclusions" table in the global
#' environment, as done by the GUI. Not intended (at the moment) to be run from
#' outside of the GUI.
#' @export

observationExclusionsTab <-
	function(
	  catList=list(c("STUDY","Study"),c("DOSE","Dose")),
	  tmpDir = NULL
	)
		{ 
	  if(is.null(tmpDir)){
	    tmpDir <- tempdir()
	    dir.create(tmpDir,recursive = T)
	  }else{
	    if(!dir.exists(tmpDir)){
	      return()
	    }
	  }
	  
	  if(catList!=""){
	    if(class(catList)!="list"){
	      catList <- list(catList)
	    }
	    
	    cats=sapply(catList, function(x){x[[1]][1]})
	    catlabs=sapply(catList, function(x){x[[2]][1]})
	  }else{
	    cats <- NULL
	    catlabs <- NULL
	  }

		datFile <- try(observationExclusions)
		if(class(datFile)=="try-error") get("observationExclusions",.GlobalEnv)
		datFile <- datFile[,unique(c("excl_reasons","NMID","TAFD",cats))]
		datFile <- datFile[!duplicated(datFile),]
		datFile <- sort_df(datFile)
		N <- reapply(datFile$TAFD,
		             datFile[,"excl_reasons"],
		             length
		)

		datFile$excl_reasons <- paste(datFile$excl_reasons, paste0("(N=",N,")"))
		datFile$excl_reasons <- reapply(datFile$excl_reasons,
		                               datFile[,"excl_reasons"],
		                               function(x) c(x[1],rep("",length(x)-1))
		)
		names(datFile) <- map(names(datFile), 
		                      from=c("excl_reasons",cats,"NMID","TAFD"),
		                      to=c("Reason for exclusion", catlabs, "ID","TIME"))

		if(nrow(datFile) <= 500){
		  f <- file.path(tmpDir,"observationExclusions.doc")
		  rtf <- RTF(f,font.size=11)
		  addTable(rtf,datFile)
		  done(rtf)
		  message <- "SUCCESS"
		}else{
		  f <- file.path(tmpDir,"observationExclusions.csv")
		  write.csv(datFile,file=f,row.names=F)
		  message <- paste0("Too many exclusions (n=", nrow(datFile), ") to create doc file.  Data dumped to PNG/",basename(f))
		}

		p1 <- datFile
		return(list(preview=datFile, file=f, message=message))
		
	# 	ltab <- rbind( sapply(strsplit(names(ltab),"_"),function(x) x[2]), ltab)
	# 	namerep <- sapply(strsplit(names(ltab),"_"),function(x) x[1])
	# 	namerep <- map(namerep,from=c(grp,cats),to=c(grplabs,catlabs),strict = F)
	# 	
	# 	ltabi <- within(ltab, grp <- c(0,rep(1:length(subDataCat), times=sapply(subDataCat,nrow))))
	# 	ltab[ltabi$grp==0,grp] <- namerep[1]
	# 	colnames(ltab) <- NULL
	# 	ltab[1,] <- paste0("{\\bfseries ",ltab[1,],"}")
	# 	
	# 	tex <- tabular(ltab,rules=c(0,1,1),
	# 	        rowgroups=ltabi$grp,grid=T,
	# 	        colgroups=namerep,
	# 	        rowgrouprule=2)
	# 
	# 	if(strat!="whole"){
	# 	  mc <- sapply(names(subDataCat), function(xx) sprintf("\\multicolumn{%i}{c}{}\\\\ \\multicolumn{%i}{c}{{\\bfseries %s}}\\\\ \\hline", 
	# 	                                                       ncol(ltab), ncol(ltab), xx))
	# 	  index <- grep("\\\\ \\hline",tex,fixed=T)
	# 	  index <- index[-c(1,length(index))]
	# 	  neworder <- c(1:length(tex),index+.5)
	# 	  tex <- c(tex,mc)[order(neworder)]      
	# 	}
	# 	
	# 	# Header
	# 	factorTable <- plyr:::count(namerep)
	# 	factorTable$x <- as.character(factorTable$x)
	# 	factorTable <- factorTable[match(unique(namerep),factorTable$x),]
	# 	factorTable$x[ factorTable$x==grplabs ] <- ""
	#   header <- apply(factorTable,1,function(r) 
	# 	  sprintf("\\multicolumn{%s}{c}{{\\bfseries %s}}", r["freq"],r["x"])
	# 	  )
	# 	header <- paste(paste(header,collapse="&"), "\\\\ ")
	# 	tex <- c( tex[c(1,2)], header, tex[4:length(tex)] )  # Skipping 3 intentionally, just blank space

		# return(tex)
	}
