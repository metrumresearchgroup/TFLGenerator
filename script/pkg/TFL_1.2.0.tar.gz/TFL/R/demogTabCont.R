#' @title Demographics table for continuous variables
#' @param datFile data.frame
#' @param groupBy a list of (multiple) two element vectors; the first element is the column 
#' of \code{datFile} on which the table is grouped and the second element is the
#' "pretty" name for printing
#' @param idVar ID variable in \code{datFile}
#' @param conList a list of (multiple) two element vectors (like \code{groupBy})
#' that denote the list of continuous variables you wish to summarize
#' @param catList a list of a single two element vector giving the variable on which
#' to stratify by.  Pass an empty string for no stratification
#' @param sigDig number of significant digits
#' @return LaTex table
#' @export

demogTabCont <-
	function(datFile, 
	         groupBy=list(c("STUDY","Study")),
	         idVar="NMID",
					 conList=list(c("AGE", "Age (years)"), c("HGTB", "Height (cm)"), c("WGTB", "Weight (kg)")),
					 catList=list(c("DIS","Disease")),
						sigDig=3)
		{ 
		
	  if(class(groupBy)!="list"){
	    groupBy <- list(groupBy)
	  }
	  if(class(catList)!="list"){
	    catList <- list(catList)
	  }
	  if(class(conList)!="list"){
	    conList <- list(conList)
	  }
	  grp=sapply(groupBy,function(x)x[[1]][1])
	  grplabs=sapply(groupBy,function(x)x[[2]][1])
		cons=sapply(conList, function(x){x[[1]][1]})
		conlabs=sapply(conList, function(x){x[[2]][1]})

		subData=datFile[!duplicated(datFile[c(idVar, grp)]),]
		
		cats=sapply(catList, function(x){x[[1]][1]})
		if(catList!=""){
		  catlabs=sapply(catList,function(x){if(length(x)==2) x[[2]][1] else x[[1]][1]}) 
		}else{
		  cats <- "whole"
		  catlabs=""
		  subData$whole <- ""
		}
		
		# New version of length which can handle NA's: if na.rm==T, don't count them
		length2 <- function (x, na.rm=TRUE) {
			if (na.rm){ sum(!is.na(x))}	else {length(x)}
		}
		
		subDataCon=dlply(subData, cats, function(statData){
		  statData <- melt(statData[,c(grp,cons)], id.vars=c(grp), variable_name="Parameter")
		  ###Analyze the continuous variables
		  statData <- ddply(statData, .variables=c(grp, "Parameter"),
		        .fun= function(xx) {
		          c( n     	= as.character(length2(xx[,"value"], na.rm=TRUE)),
		             Mean= signif(mean(xx[,"value"], na.rm=TRUE), digits=sigDig),
		             Median=signif(median(xx[,"value"], na.rm=TRUE), digits=sigDig),
		             sd=signif(sd(xx[,"value"], na.rm=TRUE), digits=sigDig),
		             CV=signif((sd(xx[,"value"], na.rm=TRUE)/mean(xx[,"value"], na.rm=TRUE)*100),digits=sigDig),
		             Min=signif(min(xx[,"value"], na.rm=TRUE),digits=sigDig),
		             Max=signif(max(xx[,"value"], na.rm=TRUE),digits=sigDig)
		          )
		        } )
		  statData[,grp] <- paste("\\quad", statData[,grp])
		  statData$value <- with(statData, sprintf("%s (%s) [%s-%s]",as.character(Mean),as.character(sd),as.character(Min),as.character(Max)))
		  statData=statData[,c(grp, "n","value", "Parameter")]
		  statData=melt(statData, id.vars=c("Parameter", grp, "n"), measure.vars=c("value"))
		  cast(statData, formula=as.formula(sprintf("%s + n~ Parameter", grp)), value="value")
		  
		})
		

		wholeData=apply(as.data.frame(subData[,cons]),2,function(xx){
		  data.frame(n=as.character(length2(xx,na.rm=T)), 
		             Mean= signif(mean(xx, na.rm=TRUE), digits=sigDig),
		             Median=signif(median(xx, na.rm=TRUE), digits=sigDig),
		             sd=signif(sd(xx, na.rm=TRUE), digits=sigDig),
		             CV=signif((sd(xx, na.rm=TRUE)/mean(xx, na.rm=TRUE)*100),digits=sigDig),
		             Min=signif(min(xx, na.rm=TRUE),digits=sigDig),
		             Max=signif(max(xx, na.rm=TRUE),digits=sigDig)
		  )
		})
		names(wholeData) <- cons
		wholeDataval <- lapply(wholeData, 
		                       function(xx) sprintf("%s (%s) [%s-%s]",as.character(xx$Mean),
		                                            as.character(xx$sd),as.character(xx$Min),as.character(xx$Max)))
		
		wholeData <- cbind(n=wholeData[[1]]$n,as.data.frame(wholeDataval,stringsAsFactors = F))
		wholeData[grp] <- "{\\bfseries Total}"
		
		subDataCon[["Total"]] <- wholeData
		names(subDataCon) <- paste0(catlabs,": ", names(subDataCon))
		
		ltab <- do.call(rbind,subDataCon)
		names(ltab) <- map(names(ltab),from=c(grp,cons),to=c(grplabs,conlabs),strict = F)
		names(ltab) <- paste("{\\bfseries", names(ltab), "}")
		ltabi <- within(ltab, grp <- rep(1:length(subDataCon), times=sapply(subDataCon,nrow)))
		tex <- tabular(ltab,rules=c(1,1,1),
		        rowgroups=ltabi$grp,grid=T,
		        colgroups=rep(1,ncol(ltab)),
		        rowgrouprule=2)
		if(cats!="whole"){
		  mc <- sapply(names(subDataCon), function(xx) sprintf("\\multicolumn{%i}{c}{}\\\\ \\multicolumn{%i}{c}{{\\bfseries %s}}\\\\ \\hline", 
		                                                       ncol(ltab), ncol(ltab), xx))
		  index <- grep("\\\\ \\hline",tex,fixed=T)
		  index <- index[-length(index)]
		  neworder <- c(1:length(tex),index+.5)
		  tex <- c(tex,mc)[order(neworder)]      
		}
		return(tex)
	}
