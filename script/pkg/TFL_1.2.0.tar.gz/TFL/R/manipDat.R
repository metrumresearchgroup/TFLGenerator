#' @title Perform data manipulation for use with the \code{TFL} R package
#' 
#' @description Perform data manipulation like factoring and summarizing in a 
#' predefined manner for use with the \code{TFL} R package
#' 
#' @param datFile A \code{data.frame} containing the necessary variables for 
#' manipulation
#' @param xBy Name of the variable denoting the x axis (typically time) in 
#' \code{datFile}
#' @param yBy Name of the variable denoting the y zxis in \code{datFile}
#' @param markBy Name of the variable on which to place a scale, either discrete
#' or continuous as specified in \code{markByType}
#' @param markByType "Discrete" or "Continuous", to be passed to the scale type
#' @param markByAdd String, a label to be appended to all levels of the factor
#' labels.  E.g., "mg/mL"
#' @param preserveMarkByLevels Logical, should we sort the levels before 
#' factorizing?  
#' @param facetBy Column in \code{datFile} on which to facet by
#' @param facetFact A character string acting as a key for re-labeling the facet values.  
#' Takes the form "value1,value2;label1,label2"
#' @param dataLimits A data parsing list as returned by \code{\link{cleanparse}}.
#' This is a list containing a character vector named "commands", and a logical 
#' vector of the same length named "within".  Most likely not used outside of the
#' GUI.
#' @param dataTrans Not used outside of the app
#' @param groupBy Character, name of the column of \code{datFile} on which to 
#' group the summaries by
#' @param sumType One of "N", "median", "mean", "sd", "se", or "ci" as calculated
#' in \code{\link{summarySE}}
#' @param sumVar Used to create intervals around \code{sumType}, typically one of either
#' "sd", "se", or "ci".  
#' @param sumThis Logical, summarize this data on \code{sumType} (\code{sumVar})
#'  by levels of \code{groupBy}, \code{markBy}, and \code{facetBy}?
#'  @examples 
#'  data("twoCmt")
#'  manipDat(twoCmt,groupBy = 'SEX',sumThis = T)
#' @return  A dataframe containing manipulated data (e.g., factored, subsetted, summarized).
#' If summarized, and grouped, each group will contain measures N, median, mean,
#' sd, se, ci, Min, and Max.
#' 
#' @details The primary use of this function is to perform summaries and manipulations
#' on the analysis dataset (\code{datFile}) created by the TFL generator app.  Some 
#' plots (e.g., ConcvTimeSum) expect input in this format.  Worker functions for
#' performing the summaries are \code{\link{summarySE}} and \code{\link{addMinMax}}.
#' @export

manipDat <-
function(datFile,
									xBy="TAFD", yBy="DV",
									markBy="DOSE",markByType='Discrete', markByAdd="",
                  preserveMarkByLevels=F,
									facetBy="", facetFact="",
									dataLimits="", dataTrans="",
									groupBy="NMID",
									sumType="mean", sumVar="sd", 
									sumThis=FALSE,
									...){
  # If preserveMarkBy, then set factor levels on full data
  if(!is.null(markBy) & preserveMarkByLevels){
    if(markBy %in% names(datFile)){
      #perform factoring to include details
      if(class(datFile[,markBy])=="factor"){
        levels0 <- levels(datFile[,markBy])
      }else{
        levels0 <- sort(unique(datFile[,markBy]))
      }
    }
  }
  
	#perform any limits on the data set
	if (class(dataLimits)=="list" | length(dataLimits)>1){
	  for(i in 1:length(dataLimits$commands)){
	    if(class(datFile)=="list"){
	      datFile.orig <- datFile; rm(datFile)
	      datFile.new <- lapply(datFile.orig, function(datFile){
	        if(dataLimits$within[i]) tryCatch(eval(parse(text=paste0("datFile <- within(datFile, {", dataLimits$commands[i], "})"))),
	                                          error=function(e) cat(file=stderr(),paste("Parsing command broken:\n",dataLimits$commands[i],"\n", e)))
	        if(!dataLimits$within[i]) tryCatch(eval(parse(text=paste0("datFile <- ", dataLimits$commands[i]))),
	                                           error=function(e) cat(file=stderr(),print(paste("Parsing command broken:\n",dataLimits$commands[i],"\n", e))))
	        datFile
	      })
	      datFile <- datFile.new
	    }else{
	      if(dataLimits$within[i]) tryCatch(eval(parse(text=paste0("datFile <- within(datFile, {", dataLimits$commands[i], "})"))),
	                                        error=function(e) cat(file=stderr(),paste("Parsing command broken:\n",dataLimits$commands[i],"\n", e)))
	      if(!dataLimits$within[i]) tryCatch(eval(parse(text=paste0("datFile <- ", dataLimits$commands[i]))),
	                                         error=function(e) cat(file=stderr(),print(paste("Parsing command broken:\n",dataLimits$commands[i],"\n", e))))
	    }
	  }
	}
  
  if(markByAdd!=""){
    if(class(datFile[,markBy])=="factor"){
      if(preserveMarkByLevels){
        levels(datFile[,markBy]) <- paste(levels0,str_trim(markByAdd))
      }else{
        levels(datFile[,markBy]) <- paste(levels(datFile[,markBy]),str_trim(markByAdd))
      }
    }else{
      if(markByType=='Discrete'){
      if(preserveMarkByLevels){
        datFile[,markBy] <- factor(datFile[,markBy], levels=levels0, 
                                   labels=paste(levels0,str_trim(markByAdd)))
      }else{
        datFile[,markBy] <- factor(datFile[,markBy], levels=sort(unique(datFile[,markBy])), 
                                   labels=paste(sort(unique(datFile[,markBy])),str_trim(markByAdd)))
      }
      }else{
        datFile[,markBy]=datFile[,markBy]
        }
    }
  }
	
	
	#perform any transformations on the data set
	if (class(dataTrans)=="list" | length(dataTrans)>1){
		if(class(dataTrans)!="list"){dataTrans=list(dataTrans)}
		for(n in c(1:length(dataTrans))){
			if(length(dataTrans[[n]])==3){
				if (dataTrans[[n]][[1]] %nin% names(datFile)){break}
				datFile[,dataTrans[[n]][[1]]]=do.call(dataTrans[[n]][[2]],
																					list(
																					suppressWarnings(as.numeric(datFile[,dataTrans[[n]][[1]]])),
																						suppressWarnings(as.numeric(dataTrans[[n]][[3]]))
																					)
																				)
			}
		}
	}

  #summarize if grouped
  if(sumThis==TRUE){
    gr=unique(c(xBy, groupBy, markBy, facetBy))
    if(facetBy==""){gr=unique(c(xBy, groupBy, markBy))}
    datFile=summarySE(datFile, measurevar=yBy, groupvars=gr)
    datFile=addMinMax(datFile, measurevar=sumType, devvar=sumVar)	
    
  }
	

	
 if (facetBy!="" & class(facetFact)=="list" ) {datFile[,facetBy]=factor(datFile[,facetBy], levels=facetFact[[1]], labels=facetFact[[2]])}	
	
	
	return(datFile)
}
