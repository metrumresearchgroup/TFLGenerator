#' @export
corTFL=function (data, mapping, alignPercent = 0.6,method = "pearson",use = "complete.obs", cor_fn=function(x, y) cor.test(x, y, method = method, use = use)[c('estimate','p.value')], ...){
  useOptions <- c("all.obs", "complete.obs", "pairwise.complete.obs", "everything", "na.or.complete")
  use <- pmatch(use, useOptions)
  if (is.na(use)) {
    warning("correlation 'use' not found.  Using default value of 'all.obs'")
    use <- useOptions[1]
  }
  else {
    use <- useOptions[use]
  }
  
  xCol <- as.character(mapping$x)
  yCol <- as.character(mapping$y)
  if (GGally:::is_date(data[, xCol]) || GGally:::is_date(data[, yCol])) {
    if (!identical(class(data), "data.frame")) {
      data <- as.data.frame(data)
    }
    for (col in c(xCol, yCol)) {
      if (GGally:::is_date(data[, col])) {
        data[, col] <- as.numeric(data[, col])
      }
    }
  }
  colorCol <- deparse(mapping$colour)
  singleColorCol <- ifelse(is.null(colorCol), NULL, paste(colorCol, 
                                                          collapse = ""))
  if (use %in% c("complete.obs", "pairwise.complete.obs", "na.or.complete")) {
    if (length(colorCol) > 0) {
      if (singleColorCol %in% colnames(data)) {
        rows <- complete.cases(data[, c(xCol, yCol, colorCol)])
      }
      else {
        rows <- complete.cases(data[, c(xCol, yCol)])
      }
    }
    else {
      rows <- complete.cases(data[, c(xCol, yCol)])
    }
    if (any(!rows)) {
      total <- sum(!rows)
      if (total > 1) {
        warning("Removed ", total, " rows containing missing values")
      }
      else if (total == 1) {
        warning("Removing 1 row that contained a missing value")
      }
    }
    data <- data[rows, ]
  }
  xVal <- data[, xCol]
  yVal <- data[, yCol]
  if (length(names(mapping)) > 0) {
    for (i in length(names(mapping)):1) {
      tmp_map_val <- as.character(mapping[names(mapping)[i]][[1]])
      if (tmp_map_val[length(tmp_map_val)] %in% colnames(data)) 
        mapping[names(mapping)[i]] <- NULL
      if (length(names(mapping)) < 1) {
        mapping <- NULL
        break
      }
    }
  }
  if (length(colorCol) < 1) {
    colorCol <- "ggally_NO_EXIST"
  }
  if ((singleColorCol != "ggally_NO_EXIST") && (singleColorCol %in% 
                                                colnames(data))) {
    cord <- ddply(data, c(colorCol), function(x) {
      cor_fn(x[, xCol], x[, yCol])
    })
    colnames(cord)[2] <- "ggally_cor"
    cord$ggally_cor <- signif(as.numeric(cord$ggally_cor), 
                              3)
    lev <- levels(data[[colorCol]])
    ord <- rep(-1, nrow(cord))
    for (i in 1:nrow(cord)) {
      for (j in seq_along(lev)) {
        if (identical(as.character(cord[i, colorCol]), 
                      as.character(lev[j]))) {
          ord[i] <- j
        }
      }
    }
    cord <- cord[order(ord[ord >= 0]), ]
    cord$label <- str_c(cord[[colorCol]], ": ", cord$ggally_cor)
    xmin <- min(xVal, na.rm = TRUE)
    xmax <- max(xVal, na.rm = TRUE)
    xrange <- c(xmin - 0.01 * (xmax - xmin), xmax + 0.01 * 
                  (xmax - xmin))
    ymin <- min(yVal, na.rm = TRUE)
    ymax <- max(yVal, na.rm = TRUE)
    yrange <- c(ymin - 0.01 * (ymax - ymin), ymax + 0.01 * 
                  (ymax - ymin))
    p <- ggally_text(label = str_c("Cor : ", signif(cor_fn(xVal, 
                                                           yVal), 3)), mapping = mapping, xP = 0.5, yP = 0.9, 
                     xrange = xrange, yrange = yrange, color = "black", 
                     ...) + theme(legend.position = "none")
    xPos <- rep(alignPercent, nrow(cord)) * diff(xrange) + 
      min(xrange, na.rm = TRUE)
    yPos <- seq(from = 0.9, to = 0.2, length.out = nrow(cord) + 
                  1)
    yPos <- yPos * diff(yrange) + min(yrange, na.rm = TRUE)
    yPos <- yPos[-1]
    cordf <- data.frame(xPos = xPos, yPos = yPos, labelp = cord$label)
    cordf$labelp <- factor(cordf$labelp, levels = cordf$labelp)
    p <- p + geom_text(data = cordf, aes(x = xPos, y = yPos, 
                                         label = labelp, color = labelp), hjust = 1, ...)
    p$type <- "continuous"
    p$subType <- "cor"
    p
  }
  else {
    xmin <- min(xVal, na.rm = TRUE)
    xmax <- max(xVal, na.rm = TRUE)
    xrange <- c(xmin - 0.01 * (xmax - xmin), xmax + 0.01 * 
                  (xmax - xmin))
    ymin <- min(yVal, na.rm = TRUE)
    ymax <- max(yVal, na.rm = TRUE)
    yrange <- c(ymin - 0.01 * (ymax - ymin), ymax + 0.01 * 
                  (ymax - ymin))
    cVal=as.numeric(cor_fn(xVal,yVal))
    cVal[1]=round(cVal[1],3)
    cVal[2]=ifelse(cVal[2]<0.0001,'<0.0001',round(cVal[2],3))
    p <- ggally_text(label = paste0("Corr:",cVal[1],'\nPval:',cVal[2]), mapping, xP = 0.5, yP = 0.5, xrange = xrange, yrange = yrange, ...)  +
      theme(legend.position = "none",panel.grid.major = element_blank(),panel.grid.minor = element_blank())
    p$type <- "continuous"
    p$subType <- "cor"
    p
  }
}

#' @export
lowerFn <- function(data, mapping, method = "loess",minorTicks,minorTickNum,xLimit,yLimit,xForm,yForm,xScale,yScale, ...){
  p <- ggplot(data = data, mapping = mapping) +
    geom_point(colour = "blue") +
    geom_smooth(method = method, color = "red", ...)+
    scale_x_continuous(breaks=pretty_breaks(), limits=xLimit, labels=eval(xForm), trans=xScale)+
    scale_y_continuous(breaks=pretty_breaks(), limits=yLimit, labels=eval(yForm), trans=yScale)
  
  if (minorTicks) p=p+annotation_ticks(ticks_per_base = minorTickNum)
  p
}

#' @export
upperFn <- function(data, mapping, ...){
  xVar <- as.character(mapping$x)
  yVar <- as.character(mapping$y)
  xVal <- data[, xCol]
  yVal <- data[, yCol]
  
  p <- ggplot(data = data, mapping = mapping) +
    geom_point(colour = "blue") +
    geom_smooth(method = method, color = "red", ...)
  p
}

#' @export
diagFn <- function(data, mapping , ...){
  xVar=as.character(mapping[[1]])
  p <- ggplot(data = data, mapping = mapping) +
    geom_density(colour = 'blue')+
    stat_function(fun = dnorm, args = list(mean = mean(data[[xVar]]), sd = sd(data[[xVar]])), col = 'red')
  pb=ggplot_build(p)
  plim=sapply(pb$layout$panel_scales, function(x) max(x[[1]]$range$range))
  p=p+annotate("text", x = plim[1]*0.65, y = plim[2]*0.95,
             label = sprintf("N(%s,%s)",round(mean(data[[xVar]]),3),round(sd(data[[xVar]]),3)),
             parse=T,size=3,colour='red')
  p
}

#' @title Correlation Comparison plot
#' @concept figure
#' @description Creates a grid ggplot object with R-squared and p-values indicated in corresponding upper trianges
#' @usage ggpairs(datFile, xCols = grep("ETA", names(datFile), value = TRUE), xLimit = NULL, yLimit = NULL, xForm = waiver(), yForm = waiver(), xScale = "identity", yScale = "identity", facetBy = "", ...)
#' @param datFile data.frame output of a NM run containing ER-SSAP standard column names and numeric-only columns
#' @param xCols character column names 
#' @param xLimit vector input for x-axis limits example: c(0,10) of lower triangle plots
#' @param yLimit vector input for y-axis limits example: c(.1,100000) of lower triangle plots
#' @param xForm function format of the x-axis (options: comma, scientific, percent or waiver() for no formatting) of lower triangle plots
#' @param yForm function format of the y-axis (options: comma, scientific, percent or waiver() for no formatting) of lower triangle plots
#' @param xScale function format for the x-axis (options, "identity", log10_trans(), log_trans()) of lower triangle plots
#' @param yScale function format for the y-axis (options, "identity", log10_trans(), log_trans()) of lower triangle plots
#' @param facetBy character column name for optional faceting
#' @details Lower triangle shows comparison plots of diagonal values with line of best fit, upper triangle shows R squared and p values for these comparisons
#' @examples 
#' data("twoCmt")
#' ggpairs(twoCmt,xCols=c('ETA1','ETA2'))
#' ggpairs(twoCmt,xCols=c('ETA1','ETA2','ETA5'))
#' @return  returns ggplot object (grob) that must be saved or printed
#' @export
#'
#' 
ggpairs=function(datFile, xCols=grep("ETA", names(datFile), value=TRUE),
                 xLab=xCols,
                 xLimit=NULL, yLimit=NULL,
                 xForm=waiver(), yForm=waiver(),
                 xScale="identity", yScale="identity",
                 facetBy="", corstat="R2",
                 minorTicks=FALSE,
                 minorTickNum=10,
                 themeUpdate=list(),
                 themeTextSize=14,
                 themePlotTitleSize=1.2,
                 themeAxisTxtSize=0.8,
                 themeAxisTxtColour='black',
                 themeAxisTitleTxtSize=0.9,
                 themeAxisTitleColour='black',
                 themePanelBackgroundFill='white',
                 themePanelGridSize=NULL,
                 themePanelGridColour='white',
                 themePanelLineType=1,
                 themePanelTitleSize=1.2,
                 themePlotTitleColour='black',
                 srcAdd=TRUE,
                 srcPath='.',
                 srcName='script',
                 figPath="../deliv/figure",
                 figName="Rplot.pdf",
                 ...){

if(all(xCols=="") | is.null(xCols)) xCols <- grep("ETA", names(datFile), value=TRUE)
names=factor(xCols, levels=xCols, labels=c(1:length(xCols)))

rel=ggplot2:::rel
themeUpdate=theme(text=              element_text(size=themeTextSize),
                  axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                  axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                  plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                  panel.background = element_rect(fill = themePanelBackgroundFill),
                  panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
)

p<-GGally::ggpairs(
  datFile%>%dplyr::select_(.dots = xCols),
  lower = list(continuous = GGally::wrap(lowerFn,minorTicks=minorTicks,minorTickNum=minorTickNum,xLimit=xLimit,yLimit=yLimit,xForm=xForm,yForm=yForm,xScale=xScale,yScale=yScale)),
  diag = list(continuous = GGally::wrap(diagFn, colour = "blue")),
  upper = list(continuous = GGally::wrap(corTFL, size = 10))
)

p<-p+themeUpdate

p1=list(pList=list(p=p),plotCols = 1,plotRows = 1,srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
class(p1)<-c(class(p1),'TFL')
return(p1)
}