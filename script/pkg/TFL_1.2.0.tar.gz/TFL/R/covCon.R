#' @title Scatterplots
#' @concept figure
#' @description Scatterplots comparing (multiple) continuous variables
#' 
#' @param datFile A \code{data.frame} containing the necessary variables for the
#' figure
#' @param conList_x A list of two character vectors.0  The first is a vector of the continuous
#' variables in \code{datFile} to be plotted on the x axis, the second is a list of matching length
#' containing "pretty" labels for each of the continuous variables
#' @param conList_y A list of two character vectors.  The first is a vector of the continuous
#' variables in \code{datFile} to be plotted on the y axis, the second object is a list of matching length
#' containing "pretty" labels for each of those variables
#' @param nCols Integer, how many columns to arrange the plots into
#' @param xLimit Two element numeric vector giving the lower and upper limits of
#'  the x axis, recycled for all x axes if multiple
#' @param yLimit Two element numeric vector giving the lower and upper limits of
#'  the y axis, recycled for all y axes if multiple
#' @param xForm One of "percent", "comma", "none", or "scientific" denoting the
#' labeling to be used for the axis
#' @param yForm One of "percent", "comma", "none", or "scientific" denoting the
#' labeling to be used for the axis
#' @param xScale One of "identity", "log", "log10"; passed to scale_x_continuous
#' @param yScale One of "identity", "log", "log10"; passed to scale_y_continuous
#' @param facetBy Variable name in \code{datFile} on which to facet_wrap by
#' @param fF Labels for the facet levels in the form "Level1,Label1;Level2,Label2"
#' @param fnrow Number of rows passed to facet_wrap
#' @param fncol Number of columns passed to facet_wrap
#' @param fscales Scale type for facet_wrap: "fixed", "free", "free_y", or "free_x" 
#' @param minorTicks Logical, include minor ticks?
#' @param minorTickNum Integer, number of minor ticks between major ticks
#' @param corstat "R2" for adjusted R^2 or "r" for Pearson correlation
#' @param theme* Various controls for the ggplot2 theme
#' @examples
#' data("twoCmt")
#' covCon(twoCmt,conList_x = 'IPRED',conList_y = 'ETA1',nCol=1)
#' covCon(twoCmt,
#' conList_x = list(
#' list('IPRED','Individual Prediction'),
#' list('IRES','Individual Residual')
#' ),
#' conList_y = list(
#' list('ETA1',expression(eta[1]))
#' )
#' )
#' 
#' @return  A "TFL" object consisting of a list of plots and the intended layout for 
#' their display.  The figure can be rendered with the \code{print} or \code{plot} 
#' methods.
#' 
#' @details In addition to reporting either the correlation coefficient or adjusted
#' R^2, the significance of the coefficient in a linear regression of y on x is 
#' reported as well (i.e., testing whether the coefficient is non-zero).  All observations
#' are shown on the plot as well as both a linear fit and loess smooth to the data.
#' @export

covCon <-
function(datFile, conList_x, conList_y, nCols=2,
								xLimit=NULL, yLimit=NULL,
								xForm=waiver(), yForm=waiver(),
								xScale="identity", yScale="identity",
								facetBy="", fF="", fnrow=NULL, fncol=NULL,fscales="fixed",
         minorTicks=FALSE,
         minorTickNum=10,
         corstat=NULL,
         themeUpdate=list(),
         themeTextSize=14,
         themePlotTitleSize=1.2,
         themeAxisTxtSize=0.8,
         themeAxisTxtColour='black',
         themeAxisTitleTxtSize=0.9,
         themeAxisTitleColour='black',
         themePanelBackgroundFill='white',
         themePanelGridSize=NULL,
         themePanelGridColour='white',
         themePanelLineType=1,
         themePanelTitleSize=1.2,
         themePlotTitleColour='black',
         srcAdd=TRUE,
         srcPath='.',
         srcName='script',
         figPath="../deliv/figure",
         figName="Rplot.pdf",
								...){
	
  # if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
  # if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
  
	#for individual plots, nCols=1, xBy and yBy is a single column name (such as "RACE" and "ETA1)
	#for a multiple plot object

  if(facetBy!="" & all(fF!="")){
    datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
  }

  if(class(conList_x)!="list"){
    conList_x <- list(conList_x)
  }
  if(class(conList_y)!="list"){
    conList_y <- list(conList_y)
  }
  
  yCols=sapply(conList_y, function(x){x[[1]][1]})
  yLabs=sapply(conList_y, function(x){if(length(x)==2) x[[2]][1] else x[[1]][1]})
  xCols=sapply(conList_x, function(x){x[[1]][1]})
  xLabs=sapply(conList_x, function(x){if(length(x)==2) x[[2]][1] else x[[1]][1]})
  
  rel=ggplot2:::rel
  themeUpdate=theme(text=              element_text(size=themeTextSize),
                    axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                    axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                    plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                    panel.background = element_rect(fill = themePanelBackgroundFill),
                    panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
  )
  
  mod.grid=expand.grid(y=yCols,x=xCols, stringsAsFactors = F)%>%do(.,cbind(modId=1:nrow(.),.))
  if(facetBy!='') mod.grid=expand.grid(y=yCols,x=xCols,facetBy=facetBy,facetByVal=unique(datFile[,facetBy]), stringsAsFactors = F)%>%do(.,cbind(modId=1:nrow(.),.))

    
  facetLbl=ddply(mod.grid,.(modId),.fun=function(mod){
    y=mod$y
    x=mod$x
    df=datFile
  
    if(facetBy!='') df=df%>%filter_(.dots = list(paste0(mod$facetBy,"%in%",mod$facetByVal)))%>%select_(.dots=list(y,x,facetBy))
    mod1 = lm(df[,y]~df[,x], data = df)
    modsum = summary(mod1)
    r2 = ifelse("adj.r.squared" %in% names(modsum), paste("R^2=",signif(modsum$adj.r.squared, digits=3)), "")
    r = paste0("r=", signif(cor(df[,x],df[,y],use="pairwise.complete.obs",method="pearson"),digits=3))
    
    my.p =ifelse(((dim(modsum$coefficients)[1]>=2) & dim(modsum$coefficients)[2]>=4), 
                 ifelse(modsum$coefficients[2,4]>0.001,
                        paste("p=",signif(modsum$coefficients[2,4],digits=3)),
                        "p<0.001"),
                 "")
    if(!is.null(corstat))mod$lbl=ifelse(corstat=="R2", sprintf("%s : %s",r2, my.p), sprintf("%s : %s",r, my.p))
    
    mod
  })
  
  
  
  pList=	dlply(facetLbl,.(x,y),.fun=function(mod){
    x=unique(mod$x)
    y=unique(mod$y)
    p1=ggplot(datFile, aes_string(x=x, y=y))+
    geom_smooth(method="loess", se=FALSE, colour="red", lty=2)+
    geom_smooth(method="lm", se=FALSE, colour="red")+
    geom_point(shape=1)+
    geom_hline(yintercept=0, lty=2)+
    labs(x=xLabs[which(x==xCols)], y=yLabs[which(y==yCols)])+
    scale_x_continuous(breaks=pretty_breaks(), limits=xLimit, labels=eval(xForm), trans=xScale)+
    scale_y_continuous(breaks=pretty_breaks(), limits=yLimit, labels=eval(yForm), trans=yScale)
  
  if (minorTicks) p1=p1%>%addMinorTicks(xScale,yScale,xForm,yForm,xLimit,yLimit,minorTickNum)
    
  if(facetBy==''&!is.null(corstat)) p1=p1+labs(title=mod$lbl)  
    
  if (facetBy!=""){
    lbl='label_value'
    if(!is.null(corstat)){
      lbl <- paste(levels(factor(datFile[,facetBy])),mod$lbl,sep='\n')
      names(lbl)=levels(factor(datFile[,facetBy]))
      lbl=as_labeller(lbl)
    }
    p1=p1 +facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,ncol=fncol,scales=fscales,labeller = lbl)
    themeUpdate=themeUpdate+theme(strip.text = element_text(size=rel(.65)))
  }
  
  p1=p1+cleanTheme +themeUpdate
    })

  names(pList)=unique(paste("plot",mod.grid$x, "vs",mod.grid$y, sep=""))

	p1=list(pList=pList,plotCols = as.numeric(nCols),plotRows = 1,srcAdd=srcAdd,srcName=srcName,srcPath=srcPath,figName=figName,figPath=figPath)
	class(p1)<-c(class(p1),'TFL')
	
	return(p1)
}
