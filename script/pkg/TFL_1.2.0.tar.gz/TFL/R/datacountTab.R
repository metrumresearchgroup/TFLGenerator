#' @title datacountTab
#' @concept table
#' @description Table that depicts the frequency by groups and exclusion criteria
#' @seealso \code{\link[texPreview]{texPreview}}
#' @examples
#'  require(texPreview)
#'  Knit<-!is.null(knitr::opts_knit$get('rmarkdown.pandoc.to')) #Check if in knit environment
#'  Chk<-interactive()||Knit #Check for Rstudio and knit environment
#' 
#'  datFile=twoCmt%>%mutate(BLQ=(DV<=100&DV>0))
#'  datFile$rndGroup=sample(1:5,size = nrow(datFile),replace = T)
#'  datFile$NODOSE=datFile$DV==0
#'  out=datacountTab(datFile,
#'          groupBy = list(c("STUDY","Study Phase"),c('rndGroup','Randomization Group')),
#'          exclVar=list(BLQ=list(label='BLQ',flag=T),NODOSE=list(label='No Dose',flag=T))
#'  )
#'  
#' if(!Knit) 
#' 
#' out
#' 
#' #Show Table in Viewer
#' if(Chk)  texPreview(obj = out,
#'                     stem = paste0('datacountTabEx1'),
#'                     fileDir = fd,
#'                     imgFormat = 'svg',
#'                     returnType=rt,
#'                     ignore.stdout=T)
#' 
#' @export
#' 
datacountTab=function(datFile,
                 groupBy=list(c("STUDY","Study Phase")),
                 idVar="NMID",
                 exclVar=list(BLQ=list(label='BLQ',flag=T)),
                 srcAdd=TRUE,
                 srcPath='.',
                 srcName='script',
                 tblPath="../deliv/table",
                 tblName="table.tex"
                 ){
   
   grpBy=sapply(groupBy,'[',1)
   grpLbl=sapply(groupBy,'[',2)
   
   out=datFile%>%select_(.dots = c(grpBy,idVar))%>%distinct%>%count_(grpBy)%>%dplyr::rename(N=n)
   out=out%>%left_join(datFile%>%count_(grpBy),by=grpBy)
   if(!is.null(exclVar)){
     eVar=names(exclVar)
     eVal=data.frame(flag=eVar,value=sapply(exclVar,function(x) x$flag))
     eLbl=sapply(exclVar,function(x) x$label)
     
     eForm=as.formula(paste0(paste0(grpBy,collapse='+'),'~flag'))
     eOut=eVal%>%
       left_join(
         datFile%>%
           select_(.dots=c(grpBy,eVar))%>%
           reshape2::melt(.,id=grpBy,variable='flag'),by=c('flag','value'))%>%
       count_(c(grpBy,'flag'))%>%
       reshape2::dcast(.,eForm,value.var='n',fill = 0)
     
     out=out%>%left_join(eOut,by=grpBy)
   } 
   names(out)[which(names(out)%in%grpBy)]=grpLbl
   if(!is.null(exclVar)) names(out)[which(names(out)%in%names(eLbl))]=eLbl
   tex=tabular(out)
   
   if(srcAdd){
     tblSplit=unlist(strsplit(tblName,'[.]'))
     tblName=tblSplit[1]
     tblExt='tex'
     if(length(tblSplit)==2) tblExt=tblSplit[2]
     
     srcLab=sprintf('{\\raggedleft \\tiny Source code: %s/%s.R}',srcPath,srcName)
     tblLab=sprintf('{\\raggedleft \\tiny Source file: %s/%s.%s}',tblPath,tblName,tblExt)
     
     tex=c(tex,' ',srcLab,' ','\\vspace{-5pt}',tblLab)
   }
   
   return(tex)
 }