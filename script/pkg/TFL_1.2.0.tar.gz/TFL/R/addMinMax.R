#' @name addMinMax
#' @title Add additional plotting columns
#' @description Add on function for summarySE
#' @usage addMinMax(data, measurevar = "DVmean", devvar = "sd", na.rm = TRUE)
#' @param data data.frame() output usually originating from the summarySE() function
#' @param measurevardependent variable
#' @param devvar deviation variable (can be "sd", "se")
#' @param na.rm remove NA (logical)
#' @examples 
#' newFile=summarySE(exData, measurevar="DV", groupvars=c("TAFD", "DOSE"))
#' newFile=addMinMax(newFile, measurevar="mean", devvar="sd")n
#' @keywords summarize
#' @export

addMinMax <-
function(data, measurevar="DVmean", devvar="sd", na.rm=TRUE) {	
	if (na.rm){data=data[!is.na(data[,measurevar]),]}
	data$Max=data[,measurevar] + abs(data[,devvar])
	data$Max[is.na(data[,devvar])]=data[is.na(data[,devvar]), measurevar]
	data$Min=data[,measurevar] -abs(data[,devvar])
	data$Min[is.na(data[,devvar])]=data[is.na(data[,devvar]), measurevar]
	
	return(data)
}
