logRun=function(run, project=getwd(), CSV=NULL, Notes=""){
	
	
# 	while(runstate(run, project) %in% c("queued", "compiled", "running")){Sys.sleep(30)}
# 	if(runstate(run, project=="indeterminate")){print("Run was not logged")}
# 	if(runstate(run, project)=="done"){

		if(is.null(CSV)){	
		CSV="NMrunLog"
	}

	if(!file.exists(sprintf("%s/%s.csv", project, CSV))){
		
		foo=data.frame(matrix(,1,10), stringsAsFactors=FALSE)
		names(foo)=c("Run", "OBVF", "Date", "Data_File", "Estimation_Step_Convergence", "Final_Estimation", "CTL_Notes", "PROB_Notes", "Extra_Notes")
		write.csv(foo,sprintf("%s/%s.csv", project, CSV), row.names=FALSE, quote=FALSE)
	}
		 
		 fileCSV=read.csv(sprintf("%s/%s.csv", project, CSV))
		rowN=length(fileCSV$Run)
    
		#duplicate last row and append
		fileCSV=data.frame(rbind(fileCSV, fileCSV[rowN,]), stringsAsFactors=FALSE, check.names=FALSE)

		
fileCSV$Run[rowN+1]=run
fileCSV$OBVF[rowN+1]=presentXML(run, "final_objective_function")
fileCSV$Date[rowN+1]=presentXML(run, "stop_datetime")

fileCSV$Data_File[rowN+1]=presentCTL(run, "Data")
fileCSV$Data_File[rowN+1]=gsub("DATA|[[:space::]]*|IGNORE=.*", "", fileCSV$Data_File[rowN+1])

test=presentCTL(run, "EST")
test=str_extract(test, "METHOD=.*")
test=gsub("METHOD=|[[:space:]].*", "", test)

		
fileCSV$Estimation_Step_Convergence[rowN+1]=paste(test, collapse=" ")

fileCSV$Final_Estimation[rowN+1]=presentXML(run, "estimation_method")
	
fileCSV$CTL_Notes[rowN+1]=gsub(",", " ", presentCTL("3015", "PRE"))

	foo=presentCTL("3015", "PROB")
	foo=gsub("^[[:space:]]RUN#[[:space:]]\\d+[[:space:]]", "", foo)
	foo=gsub(",", " ", foo)
	
fileCSV$PROB_Notes[rowN+1]=foo
	
fileCSV$Extra_Notes[rowN+1]=gsub(",", " ", Notes)
	
	fileCSV=fileCSV[!is.na(fileCSV$Run),]
	
	write.csv(fileCSV,sprintf("%s/%s.csv", project, CSV), row.names=FALSE, quote=FALSE)
	}		 
#}