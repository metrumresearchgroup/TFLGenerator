#' @title Creates a confidence interval around a prediction interval
#' @description Using an internal bootstrapping algorithm, creates a confidence estimate of the prediction interval line (used in VPC development)
#' @usage ci.mean(x, ci, conf.interval, type = "low")
#' @param x numerical vector (or data.frame column) to predict confidence interval
#' @param ci prediction interval value (example .95)
#' @param type either "high" or "low" to return the upper or lower value
#' @details Utilizes quantile for basic calculation
#' @examples 
#' qLowLow=ci.mean(xx[,col], ci=ci, conf.interval[1], "low") #where xx[,col] is a ddply internal call
#' @export

ci.mean <-
function(x, ci, conf.interval, type="low") {
	if(type=="low"){n=2}
	if(type=="high"){n=3}

	temp <- tryCatch(
			if(length(unique(x)) > 1) {
				boot.ci(boot(x, f.quantile, R=50, probs=conf.interval), na.rm=TRUE, conf=ci,type=c("norm"))$normal[1,n]
			},
	error=function(e) e,
	warning=function(w) w)
	
	
	
	if(!is.null(temp)){
		if("error" %in% class(temp))
		{
			temp=mean(x)
		}
	}

	
	if(is.null(temp)){temp=mean(x)}

	return(temp)
	
}
