#' @title Creates a confidence interval around a prediction interval
#' @usage ci.meanSim(x, ci, type = "low")
#' @param x numerical vector (or data.frame column) to predict confidence interval
#' @param ci prediction interval value (example .95)
#' @param conf.interval numerical vector giving values for lower, median, and upper intervals for use in f.quantile() (example c(.1, .5, .9))
#' @param type either "high" or "low" to return the upper or lower value
#' @details This function serves as an internal bootstrap function for VPC() and requires f.quantile()
#' @export

ci.meanSim <-
function(x, ci, type="low") {
	if(type=="low"){n=ci+(1-ci)/2}
	if(type=="high"){n=(1-ci)/2}
	temp=quantile(x, probs=n, na.rm=TRUE, names=FALSE)
	if(is.null(temp)){temp=mean(x)}
	return(temp)
}
