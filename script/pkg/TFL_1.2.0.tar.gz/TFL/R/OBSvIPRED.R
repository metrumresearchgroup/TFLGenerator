#' @title Standard goodness of fit plots for observed versus predicted values
#' @concept figure
#' @description Yields a ggplot object comparing observed values to predicted values
#' @usage OBSvIPRED(datFile,  xBy = "IPRE", yBy = "DV", groupBy=NULL, markBy = NULL, xLimit = NULL, yLimit = xLimit, xBreaks = lseq(datFile[c(xBy, yBy)]), yBreaks = xBreaks, xForm = waiver(), yForm = xForm, xScale = log10_trans(), yScale = xScale, Title = "", xLab = "Individiual Prediction", yLab = "Observed Plasma Concentration", facetBy = "", minorTicks = FALSE, ...)
#' @param datFile data.frame output of a NM run containing ER-SSAP standard column names and numeric-only columns
#' @param xBy character column name for x-axis
#' @param yBy character column name for y-axis
#' @param markBy character column name for characteristic groupings within the plot (such as color and shape)
#' @param groupBy character column name for  groupings within the plot (such as smoothing line)
#' @param xLimit vector input for x-axis limits example: c(.1,100000)
#' @param yLimit vector input for y-axis limits example: c(.1,100000).  For best comparison should be left as the default (set to xLimit)
#' @param xBreaks vector input for x-axis breaks.  Best set as a log sequence of the range of x and y data.
#' @param yBreaks vector input for x-axis breaks.  For best comparison should be left as the default (set to xBreaks)
#' @param xForm function format of the x-axis (options: comma, scientific, percent or waiver() for no formatting)
#' @param yForm function format of the y-axis (options: comma, scientific, percent or waiver() for no formatting)
#' @param xScale function format for the x-axis (options, "identity", log10_trans(), log_trans())
#' @param yScale function format for the y-axis (options, "identity", log10_trans(), log_trans())
#' @param Title character figure title
#' @param xLab character x-axis title
#' @param yLab character y-axis title
#' @param facetBy character column name for optional faceting
#' @param minorTicks logical indicating whether minor log 10 ticks should be added to the y and x axis
#' @details Standard goodness of fit showing DV versus population prediction or individual prediction.
#' @examples 
#' data("twoCmt")
#' OBSvIPRED(twoCmt%>%filter(DV>0),xBy='IPRED')
#' OBSvIPRED(twoCmt,xBy='IPRED',xScale = 'identity',markBy = 'SEX')
#' @return  returns ggplot object (grob) that must be saved or printed
#' @export

OBSvIPRED <-
function(datFile, xBy="IPRE", yBy="DV", 
									 groupBy=NULL, markBy=NULL, 
                   markByType="Discrete",
                   obsLabel=NULL,
                   smoothType=if(nrow(datFile)<=1000) {'loess'}else{'gam'},
									 xLimit="", 
				 					 xBreaks=waiver(), 
									 xForm=waiver(), 
									 xScale=log10_trans(), 
									 Title="", xLab="Individiual Prediction", yLab="Observed Plasma Concentration",
									 facetBy="", fF="",fnrow="", fncol="",fscales="fixed",
									 minorTicks=FALSE,
                  minorTickNum=10,
         themeUpdate=list(),
         themeTextSize=14,
         themePlotTitleSize=1.2,
         themeAxisTxtSize=0.8,
         themeAxisTxtColour='black',
         themeAxisTitleTxtSize=0.9,
         themeAxisTitleColour='black',
         themePanelBackgroundFill='white',
         themePanelGridSize=NULL,
         themePanelGridColour='white',
         themePanelLineType=1,
         themePanelTitleSize=1.2,
         themePlotTitleColour='black',
         themePlotLegendPosition='right',
									 ...)
{
  if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
  if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
  
  if(facetBy!="" & all(fF!="")){
    datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
  }
  
  # if(fscales=="fixed"){
    if(xLimit==""){
      xLimit=range(datFile[,c(xBy,yBy)], na.rm=TRUE)		
      if("log10" %in% as.character(xScale)){
        xLimit[1]=max(
          floor(min(datFile[which(datFile[,xBy]>0 & datFile[,yBy]>0),c(xBy,yBy)], na.rm=TRUE)/10)*10,
          1E-6)
      }
    }
    if("log" %in% as.character(xScale)){
      datFile=datFile[datFile[,xBy]>0,]
      datFile=datFile[datFile[,yBy]>0,]
      xBreaks=lnseq(datFile[c(xBy,yBy)])
      if(!is.null(xLimit)){xBreaks=xBreaks[xBreaks>=xLimit[1] & xBreaks<=xLimit[2]]}
      yBreaks=xBreaks
    }
    if("log10" %in% as.character(xScale)){
      datFile=datFile[datFile[,xBy]>0,]
      datFile=datFile[datFile[,yBy]>0,]
      xBreaks=lseq(datFile[c(xBy,yBy)])
      if(!is.null(xLimit)){xBreaks=xBreaks[xBreaks>=xLimit[1] & xBreaks<=xLimit[2]]}
      yBreaks=xBreaks
    }
  # }
	
  if(!is.null(markBy)&markByType=='Discrete'){
    if(class(datFile[,markBy])!="factor") datFile[,markBy] <- factor(datFile[,markBy], sort(unique(datFile[,markBy])))
  }
  
	p1=
		ggplot(datFile, aes_string(x=xBy, y=yBy, colour=markBy))+
		stat_smooth(formula = y ~ x, se=FALSE, na.rm=TRUE, color="red", lty=2, lwd=2, method=smoothType)+
		scale_y_continuous(limits=xLimit, breaks=xBreaks, labels=eval(xForm), trans=xScale)+
	  scale_x_continuous(labels=eval(xForm), breaks=xBreaks, limits=xLimit, trans=xScale)+		
		geom_abline(intercept=0, slope=1)+
		coord_fixed(ratio = 1, xlim = xLimit, ylim = xLimit)+
		labs(title=Title, x=xLab, y=yLab)
	
	if(is.null(obsLabel)) p1=p1+geom_point(shape=1)
	if(!is.null(obsLabel)) p1=p1+geom_text(aes_string(label=obsLabel))
	
	#Add in better ticks if the scale is log10
	if (minorTicks){
	  if(xScale=='identity'){
	    p1=p1%>%addMinorTicks(xScale,xScale,xForm,xForm,xLimit,xLimit,minorTickNum)
	  }else{
	    p1=p1+annotation_logticks(base=ifelse(as.character(xScale)[1]=='log10',10,exp(1)), sides="lb", mid=unit(0.1, "cm"))
	  } 
	}
	
	
	#Add in the faceting if it exists
	if (facetBy!=""){
		p1=p1 +facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,ncol=fncol,scales=fscales)
	}
	
	rel=ggplot2:::rel
	themeUpdate=theme(text=              element_text(size=themeTextSize),
	                  axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
	                  axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
	                  plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
	                  panel.background = element_rect(fill = themePanelBackgroundFill),
	                  panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
	                  legend.position =  themePlotLegendPosition
	)
	
	if(!is.null(markBy)&markByType=='Discrete'){
	  p2=try(p1+cleanScales)
	  if(!"try-error"%in%class(p2)) p1 <- p2
	}
	  	
	p1=p1+cleanTheme +themeUpdate
	
	p1=list(pList=list(OBSvIPRED=p1),plotCols=1,plotRows=1)
	class(p1)<-c(class(p1),'TFL')
	return(p1)
	
}
