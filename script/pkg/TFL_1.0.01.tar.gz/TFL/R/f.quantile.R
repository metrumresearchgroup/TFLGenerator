f.quantile <-
function(x, ind, ...){
	
quantile(x[ind], ...)

}