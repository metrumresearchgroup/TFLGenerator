ggpairs <-
function(datFile, xCols=grep("ETA", names(datFile), value=TRUE),
								 xLimit=NULL, yLimit=NULL,
								 xForm=waiver(), yForm=waiver(),
								 xScale="identity", yScale="identity",
								facetBy="", 
								 ...){
	
	if(xCols=="" | is.null(xCols)) xCols <- grep("ETA", names(datFile), value=TRUE)
	names=factor(xCols, levels=xCols, labels=c(1:length(xCols)))
	pList=list() #create an empty list
	
	for (i in names){
		i=as.numeric(i)
		for (j in names){	
			j=as.numeric(j)
			#fit the linear regression line
			mod1 = lm(datFile[,xCols[i]]~datFile[,xCols[j]], data = datFile)
			modsum = summary(mod1)
			r2 = ifelse("adj.r.squared" %in% names(modsum), paste("R^2=",signif(modsum$adj.r.squared, digits=3)), "")
			my.p =ifelse(((dim(modsum$coefficients)[1]>=2) & dim(modsum$coefficients)[2]>=4), paste("p=",signif(modsum$coefficients[2,4],digits=3)), "")
			
			if(i==j){
				pList[[paste("plot",i,j, sep="")]]=
					textGrob(xCols[i])
				
			}
			if(j>i){
				pList[[paste("plot",i,j, sep="")]]=
					textGrob(sprintf("%s\n%s",eval(r2), eval(my.p)), gp=gpar(fontsize=10))
				
			}
			
			if(i>j){
				pList[[paste("plot",i,j, sep="")]]=
					ggplot(datFile, aes_string(x=xCols[j], y=xCols[i]))+
					geom_smooth(method="loess", se=FALSE, colour="red")+
					geom_point(shape=1, size=.5)+
					geom_hline(yintercept=0, lty=2)+
					geom_vline(xintercept=0, lty=2)+
					labs(x=NULL, y=NULL)+
					scale_x_continuous(breaks=pretty_breaks(), limits=xLimit, labels=eval(xForm), trans=xScale)+
					scale_y_continuous(breaks=pretty_breaks(), limits=yLimit, labels=eval(yForm), trans=yScale)+
					theme(panel.background = element_blank(),
								axis.text=element_text(size=6, colour="black"),	axis.line=element_line(),
								panel.border=element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
								plot.margin=unit(c(.1,0,.1,0), "cm"))
				
				
			}
			
		}
	}
	for(i in 1:length(pList)){
	  if(any(grepl("ggplot",class(pList[[i]])))) class(pList[[i]]) <- "ggplot"
	} 
	
	return(do.call("arrangeGrob", c(pList, ncol=length(xCols))))	
	
}
