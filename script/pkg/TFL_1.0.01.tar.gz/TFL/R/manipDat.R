manipDat <-
function(datFile,
									xBy="TAFD", yBy="DV",
									markBy="DOSE", markByAdd="",
                  preserveMarkByLevels=F,
									facetBy="", facetFact="",
									dataLimits="", dataTrans="",
									groupBy="NMID",
									sumType="mean", sumVar="sd", 
									sumThis=FALSE,
									...){
	
  # If preserveMarkBy, then set factor levels on full data
  if(!is.null(markBy) & preserveMarkByLevels){
    if(markBy %in% names(datFile)){
      #perform factoring to include details
      datFile[,markBy]=factor(datFile[,markBy], levels=sort(unique(datFile[,markBy])), labels=paste(sort(unique(datFile[,markBy])), markByAdd, sep=""))
    }
  }
  
	#perform any limits on the data set
	if (class(dataLimits)=="list" | length(dataLimits)>1){
		#check if there is only a single item
		if(length(dataLimits)==3){
			if(length(dataLimits[[1]]==1 & length(dataLimits[[2]])==1 & length(dataLimits[[3]])==1)){
				dataLimits=list(dataLimits)
			}
		}
		for(n in c(1:length(dataLimits))){
			if(length(dataLimits[[n]])==3){
				if (dataLimits[[n]][1] %nin% names(datFile)){break}
				datFile=datFile[which(do.call(dataLimits[[n]][[2]],list(datFile[,dataLimits[[n]][[1]]],dataLimits[[n]][[3]]))),]
			}
			if(length(dataLimits[[n]])==7){
				if (dataLimits[[n]][[1]] %nin% names(datFile) | dataLimits[[n]][[5]] %nin% names(datFile)){break}
				datFile=datFile[which(
				do.call(
					dataLimits[[n]][4],
					list(
						do.call(dataLimits[[n]][[2]],list(datFile[,dataLimits[[n]][[1]]],dataLimits[[n]][[3]])),
						do.call(dataLimits[[n]][[6]],list(datFile[,dataLimits[[n]][[5]]],dataLimits[[n]][[7]]))
					)
				)
					),]
			}
		}
	}
	
	
	#perform any transformations on the data set
	if (class(dataTrans)=="list" | length(dataTrans)>1){
		if(class(dataTrans)!="list"){dataTrans=list(dataTrans)}
		for(n in c(1:length(dataTrans))){
			if(length(dataTrans[[n]])==3){
				if (dataTrans[[n]][[1]] %nin% names(datFile)){break}
				datFile[,dataTrans[[n]][[1]]]=do.call(dataTrans[[n]][[2]],
																					list(
																					suppressWarnings(as.numeric(datFile[,dataTrans[[n]][[1]]])),
																						suppressWarnings(as.numeric(dataTrans[[n]][[3]]))
																					)
																				)
			}
		}
	}
		
  	#summarize if grouped
			if(sumThis==TRUE){
			gr=unique(c(xBy, groupBy, markBy, facetBy))
			if(facetBy==""){gr=unique(c(xBy, groupBy, markBy))}
			datFile=summarySE(datFile, measurevar=yBy, groupvars=gr)
			datFile=addMinMax(datFile, measurevar=sumType, devvar=sumVar)	

	}
	
	
	if(!is.null(markBy) & !preserveMarkByLevels){
		if(markBy %in% names(datFile)){
	#perform factoring to include details
	datFile[,markBy]=factor(datFile[,markBy], levels=sort(unique(datFile[,markBy])), labels=paste(sort(unique(datFile[,markBy])), markByAdd, sep=""))
	}
	}
	
	
 if (facetBy!="" & class(facetFact)=="list" ) {datFile[,facetBy]=factor(datFile[,facetBy], levels=facetFact[[1]], labels=facetFact[[2]])}	
	
	
	return(datFile)
}
