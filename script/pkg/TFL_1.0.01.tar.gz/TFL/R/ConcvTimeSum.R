ConcvTimeSum <-
function(datFile, groupBy="DOSE", xBy="TAFD", yBy="DV",
											sumType="mean", sumVar="sd", 
											markBy="DOSE", preserveMarkByLevels=F, Color=T,
											xLimit=NULL,yLimit=NULL,
				 							xForm=waiver(), yForm=waiver(),
											 xScale="identity", yScale="log10", 
											Title="Individuals by Dose Cohort", xLab="Time", yLab="Concentration",
											facetBy="", 
											...)
{
  # Only update in the scope of this function
  if(preserveMarkByLevels){
    if(Color) cleanScales <- setColorScale(drop=F) else cleanScales <- setGrayScale(drop=F)
  }
  
	p1=
		ggplot(datFile, aes_string(x=xBy, y=sumType, ymax="Max", ymin="Min", group=groupBy, color=markBy, shape=markBy, lty=markBy))+
		geom_line()+
		geom_point()+
		geom_errorbar()+
		cleanTheme+
		cleanScales+
		scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
		scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
		labs(title=Title, x=xLab, y=yLab)
	
	#Add in better ticks if the scale is log10
	if (as.character(yScale)[1]=="log-10"){
		p1=p1+annotation_logticks(, sides="l", mid=unit(0.1, "cm"))
	}
	
	if (as.character(xScale)[1]=="log-10"){
		p1=p1+annotation_logticks(, sides="b", mid=unit(0.1, "cm"))
		
	}
	
	#Add in the faceting if it exists
	if (facetBy!=""){
		p1=p1 +facet_wrap(as.formula(paste("~", facetBy)))
		
	}
	
	return(p1)
	
	
}
