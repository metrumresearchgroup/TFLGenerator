setGrayScale <-
function(fillList=NULL, shapeList=NULL, lineList=NULL, colourList=NULL){
	
	fillList=fillList %||% grayPalette
	shapeList=shapeList %||% shapesPalette
	lineList=lineList %||% graylinePalette
	colourList=colourList	%||% grayPalette
	
	return(list(scale_fill_manual(values=fillList), 
							scale_shape_manual(values=shapeList), 
							scale_linetype_manual(values=lineList),
							scale_colour_manual(values=colourList))
	)
}
