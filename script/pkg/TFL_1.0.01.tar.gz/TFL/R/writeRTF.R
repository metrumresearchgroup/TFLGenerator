writeRTF=function(grobPath)
{	
	library(rtf)
	
	fileName=gsub("Grob(s)*\\.R", "Figures.doc", grobPath)
	
	rtf=RTF(fileName, width=8.5, height=11, font.size=12, omi=c(1,1,1,1))							 
	addHeader(rtf, title="Amgen GUI TFL Output", subtitle=sprintf("Produced on %s", Sys.Date()))	
	
	addHeader(rtf, title="Preliminary Population Pharmacokinetic Analysis of <<matrix>>\nin <<subjects>> from Amgen Phase <<#>> Studies",
						subtitle="Authors:\n\nContributing Scientists:")
	
	if(!exists("guiGrobs")){
	  loadGrobs(sprintf("%s_Grobs.R", fileHead))
	}
	
	for (n in c(1:length(guiGrobs))){
	  addPageBreak(rtf)
	  if(n==1 | (guiGrobs[[n]]$Type!=guiGrobs[[max(n-1,1)]]$Type)){
	    addHeader(rtf,guiGrobs[[n]]$Type,bold=TRUE,TOC.level=1,font.size=18)
	    addPageBreak(rtf)
	  }
		 	addHeader(rtf,guiGrobs[[n]]$LegendTitle,bold=TRUE,TOC.level=2)
		 	addNewLine(rtf, n=1)
		 	addParagraph(rtf, guiGrobs[[n]]$Legend)
		 	addNewLine(rtf, n=1)
		 	if(grepl("Tab",names(guiGrobs)[n])){
		 	  htwdth <- GUI:::.identify(guiGrobs[[n]]$Plot)
		 	  ratio <- as.numeric(htwdth["height"]) / as.numeric(htwdth["width"])
		 	  if(ratio >=1){
		 	    if( 7.5*ratio < 8){  widthi <- 7.5; heighti <- 7.5 * ratio 
		 	    }else{ heighti <- 8; widthi <- heighti / ratio }
		 	  }else{ # ratio < 1
		 	    widthi=7.5; heighti <- 7.5*ratio
		 	  }
		 	  addPng(rtf, guiGrobs[[n]]$Plot$src, width=widthi, height=heighti, res=150)
		 	}else{
		 	  if(grepl("GOF",names(guiGrobs)[n])){
		 	    addPlot(rtf, plot.fun=print,width=8*637.5/825,height=8,res=150, guiGrobs[[n]]$Plot)	
		 	    # From the panel defn for GOF
		 	  }else if (grepl("ConcvTimeMult",names(guiGrobs)[n])){
		 	    plots <- grep(names(guiGrobs[n]),list.files(dirname(guiGrobs[[n]]$Plot$src),full.names=T),value=T)
		 	    plots <- mixedsort(plots)
		 	    htwdth <- GUI:::.identify(guiGrobs[[n]]$Plot)
		 	    ratio <- as.numeric(htwdth["height"]) / as.numeric(htwdth["width"])
		 	    heighti <- 8; widthi <- heighti / ratio; # These are full page plots
		 	    for(f in plots){
		 	      addPng(rtf, f, width=widthi, height=heighti, res=150)
		 	      addPageBreak(rtf)
		 	    }
		 	  } else addPlot(rtf, plot.fun=print,width=7.5,height=4,res=150, guiGrobs[[n]]$Plot)	
		 	}
		 	#addPageBreak(rtf)
		 }
		 done(rtf)
}