writeRTF=function(grobPath)
{	
	library(rtf)
	
	fileName=gsub("Grob(s)*\\.R", "Figures.doc", grobPath)
	
	rtf=RTF(fileName, width=8.5, height=11, font.size=12, omi=c(1,1,1,1))							 
	addHeader(rtf, title="Amgen GUI TFL Output", subtitle=sprintf("Produced on %s", Sys.Date()))	
	
	addHeader(rtf, title="Preliminary Population Pharmacokinetic Analysis of <<matrix>>\nin <<subjects>> from Amgen Phase <<#>> Studies",
						subtitle="Authors:\n\nContributing Scientists:")
	
	if(!exists("guiGrobs")){loadGrobs(sprintf("%s_Grobs.R", fileHead))} 
		 for (n in c(1:length(guiGrobs))){
		 	addText(rtf,guiGrobs[[n]]$LegendTitle,bold=TRUE)
		 	addNewLine(rtf, n=1)
		 	addParagraph(rtf, guiGrobs[[n]]$Legend)
		 	addNewLine(rtf, n=1)
		 	addPlot(rtf, plot.fun=print,width=7.5,height=4,res=150, guiGrobs[[n]]$Plot)	
		 	addNewLine(rtf, n=1)
		 }
		 done(rtf)
}