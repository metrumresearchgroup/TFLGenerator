savePlots <-
function(plotName, directory, saveName=as.character(plotName)){
	dir.create(directory,showWarning=FALSE)
	dir.create(sprintf("%s/PNG/", directory),showWarning=FALSE)
	
	height=ifelse(class(plotName)=="arrange", 11*7.5/8.5, 4.5)
	
	png(file=sprintf("%s/PNG/%s.png", directory, saveName), width = 7.5, height = height, units="in", res=150)
	print(plotName)
# 	dev.off(which=dev.list()[[length(dev.list())]])
# 	dev.set(which=dev.list()[["RStudioGD"]])
	dev.off()
	
}
