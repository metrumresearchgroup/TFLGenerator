savePlots <-
function(plotName, directory, saveName=as.character(plotName)){
	dir.create(directory,showWarning=FALSE)
	dir.create(sprintf("%s/PNG/", directory),showWarning=FALSE)
	
	
# 	ggsave(filename = sprintf("%s/PNG/%s.png", directory, saveName), plot = plotName,
# 				 width = 7.5, height = 4, units = "in", dpi = 300, limitsize = TRUE)
	
	
	png(file=sprintf("%s/PNG/%s.png", directory, saveName), width = 7.5, height = 4, units="in", res=150)
	print(plotName)
# 	dev.off(which=dev.list()[[length(dev.list())]])
# 	dev.set(which=dev.list()[["RStudioGD"]])
	dev.off()
	
}
