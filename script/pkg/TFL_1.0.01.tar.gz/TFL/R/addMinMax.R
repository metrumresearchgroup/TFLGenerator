addMinMax <-
function(data, measurevar="DVmean", devvar="sd", na.rm=TRUE) {	
	if (na.rm){data=data[!is.na(data[,measurevar]),]}
	data$Max=data[,measurevar] + abs(data[,devvar])
	data$Max[is.na(data[,devvar])]=data[is.na(data[,devvar]), measurevar]
	data$Min=data[,measurevar] -abs(data[,devvar])
	data$Min[is.na(data[,devvar])]=data[is.na(data[,devvar]), measurevar]
	
	return(data)
}
