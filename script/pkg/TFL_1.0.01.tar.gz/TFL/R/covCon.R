covCon <-
function(datFile, xCols, yCols, nCols=2,
								xLimit=NULL, yLimit=NULL,
								xForm=waiver(), yForm=waiver(),
								xScale="identity", yScale="identity",
								facetBy="", 
								...){
	
	#for individual plots, nCols=1, xBy and yBy is a single column name (such as "RACE" and "ETA1)
	#for a multiple plot object

	pList=list()
	for (x in xCols){
		for (y in yCols){	
			#perform a one way analysis of variance
			mod1 = lm(datFile[,y]~datFile[,x], data = datFile)
			modsum = summary(mod1)
			r2 = ifelse("adj.r.squared" %in% names(modsum), paste("R^2=",signif(modsum$adj.r.squared, digits=3)), "")
			my.p =ifelse(((dim(modsum$coefficients)[1]>=2) & dim(modsum$coefficients)[2]>=4), paste("p=",signif(modsum$coefficients[2,4],digits=3)), "")
			
			
		p1=	
				ggplot(datFile, aes_string(x=x, y=y))+
				geom_smooth(method="loess", se=FALSE, colour="red", lty=2)+
				geom_abline(intercept=mod1$coeff[1], slope=mod1$coeff[2],  colour="red")+
				geom_point(shape=1)+
				geom_hline(yintercept=0, lty=2)+
				labs(x=x, y=y, title=sprintf("%s:%s", r2, my.p))+
				scale_x_continuous(breaks=pretty_breaks(), limits=xLimit, labels=eval(xForm), trans=xScale)+
				scale_y_continuous(breaks=pretty_breaks(), limits=yLimit, labels=eval(yForm), trans=yScale)+
				theme(panel.background = element_blank(),
							axis.text=element_text(size=12, colour="black"),	axis.line=element_line(),
							panel.border=element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
							plot.margin=unit(c(.1,0,.1,0), "cm"))
		
			if (facetBy!=""){
				p1=p1 +facet_wrap(as.formula(paste("~", facetBy)))
				
			}
			
			pList[[paste("plot",x, "vs", y, sep="")]]=p1
		
		
		}
	}
	
	
	if(length(c(xCols,yCols))==2){return(pList[[1]])}
	return(do.call("arrangeGrob", c(pList, ncol=nCols)))
	
}
