
OBSvIPRED <-
function(datFile, xBy="IPRE", yBy="DV", 
									 groupBy=NULL, markBy=NULL,
									 xLimit=NULL, 
				 					 xBreaks=waiver(), 
									 xForm=waiver(), 
									 xScale=log10_trans(), 
									 Title="", xLab="Individiual Prediction", yLab="Observed Plasma Concentration",
									 facetBy="", 
									 minorTicks=FALSE,
									 ...)
{
	
	if(is.null(xLimit)){
		xLimit=range(datFile[,c(xBy,yBy)], na.rm=TRUE)		
		if("log10" %in% as.character(xScale)){
			xLimit[1]=floor(min(datFile[which(datFile[,xBy]>0 & datFile[,yBy]>0),c(xBy,yBy)], na.rm=TRUE)/10)*10
		}
	}
	if("log" %in% as.character(xScale)){
		datFile=datFile[datFile[,xBy]>0,]
		datFile=datFile[datFile[,yBy]>0,]
		xBreaks=lnseq(datFile[c(xBy,yBy)])
		if(!is.null(xLimit)){xBreaks=xBreaks[xBreaks>=xLimit[1] & xBreaks<=xLimit[2]]}
		yBreaks=xBreaks
	}
	if("log10" %in% as.character(xScale)){
		datFile=datFile[datFile[,xBy]>0,]
		datFile=datFile[datFile[,yBy]>0,]
		xBreaks=lseq(datFile[c(xBy,yBy)])
		if(!is.null(xLimit)){xBreaks=xBreaks[xBreaks>=xLimit[1] & xBreaks<=xLimit[2]]}
		yBreaks=xBreaks
	}
	

	
	
	p1=
		ggplot(datFile, aes_string(x=xBy, y=yBy, colour=markBy))+
		geom_point(shape=1)+	
		stat_smooth(formula = y ~ x, se=FALSE, na.rm=TRUE, color="red", lty=2, aes_string(group=groupBy))+
		cleanTheme+
		cleanScales+
		scale_y_continuous(limits=xLimit, breaks=xBreaks, labels=eval(xForm), trans=xScale)+
	 scale_x_continuous(labels=eval(xForm), breaks=xBreaks, limits=xLimit, trans=xScale)+		
		geom_abline(intercept=0, slope=1)+
		coord_fixed(ratio = 1, xlim = xLimit, ylim = xLimit, wise = NULL)+
		labs(title=Title, x=xLab, y=yLab)
	
	#Add in better ticks if the scale is log10
	if (minorTicks){
		p1=p1+
			annotation_logticks(, sides="l", mid=unit(0.1, "cm")) +
			annotation_logticks(, sides="b", mid=unit(0.1, "cm"))
	}
	
	
	#Add in the faceting if it exists
	if (facetBy!=""){
		p1=p1 +facet_wrap(as.formula(paste("~", facetBy)))
	}
	
	return(p1)
	
}
