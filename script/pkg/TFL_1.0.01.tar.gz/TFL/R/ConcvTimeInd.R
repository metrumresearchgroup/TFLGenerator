ConcvTimeInd <-
function(datFile, groupBy="NMID", xBy="TAFD", yBy="DV", 
         markBy="DOSE", preserveMarkByLevels=F, Color=T,
         xLimit=NULL, yLimit=NULL,
         xForm=waiver(), yForm=waiver(),
         xScale="identity", yScale="log10", 
         Title="Individuals", xLab="Time", yLab="Concentration",
         facetBy="", 
         ...)
{
		
  # Only update in the scope of this function
  if(preserveMarkByLevels){
    if(Color) cleanScales <- setColorScale(drop=F) else cleanScales <- setGrayScale(drop=F)
  }

	p1=ggplot(datFile, aes_string(x=xBy, y=yBy, group=groupBy, color=markBy, shape=markBy, lty=markBy))+
		geom_line()+
		geom_point()+
		cleanTheme+
		cleanScales+
		scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
		scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
		labs(title=Title, x=xLab, y=yLab)

	#Add in better ticks if the scale is log10
	if ("log-10" %in% as.character(yScale)){
		p1=p1+annotation_logticks(, sides="l", mid=unit(0.1, "cm"))
	}
	
	if ("log-10" %in% as.character(xScale)){
		p1=p1+annotation_logticks(, sides="b", mid=unit(0.1, "cm"))
		
	}

	#Add in the faceting if it exists
	if (facetBy!=""){
		p1=p1 +facet_wrap(as.formula(paste("~", facetBy)))
	}
	
	return(p1)

}
