#' @export
makeDefaultbarchartMult <-
function(title, Defaults){																
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
  
	Defaults[[paste0("catList", title)]]="SEX; Gender\nRACE; Race\nDIS; Disease status"						
	Defaults[[paste0("nrow", title)]]=1

	Defaults[[paste0("plotdeets", title)]]=FALSE
	Defaults[[paste0("reorg", title)]]=FALSE
	Defaults[[paste0("notches", title)]]=TRUE
	
	Defaults[[paste0("order", title)]]=c("Density", "QQ", "Boxplot")
	
	Defaults[[paste("DataLim", title, sep="")]]="!duplicated(NMID)"
	Defaults[[paste("Trans", title, sep="")]]=""

	Defaults[[paste("LegendTitle", title, sep="")]]="Distribution of Subject's Sex, Race, and Disease status"
	Defaults[[paste("Legend", title, sep="")]]="Caption"
	Defaults[[paste("Footnote", title, sep="")]]=""
	Defaults[[paste("minorTicks", title, sep="")]]=FALSE
	Defaults[[paste("minorTickNum", title, sep="")]]=10
	Defaults[[paste("reset", title, sep="")]]=FALSE
	
	Defaults[[paste("plotHeight", title, sep="")]]=defaultPlot$Ratio$height[defaultPlot$Ratio$shape==defaultPlot$Shapes$shape[defaultPlot$Shapes$plot==gsub('[0-9]','',title)]]
	Defaults[[paste("plotShape", title, sep="")]]=defaultPlot$Shapes$shape[defaultPlot$Shapes$plot==gsub('[0-9]','',title)]
	
	for(item in names(themeEditorDefaults)){
	  Defaults[[paste(item, title, sep="")]]=themeEditorDefaults[[item]]
	}
	
	return(Defaults)	
}
