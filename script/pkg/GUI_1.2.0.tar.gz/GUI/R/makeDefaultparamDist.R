makeDefaultparamDist <-
function(title, Defaults){																
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	Defaults[[paste("groupP", title, sep="")]]=FALSE					
	Defaults[[paste("facetBy", title, sep="")]]=""
	Defaults[[paste("facetFact", title, sep="")]]=""
	Defaults[[paste("fdeets", title, sep="")]]=FALSE
	Defaults[[paste('fnrow',title,sep="")]]=""
	Defaults[[paste('fncol',title,sep="")]]=""
	Defaults[[paste("fscales",title,sep="")]]="fixed"
	Defaults[[paste("strat", title, sep="")]]=""
	Defaults[[paste("reorg", title, sep="")]]=FALSE
	Defaults[[paste("plotdeets", title, sep="")]]=FALSE
	Defaults[[paste("Title", title, sep="")]]=""
	Defaults[[paste("Xtit", title, sep="")]]="Parameter"
	Defaults[[paste("Ytit", title, sep="")]]="Density"
	Defaults[[paste("Xlim", title, sep="")]]=""
	Defaults[[paste("Ylim", title, sep="")]]=""
	Defaults[[paste("xForm", title, sep="")]]="none"
	Defaults[[paste("xScale", title, sep="")]]="identity"
	Defaults[[paste("yForm", title, sep="")]]="none"
	Defaults[[paste("yScale", title, sep="")]]="identity"
	Defaults[[paste("DataLim", title, sep="")]]="!duplicated(NMID)"
	Defaults[[paste("Trans", title, sep="")]]=""
	Defaults[[paste("AES", title, sep="")]]=FALSE	
	Defaults[[paste("xCols", title, sep="")]]="ETA1"						
	Defaults[[paste("LegendTitle", title, sep="")]]="Histograms of Interindividual Random Effects"
	Defaults[[paste("Legend", title, sep="")]]="Caption"
		Defaults[[paste("Footnote", title, sep="")]]="The y-axis shows the percent of observations that fall into respective bins.  The solid blue lines illustrate the density of the random effect distributions.  The red vertical lines show medians of these distributions.  The dashed red lines show the density of the random effect distributions as estimated by the model.  Shrinkage calculations are described in the Methods section."
	Defaults[[paste("binWidth", title, sep="")]]=.1
	Defaults[[paste("reset", title, sep="")]]=FALSE
	Defaults[[paste("ncol",title,sep="")]]=1
	Defaults[[paste("nrow",title,sep="")]]=1
	Defaults[[paste("minorTicks", title, sep="")]]=FALSE
	Defaults[[paste("minorTickNum", title, sep="")]]=10
	
	Defaults[[paste("plotHeight", title, sep="")]]=defaultPlot$Ratio$height[defaultPlot$Ratio$shape==defaultPlot$Shapes$shape[defaultPlot$Shapes$plot==gsub('[0-9]','',title)]]
	Defaults[[paste("plotShape", title, sep="")]]=defaultPlot$Shapes$shape[defaultPlot$Shapes$plot==gsub('[0-9]','',title)]
	
	for(item in names(themeEditorDefaults)){
	  Defaults[[paste(item, title, sep="")]]=themeEditorDefaults[[item]]
	}
	
	return(Defaults)	
}
