makeDefaultcorPairs <-
function(title, Defaults){																
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	Defaults[[paste("groupP", title, sep="")]]=FALSE	
	Defaults[[paste("facetBy", title, sep="")]]=""
	Defaults[[paste("facetFact", title, sep="")]]=""
	Defaults[[paste("strat", title, sep="")]]=""
	Defaults[[paste("reorg", title, sep="")]]=FALSE
	Defaults[[paste("plotdeets", title, sep="")]]=FALSE
	
	Defaults[[paste("corstat",title,sep="")]]="R2"
	Defaults[[paste("xCols", title, sep="")]]=c("ETA1","ETA2")
	Defaults[[paste("Xtit", title, sep="")]]=c("Eta 1; Eta 2")
	Defaults[[paste("Xlim", title, sep="")]]=NULL
	Defaults[[paste("xForm", title, sep="")]]="none"
	Defaults[[paste("xScale", title, sep="")]]="identity"
	Defaults[[paste("Ylim", title, sep="")]]=NULL
	Defaults[[paste("yForm", title, sep="")]]="none"
	Defaults[[paste("yScale", title, sep="")]]="identity"
	
	Defaults[[paste("DataLim", title, sep="")]]="!duplicated(NMID)"
	Defaults[[paste("Trans", title, sep="")]]=""
	Defaults[[paste("AES", title, sep="")]]=FALSE					
	Defaults[[paste("LegendTitle", title, sep="")]]="Correlations of Interindividual Random Effects"
	Defaults[[paste("Legend", title, sep="")]]="Caption"
	Defaults[[paste("Footnote", title, sep="")]]="The continuous covariates (points) and the red lowess (local regression smoother) trend lines are plotted.  The coefficient of determination between the covariates are also presented."
	Defaults[[paste("minorTicks", title, sep="")]]=FALSE
	Defaults[[paste("minorTickNum", title, sep="")]]=10
	Defaults[[paste("reset", title, sep="")]]=FALSE
	
	Defaults[[paste("plotHeight", title, sep="")]]=defaultPlot$Ratio$height[defaultPlot$Ratio$shape==defaultPlot$Shapes$shape[defaultPlot$Shapes$plot==gsub('[0-9]','',title)]]
	Defaults[[paste("plotShape", title, sep="")]]=defaultPlot$Shapes$shape[defaultPlot$Shapes$plot==gsub('[0-9]','',title)]
	
	for(item in names(themeEditorDefaults)){
	  Defaults[[paste(item, title, sep="")]]=themeEditorDefaults[[item]]
	}
	
	
	return(Defaults)	
}
