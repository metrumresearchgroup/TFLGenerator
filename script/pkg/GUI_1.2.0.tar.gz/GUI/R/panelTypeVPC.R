#' @export
panelTypeVPC <-
  function(plotType, input, varNames=list(), Set=list()){
    
    #All if statements relate to a specific output type, which then add an additional panel
    if(input[[paste(plotType, "Num", sep="")]]>=1){
      
      numbers=as.numeric(unlist(str_extract_all(input[[paste(plotType, "Num", sep="")]], "\\d+")))
      if(length(numbers)>1){numRange=numbers[which(numbers!=0)]}
      if(length(numbers)==1){numRange=c(1:numbers)}
      for (n in numRange){
        
        title=paste(plotType, n, sep="")
        #set originating defaults
        checkPriors(plotType=plotType, input=input, n=n)
        
        nn=length(Set)
        
        if(paste0("nms_source",title) %nin% names(varNames)) varNames[[paste0("nms_source",title)]] <- ""
        if(paste0("nms_tab",title) %nin% names(varNames)) varNames[[paste0("nms_tab",title)]] <- ""
        
        Set[[nn+1]]=
          tabPanel(paste(plotType,n, sep="#"),
                   tabsetPanel(
                     tabPanel("VPC Data",
                              fluidRow(
                                column(width = 6, title="Code parser (VPC sims)",
                                       h4("Manipulation code"),
                                       aceEditor(paste0("dataParse_vpc",title), value=Defaults[[paste0("dataParse_vpc",title)]], mode="r", theme="chrome", wordWrap=T)
                                ),
                                column(width=6, title="VPC data specification",
                                       fluidRow(
                                         column(width=12, title="Action button",
                                                actionButton(paste0("updateVPCView",title), "Generate VPC data")
                                         )
                                       ),
                                       wellPanel(
                                         fluidRow(
                                           column(width = 12, title=paste0("Data specification ",title),
                                                  textInput(paste0("vpcRun",title), "Run # for simulations", Defaults[[paste0("vpcRun",title)]]),
                                                  textInput(paste0("vpcColnames",title), "Column names for simulation table", Defaults[[paste0("vpcColnames",title)]]),
                                                  numericInput(paste0("vpcRep",title), "Number of subproblems", Defaults[[paste0("vpcRep",title)]], min=0),
                                                  textInput(paste0("vpcSource",title), "Source file location for VPC run", Defaults[[paste0("vpcSource",title)]]),
                                                  textInput(paste0("vpcSourceDV",title), "DV in source file (observed)", Defaults[[paste0("vpcSourceDV",title)]]),
                                                  selectizeInput(paste0("dataSubset",title), "Source file columns to to keep", selected=Defaults[[paste0("dataSubset",title)]],choices=Defaults[[paste0("dataSubset",title)]],
                                                                 multiple=T, options=list(create=TRUE)),
                                                  # selectizeInput(paste0("mergeKey",title), "Choose merge key", 
                                                  #                choices=intersect(varNames[[paste0("nms_source",title)]],
                                                  #                                  varNames[[paste0("nms_tab",title)]]),
                                                  #                multiple=T, options=list(create=TRUE),
                                                  #                selected=Defaults[[paste0("mergeKey",title)]]),
                                                  textInput(paste0("mergeKey",title), "Choose merge key (comma separated)", Defaults[[paste0("mergeKey",title)]]),
                                                  checkboxInput(paste0("sortBy",title), "Sort by study, patient, and time?",value=T),
                                                  checkboxInput(paste0("renameToDefaults",title), "Rename to defaults?",Defaults[[paste0("renameToDefaults",title)]])
                                                  
                                           )
                                         )
                                       )
                                )
                              ),
                              fluidRow(
                                column(width=12, title="Data viewer",
                                       numericInput(paste0("nhead",title), "Number of rows of merged dataset to preview", 10, min=0),
                                       # verbatimTextOutput(paste0('contentsHead_vpcdata',n))
                                       tableOutput(paste0('contentsHead_vpcdata',n))
                                       # DT:::dataTableOutput(paste0("contentsHead_vpcdata",n))
                                       # The following should give a DT view of the data, but breaks the app.  Not sure why.
                                       # fluidRow(
                                       #   column(width = 12,
                                       #          box(
                                       #            title = "", width = NULL, status = "primary",
                                       #            div(style = 'overflow-x: scroll', DT::dataTableOutput(paste0('contentsHead_vpcdata',n)))
                                       #          )
                                       #   )
                                       # )

                                )
                              )
                     ),
                     tabPanel("Additional data specification",
                              fluidRow(
                                column(width = 6, title="Code parser (additional data)",
                                       h4("Manipulation code"),
                                       p("Column names for y-axis, x-axis, dose (if dose correction), and population predictions (if prediction corrected) are assumed to be the same as the main VPC data source.  If not, update here."),
                                       aceEditor(paste0("addlDataParse_vpc",title), value=Defaults[[paste0("addlDataParse_vpc",title)]], mode="r", theme="chrome", wordWrap=T)
                                ),
                                column(width=6, title="Additional data specification",
                                       fluidRow(
                                         column(width=12, title="Action button",
                                                actionButton(paste0("updateAddlVPCView",title), "Load data layer")
                                         )
                                       ),
                                       wellPanel(
                                         fluidRow(
                                           column(width = 12, title=paste0("Data specification ",title),
                                                  textInput(paste0("addlVpcSource",title), "Source file location", Defaults[[paste0("addlVpcSource",title)]]),
                                                  # textInput(paste0("addlVpcSourceY",title), "Y axis in source file", Defaults[[paste0("addlVpcSourceY",title)]]),
                                                  # textInput(paste0("addlVpcSourceX",title), "X axis in source file", Defaults[[paste0("addlVpcSourceX",title)]]),
                                                  checkboxInput(paste0("addlRenameToDefaults",title), "Rename to defaults?",Defaults[[paste0("addlRenameToDefaults",title)]])
                                                  
                                           )
                                         )
                                       )
                                )
                              ),
                              fluidRow(
                                column(width=12, title="Data viewer",
                                       numericInput(paste0("addlNhead",title), "Number of rows of dataset to preview", 10, min=0),
                                       # verbatimTextOutput(paste0('contentsHead_vpcdata',n))
                                       tableOutput(paste0('contentsHead_addlVpcdata',n))
                                       # DT:::dataTableOutput(paste0("contentsHead_vpcdata",n))
                                       # The following should give a DT view of the data, but breaks the app.  Not sure why.
                                       # fluidRow(
                                       #   column(width = 12,
                                       #          box(
                                       #            title = "", width = NULL, status = "primary",
                                       #            div(style = 'overflow-x: scroll', DT::dataTableOutput(paste0('contentsHead_vpcdata',n)))
                                       #          )
                                       #   )
                                       # )

                                )
                              )
                     ),
                     tabPanel("Figure",
                              sidebarPanel(
                                actionButton(paste("button", plotType, n, sep=""), "Generate Plot"),
                                
                                wellPanel(
                                  selectInput(paste0("shadingType",title), "Shading reflects uncertainty in:",
                                              choices=c("simulated percentiles",
                                                        # "observed and predicted mean", 
                                                        "predicted median", "no shading"),
                                              selected=Defaults[[paste0("shadingType",title)]]),
                                  conditionalPanel(condition= (paste0("input.shadingType",title,"=='simulated percentiles'")),
                                                   radioButtons(inputId = paste0("shadingTypeShape",title),label = "Placement of Shading",choices = c("Each Percentile","Overall Percentile"),selected = Defaults[[paste0("shadingTypeShape",title)]],inline = T),
                                                   textRow(paste0("PI",title), "Percentiles of interest", Defaults[[paste0("PI",title)]]),
                                                   h2(""),
                                                   textRow(paste0("ci",title),"Confidence level around PI",Defaults[[paste0("ci",title)]])
                                  ),
                                  
                                  conditionalPanel(condition= (paste0("input.shadingType",title,"=='no shading'")),
                                                   textRow(paste0("PIns",title), "Percentiles of interest", Defaults[[paste0("PIns",title)]])
                                  ),
                                  
                                  conditionalPanel(condition= (paste0("input.shadingType",title,"=='predicted median'")),
                                                   textRow(paste0("ciPM",title),"Confidence level around median",Defaults[[paste0("ciPM",title)]])
                                  ),
                                  
                                  conditionalPanel(condition= (paste0("input.shadingType",title,"=='observed and predicted mean'")),
                                                   textRow(paste0("ci",title),"Confidence level",Defaults[[paste0("ci",title)]])

                                  ),
                                  h1(),
                                  textRow(paste0("yByObs",title), "Dependent variable (observed)", Defaults[[paste0("yByObs",title)]]),
                                  h2(""),
                                  textRow(paste0("label",title), "Label for data", Defaults[[paste0('label',title)]]),
                                  checkboxInput(paste0('showObs',title),"Show observed points", Defaults[[paste0("showObs",title)]]),
                                  h1(),
                                  textRow(paste0("predVar",title), "Simulated DV column", Defaults[[paste0("predVar",title)]]),
                                  h2(""),
                                  textRow(paste0("xBy",title), "Independent variable (x-axis)", Defaults[[paste0("xBy",title)]]),
                                  h2(""),
                                  textRow(paste0("simCol",title), "Sim # column", Defaults[[paste0("simCol",title)]]),
                                  h2(""),
                                  textRow(paste0('lb',title), "Lower bound (DV)", Defaults[[paste0("lb",title)]]),
                                  h2(""),
                                  checkboxInput(paste0("includeAddl_pts",title), "Include additional data points?", Defaults[[paste0("includeAddl_pts",title)]]),
                                  checkboxInput(paste0("includeAddl_trend",title), "Include additional data trend?", Defaults[[paste0("includeAddl_trend",title)]]),
                                  textRow(paste0("addlLabel",title), "Label for additional data", Defaults[[paste0('addlLabel',title)]])
                                  
                                ),
                                
                                
                                checkboxInput(paste0("predCor",title), "Prediction correction", Defaults[[paste0("predCor",title)]]),
                                conditionalPanel(condition= (paste0("input.predCor",title)),
                                                 wellPanel(
                                                   textRow(paste0("predCol",title), "Prediction column", Defaults[[paste0("predCol",title)]])
                                                 )
                                ),
                                checkboxInput(paste0("doseCor",title), "Dose correction", Defaults[[paste0("doseCor",title)]]),
                                conditionalPanel(condition= (paste0("input.doseCor",title)),
                                                 wellPanel(
                                                   textRow(paste0("doseCol",title), "Dose column", Defaults[[paste0("doseCol",title)]])
                                                 )
                                ),
                                
                                checkboxInput(paste0("bql",title), "BQL handling", Defaults[[paste0("bql",title)]]),
                                conditionalPanel(condition= (paste0("input.bql",title)),
                                                 wellPanel(
                                                   textRow(paste0("BQLlevel",title),"BQL level", Defaults[[paste0("BQLlevel",title)]]),
                                                   selectizeInput(paste0("BQLmethod",title),"BQL method", selected=Defaults[[paste0("BQLmethod",title)]],
                                                                  choices=c("Keep","Drop")
                                                   )
                                                 )
                                ),
                                
                                checkboxInput(paste0("bins",title), "Bins", Defaults[[paste0("bins",title)]]),
                                conditionalPanel(condition = (paste0("input.bins",title)),
                                                 wellPanel(
                                                   textRow(paste0("binBy",title),"Bin width, or comma separated cuts",Defaults[[paste0("binBy",title)]])
                                                 )
                                ),
                                
                                checkboxInput(paste("groupP", plotType, n, sep=""), "Group Plots", Defaults[[paste("groupP", title, sep="")]]),
                                conditionalPanel(condition = (paste("input.", "groupP", plotType, n, sep="")),
                                                 wellPanel(textRow(paste("markBy", plotType, n, sep=""), "Mark by:",  Defaults[[paste("markBy", title, sep="")]]),
                                                           #textRow(paste("markByAdd", plotType, n, sep=""), "Add Text", Defaults[[paste("markByAdd", title, sep="")]]),
                                                           h2(""),
                                                           textRow(paste("facetBy", plotType, n, sep=""), "Facet by:", Defaults[[paste("facetBy", title, sep="")]]),
                                                           checkboxInput(paste("fdeets",plotType,n,sep=""),"Faceting details", Defaults[[paste("fdeets",title,sep="")]]),
                                                           conditionalPanel(condition=(paste("input.","fdeets",plotType,n,sep="")),
                                                                            textRow(paste("facetFact", plotType, n, sep=""), "Factor Facet:", Defaults[[paste("facetFact", title, sep="")]]),
                                                                            h2(""),
                                                                            textRow(paste("fnrow",plotType,n,sep=""),"Facet layout (rows)",Defaults[[paste("fnrow",title,sep="")]]),
                                                                            selectInput(paste("fscales",plotType,n,sep=""), "Facet scales", choices=c("fixed","free","free_x","free_y"))
                                                           )                                                
                                                 )
                                                 
                                ),
                                
                                
                                checkboxInput(paste("plotdeets", plotType, n, sep=""), "Plots Details", Defaults[[paste("plotdeets", title, sep="")]]),
                                conditionalPanel(condition = (paste("input.", "plotdeets", plotType, n, sep="")),
                                                 wellPanel(textRow(paste("Title", plotType, n, sep=""), "Figure Title",  Defaults[[paste("Title", title, sep="")]]),
                                                           h2(""),
                                                           textRow(paste("Xtit", plotType, n, sep=""), "X Axis Title", Defaults[[paste("Xtit", title, sep="")]]),
                                                           h2(""),
                                                           textRow(paste("Ytit", plotType, n, sep=""), "Y Axis Title", Defaults[[paste("Ytit", title, sep="")]]),
                                                           h1(),
                                                           textRow(paste("Xlim", title, sep=""), "X Axis Limits",  Defaults[[paste("Xlim", title, sep="")]]),
                                                           inputSelect2(paste("xForm", title, sep=""), paste("xScale", title, sep=""), "Format", choices1=c("percent" = "percent",
                                                                                                                                                            "comma" = "comma",
                                                                                                                                                            "none"="none",
                                                                                                                                                            "scientific" = "scientific"),
                                                                        choices2=c("identity"="identity"
                                                                                   # ,
                                                                                   # "log10" = "log10",
                                                                                   # "log" = "log"
                                                                        ),
                                                                        selected1=Defaults[[paste("xForm", title, sep="")]],
                                                                        selected2=Defaults[[paste("xScale", title, sep="")]]),
                                                           
                                                           
                                                           h2(""),
                                                           textRow(paste("Ylim", title, sep=""), "Y Axis Limits",  Defaults[[paste("Ylim", title, sep="")]]),
                                                           inputSelect2(paste("yForm", title, sep=""), paste("yScale", title, sep=""), "Format", choices1=c("percent" = "percent",
                                                                                                                                                            "comma" = "comma",
                                                                                                                                                            "none"="none",
                                                                                                                                                            "scientific" = "scientific"),
                                                                        choices2=c("identity"="identity",
                                                                                   "log10" = "log10",
                                                                                   "log" = "log"
                                                                        ),
                                                                        selected1=Defaults[[paste("yForm", title, sep="")]],
                                                                        selected2=Defaults[[paste("yScale", title, sep="")]]),
                                                           checkboxInput(paste("minorTicks", plotType,n,sep=""), "Minor Ticks?", Defaults[[paste("minorTicks", title, sep="")]]),
                                                           conditionalPanel(paste("input.", "minorTicks", plotType, n, sep=""),
                                                                            numericInput(inputId = paste("minorTickNum", plotType,n,sep=""), label = "Number of Minor Ticks", min = 1,max = 20,value = Defaults[[paste("minorTickNum", title, sep="")]])
                                                           )
                                                 )
                                ),
                                
                                
                                checkboxInput(paste("reorg", plotType, n, sep=""), "Manipulate Data", Defaults[[paste("reorg", title, sep="")]]),
                                conditionalPanel(condition = (paste("input.", "reorg", plotType, n, sep="")),
                                                 wellPanel(boxInput(paste("DataLim", title, sep=""), "Limits and transformations",  Defaults[[paste("DataLim", title, sep="")]])
                                                           #boxInput(paste("Trans", title, sep=""), "Transform", Defaults[[paste("Trans", title, sep="")]])
                                                 )
                                ),
                                checkboxInput(paste("theme", plotType, n, sep=""), "Manipulate Theme"),
                                do.call(ThemeEditorUI,list(plotType,n)),
                                checkboxInput(paste("reset", plotType, n, sep=""), "Reset to Defaults", FALSE)
                              ),
                              
                              do.call(plotMainPanel,list(plotType,n))
                     )
                   )
                   
          )
        names(Set)[[nn+1]]=paste("Tab", plotType,n,  sep="")
      }
    }
    return(Set)	
  }
