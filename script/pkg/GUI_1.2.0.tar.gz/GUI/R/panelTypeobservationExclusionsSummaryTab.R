#' @export
panelTypeobservationExclusionsSummaryTab <-
  function(plotType, input, Set=list()){
    
    #All if statements relate to a specific output type, which then add an additional panel
    if(input[[paste(plotType, "Num", sep="")]]>=1){
      
      numbers=as.numeric(unlist(str_extract_all(input[[paste(plotType, "Num", sep="")]], "\\d+")))
      if(length(numbers)>1){numRange=numbers[which(numbers!=0)]}
      if(length(numbers)==1){numRange=c(1:numbers)}
      for (n in numRange){
        
        title=paste(plotType, n, sep="")
        #set originating defaults
        checkPriors(plotType=plotType, input=input, n=n)
        
        nn=length(Set)
        
        Set[[nn+1]]=
          tabPanel(paste(plotType,n, sep="#"),
                   
                   sidebarPanel(
                     actionButton(paste("button", title, sep=""), "Generate Plot"),
                     wellPanel(
                       numericInput(paste0("previewhead",title),"Number of lines to preview",Defaults[[paste0("previewhead",title)]])
                     ),
                     checkboxInput(paste("reset", title, sep=""), "Reset to Defaults", FALSE)
                   ),
                   
                   mainPanel(div(align="center",
                                 textOutput(paste0("generated",plotType,n)),
                                 boxInputLong(paste("LegendTitle", title, sep=""), "Table title", Defaults[[paste("LegendTitle", title, sep="")]]),
                                 boxInputWide(paste("Legend", title, sep=""), "Table caption", Defaults[[paste("Legend", title, sep="")]]),
                                 verbatimTextOutput(paste("Plot", title,  sep="")),
                                 boxInputLong(paste("Footnote", title, sep=""), "Footnote", Defaults[[paste("Footnote", title, sep="")]])
                                 
                   ))
                   
          )
        names(Set)[[nn+1]]=paste("Tab", title,  sep="")
      }
    }
    return(Set)	
  }
