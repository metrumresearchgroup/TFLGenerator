#' @export
plotMainPanel=function(plotType,n){
  title=paste(plotType, n, sep="")
  
  if(is.null(Defaults[[paste0("plotShape", title)]])){
    plotShape=DefaultsFirst[['plotShape']]
  }else{
    plotShape=Defaults[[paste0("plotShape", title)]]
  } 
  
  if(is.null(Defaults[[paste0("plotHeight", title)]])){
    plotHeight=DefaultsFirst[['plotHeight']]
  }else{
    plotHeight=Defaults[[paste0("plotHeight", title)]]
  } 
  
  mainPanel(div(align="center",style="height:600px;overflow-y:auto",
                # column(width=3,actionLink(paste0("updateElem",title),"Update Plot Layer")),
                # column(width=3,actionLink(paste0("updateTheme",title),"Update Plot Theme")),
                # column(width=3,actionLink(paste0("SetThemeGrid",title),'Update Grid Theme')),
                # column(width=3,actionLink(paste0("SetThemeGlobal",title),'Update Global Theme')),
                #uiOutput(paste0('activePlot',title)),
                column(12,
                       fluidRow(
                         textOutput(paste0("generated",title)),
                         boxInputLong(paste0("LegendTitle", title), "Figure Title", Defaults[[paste0("LegendTitle", title)]]),
                         boxInputWide(paste0("Legend", title), "Legend Text", Defaults[[paste0("Legend", title)]]),
                         boxInputLong(paste0("Footnote", title), "Footnote", Defaults[[paste0("Footnote", title)]]),
                         div(class='col-sm-3 col-sm-offset-3',style = "padding: 0px;",sliderInput(paste0("plotHeight", title),label = "Height",min = 1,max = 10,step = 0.1,value = plotHeight,ticks = F,width = 100)),
                         div(class='col-sm-3',radioButtons(paste0("plotShape", title),"Layout",
                                                           choices = c("Square"='squares',"Rectangle"='rectangles',"Panel"='panel'),selected = plotShape,inline = T)),
                         plotOutput(paste0("Plot", title))
                       )
                )
  )
  #,
  #uiOutput(paste0('popTheme',title))
  )
}