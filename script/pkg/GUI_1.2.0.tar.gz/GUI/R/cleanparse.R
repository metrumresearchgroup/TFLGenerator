cleanparse <- function(parsethis,data_obj_name){
  mysubstring <- function(string, x){
    if(class(x)=="list"){
      if(length(x)==length(string)){
        return(sapply(1:length(string), function(i) substring(string[i], first=x[[i]], last=x[[i]]-1+attr(x[[i]],"match.length"))))
      }
    }else{
      cat(file=stderr(), "Error in mysubstring, dimensions of x are wrong")
      return()
    } 
    substring(string, first=x, last=x-1+attr(x,"match.length"))
  }
  if(parsethis=="") return(NULL)
  x <- unlist(strsplit(parsethis,"\n"))
  x_inline <- grep("$DATA",x,fixed=T,value=T)
  x_within <- setdiff(x,x_inline)
  x_inline_new <- gsub("$DATA",data_obj_name,x_inline,fixed=T)
  
  n_op <- gregexpr(x_within, pattern="==|<-|<=|<|>=|>|=")
  
  if(length(n_op)>0){
    ops <- mysubstring(x_within, n_op)
    ops <- sapply(ops, function(x) (x[1]=="=") | (any(x=="<-") ))
    if(any(!ops)){
      x_inline_new <- c(x_inline_new, paste("subset(",data_obj_name,",",x_within[!ops],")"))
      x_within <- x_within[ops]
    }
  }
  

  commands <- c(x_inline_new,x_within)
  within <- c(rep(FALSE,length(x_inline_new)),rep(TRUE,length(x_within)))
  index <- sapply(commands, agrep, x=x, fixed=T)
  multiple <- which(sapply(index,length) > 1 )
  if(length(multiple)>0){
    for(i in 1:length(multiple)) index[ multiple[i] ] <- agrep(commands[multiple[i]],x,fixed=T,max=list(all=1))
  }
  if(all(sapply(index,length)==1)){
    return(list(commands=commands[unlist(index)],within=within[unlist(index)]))
  }else{
    cat(file=stderr(), "LOG: Fuzzy matching parsing commands failed, order of commands not guaranteed to be that which was given\n")
    return(list(commands=commands, within=within))
  }
}