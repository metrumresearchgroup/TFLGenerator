#' @export
cleanparse <- function(parsethis,data_obj_name){
  mysubstring <- function(string, x){
    if(class(x)=="list"){
      if(length(x)==length(string)){
        return(sapply(1:length(string), function(i) substring(string[i], first=x[[i]], last=x[[i]]-1+attr(x[[i]],"match.length"))))
      }
    }else{
      cat(file=stderr(), "Error in mysubstring, dimensions of x are wrong")
      return()
    } 
    substring(string, first=x, last=x-1+attr(x,"match.length"))
  }
  if(parsethis=="") return(NULL)
  x <- unlist(strsplit(parsethis,"\n"))
  x <- str_trim(x)
  x <- x[x!=""]
  
  x_inline_i <- grep("$DATA",x,fixed=T)
  if(length(x_inline_i)>0){
    x_inline <- x[x_inline_i]
  }else{
    x_inline <- NULL
  }
  x_within_i <- setdiff(1:length(x),x_inline_i)
  if(length(x_within_i)>0){
    x_within <- x[x_within_i]
  }else{
    x_within <- NULL
  }
  x_inline_new <- gsub("$DATA",data_obj_name,x_inline,fixed=T)
  
  n_op <- gregexpr(x_within, pattern="==|<-|<=|<|>=|>|=")
  
  if(length(n_op)>0){
    ops <- mysubstring(x_within, n_op)
    ops <- sapply(ops, function(x) (x[1]=="=") | (any(x=="<-") ))
    if(any(!ops)){
      x_inline_new <- c(x_inline_new, paste("subset(",data_obj_name,",",x_within[!ops],")"))
      x_inline_i <- c(x_inline_i, x_within_i[!ops])
      x_within <- x_within[ops]
      x_within_i <- x_within_i[ops]
    }
  }
  
  commands <- vector(length=length(x))
  within <- rep(FALSE, length=length(x))
  if(length(x_inline_i)>0){
    commands[x_inline_i] <- x_inline_new
  }
  if(length(x_within_i)>0){
    commands[x_within_i] <- x_within
    within[ x_within_i ] <- TRUE
  }

  return(list(commands=commands,within=within))
}