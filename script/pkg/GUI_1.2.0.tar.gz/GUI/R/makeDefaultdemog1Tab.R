#' @export
makeDefaultdemogTab <-
function(title, Defaults){		
	Defaults[[paste("AES", title, sep="")]]=FALSE	
	Defaults[[paste("group", title, sep="")]]="STUD"	
	Defaults[[paste("idVar", title, sep="")]]="NMID"
	Defaults[[paste("statList", title, sep="")]]="n, Mean, Median, CV, Min, Max"
	Defaults[[paste("conList", title, sep="")]]="AGE;years" #AGE;years\nHGTB;cm\nWGTB;kg"
	Defaults[[paste("covList", title, sep="")]]="SEX,DIS"
	Defaults[[paste("sigDig", title, sep="")]]=3
	
	
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	Defaults[[paste("reorg", title, sep="")]]=FALSE
	Defaults[[paste("DataLim", title, sep="")]]=""
	Defaults[[paste("Trans", title, sep="")]]=""

	Defaults[[paste("idVar", title, sep="")]]="NMID"
	Defaults[[paste("LegendTitle", title, sep="")]]=sprintf("Legend Title", title)
	Defaults[[paste("Legend", title, sep="")]]=sprintf("Information about figure", title)
	Defaults[[paste("Footnote", title, sep="")]]=sprintf("Figure footnote", title)
	Defaults[[paste("reset", title, sep="")]]=FALSE
	return(Defaults)
	
	
}
