makeDefaultConcvTimeMult <-
function(title, Defaults){		
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	
	Defaults[[paste("ID",title,sep="")]]=""
	Defaults[[paste("allID",title,sep="")]]=TRUE
	Defaults[[paste("nrow",title,sep="")]]=4
	Defaults[[paste("ncol",title,sep="")]]=3
	Defaults[[paste("page",title,sep="")]]=1

	Defaults[[paste("plotdeets", title, sep="")]]=FALSE
	
	Defaults[[paste("Title", title, sep="")]]="A Plot Title"
	Defaults[[paste("Xtit", title, sep="")]]="Time"
	Defaults[[paste("Ytit", title, sep="")]]="Serum Concentration"
	Defaults[[paste("Xlim", title, sep="")]]=""
	Defaults[[paste("xForm", title, sep="")]]="plain"
	Defaults[[paste("xScale", title, sep="")]]="none"
	
	Defaults[[paste("Ylim", title, sep="")]]=""
	Defaults[[paste("yForm", title, sep="")]]="plain"
	Defaults[[paste("yScale", title, sep="")]]="log10"
	
	Defaults[[paste("AES", title, sep="")]]=FALSE	
	Defaults[[paste("xBy", title, sep="")]]="TAFD"						
	Defaults[[paste("yBy", title, sep="")]]="DV"
	Defaults[[paste("idVar", title, sep="")]]="NMID"
	Defaults[[paste("ipredVar", title, sep="")]]="IPRED"
	Defaults[[paste("predVar", title, sep="")]]="PRED"
	Defaults[[paste("doseVar",title,sep="")]]="DOSE"
	Defaults[[paste("doseLab",title,sep="")]]="mg/kg"
	
	Defaults[[paste("reorg", title, sep="")]]=FALSE
	Defaults[[paste("DataLim", title, sep="")]]=""
	Defaults[[paste("Trans", title, sep="")]]=""

	Defaults[[paste("LegendTitle", title, sep="")]]="Population (Solid Lines), Individual Model Fit (Dashed Lines), and Observations (Open Circles) for Subjects in Clinical Studies Using <Model>"
	Defaults[[paste("Legend", title, sep="")]]="Caption"
	Defaults[[paste("Footnote", title, sep="")]]="Footnote"
	Defaults[[paste("minorTicks", title, sep="")]]=FALSE
	Defaults[[paste("minorTickNum", title, sep="")]]=10
	Defaults[[paste("reset", title, sep="")]]=FALSE
	
	Defaults[[paste("plotHeight", title, sep="")]]=defaultPlot$Ratio$height[defaultPlot$Ratio$shape==defaultPlot$Shapes$shape[defaultPlot$Shapes$plot==gsub('[0-9]','',title)]]
	Defaults[[paste("plotShape", title, sep="")]]=defaultPlot$Shapes$shape[defaultPlot$Shapes$plot==gsub('[0-9]','',title)]
	
	for(item in names(themeEditorDefaults)){
	  Defaults[[paste(item, title, sep="")]]=themeEditorDefaults[[item]]
	}
	

	return(Defaults)
	
	
}
