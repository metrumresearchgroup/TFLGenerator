#' @export
createArgList=function(input, item, n, dataFile, callType){
  
  #This function creates the appropriate functional argument list for each figure call
  
  #Deal with formatting the data limits for functions
  #Every input call has to be verified for existence in the current plot input
  
  
  if(paste("DataLim", item, n,sep="") %in% names(input)){
    dLim=limitations(input[[paste("DataLim", item, n,sep="")]])
  }
  
  if(paste("Trans", item, n,sep="") %in% names(input)){
    dTrans=transformations(input[[paste("Trans", item, n,sep="")]])
  }
  
  if(paste("strat", plotType, n, sep="") %in% names(input)){
    if(input[[paste("strat", plotType, n, sep="")]]!=""){
      strat=input[[paste("strat", plotType, n, sep="")]]
    }
  }
  
  #Deal with formatting the plot axis formats for functions
  xForm=ifelse(paste("xForm", item, n,sep="") %in% names(input), input[[paste("xForm", item, n,sep="")]], "none")		
  if (xForm!="none"){xForm=as.name(xForm)}
  if (class(xForm)=="character"){
    if(xForm=="none"){xForm=parse(text="waiver()")}}
  
  xScale=ifelse(paste("xScale", item, n,sep="") %in% names(input),input[[paste("xScale", item, n,sep="")]], "identity")
  
  
  yForm=ifelse(paste("yForm", item, n,sep="") %in% names(input), input[[paste("yForm", item, n,sep="")]], "none")		
  if (yForm!="none"){yForm=as.name(yForm)}
  if (class(yForm)=="character"){
    if(yForm=="none"){yForm=parse(text="waiver()")}}
  
  yScale=ifelse(paste("yScale", item, n,sep="") %in% names(input),input[[paste("yScale", item, n,sep="")]], "log10")
  
  
  #Deal with formatting the FacetFactoring for functions
  
  fF=ifelse(paste("facetFact", item, n,sep="") %in% names(input), input[[paste("facetFact", item, n,sep="")]], "")
  if(nchar(fF)>1){
    fF=str_split(fF, ";[[:space:]]*")
    fF=list(as.numeric(str_extract_all(fF[[1]][1], "\\d+")[[1]]), unlist(str_split(fF[[1]][2], ",[[:space:]]*")))	
  }
  
  #Deal with formatting the conList and paramList for functions
  
  conList=ifelse(paste("conList", item, n,sep="") %in% names(input), input[[paste("conList", item, n,sep="")]], "")
  if(nchar(conList)>1){
    conList=unlist(str_split(conList, "\n"))
    conList=str_split(conList, ";[[:space:]]*")	
  }
  
  paramList=ifelse(paste("paramList", item, n,sep="") %in% names(input), input[[paste("paramList", item, n,sep="")]], "")
  if(nchar(paramList)>1){
    paramList=unlist(str_split(paramList, "\n"))
    paramList=str_split(paramList, ";[[:space:]]*")
    test<<-paramList
  }
  
  #Select the appropriate function call	and insure Group by/Mark by doesn't interfere
  callType=plotList$Ind[which(plotList$type==item)]
  if(paste("sum", item, n, sep="") %in% names(input)){
    if (input[[paste("sum", item, n, sep="")]]) {
      callType=plotList$Sum[which(plotList$type==item)]
    }
  }
  
  argList=list(
    project=currentWD, #some require a project working directory outside of the shiny subdirectory
    datFile=dataFile,
    Run=input[["runno"]],
    run=input[["runno"]],
    runno=input[["runno"]],
    callType=as.character(callType),
    View=FALSE #some functions initialize a grid object display in RStudio, setting View to FALSE prevents this
    
  )		
  
  #add in all other arguments to the list if they exists	
  if(exists("dLim")){argList$dataLimits=dLim}
  if(exists("dTrans")){argList$dataTrans=dTrans}
  if(exists("xForm")){argList$xForm=xForm}
  if(exists("yForm")){argList$yForm=yForm}
  if(exists("xScale")){argList$xScale=xScale}
  if(exists("yScale")){argList$yScale=yScale}
  if(exists("fF")){argList$facetFact=fF}
  if(exists("conList")){argList$conList=conList}
  if(exists("paramList")){argList$paramList=paramList}
  if(exists("strat")){arglist$strat=strat}
  
  
  
  #Deal with formatting the plot limits for functions
  if(paste("Xlim", item, n,sep="") %in% names(input)){
    Xlim=as.numeric(str_extract_all(input[[paste("Xlim", item, n,sep="")]], "-*\\d+")[[1]])
    if (length(Xlim)!=2){Xlim=NULL}
    argList$xLimit=Xlim
  }
  if(paste("Ylim", item, n,sep="") %in% names(input)){
    Ylim=as.numeric(str_extract_all(input[[paste("Ylim", item, n,sep="")]], "-*\\d+")[[1]])
    if (length(Ylim)!=2){Ylim=NULL}
    argList$yLimit=Ylim
  }
  
  #Special Group and Markings Handling
  if(paste("group", item, n, sep="") %in% names(input)){
    argList$groupBy=input[[paste("group", item, n, sep="")]]
    if (paste("sum", item, n, sep="") %in% names(input) ){
      if (input[[paste("sum", item, n, sep="")]]){
        argList$sumThis=TRUE
        if(paste("markBy", item, n, sep="") %in% names(input)){
          argList$groupBy=input[[paste("markBy", item, n, sep="")]]
        }
        
      }	
    }	
    if(argList$groupBy==""){argList$groupBy=NULL}
  }
  
  if(paste("markBy", item, n, sep="") %in% names(input)){
    argList$markBy= input[[paste("markBy", item, n, sep="")]]
    if(input[[paste("markBy", item, n, sep="")]]==""){argList$markBy=NULL}
  }	
  
  for(varName in c(
    "minorTicks", "binWidth", "xBy", "yBy", "idVar", "predVar",
    "ipredVar", "ID", "Sig", "sumType", "sumVar", "facetBy", "markByAdd",
    "ConfInt", "OffDiagonals", "unTransform", "removeFixed", "group")){
    if(paste(varName, item, n, sep="") %in% names(input)){
      argList[varName]=input[[paste(varName, item, n, sep="")]]
    }	
  }
  
  #special column name handling
  if(paste("xCols", item, n, sep="") %in% names(input)){
    argList$xCols=unlist(str_split(input[[paste("xCols", item, n, sep="")]], pattern="[[:space:]]*,[[:space:]]*"))
  }
  if(paste("yCols", item, n, sep="") %in% names(input)){
    argList$yCols=unlist(str_split(input[[paste("yCols", item, n, sep="")]], pattern="[[:space:]]*,[[:space:]]*"))
  }
  if(paste("nCols", item, n, sep="") %in% names(input)){
    argList$nCols=as.numeric(input[[paste("nCols", item, n, sep="")]])
  }
  if(paste("statList", item, n, sep="") %in% names(input)){
    argList$statList=unlist(str_split(input[[paste("statList", item, n, sep="")]], pattern="[[:space:]]*,[[:space:]]*"))
  }
  if(paste("covList", item, n, sep="") %in% names(input)){
    argList$covList=unlist(str_split(input[[paste("covList", item, n, sep="")]], pattern="[[:space:]]*,[[:space:]]*"))
    
  }
  
  #special title handling
  if(paste("Title", item, n, sep="") %in% names(input)){
    argList$Title=input[[paste("Title", item, n, sep="")]]
    if(length(grep("^paste|^sprintf", argList$Title))>0){
      argList$Title=parse(text=input[[paste("Title", item, n, sep="")]])
    }
  }
  if(paste("Xtit", item, n, sep="") %in% names(input)){
    argList$xLab=input[[paste("Xtit", item, n, sep="")]]
    if(length(grep("^paste|^sprintf", argList$Xtit))>0){
      argList$Xtit=parse(text=input[[paste("Xtit", item, n, sep="")]])
    }
  }
  if(paste("Ytit", item, n, sep="") %in% names(input)){
    argList$yLab=input[[paste("Ytit", item, n, sep="")]]
    if(length(grep("^paste|^sprintf", argList$Ytit))>0){
      argList$Ytit=parse(text=input[[paste("Ytit", item, n, sep="")]])
    }
  }
  
  
  #reduce argList to arguments used in the dataManip
  argListManip=argList[names(argList) %in% names(formals(manipDat))]
  
  #reduce argList to non-default arguments 
  for(this_name in names(argListManip)){
    if(this_name!="datFile"){
      if(is.null(argListManip[[this_name]]) & is.null(formals(manipDat)[[this_name]])){
        argListManip=argListManip[names(argListManip)[names(argListManip)!=this_name]]
      }
      if(!is.null(argListManip[[this_name]]) & !is.null(formals(manipDat)[[this_name]]) ){
        if(all(argListManip[[this_name]]==formals(manipDat)[[this_name]])){	
          argListManip=argListManip[names(argListManip)[names(argListManip)!=this_name]]		
        }
      }	
    }
  }
  
  #if data manipulation takes place, replace data File
  if (length(argListManip)>0){
    tempDat=do.call(manipDat, args=argListManip)
    argList$datFile=tempDat	
    if(is.null(tempDat)){
      return()
    }
  }
  
  
  #reduce argList to arguments used in this particular plot function
  argList=argList[names(argList) %in% names(formals(callType))]
  
  #Keep a recording of the complete list <-this is only used to write out the complete argument list in the verbose script
  argListComplete=formals(callType)
  argListComplete$"..."=NULL
  for(listName in names(argList)){
    argListComplete[[listName]]=argList[[listName]]
  }
  
  
  #reduce argList to non-default arguments 
  for(this_name in names(argList)){
    if(is.null(argList[[this_name]]) & is.null(formals(manipDat)[[this_name]])){
      argList=argList[names(argList)[names(argList)!=this_name]]
    }
    if(!is.null(argList[[this_name]]) & !is.null(formals(manipDat)[[this_name]]) & this_name!="datFile"){
      if(all(argList[[this_name]]==formals(manipDat)[[this_name]])){	
        argList=argList[names(argList)[names(argList)!=this_name]]		
      }
    }	
  }
  
  argList$callType=callType
  
  return(argList)
  
  
  
}

