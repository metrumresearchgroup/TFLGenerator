#' @export
captureFunSimple <-
  function(Name, plotName, toWhat, input){
    funText=capture.output(eval(parse(text=Name)))
    #start=grep("[//{]", funText)[1]
    start=grep("^\\{",funText)[1]
    end=grep("return", funText)
    end=ifelse(Name%in%c("VPC"),end[1],end[length(end)])
    if(Name=="VPC"){
      funText <- funText[(start+3):(end-1)]
    }else{
      funText=funText[(start+1):(end-1)]
    }
    funText=gsub("p1", plotName, funText)
    
    while(any(grepl("^else",str_trim(funText)))){
      thisBadPrint <- grep("^else",str_trim(funText))[1]
      funText[thisBadPrint-1] <- paste(funText[thisBadPrint-1],funText[thisBadPrint])
      funText <- funText[-thisBadPrint]
    }
    
    if(Name=="GOF"){
      idx <- grep("return\\(",funText)
      for(idxi in idx){
        funText[idxi] <- paste0("# ",funText[idxi])
        funText[idxi+1] <- paste0("# ",funText[idxi+1])
      }
    }
    funText <- gsub("return\\(","#return(",funText)
    
    #write arguments
    funText=c(makeArgs(toWhat, addComma=FALSE), funText)
    
    #remove any "..." arguments
    funText=gsub(",[//.]{3}", "", funText)
    
    funText=paste(funText, collapse="\n")
    
    
    return(funText)
  }
