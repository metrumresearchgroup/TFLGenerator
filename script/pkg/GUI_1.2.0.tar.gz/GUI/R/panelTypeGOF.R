#' @export
panelTypeGOF <-
  function(plotType, input, Set=list()){
    
    #All if statements relate to a specific output type, which then add an additional panel
    if(input[[paste(plotType, "Num", sep="")]]>=1){
      
      numbers=as.numeric(unlist(str_extract_all(input[[paste(plotType, "Num", sep="")]], "\\d+")))
      if(length(numbers)>1){numRange=numbers[which(numbers!=0)]}
      if(length(numbers)==1){numRange=c(1:numbers)}
      for (n in numRange){
        
        title=paste(plotType, n, sep="")
        #set originating defaults
        checkPriors(plotType=plotType, input=input, n=n)
        
        nn=length(Set)
        
        
        Set[[nn+1]]=
          tabPanel(paste(plotType,n, sep="#"),
                   
                   sidebarPanel(
                     actionButton(paste("button", plotType, n, sep=""), "Generate Plot"),										 	
                     checkboxInput(paste("plotdeets", plotType, n, sep=""), "Plot Details", Defaults[[paste("plotdeets", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "plotdeets", plotType, n, sep="")),
                                      wellPanel(
                                        textRow(paste("markBy",plotType,n,sep=""), "Mark by", Defaults[[paste("markBy",title,sep="")]]),
                                        radioButtons(inputId = paste("markByType", plotType, n, sep=""), label = "",choices = c("Discrete","Continuous"),selected = Defaults[[paste("markByType", title, sep="")]],inline = T),
                                        h2(""),
                                        checkboxInput(paste("preserveMarkByLevels",plotType,n,sep=""),"Preserve mark-by levels?", Defaults[[paste("preserveMarkByLevels",title,sep="")]]),
                                        h2(""),
                                        # textRow(paste("Title", plotType, n, sep=""), "Figure Title",  Defaults[[paste("Title", title, sep="")]]),
                                        # h1(""),
                                        checkboxInput(paste("smooth",plotType,n,sep=""), "Plot lowess", Defaults[[paste("smooth",title,sep="")]])
                                      )
                     ),
                     checkboxInput(paste("timedeets",plotType,n,sep=""), "Time details", Defaults[[paste("timedeets", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "timedeets", plotType, n, sep="")),
                                      wellPanel(
                                        textRow(paste("timeBy", title, sep=""), "Time column", Defaults[[paste("timeBy",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("timeLab", title, sep=""), "Time label", Defaults[[paste("timeLab",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("timeLimit", title, sep=""), "Time Limits",  Defaults[[paste("timeLimit", title, sep="")]]),
                                        h2(""),
                                        inputSelect(paste("timeScale", title, sep=""), "Time scale transformation",
                                                    choices=c("identity"="identity",
                                                              "log10" = "log10",
                                                              "log" = "log"
                                                    ), selected=Defaults[[paste("timeScale", title, sep="")]]),
                                        h2(""),
                                        inputSelect(paste("timeFmt", title, sep=""), "Time scale format",
                                                    choices=c("plain","comma","scientific"), selected=Defaults[[paste("timeFmt",title,sep="")]])
                                        )
                                      ),
                     checkboxInput(paste("ipreddeets",plotType,n,sep=""), "IPRED details", Defaults[[paste("ipreddeets", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "ipreddeets", plotType, n, sep="")),
                                      wellPanel(
                                        textRow(paste("ipredBy", title, sep=""), "IPRED column", Defaults[[paste("ipredBy",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("ipredLab", title, sep=""), "IPRED label", Defaults[[paste("ipredLab",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("ipredLimit", title, sep=""), "IPRED Limits",  Defaults[[paste("ipredLimit", title, sep="")]]),
                                        h2(""),
                                        inputSelect(paste("ipredScale", title, sep=""), "IPRED scale transformation",
                                                    choices=c("identity"="identity",
                                                              "log10" = "log10",
                                                              "log" = "log"
                                                    ), selected=Defaults[[paste("ipredScale", title, sep="")]]),
                                        h2(""),
                                        inputSelect(paste("ipredFmt", title, sep=""), "IPRED scale format",
                                                    choices=c("plain","comma","scientific"), selected=Defaults[[paste("ipredFmt",title,sep="")]])
                                      )
                     ),
                     checkboxInput(paste("preddeets",plotType,n,sep=""), "PRED details", Defaults[[paste("preddeets", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "preddeets", plotType, n, sep="")),
                                      wellPanel(
                                        textRow(paste("predBy", title, sep=""), "PRED column", Defaults[[paste("predBy",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("predLab", title, sep=""), "PRED label", Defaults[[paste("predLab",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("predLimit", title, sep=""), "PRED Limits",  Defaults[[paste("predLimit", title, sep="")]]),
                                        h2(""),
                                        inputSelect(paste("predScale", title, sep=""), "PRED scale transformation",
                                                    choices=c("identity"="identity",
                                                              "log10" = "log10",
                                                              "log" = "log"
                                                    ), selected=Defaults[[paste("predScale", title, sep="")]]),
                                        h2(""),
                                        inputSelect(paste("predFmt", title, sep=""), "pred scale format",
                                                    choices=c("plain","comma","scientific"), selected=Defaults[[paste("predFmt",title,sep="")]])
                                      )
                     ),
                     checkboxInput(paste("concdeets",plotType,n,sep=""), "DV details", Defaults[[paste("concdeets", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "concdeets", plotType, n, sep="")),
                                      wellPanel(
                                        textRow(paste("concBy", title, sep=""), "DV column", Defaults[[paste("concBy",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("concLab", title, sep=""), "conc label", Defaults[[paste("concLab",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("concLimit", title, sep=""), "DV Limits",  Defaults[[paste("concLimit", title, sep="")]]),
                                        h2(""),
                                        inputSelect(paste("concScale", title, sep=""), "DV scale transformation",
                                                    choices=c("identity"="identity",
                                                              "log10" = "log10",
                                                              "log" = "log"
                                                    ), selected=Defaults[[paste("concScale", title, sep="")]]),
                                        h2(""),
                                        inputSelect(paste("concFmt", title, sep=""), "conc scale format",
                                                    choices=c("plain","comma","scientific"), selected=Defaults[[paste("concFmt",title,sep="")]])
                                        
                                      )                                        
                     ),
                     checkboxInput(paste("cwresdeets",plotType,n,sep=""), "Resid details", Defaults[[paste("cwresdeets", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "cwresdeets", plotType, n, sep="")),
                                      wellPanel(
                                        
                                        textRow(paste("cwresBy", title, sep=""), "Resid column", Defaults[[paste("cwresBy",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("cwresLab", title, sep=""), "Resid label", Defaults[[paste("cwresLab",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("cwresLimit", title, sep=""), "Resid Limits",  Defaults[[paste("cwresLimit", title, sep="")]]),
                                        h2(""),
                                        inputSelect(paste("cwresScale", title, sep=""), "Resid scale transformation",
                                                    choices=c("identity"="identity",
                                                              "log10" = "log10",
                                                              "log" = "log"
                                                    ), selected=Defaults[[paste("cwresScale", title, sep="")]]),
                                        h2(""),
                                        inputSelect(paste("cwresFmt", title, sep=""), "cwres scale format",
                                                    choices=c("plain","comma","scientific"), selected=Defaults[[paste("cwresFmt",title,sep="")]])
                                      )
                     ),
                     checkboxInput(paste("npdedeets",plotType,n,sep=""), "NPDE details", Defaults[[paste("npdedeets", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "npdedeets", plotType, n, sep="")),
                                      wellPanel(
                                        
                                        textRow(paste("npdeBy", title, sep=""), "NPDE column", Defaults[[paste("npdeBy",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("npdeLab", title, sep=""), "NPDE label", Defaults[[paste("npdeLab",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("npdeLimit", title, sep=""), "NPDE Limits",  Defaults[[paste("npdeLimit", title, sep="")]]),
                                        h2(""),
                                        inputSelect(paste("npdeScale", title, sep=""), "NPDE scale transformation",
                                                    choices=c("identity"="identity",
                                                              "log10" = "log10",
                                                              "log" = "log"
                                                    ), selected=Defaults[[paste("npdeScale", title, sep="")]]),
                                        h2(""),
                                        inputSelect(paste("npdeFmt", title, sep=""), "npde scale format",
                                                    choices=c("plain","comma","scientific"), selected=Defaults[[paste("npdeFmt",title,sep="")]])
                                      )
                     ),
                     
                     checkboxInput(paste("reorg", plotType, n, sep=""), "Manipulate Data", Defaults[[paste("reorg", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "reorg", plotType, n, sep="")),
                                      wellPanel(boxInput(paste("DataLim", title, sep=""), "Limits and transformations",  Defaults[[paste("DataLim", title, sep="")]])
                                                # ,
                                                # boxInput(paste("Trans", title, sep=""), "Transform", Defaults[[paste("Trans", title, sep="")]])
                                      )
                     ),
                     checkboxInput(paste("theme", plotType, n, sep=""), "Manipulate Theme"),
                     do.call(ThemeEditorUI,list(plotType,n)),	 
                     checkboxInput(paste("reset", plotType, n, sep=""), "Reset to Defaults", FALSE)
                   ),
                   
                   do.call(plotMainPanel,list(plotType,n))
          )
        
        names(Set)[[nn+1]]=paste("Tab", plotType,n,  sep="")
      }
    }
    return(Set)	
  }
