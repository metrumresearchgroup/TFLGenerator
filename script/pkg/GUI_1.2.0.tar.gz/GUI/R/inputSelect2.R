#' @export
inputSelect2 <-
function(inputId1, inputId2, label, choices1, choices2,selected1 = NULL, selected2=NULL, multiple = FALSE) 
{
	choices1 <- choicesWithNames(choices1)
	if (is.null(selected1) && !multiple) 
		selected <- names(choices1)[[1]]
	selectTag <- tags$select(id = inputId1)
	if (multiple) 
		selectTag$attribs$multiple <- "multiple"
	optionTags1 <- mapply(choices1, names(choices1), SIMPLIFY = FALSE, 
											 USE.NAMES = FALSE, FUN = function(choice, name) {
											 	optionTag <- tags$option(value = choice, name)
											 	if (name %in% selected1) 
											 		optionTag$attribs$selected = "selected"
											 	optionTag
											 })
	selectTag1 <- tagSetChildren(selectTag, list = optionTags1)
	
	choices2 <- choicesWithNames(choices2)
	if (is.null(selected2) && !multiple) 
		selected <- names(choices2)[[1]]
	selectTag <- tags$select(id = inputId2)
	if (multiple) 
		selectTag$attribs$multiple <- "multiple"
	optionTags2 <- mapply(choices2, names(choices2), SIMPLIFY = FALSE, 
												USE.NAMES = FALSE, FUN = function(choice, name) {
													optionTag <- tags$option(value = choice, name)
													if (name %in% selected2) 
														optionTag$attribs$selected = "selected"
													optionTag
												})
	selectTag2 <- tagSetChildren(selectTag, list = optionTags2)
	
	div(class='row',
			div(class="span2 offset1", p(label, style="min-width:75px;max-width:90px")),
			div(class="span2",style="min-width:105px;max-width:150px", selectTag1),
			div(class="span2",style="min-width:105px;max-width:150px", selectTag2)
	)
}
