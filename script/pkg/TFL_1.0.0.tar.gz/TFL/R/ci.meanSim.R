ci.meanSim <-
function(x, ci, type="low") {
	if(type=="low"){n=ci+(1-ci)/2}
	if(type=="high"){n=(1-ci)/2}
	temp=quantile(x, probs=n, na.rm=TRUE, names=FALSE)
	if(is.null(temp)){temp=mean(x)}
	return(temp)
}
