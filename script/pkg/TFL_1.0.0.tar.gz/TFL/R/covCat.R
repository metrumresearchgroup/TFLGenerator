covCat <-
function(datFile, catList, conList, nCols=2, idVar="NMID",
								yLimit=NULL,
							  yForm=waiver(),
							  yScale="identity",
								facetBy="", notches=TRUE,
								...){
	
	#for individual plots, nCols=1, xBy and yBy is a single column name (such as "RACE" and "ETA1)
	#for a multiple plot object
	
	#set a new quantil function to show the middle 10%, normal boxplot does 5% 95% for whiskers, 25 and 75% for box, and 50% for inner line.
	f = function(x) {
		r = quantile(x, probs = c(0.04, 0.4,0.5, 0.6, 0.6))
		names(r) <- c("ymin", "lower", "middle", "upper", "ymax")
		r
	}

	if(class(catList)!="list"){
	  catList <- list(catList)
	}
	if(class(conList)!="list"){
	  conList <- list(conList)
	}
	
	cats=sapply(catList, function(x){x[[1]][1]})
	catlabs=sapply(catList, function(x){x[[2]][1]})
	covs=sapply(conList, function(x){x[[1]][1]})
	covlabs=sapply(conList, function(x){x[[2]][1]})
	
	pList=list()
	for (x in cats){
		for (y in covs){	
			#perform a one way analysis of variance
			mod1= aov(as.formula(paste(y,"~",x)), data = datFile)
			modsum1 <- summary(mod1)
			my.p = ifelse(unlist(modsum1)["Pr(>F)1"] < 0.001, "p<.001", paste0("p=",signif(unlist(modsum1)["Pr(>F)1"], digits=3)))

			mod2 = lm(datFile[,y]~factor(datFile[,x]), data = datFile)
			modsum2 <- summary(mod2)
			r2 = ifelse("adj.r.squared" %in% names(modsum2), paste("R^2=",signif(modsum2$adj.r.squared, digits=3)), "")

			temp=unique(datFile[,c(idVar,x)])
			numbers=data.frame(table(temp[,c(x)]))
			numbers=plyr:::rename(numbers,c(Var1=x))
			
			tempFile=merge(numbers, datFile, all=TRUE)
			tempFile[,x]=sprintf("%s\nn=%s", tempFile[,x], tempFile$Freq)
			
			tempFile[,x]=factor(tempFile[,x])
			
			pList[[paste("plot",x, "vs", y, sep="")]]=
				ggplot(tempFile, aes_string(x=x, y=y))+
				geom_hline(yintercept=0, lty=2)+	
				stat_boxplot(geom ='errorbar') +	
				stat_summary(fun.data = f, geom="boxplot", fill="grey", alpha=.2, lty=2)+
				geom_boxplot(notch=notches, fill="cadetblue3", alpha=0.6)+
				labs(x=catlabs[which(cats==x)], y=covlabs[which(covs==y)], title=paste(r2,my.p,sep="  "))+
				scale_y_continuous(breaks=pretty_breaks(),  limits=yLimit, labels=eval(yForm), trans=yScale)+
				theme(panel.background = element_blank(),
							axis.text=element_text(size=10, colour="black"),	axis.line=element_line(),
							panel.border=element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
							plot.margin=unit(c(.1,0,.1,0), "cm"))

		}
	}
	for(i in 1:length(pList))	class(pList[[i]]) <- "ggplot"
	if(length(c(cats,covs))==2){return(pList[[1]])}
	return(do.call("arrangeGrob", c(pList, ncol=nCols)))
	
}
