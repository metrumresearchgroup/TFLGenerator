writeRTF=function(grobPath, ordering=NULL)
{	
	library(rtf)
	
	fileName=gsub("Grob(s)*\\.R", "Figures.doc", grobPath)
	# Get the versions of TFL and GUI
	guiv <- sessionInfo()$other[["GUI"]]$Version
	tflv <- sessionInfo()$other[["TFL"]]$Version
	
	rtf=RTF(fileName, width=8.5, height=11, font.size=12, omi=c(1,1,1,1))							 
	addHeader(rtf, title="Amgen GUI TFL Output", subtitle=sprintf("Produced on %s using the Pharmacometrics TFL Generator (R::GUI %s, R::TFL %s)", 
	                                                              Sys.Date(),guiv,tflv))	
	
	addHeader(rtf, title="Preliminary Population Pharmacokinetic Analysis of <<matrix>>\nin <<subjects>> from Amgen Phase <<#>> Studies",
						subtitle="Authors:\n\nContributing Scientists:")
	
	if(!exists("guiGrobs")){
	  loadGrobs(sprintf("%s_Grobs.R", fileHead))
	}
	
	if(!is.null(ordering)) guiGrobs <- guiGrobs[ordering]
	
	for (n in c(1:length(guiGrobs))){
	  invisible(try(rm("f","file")))
	  addPageBreak(rtf)
	  if(n==1 | (guiGrobs[[n]]$Type!=guiGrobs[[max(n-1,1)]]$Type)){
	    addHeader(rtf,guiGrobs[[n]]$Type,bold=TRUE,TOC.level=1,font.size=18)
	    addPageBreak(rtf)
	  }
		 	addHeader(rtf,guiGrobs[[n]]$LegendTitle,bold=TRUE,TOC.level=2)
		 	addNewLine(rtf, n=1)
		 	if("Legend" %in% names(guiGrobs)[[n]]){
		 	  if(str_trim(guiGrobs[[n]]$Legend)!="") addParagraph(rtf, guiGrobs[[n]]$Legend)
		 	}
		 	addNewLine(rtf, n=1)
		 	if(grepl("ExclusionsTab",names(guiGrobs)[[n]])){
		 	  addTable(rtf, guiGrobs[[n]]$Plot$preview, col.justify="L",header.col.justify="C",
		 	           font.size=11,row.names=F,NA.string="")
		 	  if("Footnote" %in% names(guiGrobs[[n]])){
		 	    addText(rtf,"Note:",bold=T,italic=T)
		 	    addText(rtf,guiGrobs[[n]]$Footnote, italic=T)
		 	  }
		 	}else if(grepl("Tab|inputFigure|inputListing[[:digit:]]",names(guiGrobs)[n])){
		 	  htwdth <- GUI:::.identify(guiGrobs[[n]]$Plot)
		 	  ratio <- as.numeric(htwdth["height"]) / as.numeric(htwdth["width"])
		 	  if(ratio >=1){
		 	    if( 6*ratio < 7.5){  widthi <- 6; heighti <- 6 * ratio 
		 	    }else{ heighti <- 7.5; widthi <- heighti / ratio }
		 	  }else{ # ratio < 1
		 	    widthi=6; heighti <- 6*ratio
		 	  }
		 	  file <- ifelse(grepl("inputTab|inputFigure|inputListing[[:digit:]]",names(guiGrobs)[n]), guiGrobs[[n]]$Plot, guiGrobs[[n]]$Plot$src)
		 	  addPng(rtf, file, width=widthi, height=heighti, res=150)
		 	  if(grepl("inputFigure|inputListing|inputTable[[:digit:]]",names(guiGrobs[n]))){
		 	    # Here we use plain text footnotes
		 	    if("Footnote" %in% names(guiGrobs[[n]])){
		 	      addText(rtf,"Note:",bold=T,italic=T)
		 	      addText(rtf,guiGrobs[[n]]$Footnote, italic=T)
		 	    }
		 	  }
		 	}else if(grepl("GOF",names(guiGrobs)[n])){
		 	  addPlot(rtf, plot.fun=print,width=7.5*637.5/825,height=7.5,res=150, guiGrobs[[n]]$Plot)	
		 	  if("Footnote" %in% names(guiGrobs[[n]])){
		 	    addText(rtf,"Note:",bold=T,italic=T)
		 	    addText(rtf,guiGrobs[[n]]$Footnote, italic=T)
		 	  }
		 	  # From the panel defn for GOF
		 	}else if (grepl("ConcvTimeMult",names(guiGrobs)[n])){
		 	  plots <- grep(names(guiGrobs[n]),list.files(dirname(guiGrobs[[n]]$Plot),full.names=T),value=T)
		 	  plots <- mixedsort(plots)
		 	  htwdth <- GUI:::.identify(guiGrobs[[n]]$Plot)
		 	  ratio <- as.numeric(htwdth["height"]) / as.numeric(htwdth["width"])
		 	  heighti <- 7.5; widthi <- heighti / ratio; # These are full page plots
		 	  for(f in plots){
		 	    addPng(rtf, f, width=widthi, height=heighti, res=150)
		 	    if("Footnote" %in% names(guiGrobs[[n]])){
		 	      addText(rtf,"Note:",bold=T,italic=T)
		 	      addText(rtf,guiGrobs[[n]]$Footnote, italic=T)
		 	    }
		 	    addPageBreak(rtf)
		 	  }
		 	} else if(grepl('inputListing',names(guiGrobs)[n])){
		 	  if("longText"%in%names(guiGrobs[[n]])){
		 	    startParagraph(rtf)
		 	    for(i in 1:length(guiGrobs[[n]]$longText)){
		 	      addText(rtf, guiGrobs[[n]]$longText[i])
		 	      addNewLine(rtf)
		 	    }
		 	    endParagraph(rtf)
		 	    if("Footnote" %in% names(guiGrobs[[n]])){
		 	      addText(rtf,"Note:",bold=T,italic=T)
		 	      addText(rtf,guiGrobs[[n]]$Footnote, italic=T)
		 	    }
		 	  }
		 	} else{
		 	  addPlot(rtf, plot.fun=print,width=7,height=4,res=150, guiGrobs[[n]]$Plot)	
		 	  if("Footnote" %in% names(guiGrobs[[n]])){
		 	    addText(rtf,"Note: ",bold=T,italic=T)
		 	    addText(rtf,guiGrobs[[n]]$Footnote, italic=T)
		 	  }
		 	}
		 	#addPageBreak(rtf)
	}
	done(rtf)
}