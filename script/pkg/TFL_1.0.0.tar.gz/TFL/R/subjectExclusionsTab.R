subjectExclusionsTab <-
	function(
	  catList=list(c("STUDY","Study"),c("DOSE","Dose")),
	  nidpercol=5,
	  tmpDir = NULL
	)
		{ 
	  if(is.null(tmpDir)){
	    tmpDir <- tempdir()
	    dir.create(tmpDir,recursive = T)
	  }else{
	    if(!dir.exists(tmpDir)) return()
	  }
	  
	  if(class(catList)!="list"){
	    catList <- list(catList)
	  }

		cats=sapply(catList, function(x){x[[1]][1]})
		catlabs=sapply(catList, function(x){x[[2]][1]})

		datFile <- try(subjectExclusions)
		if(class(datFile)=="try-error") get("subjectExclusions",.GlobalEnv)
		
		datFile <- datFile[,c("excl_reasons",cats,"NMID")]
		datFile <- datFile[!duplicated(datFile),]
		datFile <- melt(datFile, measure.vars="NMID")
		datFile <- sort_df(datFile)
		N <- reapply(datFile$value,
		             datFile[,"excl_reasons"],
		             length
		)
		datFile$grp_ <- reapply(datFile$value,
		        datFile[,setdiff(names(datFile),c("variable","value"))],
		        function(x){
		          rep(1:(ceiling(length(x)/nidpercol)), each=nidpercol)[seq_along(x)]
		        }
		)

		datFile$excl_reasons <- paste(datFile$excl_reasons, paste0("(N=",N,")"))
		datFile <- cast(datFile, ... ~ variable, value="value",
		                fun.aggregate=function(x)paste(x,collapse=", "))
		datFile$grp_ <- NULL
		datFile$excl_reasons <- reapply(datFile$excl_reasons,
		                               datFile[,"excl_reasons"],
		                               function(x) c(x[1],rep("",length(x)-1))
		)
		names(datFile) <- map(names(datFile), 
		                      from=c("excl_reasons",cats,"NMID"),
		                      to=c("Reason for exclusion", catlabs, "ID"))
		

		f <- file.path(tmpDir,"subjectExclusions.doc")
		rtf <- RTF(f,font.size=11)
		addTable(rtf,datFile)
		done(rtf)
		
		return(list(preview=datFile, file=f))
		
	# 	ltab <- rbind( sapply(strsplit(names(ltab),"_"),function(x) x[2]), ltab)
	# 	namerep <- sapply(strsplit(names(ltab),"_"),function(x) x[1])
	# 	namerep <- map(namerep,from=c(grp,cats),to=c(grplabs,catlabs),strict = F)
	# 	
	# 	ltabi <- within(ltab, grp <- c(0,rep(1:length(subDataCat), times=sapply(subDataCat,nrow))))
	# 	ltab[ltabi$grp==0,grp] <- namerep[1]
	# 	colnames(ltab) <- NULL
	# 	ltab[1,] <- paste0("{\\bfseries ",ltab[1,],"}")
	# 	
	# 	tex <- tabular(ltab,rules=c(0,1,1),
	# 	        rowgroups=ltabi$grp,grid=T,
	# 	        colgroups=namerep,
	# 	        rowgrouprule=2)
	# 
	# 	if(strat!="whole"){
	# 	  mc <- sapply(names(subDataCat), function(xx) sprintf("\\multicolumn{%i}{c}{}\\\\ \\multicolumn{%i}{c}{{\\bfseries %s}}\\\\ \\hline", 
	# 	                                                       ncol(ltab), ncol(ltab), xx))
	# 	  index <- grep("\\\\ \\hline",tex,fixed=T)
	# 	  index <- index[-c(1,length(index))]
	# 	  neworder <- c(1:length(tex),index+.5)
	# 	  tex <- c(tex,mc)[order(neworder)]      
	# 	}
	# 	
	# 	# Header
	# 	factorTable <- plyr:::count(namerep)
	# 	factorTable$x <- as.character(factorTable$x)
	# 	factorTable <- factorTable[match(unique(namerep),factorTable$x),]
	# 	factorTable$x[ factorTable$x==grplabs ] <- ""
	#   header <- apply(factorTable,1,function(r) 
	# 	  sprintf("\\multicolumn{%s}{c}{{\\bfseries %s}}", r["freq"],r["x"])
	# 	  )
	# 	header <- paste(paste(header,collapse="&"), "\\\\ ")
	# 	tex <- c( tex[c(1,2)], header, tex[4:length(tex)] )  # Skipping 3 intentionally, just blank space

		# return(tex)
	}
