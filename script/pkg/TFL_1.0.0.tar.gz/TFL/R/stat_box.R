stat_box <- function (mapping = NULL, data = NULL, geom = "box", position = "dodge",
											na.rm = FALSE, coef = 1.5, ci=c(0,.25,.5,.75,1), ...) {
	
	StatBox$new(mapping = mapping, data = data, geom = geom,
							position = position, na.rm = na.rm, coef = coef, ci=ci, ...)
}

