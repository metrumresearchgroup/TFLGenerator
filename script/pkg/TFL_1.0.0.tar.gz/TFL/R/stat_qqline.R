
	
	stat_qqline <- function (mapping = NULL, data = NULL, geom = "abline", position = "identity", 
													 distribution = qnorm, dparams = list(), na.rm = FALSE, ...) { 

		StatQqline$new(mapping = mapping, data = data, geom = geom, position = position, 
									 distribution = distribution, dparams = dparams, na.rm = na.rm, ...)
	}
	
	environment(stat_qqline)=asNamespace('ggplot2')