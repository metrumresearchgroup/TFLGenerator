lnseq <-
function(x){
	
	ln=signif(2.718282^(seq(from=floor(log(range(x, na.rm=TRUE)[1])), to=ceiling(log(range(x, na.rm=TRUE)[2])), by=1)), digits=3)
	
	
	return(ln)
}
