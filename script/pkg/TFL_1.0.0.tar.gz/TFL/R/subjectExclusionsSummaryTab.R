subjectExclusionsSummaryTab <-
	function(
	  tmpDir = NULL
	)
		{ 
	  if(is.null(tmpDir)){
	    tmpDir <- tempdir()
	    dir.create(tmpDir,recursive = T)
	  }else{
	    if(!dir.exists(tmpDir)) return()
	  }
	  
		datFile <- try(subjectExclusions)
		if(class(datFile)=="try-error") datFile <-  get("subjectExclusions",.GlobalEnv)
		
		datFile <- datFile[,c("excl_reasons","NMID")]
		datFile0 <- datFile[!duplicated(datFile),]
		datFile <- group_by(datFile0,excl_reasons) %>% 
		  dplyr:::summarise(N=length(NMID), perc=round(length(NMID)/nrow(datFile0)*100,1))
		datFile <- rbind(datFile, c("Total",nrow(datFile0),"100.0"))
		
		
		names(datFile) <- map(names(datFile), 
		                      from=c("excl_reasons","perc"),
		                      to=c("Reason for exclusion", "% of Exclusions"),
		                      strict=F)
		nms <- names(datFile)
		datFile <- as.data.frame(datFile)
		names(datFile) <- nms
		

		f <- file.path(tmpDir,"subjectExclusionsSummary.doc")
		rtf <- RTF(f,font.size=11)
		addTable(rtf,datFile)
		done(rtf)
		
		return(list(preview=datFile, file=f))
	}
