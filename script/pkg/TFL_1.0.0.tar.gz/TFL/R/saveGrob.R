
saveGrob <-
function(plot, Name, file,
									fac="", mar="", gro="", str="", legtit=Name, 
         leg=sprintf("Information about %s", Name), foot="",type="",writeRda=T,
         ...){
	
	fileTitle=file
	dots <- list(...)
	
	if(!file.exists(fileTitle)){
		#Add empty Grob List
		guiGrobs=list()
		save(guiGrobs, file=fileTitle)
		
	}
	
	#if the grobs aren't loaded already, load them in
	if(!exists("guiGrobs", envir=.GlobalEnv)){
		load(file=fileTitle, envir=.GlobalEnv, verbose=TRUE)
	}
	
	#Now append the new Grob 
	nn=length(guiGrobs)
	if (Name==""){saveName=nn}
	#convert the items to a list of the proper order
	if ("list" %nin% class(plot) | all(names(plot)=="src")){
		plot=list(Facets=fac, Marks=mar, Groups=gro, Stratification=str, 
		          LegendTitle=legtit, Legend=leg, Footnote=foot, Plot=plot,
		          Type=type)
	}
	if("Footnote" %in% names(plot)){
	  if(plot$Footnote=="") plot$Footnote <- NULL
	}
	if(!is.null(dots$longText)) plot[["longText"]] <- dots$longText

	guiGrobs[[Name]]<<-plot
	
	# Trying to improve efficiency
	if(writeRda) save(guiGrobs, file=fileTitle)

}
