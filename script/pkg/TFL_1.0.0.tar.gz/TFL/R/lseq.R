lseq <-
function(x){
	
	lq=10^(seq(from=floor(log10(range(x, na.rm=TRUE)[1])), to=ceiling(log10(range(x, na.rm=TRUE)[2])), by=1))
	
	
	return(lq)
}
