ConcvTimeMult <-
  function(datFile, item, n, 
           groupBy="NMID", xBy="TAFD", yBy="DV", ipredVar="IPRE", predVar="PRED", doseVar="DOSE", doseLab="mg/kg",
           markBy="DOSE", preserveMarkByLevels=F, Color=T,
           xLimit=NULL, yLimit=NULL,
           xForm=waiver(), yForm=waiver(),
           xScale="identity", yScale="log10", 
           Title="Individuals", xLab="Time", yLab="Concentration",
           ncol=3, nrow=3, ID=NULL,
           tmpDir=NULL, regenPlots=T, page=1,
           ...)
  {
    
    if(is.null(tmpDir)){
      tmpDir <- tempdir()
      dir.create(tmpDir,recursive = T,showWarnings=F)
      if(regenPlots){
        preexisting <- grep(paste0(item,n),list.files(tmpDir),value=T)
        unlink(file.path(tmpDir,preexisting))
      }
    }else{
      if(!dir.exists(tmpDir)) return()
    }
    filename <- file.path(tmpDir,paste0(item,n,"_%1d.png"))

    if(regenPlots){
      
      # Delete old files first
      sapply(grep(paste0(item,n,"*.png"),list.files(tmpDir),value=T),unlink)
      
      # Only update in the scope of this function
      if(preserveMarkByLevels){
        if(Color){ cleanScales <- setColorScale(drop=F) }else{ cleanScales <- setGrayScale(drop=F)}
      }
      
      if(!is.null(ID)) datFile <- datFile[datFile[,groupBy]%in%ID,]
      
      datFile$groupBy <- datFile[,groupBy]
      pList <- dlply(datFile,.(groupBy),function(df){
 
        df=melt(df, id.vars=c(groupBy, xBy, doseVar), measure.vars=c(yBy, predVar, ipredVar))
        df$variable=factor(df$variable, levels=c(yBy, predVar, ipredVar), labels=c("Observed", "Population Predicted", "Individual"))
        #browser()
        p1=ggplot(data=df, aes_string(x=xBy, y="value", color="variable", shape="variable", lty="variable"))+
          geom_line()+
          geom_point()+
          cleanTheme+theme(legend.position="none")+
          scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
          scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
          labs(title=paste0("ID=",unique(df[,groupBy]),", ",unique(df[,doseVar])," ",doseLab), 
               x="", y="", shape=NULL, lty=NULL, color=NULL) +
          scale_shape_manual( values = c("O", ".", "."))+
          scale_colour_manual(values = c('black', 'black','blue'))+
          scale_linetype_manual( values=c(0,1,3))
        
        
        # #Add in better ticks if the scale is log10
        # if (as.character(yScale)[1]=="log-10"){
        #   p1=p1+annotation_logticks(, sides="l", mid=unit(0.1, "cm"))
        # }
        # 
        # if (as.character(xScale)[1]=="log-10"){
        #   p1=p1+annotation_logticks(, sides="b", mid=unit(0.1, "cm"))
        #   
        # }
        # 
        p1
        
      })
      
      for(i in 1:length(pList)) class(pList[[i]]) <- "ggplot"
      
      png(filename = file.path(tmpDir,paste0(item,n,"_%1d.png")), width=637.5, height=825, units="px")
      print(do.call(marrangeGrob,c(pList,
                                   list(
                                     top=textGrob(Title,gp=gpar(fontsize=14)),
                                     left=textGrob(yLab,rot=90,gp=gpar(fontsize=16,fontface="bold")),
                                     bottom=textGrob(xLab,gp=gpar(fontsize=16,fontface="bold")),
                                     ncol=as.numeric(ncol),
                                     nrow=as.numeric(nrow)
                                   )))
      )
      dev.off()
    }
    
    return(list(src=sprintf(filename,page),width=637.5,height=825))
    
  }
