library(testthat)
library(tufterhandout)

test_check("tufterhandout")
