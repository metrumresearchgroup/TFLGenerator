captureFun <-
function(Name, plotName, toWhat, input){
funText=capture.output(eval(parse(text=Name)))
start=grep("[//{]", funText)[1]
end=grep("return", funText)
end=end[length(end)]
funText=funText[(start+1):(end-1)]
funText=gsub("p1", plotName, funText)

#now sub out all the rest of the names
for(stuff in names(toWhat)){
	this='dataFile'
	if(class(toWhat[[stuff]]) %nin% c("data.frame")){
		this=(as.character(toWhat[[stuff]]))
		if(length(this)==1){this=paste("'", this, "'", sep="")
												this=gsub("^'c[\\(]","c(", this)
												this=gsub(")'$",")", this)
												this=gsub("^'list","list", this)
												if(!is.na(as.logical(this))){this=as.logical(this)}
												if(!is.na(as.numeric(this))){this=as.numeric(this)}
		}
		if(length(this)>1){
			
			this=
				lapply(X=this, FUN=function(x){	
					if(!is.na(as.logical(x))){foo=as.logical(x)}
					if(!is.na(suppressWarnings(as.numeric(x)))){foo=as.numeric(x)}
					if(is.na(suppressWarnings(as.numeric(x))) & is.na(as.logical(x))){foo=x}
					return(foo)
					
				})
			
			this=paste("c(", paste(unlist(this), collapse=","), ")", sep="")
			this=gsub("c[\\(]c","list(c", this)			
		}
		if(length(this)==0){this="NULL"}
	}
	
	if(this %in% c("'comma'", "'scientific'", "'percent'", "'tempDat'")){
		funText=gsub(paste("=",stuff,sep=""), paste("=",gsub("'", "", this), sep=""), funText)
		funText=gsub(paste("[\\(]",stuff,"[\\)]",sep=""), paste("(",gsub("'", "", this),")", sep=""), funText)
	}
	if(length(grep("'log|'waiv", this)>0)){this=gsub("'", "", this)}
	if(this %nin% c("'none'", "'comma'", "'scientific'", "'percent'","'tempDat'")){
		funText=gsub(paste("=",stuff,sep=""), paste("=",this,sep=""), funText)
		funText=gsub(paste("[\\(]",stuff,"[\\)]",sep=""), paste("(",this,")",sep=""), funText)
	}
	
	for(test in grep("if[[:space:]]\\(", funText)){
		
		start=test
		starts=grep("[//{]", funText) #Pull out all starting brackets
		starts=starts[(start-starts)<=0] #Pull out all starting brackets after and including the one of interest
		ends=grep("[//}]", funText) #Pull out all ending brackets
		ends=ends[(ends-start)>0] #Pull out only those after the starting bracket
		
		for(end in ends){
			this_test=end-starts
			this_start=starts[this_test>=0]
			this_test=this_test[this_test>=0]
			this_start=this_start[this_test==min(this_test)]
			
			if(this_start==start){break}
			ends=ends[ends!=end]
			starts=starts[starts!=this_start]	
		}
		
		test=grep(test, funText, value=TRUE)
		test=gsub("if[[:space:]]*[//(]|\\{|[//)]", "", test)
		test=gsub(stuff, this, test)
		test=eval(parse(text=test))
		
		#sub out stuff for this, remove top and bottom, or remove all
		funText[start:end]=gsub(stuff, this, funText[start:end])
		
		if(test){
			funText=funText[-end]
			funText=funText[-start]
			
		}
		if(!test){
			funText=funText[-(start:end)]
			
		}
		
	}
	
	
# 	test=paste("if[[:space:]]*[//(]", stuff, ".*[//)][[:space:]]*[//{]",sep="")
# 	if(length(grep(test, funText))>0){
# 		start=grep(test, funText)
# 		end=grep("[//}]", funText)
# 		end=end[(end-start)>0]
# 		end=end[end==min(end, na.rm=TRUE)] 
# 		
# 		test=grep(test, funText, value=TRUE)
# 		test=gsub("if[[:space:]]*[//(]|\\{|[//)]", "", test)
# 		test=gsub(stuff, this, test)
# 		test=eval(parse(text=test))
# 		
# 		#sub out stuff for this, remove top and bottom, or remove all
# 		funText[start:end]=gsub(stuff, this, funText[start:end])
# 			
# 		if(test){
# 			funText=funText[-end]
# 			funText=funText[-start]
# 			
# 		}
# 		if(!test){
# 			funText=funText[-(start:end)]
# 			
# 		}
# 		
# 	}
 
	
}

#remove any "..." arguments
funText=gsub(",[//.]{3}", "", funText)

funText=paste(funText, collapse="\n")


return(funText)
}
