makeDefaultobservationExclusionsSummaryTab <-
function(title, Defaults){		
  Defaults[[paste("priorExists",title,sep="")]]=TRUE
	Defaults[[paste("LegendTitle", title, sep="")]]="Summary of Observation Exclusions by Reason for Exclusion"
	Defaults[[paste("Legend", title, sep="")]]="Caption"
	Defaults[[paste("Footnote", title, sep="")]]="Footnote"
	
	Defaults[[paste("previewhead",title,sep="")]]=30
	
	Defaults[[paste("reset", title, sep="")]]=FALSE

	return(Defaults)
	

	
}
