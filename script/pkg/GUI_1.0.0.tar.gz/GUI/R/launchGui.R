launchGui <-
function (appDir = "/opt/nonmem/poc", port = NULL,
										launch.browser = getOption("shiny.launch.browser",interactive()),
										host = NULL, workerId = "", quiet = TRUE,
										display.mode = c("auto", "normal", "showcase"),
										workingDirectory=getwd()
										) 
{
	library(shiny)
	library(metrumrg)
	
	#First, set a data working directory information because shiny will immediately make the working directory the shiny app directory
	workingDirectory<<-workingDirectory
	
	
	if (is.null(host) || is.na(host)) {
		foo=system("/sbin/ifconfig | grep 'inet' | grep -v '127.0.0.1' | cut -d: -f2 | awk '{print $1}'", intern=TRUE)
		host=grep("^\\d+", foo, value=TRUE)[1]
	}


{
	on.exit({
		handlerManager$clear()
	}, add = TRUE)
	if (is.null(host) || is.na(host)) 
		host <- "0.0.0.0"
	ops <- options(warn = 1)
	on.exit(options(ops), add = TRUE)
	workerId(workerId)
	if (nzchar(Sys.getenv("SHINY_PORT"))) {
		ver <- Sys.getenv("SHINY_SERVER_VERSION")
		if (compareVersion(ver, .shinyServerMinVersion) < 0) {
			warning("Shiny Server v", .shinyServerMinVersion, 
							" or later is required; please upgrade!")
		}
	}
	setShowcaseDefault(0)
	if (is.character(appDir)) {
		desc <- file.path.ci(appDir, "DESCRIPTION")
		if (file.exists(desc)) {
			settings <- read.dcf(desc)
			if ("DisplayMode" %in% colnames(settings)) {
				mode <- settings[1, "DisplayMode"]
				if (mode == "Showcase") {
					setShowcaseDefault(1)
				}
			}
		}
	}
	display.mode <- match.arg(display.mode)
	if (display.mode == "normal") 
		setShowcaseDefault(0)
	else if (display.mode == "showcase") 
		setShowcaseDefault(1)
	require(shiny)
	if (is.null(port)) {
		for (i in 1:20) {
			if (!is.null(.globals$lastPort)) {
				port <- .globals$lastPort
				.globals$lastPort <- NULL
			}
			else {
				port <- p_randomInt(3000, 8000)
			}
			tmp <- try(startServer(host, port, list()), silent = TRUE)
			if (!inherits(tmp, "try-error")) {
				stopServer(tmp)
				.globals$lastPort <- port
				break
			}
		}
	}
	appParts <- as.shiny.appobj(appDir)
	if (!is.null(appParts$onStart)) 
		appParts$onStart()
	if (!is.null(appParts$onEnd)) 
		on.exit(appParts$onEnd(), add = TRUE)
	server <- startApp(appParts, port, host, quiet)
	on.exit({
		stopServer(server)
	}, add = TRUE)
	if (!is.character(port)) {
		browseHost <- if (identical(host, "0.0.0.0")) 
			"127.0.0.1"
		else host
		appUrl <- paste("http://", browseHost, ":", port, sep = "")
		if (is.function(launch.browser)) 
			launch.browser(appUrl)
		else if (launch.browser) 
			utils::browseURL(appUrl)
	}
	else {
		appUrl <- NULL
	}
	callAppHook("onAppStart", appUrl)
	on.exit({
		callAppHook("onAppStop", appUrl)
	}, add = TRUE)
	.globals$retval <- NULL
	.globals$stopped <- FALSE
	shinyCallingHandlers(while (!.globals$stopped) {
		serviceApp()
		Sys.sleep(0.001)
	})
	return(.globals$retval)
}
}

environment(launchGui)=asNamespace('shiny')
