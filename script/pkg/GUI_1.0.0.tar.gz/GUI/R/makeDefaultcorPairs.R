makeDefaultcorPairs <-
function(title, Defaults){																
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	Defaults[[paste("groupP", title, sep="")]]=FALSE	
	Defaults[[paste("facetBy", title, sep="")]]=""
	Defaults[[paste("facetFact", title, sep="")]]=""
	Defaults[[paste("strat", title, sep="")]]=""
	Defaults[[paste("reorg", title, sep="")]]=FALSE
	Defaults[[paste("plotdeets", title, sep="")]]=FALSE
	
	Defaults[[paste("corstat",title,sep="")]]="R2"
	Defaults[[paste("xCols", title, sep="")]]=c("ETA1","ETA2")
	Defaults[[paste("Xtit", title, sep="")]]=c("Eta 1; Eta 2")
	Defaults[[paste("Xlim", title, sep="")]]=NULL
	Defaults[[paste("xForm", title, sep="")]]="none"
	Defaults[[paste("xScale", title, sep="")]]="identity"
	Defaults[[paste("Ylim", title, sep="")]]=NULL
	Defaults[[paste("yForm", title, sep="")]]="none"
	Defaults[[paste("yScale", title, sep="")]]="identity"
	
	Defaults[[paste("DataLim", title, sep="")]]=""
	Defaults[[paste("Trans", title, sep="")]]=""
	Defaults[[paste("AES", title, sep="")]]=FALSE					
	Defaults[[paste("LegendTitle", title, sep="")]]=sprintf("Legend Title", title)
	Defaults[[paste("Legend", title, sep="")]]=sprintf("Information about figure", title)
	Defaults[[paste("Footnote", title, sep="")]]=sprintf("Figure footnote", title)
	Defaults[[paste("reset", title, sep="")]]=FALSE
	return(Defaults)	
}
