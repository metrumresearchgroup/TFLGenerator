

comparitor=function(script1, script2, project=getwd()){

	
compared=as.character(system(sprintf("diff -bBEyW 1000 --left-column --strip-trailing-cr %s%s %s%s", project, script2, project, script1), intern=TRUE))
compared=gsub("^\t*[[:space:]]*>\t*[[:space:]]*", "\t\t##QC Deletion - Original: \t", compared)
compared=gsub("\t*[[:space:]]*<\t*[[:space:]]*$", "\t\t##QC Additon", compared)
# compared=gsub("\t*[[:space:]]*\\|\t*[[:space:]]*", "\t\t##QC Alteration - Original - : \t", compared)
compared=gsub("\t*[[:space:]]*\\($", "", compared)


#because this diff uses | as a delimeter for changes

check=suppressWarnings(system(sprintf("diff -BbE --suppress-common-lines %s %s", script1, script2),
															intern=TRUE))

check=as.character(check)

nums=grep("---", check)

#annotate only those annotated as changes [can include deletions] because the rest will be properly annotated above

for(item in nums){
	lookFor=sprintf("%s[\t]+[::space::]+\\|[\t]+%s", str_sub(check[item+1], start=3), str_sub(check[item-1], start=3))
	lookFor=str_sub(check[item+1], start=3)
	grep(lookFor, compared)
}


writeLines(compared, con=sprintf("%s%s-compared.R", project, script1))


}
