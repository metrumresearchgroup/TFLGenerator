captureFunSimple <-
function(Name, plotName, toWhat, input){
funText=capture.output(eval(parse(text=Name)))
#start=grep("[//{]", funText)[1]
start=grep("^\\{",funText)[1]
end=grep("return", funText)
end=end[length(end)]
funText=funText[(start+1):(end-1)]
funText=gsub("p1", plotName, funText)

while(any(grepl("^else",str_trim(funText)))){
  thisBadPrint <- grep("^else",str_trim(funText))[1]
  funText[thisBadPrint-1] <- paste(funText[thisBadPrint-1],funText[thisBadPrint])
  funText <- funText[-thisBadPrint]
}

#write arguments
funText=c(makeArgs(toWhat, addComma=FALSE), funText)

#remove any "..." arguments
funText=gsub(",[//.]{3}", "", funText)

funText=paste(funText, collapse="\n")


return(funText)
}
