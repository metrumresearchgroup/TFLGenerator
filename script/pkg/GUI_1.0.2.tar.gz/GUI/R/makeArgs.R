makeArgs <-
function(toWhat, completeArg=TRUE, addComma=TRUE){
	foo=vector()
	for(stuff in names(toWhat)){
		this='dataFile'
		if(class(toWhat[[stuff]]) %nin% c("data.frame") ){
		  if("vpc" %nin% names(toWhat[[stuff]])){
		    
		    this=(as.character(toWhat[[stuff]]))
		    if(length(this)==1){
		      if(!is.na(as.logical(this))){
		        this=as.logical(this)
		      }else if((!is.na(as.numeric(this))) & (stuff%nin%c("run","Run","runno"))){
		        this=as.numeric(this)
		      }else{
		        this=paste("'", this, "'", sep="")
		        this=gsub("^'c[\\(]","c(", this)
		        if(grepl("^c\\(",this)) this=gsub(")'$",")", this)
		        this=gsub("^'list","list", this)}	
		    }
		    
		    if(length(this)>1){
		      
		      this=
		        lapply(X=this, FUN=function(x){	
		          
		          if(!is.na(as.logical(x))){foo=as.logical(x)}
		          if(!is.na(suppressWarnings(as.numeric(x)))){foo=as.numeric(x)}
		          if(is.na(suppressWarnings(as.numeric(x))) & is.na(as.logical(x))){foo=paste("'",x,"'", sep="")}
		          foo=gsub("^'c[\\(]","c(", foo)
		          foo=gsub(")'$",")", foo)
		          return(foo)
		          
		        })
		      
		      this=paste("c(", paste(unlist(this), collapse=","), ")", sep="")
		      this=gsub("c[\\(]c","list(c", this)			
		    }
		    if(length(this)==0){this="NULL"}
		  }
		}
		
		if(this %in% c("'comma'", "'scientific'", "'percent'", "'tempDat'")){this_foo=sprintf("%s=%s", stuff, gsub("'", "", this))}
		if(length(grep("'waiv", this)>0)){this=gsub("'", "", this)}
		if(length(grep("'sprint", this)>0)){this=gsub("'sprint", "sprint", this)}
		if(length(grep("sprintf|paste", this)>0)){this_foo=sprintf("%s=eval(parse(text=%s))", stuff, this)}
		if(this %nin% c("'none'", "'comma'", "'scientific'", "'percent'","'tempDat'") | length(grep("sprintf|paste", this)==0)){	this_foo=sprintf("%s=%s", stuff, this)}

			
		if(completeArg==FALSE){
			this_foo=sprintf('%s', this)
		}
		
		foo=c(foo, this_foo)
	}
	
	if(completeArg==TRUE & addComma==TRUE){
		foo=paste(foo, collapse=",\n\t\t\t\t\t\t\t\t")
	}
	
	if(addComma==FALSE){
		foo=paste(foo, collapse="\n")
	}
	return(foo)
}
