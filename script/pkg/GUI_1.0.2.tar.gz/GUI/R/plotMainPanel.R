plotMainPanel=function(plotType,n){
  title=paste(plotType, n, sep="")
              mainPanel(div(align="center",
                            column(width=3,actionLink(paste0("updateElem",title),"Update Plot Layer")),
                            column(width=3,actionLink(paste0("updateTheme",title),"Update Plot Theme")),
                            column(width=3,actionLink(paste0("SetThemeGrid",title),'Update Grid Theme')),
                            column(width=3,actionLink(paste0("SetThemeGlobal",title),'Update Global Theme')),
                            textOutput(paste0("generated",title)),
                            boxInputLong(paste0("LegendTitle", title), "Figure Title", Defaults[[paste0("LegendTitle", title)]]),
                            plotOutput(paste0("Plot", title), width="600px", height="400px"),
                            boxInputWide(paste0("Legend", title), "Legend Text", Defaults[[paste0("Legend", title)]]),
                            boxInputLong(paste0("Footnote", title), "Footnote", Defaults[[paste0("Footnote", title)]])
                            ),
                        uiOutput(paste0('popTheme',title))
                        )
}