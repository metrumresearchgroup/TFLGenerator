makeDefaultOBSvPRED <-
function(title, Defaults){																
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	Defaults[[paste("groupP", title, sep="")]]=FALSE					
	Defaults[[paste("group", title, sep="")]]=NULL
	Defaults[[paste("markBy", title, sep="")]]=""				 
	Defaults[[paste("markByAdd", title, sep="")]]=""
	Defaults[[paste("facetBy", title, sep="")]]=""
	Defaults[[paste("facetFact", title, sep="")]]=""
	Defaults[[paste("fdeets", title, sep="")]]=FALSE
	Defaults[[paste('fnrow',title,sep="")]]=""
	Defaults[[paste('fncol',title,sep="")]]=""
	Defaults[[paste("fscales",title,sep="")]]="fixed"
	Defaults[[paste("strat", title, sep="")]]=""
	Defaults[[paste("reorg", title, sep="")]]=FALSE
	Defaults[[paste("plotdeets", title, sep="")]]=FALSE
	Defaults[[paste("Title", title, sep="")]]=""
	Defaults[[paste("Xtit", title, sep="")]]="Population Prediction"
	Defaults[[paste("Ytit", title, sep="")]]="Observed Serum Concentration"
	Defaults[[paste("Xlim", title, sep="")]]=""
	Defaults[[paste("xForm", title, sep="")]]="comma"
	Defaults[[paste("xScale", title, sep="")]]="log10"
	Defaults[[paste("DataLim", title, sep="")]]=""
	Defaults[[paste("Trans", title, sep="")]]=""
	Defaults[[paste("AES", title, sep="")]]=FALSE	
	Defaults[[paste("xBy", title, sep="")]]="PRED"						
	Defaults[[paste("yBy", title, sep="")]]="DV"
	Defaults[[paste("LegendTitle", title, sep="")]]="Observed vs Population Predicted Serum Concentrations from <model>"
	Defaults[[paste("Legend", title, sep="")]]="Caption"
	Defaults[[paste("Footnote", title, sep="")]]="Footnote"
	Defaults[[paste("minorTicks", title, sep="")]]=FALSE
	Defaults[[paste("reset", title, sep="")]]=FALSE
	
	for(item in names(themeEditorDefaults)){
	  Defaults[[paste(item, title, sep="")]]=themeEditorDefaults[[item]]
	}
	
	return(Defaults)

}
