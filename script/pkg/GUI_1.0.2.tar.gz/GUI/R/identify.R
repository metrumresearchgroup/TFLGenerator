.identify <- function(...){
  if(system2("which",args="identify"))
    return("Install ImageMagick to use .identify")
  stdout <- system2("identify", args=..., stdout=T)
  stdout <- as.numeric(strsplit(strsplit(stdout,split=" ",fixed=T)[[1]][3],"x")[[1]])
  names(stdout) <- c("width","height")
  return(stdout)
}