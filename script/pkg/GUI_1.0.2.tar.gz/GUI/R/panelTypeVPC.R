panelTypeVPC <-
  function(plotType, input, varNames=list(), Set=list()){
    
    #All if statements relate to a specific output type, which then add an additional panel
    if(input[[paste(plotType, "Num", sep="")]]>=1){
      
      numbers=as.numeric(unlist(str_extract_all(input[[paste(plotType, "Num", sep="")]], "\\d+")))
      if(length(numbers)>1){numRange=numbers[which(numbers!=0)]}
      if(length(numbers)==1){numRange=c(1:numbers)}
      for (n in numRange){
        
        title=paste(plotType, n, sep="")
        #set originating defaults
        checkPriors(plotType=plotType, input=input, n=n)
        
        nn=length(Set)
        
        if(paste0("nms_source",title) %nin% names(varNames)) varNames[[paste0("nms_source",title)]] <- ""
        if(paste0("nms_tab",title) %nin% names(varNames)) varNames[[paste0("nms_tab",title)]] <- ""
        
        Set[[nn+1]]=
          tabPanel(paste(plotType,n, sep="#"),
                   tabsetPanel(
                     tabPanel("VPC Data",
                              fluidRow(
                                column(width = 6, title="Code parser (VPC sims)",
                                       h4("Manipulation code"),
                                       aceEditor(paste0("dataParse_vpc",title), value=Defaults[[paste0("dataParse_vpc",title)]], mode="r", theme="chrome", wordWrap=T)
                                ),
                                column(width=6, title="VPC data specification",
                                       fluidRow(
                                         column(width=12, title="Action button",
                                                actionButton(paste0("updateVPCView",title), "Generate VPC data")
                                         )
                                       ),
                                       wellPanel(
                                         fluidRow(
                                           column(width = 12, title=paste0("Data specification ",title),
                                                  textInput(paste0("vpcRun",title), "Run # for simulations", Defaults[[paste0("vpcRun",title)]]),
                                                  textInput(paste0("vpcColnames",title), "Column names for simulation table", Defaults[[paste0("vpcColnames",title)]]),
                                                  numericInput(paste0("vpcRep",title), "Number of subproblems", Defaults[[paste0("vpcRep",title)]], min=0),
                                                  textInput(paste0("vpcSource",title), "Source file location for VPC run", Defaults[[paste0("vpcSource",title)]]),
                                                  textInput(paste0("vpcSourceDV",title), "DV in source file (observed)", Defaults[[paste0("vpcSourceDV",title)]]),
                                                  selectizeInput(paste0("dataSubset",title), "Source file columns to to keep", selected=Defaults[[paste0("dataSubset",title)]],choices=Defaults[[paste0("dataSubset",title)]],
                                                                 multiple=T, options=list(create=TRUE)),
                                                  selectizeInput(paste0("mergeKey",title), "Choose merge key", 
                                                                 choices=intersect(varNames[[paste0("nms_source",title)]],
                                                                                   varNames[[paste0("nms_tab",title)]]),
                                                                 multiple=T, options=list(create=TRUE),
                                                                 selected=Defaults[[paste0("mergeKey",title)]]),
                                                  checkboxInput(paste0("sortBy",title), "Sort by study, patient, and time?",value=T),
                                                  checkboxInput(paste0("renameToDefaults",title), "Rename to defaults?",Defaults[[paste0("renameToDefaults",title)]])
                                                  
                                           )
                                         )
                                       )
                                )
                              ),
                              fluidRow(
                                column(width=12, title="Data viewer",
                                       numericInput(paste0("nhead",title), "Number of rows of merged dataset to preview", 10, min=0),
                                       # verbatimTextOutput(paste0('contentsHead_vpcdata',n))
                                       tableOutput(paste0('contentsHead_vpcdata',n))
                                       # DT:::dataTableOutput(paste0("contentsHead_vpcdata",n))
                                       # The following should give a DT view of the data, but breaks the app.  Not sure why.
                                       # fluidRow(
                                       #   column(width = 12,
                                       #          box(
                                       #            title = "", width = NULL, status = "primary",
                                       #            div(style = 'overflow-x: scroll', DT::dataTableOutput(paste0('contentsHead_vpcdata',n)))
                                       #          )
                                       #   )
                                       # )
                                       
                                )
                              )
                     )
                     ,
                     tabPanel("Figure",
                              sidebarPanel(
                                actionButton(paste("button", plotType, n, sep=""), "Generate Plot"),

                                wellPanel(
                                  selectInput(paste0("shadingType",title), "Shading reflects uncertainty in:",
                                                 choices=c("simulated percentiles", "observed and predicted mean", "observed and predicted median", "no shading"),
                                                 selected=Defaults[[paste0("shadingType",title)]]),
                                  conditionalPanel(condition= (paste0("input.shadingType",title,"=='simulated percentiles'")),
                                                   textRow(paste0("PI",title), "Percentiles of interest", Defaults[[paste0("PI",title)]])
                                  ),
                                  
                                  conditionalPanel(condition= (paste0("input.shadingType",title,"=='no shading'")),
                                                   textRow(paste0("PI",title), "Percentiles of interest", Defaults[[paste0("PI",title)]])
                                  ),

                                  conditionalPanel(condition= (paste0("input.shadingType",title,"=='ovserved and predicted median'")),
                                                   textRow(paste0("ci",title),"Confidence level",Defaults[[paste0("ci",title)]])
                                  ),
                                  
                                  conditionalPanel(condition= (paste0("input.shadingType",title,"=='observed and predicted mean'")),
                                                   textRow(paste0("ci",title),"Confidence level",Defaults[[paste0("ci",title)]])
                                  ),
                                  textRow(paste0("yByObs",title), "Dependent variable (observed)", Defaults[[paste0("yByObs",title)]]),
                                  textRow(paste0("predVar",title), "Simulated DV column", Defaults[[paste0("predVar",title)]]),
                                  textRow(paste0("xBy",title), "Independent variable (x-axis)", Defaults[[paste0("xBy",title)]]),
                                  textRow(paste0("simCol",title), "Sim # column", Defaults[[paste0("simCol",title)]]),
                                  textRow(paste0('lb',title), "Lower bound (DV)", Defaults[[paste0("lb",title)]])
                                ),
                                

                                checkboxInput(paste0("predCor",title), "Prediction correction", Defaults[[paste0("predCor",title)]]),
                                conditionalPanel(condition= (paste0("input.predCor",title)),
                                                 wellPanel(
                                                   textRow(paste0("predCol",title), "Prediction column", Defaults[[paste0("predCol",title)]])
                                                   )
                                ),
                                checkboxInput(paste0("doseCor",title), "Dose correction", Defaults[[paste0("doseCor",title)]]),
                                conditionalPanel(condition= (paste0("input.doseCor",title)),
                                                 wellPanel(
                                                   textRow(paste0("doseCol",title), "Dose column", Defaults[[paste0("doseCol",title)]])
                                                   )
                                ),

                                checkboxInput(paste0("bql",title), "BQL handling", Defaults[[paste0("bql",title)]]),
                                conditionalPanel(condition= (paste0("input.bql",title)),
                                                 wellPanel(
                                                   textRow(paste0("BQLlevel",title),"BQL level", Defaults[[paste0("BQLlevel",title)]]),
                                                   selectizeInput(paste0("BQLmethod",title),"BQL method", selected=Defaults[[paste0("BQLmethod",title)]],
                                                                  choices=c("Keep","Drop")
                                                                  )
                                                 )
                                ),

                                checkboxInput(paste0("bins",title), "Bins", Defaults[[paste0("bins",title)]]),
                                conditionalPanel(condition = (paste0("input.bins",title)),
                                                 wellPanel(
                                                   textRow(paste0("binBy",title),"Bin width, or comma separated cuts",Defaults[[paste0("binBy",title)]])
                                                 )
                                ),
                                                 
                                checkboxInput(paste("groupP", plotType, n, sep=""), "Group Plots", Defaults[[paste("groupP", title, sep="")]]),
                                conditionalPanel(condition = (paste("input.", "groupP", plotType, n, sep="")),
                                                 wellPanel(textRow(paste("markBy", plotType, n, sep=""), "Mark by:",  Defaults[[paste("markBy", title, sep="")]]),
                                                           #textRow(paste("markByAdd", plotType, n, sep=""), "Add Text", Defaults[[paste("markByAdd", title, sep="")]]),
                                                           textRow(paste("facetBy", plotType, n, sep=""), "Facet by:", Defaults[[paste("facetBy", title, sep="")]]),
                                                           checkboxInput(paste("fdeets",plotType,n,sep=""),"Faceting details", Defaults[[paste("fdeets",title,sep="")]]),
                                                           conditionalPanel(condition=(paste("input.","fdeets",plotType,n,sep="")),
                                                                              textRow(paste("facetFact", plotType, n, sep=""), "Factor Facet:", Defaults[[paste("facetFact", title, sep="")]]),
                                                                              textRow(paste("fnrow",plotType,n,sep=""),"Facet layout (rows)",Defaults[[paste("fnrow",title,sep="")]]),
                                                                              selectInput(paste("fscales",plotType,n,sep=""), "Facet scales", choices=c("fixed","free","free_x","free_y"))
                                                           )                                                
                                                 )
                                                 
                                ),
                                
                                
                                checkboxInput(paste("plotdeets", plotType, n, sep=""), "Plots Details", Defaults[[paste("plotdeets", title, sep="")]]),
                                conditionalPanel(condition = (paste("input.", "plotdeets", plotType, n, sep="")),
                                                 wellPanel(textRow(paste("Title", plotType, n, sep=""), "Figure Title",  Defaults[[paste("Title", title, sep="")]]),
                                                           textRow(paste("Xtit", plotType, n, sep=""), "X Axis Title", Defaults[[paste("Xtit", title, sep="")]]),
                                                           textRow(paste("Ytit", plotType, n, sep=""), "Y Axis Title", Defaults[[paste("Ytit", title, sep="")]]),
                                                           textRow(paste("Xlim", title, sep=""), "X Axis Limits",  Defaults[[paste("Xlim", title, sep="")]]),
                                                           inputSelect2(paste("xForm", title, sep=""), paste("xScale", title, sep=""), "Format", choices1=c("percent" = "percent",
                                                                                                                                                            "comma" = "comma",
                                                                                                                                                            "none"="none",
                                                                                                                                                            "scientific" = "scientific"),
                                                                        choices2=c("none"="identity",
                                                                                   "log10" = "log10",
                                                                                   "log" = "log"
                                                                        ),
                                                                        selected1=Defaults[[paste("xForm", title, sep="")]],
                                                                        selected2=Defaults[[paste("xScale", title, sep="")]]),
                                                           
                                                           
                                                           
                                                           textRow(paste("Ylim", title, sep=""), "Y Axis Limits",  Defaults[[paste("Ylim", title, sep="")]]),
                                                           inputSelect2(paste("yForm", title, sep=""), paste("yScale", title, sep=""), "Format", choices1=c("percent" = "percent",
                                                                                                                                                            "comma" = "comma",
                                                                                                                                                            "none"="none",
                                                                                                                                                            "scientific" = "scientific"),
                                                                        choices2=c("none"="identity",
                                                                                   "log10" = "log10",
                                                                                   "log" = "log"
                                                                        ),
                                                                        selected1=Defaults[[paste("yForm", title, sep="")]],
                                                                        selected2=Defaults[[paste("yScale", title, sep="")]]),
                                                           checkboxInput(paste("minorTicks", plotType,n,sep=""), "Minor Log Ticks?", Defaults[[paste("minorTicks", title, sep="")]])
                                                 )
                                ),
                                
                                
                                checkboxInput(paste("reorg", plotType, n, sep=""), "Manipulate Data", Defaults[[paste("reorg", title, sep="")]]),
                                conditionalPanel(condition = (paste("input.", "reorg", plotType, n, sep="")),
                                                 wellPanel(boxInput(paste("DataLim", title, sep=""), "Limit",  Defaults[[paste("DataLim", title, sep="")]])
                                                           #boxInput(paste("Trans", title, sep=""), "Transform", Defaults[[paste("Trans", title, sep="")]])
                                                 )
                                ),
                                checkboxInput(paste("reset", plotType, n, sep=""), "Reset to Defaults", FALSE)
                              ),
                              
                              mainPanel(div(align="center",
                                            textOutput(paste0("generated",plotType,n)),
                                            boxInputLong(paste("LegendTitle", plotType, n, sep=""), "Figure Title", Defaults[[paste("LegendTitle", title, sep="")]]),
                                            plotOutput(paste("Plot", plotType,n,  sep=""), width="800px", height="400px"),
                                            boxInputWide(paste("Legend", plotType, n, sep=""), "Legend Text", Defaults[[paste("Legend", title, sep="")]]),
                                            boxInputLong(paste("Footnote", plotType, n, sep=""), "Footnote", Defaults[[paste("Footnote", title, sep="")]])
                                            
                              ))
                     )
                   )
                   
          )
        names(Set)[[nn+1]]=paste("Tab", plotType,n,  sep="")
      }
    }
    return(Set)	
  }
