ThemeEditorUI=function(plotType,n){
  title=paste0(plotType,n)
  conditionalPanel(condition = (paste("input.", "theme", plotType, n, sep="")),
                   wellPanel(
                     checkboxInput(paste("themeSize", plotType, n, sep=""), "Manipulate Size"),
                     conditionalPanel(condition = (paste("input.", "themeSize", plotType, n, sep="")),
                                      sliderInput(inputId = paste0('themeTextSize',plotType,n),label = "Plot Overall Text Size",min = 0,max=30,step = 0.1,value = Defaults[[paste("themeTextSize", title, sep="")]]),
                                      hr(),
                                      sliderInput(inputId = paste0('themePlotTitleSize',plotType,n),label = "Plot Title Text Size",min = 0,max=10,step = 0.1,value = Defaults[[paste("themePlotTitleSize", title, sep="")]]),
                                      sliderInput(inputId = paste0('themeAxisTxtSize',plotType,n),label = "Axis Text Size",min = 0,max=10,step = 0.1,value = Defaults[[paste("themeAxisTxtSize", title, sep="")]]),
                                      sliderInput(inputId = paste0('themeAxisTitleTxtSize',plotType,n),label = "Axis Title Text Size",min = 0,max=10,step = 0.1,value = Defaults[[paste("themeAxisTitleTxtSize", title, sep="")]]),
                                      sliderInput(inputId = paste0('themePanelLineType',plotType,n),label = "Major Grid Line Type",min = 0,max=3,step = 1,value = Defaults[[paste("themePanelLineType", title, sep="")]])
                     ),
                     checkboxInput(paste("themeColour", plotType, n, sep=""), "Manipulate Colour"),
                     conditionalPanel(condition = (paste("input.", "themeColour", plotType, n, sep="")),
                                      colourInput(inputId = paste0('themePlotTitleColour',plotType,n),label = "Title Colour",value = Defaults[[paste("themePlotTitleColour", title, sep="")]],allowTransparent = T,showColour = 'background'),
                                      colourInput(inputId = paste0('themePanelBackgroundFill',plotType,n),label = "Plot Background Colour",value = Defaults[[paste("themePanelBackgroundFill", title, sep="")]],allowTransparent = T,showColour = 'background'),
                                      colourInput(inputId = paste0('themePanelGridColour',plotType,n),label = "Major Grid Colour",value = Defaults[[paste("themePanelGridColour", title, sep="")]],allowTransparent = T,showColour = 'background'),
                                      colourInput(inputId = paste0('themeAxisTitleColour',plotType,n),label = "Axes Title Colour",value = Defaults[[paste("themeAxisTitleColour", title, sep="")]],allowTransparent = T,showColour = 'background'),
                                      colourInput(inputId = paste0('themeAxisTxtColour',plotType,n),label = "Axes Text Colour",value = Defaults[[paste("themeAxisTxtColour", title, sep="")]],allowTransparent = T,showColour = 'background')
                     )
                   )
  )
}