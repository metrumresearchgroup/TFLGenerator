ThemeEditorUI=function(plotType,n){
  title=paste0(plotType,n)
  conditionalPanel(condition = (paste("input.", "theme", plotType, n, sep="")),
                   wellPanel(
                     checkboxInput(paste("themeSize", plotType, n, sep=""), "Manipulate Size"),
                     conditionalPanel(condition = (paste("input.", "themeSize", plotType, n, sep="")),
                                      sliderInput(inputId = paste0('themeTextSize',plotType,n),label = "Plot Overall Text Size",min = 0,max=30,step = 0.1,
                                                  value = ifelse(paste0("themeTextSize",plotType,n)%in%names(Defaults),
                                                                 Defaults[[paste("themeTextSize", plotType,n, sep="")]], 
                                                                 themeEditorDefaults[["themeTextSize"]])
                                      ),
                                      hr(),
                                      sliderInput(inputId = paste0('themePlotTitleSize',plotType,n),label = "Plot Title Text Size",min = 0,max=10,step = 0.1,
                                                  value = ifelse(paste0("themePlotTitleSize",plotType,n)%in%names(Defaults), 
                                                                 Defaults[[paste("themePlotTitleSize", title, sep="")]], 
                                                                 themeEditorDefaults[["themePlotTitleSize"]])
                                      ),
                                      sliderInput(inputId = paste0('themeAxisTxtSize',plotType,n),label = "Axis Text Size",min = 0,max=10,step = 0.1,
                                                  value = ifelse(paste0("themeAxisTxtSize",plotType,n)%in%names(Defaults),
                                                                 Defaults[[paste("themeAxisTxtSize", title, sep="")]],
                                                                 themeEditorDefaults[["themeAxisTxtSize"]])
                                      ),
                                      sliderInput(inputId = paste0('themeAxisTitleTxtSize',plotType,n),label = "Axis Title Text Size",min = 0,max=10,step = 0.1,
                                                  value = ifelse(paste0("themeAxisTitleTxtSize",plotType,n)%in%names(Defaults),
                                                                 Defaults[[paste("themeAxisTitleTxtSize", title, sep="")]],
                                                                 themeEditorDefaults[["themeAxisTitleTxtSize"]])
                                      ),
                                      sliderInput(inputId = paste0('themePanelLineType',plotType,n),label = "Major Grid Line Type",min = 0,max=3,step = 1,
                                                  value = ifelse(paste0("themePanelLineType",title)%in%names(Defaults),
                                                                 Defaults[[paste("themePanelLineType", title, sep="")]],
                                                                 themeEditorDefaults[["themePanelLineType"]])
                                      )
                     ),
                     checkboxInput(paste("themeColour", plotType, n, sep=""), "Manipulate Colour"),
                     conditionalPanel(condition = (paste("input.", "themeColour", plotType, n, sep="")),
                                      colourInput(inputId = paste0('themePlotTitleColour',plotType,n),label = "Title Colour",
                                                  value = ifelse(paste0("themePlotTitleColour",title)%in%names(Defaults),
                                                                 Defaults[[paste("themePlotTitleColour", title, sep="")]],
                                                                 themeEditorDefaults[["themePlotTitleColour"]]
                                                  ),
                                                  allowTransparent = T,showColour = 'background'),
                                      colourInput(inputId = paste0('themePanelBackgroundFill',plotType,n),label = "Plot Background Colour",
                                                  value = ifelse(paste0("themePanelBackgroundFill",title)%in%names(Defaults),
                                                                 Defaults[[paste("themePanelBackgroundFill", title, sep="")]],
                                                                 themeEditorDefaults[["themePanelBackgroundFill"]]
                                                  ),
                                                  allowTransparent = T,showColour = 'background'),
                                      colourInput(inputId = paste0('themePanelGridColour',plotType,n),label = "Major Grid Colour",
                                                  value = ifelse(paste0("themePanelGridColour",title) %in% names(Defaults),
                                                                 Defaults[[paste("themePanelGridColour", title, sep="")]],
                                                                 themeEditorDefaults[["themePanelGridColour"]]
                                                  ),
                                                  allowTransparent = T,showColour = 'background'),
                                      colourInput(inputId = paste0('themeAxisTitleColour',plotType,n),label = "Axes Title Colour",
                                                  value = ifelse(paste0("themeAxisTitleColour",title)%in%names(Defaults),
                                                                 Defaults[[paste("themeAxisTitleColour", title, sep="")]],
                                                                 themeEditorDefaults[["themeAxisTitleColour"]]
                                                  ),
                                                  allowTransparent = T,showColour = 'background'),
                                      colourInput(inputId = paste0('themeAxisTxtColour',plotType,n),label = "Axes Text Colour",
                                                  value = ifelse(paste0("themeAxisTxtColour",title)%in%names(Defaults),
                                                                 Defaults[[paste("themeAxisTxtColour", title, sep="")]],
                                                                 themeEditorDefaults[["themeAxisTxtColour"]]
                                                  ),
                                                  allowTransparent = T,showColour = 'background')
                     )
                   )
  )
}