panelTypeConcvTimeGroup <-
  function(plotType, input, Set=list()){
    
    #All if statements relate to a specific output type, which then add an additional panel
    if(input[[paste(plotType, "Num", sep="")]]>=1){
      
      numbers=as.numeric(unlist(str_extract_all(input[[paste(plotType, "Num", sep="")]], "\\d+")))
      if(length(numbers)>1){numRange=numbers[which(numbers!=0)]}
      if(length(numbers)==1){numRange=c(1:numbers)}
      for (n in numRange){
        
        title=paste(plotType, n, sep="")
        #set originating defaults
        checkPriors(plotType=plotType, input=input, n=n)
        
        
        nn=length(Set)
        
        Set[[nn+1]]=
          tabPanel(paste(plotType,n, sep="#"),
                   
                   sidebarPanel(
                     actionButton(paste("button", plotType, n, sep=""), "Generate Plot"),									 	
                     checkboxInput(paste("groupP", plotType, n, sep=""), "Group Plots", Defaults[[paste("groupP", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "groupP", plotType, n, sep="")),
                                      wellPanel(textRow(paste("markBy", plotType, n, sep=""), "Mark by:",  Defaults[[paste("markBy", title, sep="")]]),
                                                h2(""),
                                                textRow(paste("markByAdd", plotType, n, sep=""), "Add Text", Defaults[[paste("markByAdd", title, sep="")]]),
                                                h2(""),
                                                checkboxInput(paste("preserveMarkByLevels", plotType, n, sep=""), "Preserve all levels", Defaults[[paste("preserveMarkByLevels", title, sep="")]]),
                                                h2(""),
                                                textRow(paste("facetBy", plotType, n, sep=""), "Facet by:", Defaults[[paste("facetBy", title, sep="")]]),
                                                h2(""),
                                                checkboxInput(paste("fdeets",plotType,n,sep=""),"Faceting details",Defaults[[paste("fdeets",title,sep="")]]),
                                                h2(""),
                                                conditionalPanel(condition=(paste("input.","fdeets",plotType,n,sep="")),
                                                                 h2(""),
                                                                 textRow(paste("facetFact", plotType, n, sep=""), "Factor Facet:", Defaults[[paste("facetFact", title, sep="")]]),
                                                                 h2(""),
                                                                 textRow(paste("fnrow",plotType,n,sep=""),"Facet layout (rows)",Defaults[[paste("fnrow",title,sep="")]]),
                                                                 h2(""),
                                                                 textRow(paste("fncol",plotType,n,sep=""),"Facet layout (cols)",Defaults[[paste("fncol",title,sep="")]]),
                                                                 h2(""),
                                                                 selectInput(paste("fscales",plotType,n,sep=""), "Facet scales", choices=c("fixed","free","free_x","free_y"))
                                                )
                                                #,textRow(paste("strat", plotType, n, sep=""), "Stratify by:", Defaults[[paste("strat", title, sep="")]])
                                      )
                     ),
                     
                     
                     checkboxInput(paste("plotdeets", plotType, n, sep=""), "Plots Details", Defaults[[paste("plotdeets", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "plotdeets", plotType, n, sep="")),
                                      wellPanel(textRow(paste("Title", plotType, n, sep=""), "Figure Title",  Defaults[[paste("Title", title, sep="")]]),
                                                h2(""),
                                                textRow(paste("Xtit", plotType, n, sep=""), "X Axis Title", Defaults[[paste("Xtit", title, sep="")]]),
                                                h2(""),
                                                textRow(paste("Ytit", plotType, n, sep=""), "Y Axis Title", Defaults[[paste("Ytit", title, sep="")]]),
                                                h2(""),
                                                textRow(paste("Xlim", title, sep=""), "X Axis Limits",  Defaults[[paste("Xlim", title, sep="")]]),
                                                h2(""),
                                                inputSelect2(paste("xForm", title, sep=""), paste("xScale", title, sep=""), "Format", choices1=c("percent" = "percent",
                                                                                                                                                 "comma" = "comma",
                                                                                                                                                 "none"="none",
                                                                                                                                                 "scientific" = "scientific"),
                                                             choices2=c("none"="identity",
                                                                        "log10" = "log10",
                                                                        "log" = "log"
                                                             ), 
                                                             selected1=Defaults[[paste("xForm", title, sep="")]],
                                                             selected2=Defaults[[paste("xScale", title, sep="")]]),
                                                
                                                
                                                
                                                h2(""),
                                                textRow(paste("Ylim", title, sep=""), "Y Axis Limits",  Defaults[[paste("Ylim", title, sep="")]]),
                                                h2(""),
                                                inputSelect2(paste("yForm", title, sep=""), paste("yScale", title, sep=""), "Format", choices1=c("percent" = "percent",
                                                                                                                                                 "comma" = "comma",
                                                                                                                                                 "none"="none",
                                                                                                                                                 "scientific" = "scientific"),
                                                             choices2=c("none"="identity",
                                                                        "log10" = "log10",
                                                                        "log" = "log"
                                                             ), 
                                                             selected1=Defaults[[paste("yForm", title, sep="")]],
                                                             selected2=Defaults[[paste("yScale", title, sep="")]])
                                      )
                     ),
                     
                     checkboxInput(paste("AES", plotType, n, sep=""), "Change Defaults",  Defaults[[paste("AES", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "AES", plotType, n, sep="")),
                                      wellPanel( textRow(paste("yBy", plotType, n, sep=""), "DV Column", Defaults[[paste("yBy", title, sep="")]]),
                                                 h2(""),
                                                 textRow(paste("xBy", plotType, n, sep=""), "Time Column", Defaults[[paste("xBy", title, sep="")]]),
                                                 h2(""),
                                                 textRow(paste("group", plotType, n, sep=""), "Grouping Column", Defaults[[paste("group", title, sep="")]])
                                      )
                     ),
                     
                     checkboxInput(paste("sum", plotType, n, sep=""), "Summarize Data?", Defaults[[paste("sum", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "sum", plotType, n, sep="")),
                                      wellPanel(selectInput(paste("sumType", plotType, n, sep=""), "Center on:",choices=c("Mean"="mean","Median"="median") ,selected=Defaults[[paste("sumType", title, sep="")]]),
                                                h2(""),
                                                selectInput(paste("sumVar", plotType, n, sep=""), "Var",choices=c("Standard Deviation"="sd", "Standard Error (SEM)"="se", "95% Confidence Interval"="ci"), selected=Defaults[[paste("sumVar", title, sep="")]])
                                      )
                     ),
                     
                     checkboxInput(paste("reorg", plotType, n, sep=""), "Manipulate Data", Defaults[[paste("reorg", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "reorg", plotType, n, sep="")),
                                      wellPanel(boxInput(paste("DataLim", title, sep=""), "Limit",  Defaults[[paste("DataLim", title, sep="")]])
                                                # ,
                                                # boxInput(paste("Trans", title, sep=""), "Transform", Defaults[[paste("Trans", title, sep="")]])
                                      )
                     ),
                     checkboxInput(paste("theme", plotType, n, sep=""), "Manipulate Theme"),
                     do.call(ThemeEditorUI,list(plotType,n)),	 
                     checkboxInput(paste("reset", plotType, n, sep=""), "Reset to Defaults", FALSE)
                   ),
                   
                   do.call(plotMainPanel,list(plotType,n))
                   
          )
        names(Set)[[nn+1]]=paste("Tab", plotType,n,  sep="")
      }
    }
    return(Set)	
  }
