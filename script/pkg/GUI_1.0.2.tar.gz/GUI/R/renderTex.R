renderTex <- function(obj,item,footnote="",tmpDir=NULL,margin=NULL,pandoc=F){
  
  if(is.null(tmpDir)){
    tmpDir <- tempdir()
    dir.create(tmpDir,recursive = T)
  }else{
    if(!dir.exists(tmpDir)) return()
  }
  

  if(is.null(margin)){
    margin <- c(left=10,top=5,right=50,bottom=5)
  }
  
  #ltable(obj,caption=footnote,cap.top=F,file=file.path(tmpDir,glue(item,".tex")))  
  if(!is.null(footnote)){
    if(footnote!=""){
      footnote <- paste0("Note: ",
                         "{\\fontsize{9}{10}\\fontshape{it}\\selectfont ",
                         footnote, "}")
      obj <- c(obj,"\\newline","\\newline",footnote)
    } 
  }
  
  if(pandoc){
    # Run through a simple pandoc renderer and then grab docx file handle
    write(obj$caption, file=file.path(tmpDir,paste0(item,"captions.tex")))
    write("\n\n",file=file.path(tmpDir,paste0(item,"captions.tex")),append=T)
    footnote <- paste0("Note: ",obj$footnote)
    write(footnote, file=file.path(tmpDir,paste0(item,"captions.tex")),append=T)
    system(paste0("/usr/lib/rstudio-server/bin/pandoc/pandoc -s ", 
                  file.path(tmpDir,paste0(item,"captions.tex")), 
                  " -o ", 
                  file.path(tmpDir,paste0(item,"captions.docx"))))
    return(
      file.path(tmpDir,paste0(item,"captions.docx"))
    )
  }
  
  writeLines(obj,con=file.path(tmpDir,glue(item,".tex")))
  tex2pdf(file.path(tmpDir,glue(item,".tex")),
          preamble = makePreamble(# wide = NULL, long = NULL, 
            documentclass = command('documentclass', 
                                    options = sprintf('varwidth, border={%s %s %s %s}',
                                                      margin["left"],margin["top"],margin["right"],margin["bottom"]), ## allows bottom text.
                                    args = 'standalone'
            ), 
            geometryPackage = NULL, # I don't think standalone can 
            geometry = NULL, # play nicely with geometry. 
            morePreamble=c(
              '\\usepackage{helvet}',
              '\\usepackage{amsmath}',
              '\\renewcommand{\\familydefault}{\\sfdefault}',
              '\\usepackage{setspace}',
              '\\usepackage{caption}',
              '\\captionsetup{labelformat=empty}') 
          )
  )
  im.convert(file.path(tmpDir,glue(item,"_doc.pdf")),
             output = file.path(tmpDir,glue(item,".png")),
             extra.opts="-density 150")
  htwdth <- GUI:::.identify(file.path(tmpDir,glue(item,".png")))
  list(src = file.path(tmpDir,glue(item,".png")),
       width = as.numeric(htwdth["width"]), height = as.numeric(htwdth["height"]))
}