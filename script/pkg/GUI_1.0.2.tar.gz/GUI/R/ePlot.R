ePlot=function(e) list(pList=list(ggplot()+geom_blank()+annotate(geom='text',x=1,y=1,label=sprintf("You broke something\n%s", e))+theme_void()),plotCols=1,plotRows=1)


