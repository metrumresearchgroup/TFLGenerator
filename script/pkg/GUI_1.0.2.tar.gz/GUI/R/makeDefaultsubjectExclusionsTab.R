makeDefaultsubjectExclusionsTab <-
function(title, Defaults){		
  Defaults[[paste("priorExists",title,sep="")]]=TRUE
	Defaults[[paste("LegendTitle", title, sep="")]]="Subject Exclusion"
	Defaults[[paste("Legend", title, sep="")]]="Caption"
	Defaults[[paste("Footnote", title, sep="")]]="Footnote"
	
	Defaults[[paste("catList",title,sep="")]]="STUDY;Study\nDOSE;Dose"
	Defaults[[paste("nidpercol",title,sep="")]]=5
	Defaults[[paste("previewhead",title,sep="")]]=30
	
	Defaults[[paste("reset", title, sep="")]]=FALSE

	return(Defaults)
	

	
}
