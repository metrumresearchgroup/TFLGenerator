makeDefaultdistMult <-
function(title, Defaults){																
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
  
	Defaults[[paste0("conList", title)]]="WGTB; Weight (kg)\nAGE; Age (years)\nCL; Creatinine Clearance (mL/min)"						

	Defaults[[paste0("plotdeets", title)]]=FALSE
	Defaults[[paste0("reorg", title)]]=FALSE
	Defaults[[paste0("notches", title)]]=TRUE
	
	Defaults[[paste0("order", title)]]=c("Density", "QQ", "Boxplot")
	
	Defaults[[paste("DataLim", title, sep="")]]="!duplicated(NMID)"
	Defaults[[paste("Trans", title, sep="")]]=""

		Defaults[[paste("LegendTitle", title, sep="")]]="Density Plots"
	Defaults[[paste("Legend", title, sep="")]]="Caption"
	Defaults[[paste("Footnote", title, sep="")]]="Left panel: Frequency histograms of the covariate distributions, where the y-axis shows the probability density of the covariate distribution. The sum of the bar heights times bar widths equal 1. The solid red line is the mean of the covariate distribution. Middle panel: Quantile-quantile plots of the random effect distributions against the standard normal distributions. Solid lines are the reference lines that correspond to perfectly normal distributions.Right panel: Box plot of the covariate distribution, with the grey dash line showing the median of the covariate distribution."
	Defaults[[paste("reset", title, sep="")]]=FALSE
	return(Defaults)	
}
