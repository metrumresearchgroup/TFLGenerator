makeDefaultVPC <-
function(title, Defaults){		


  #Data
	Defaults[[paste0("dataParse_vpc",title)]] =  "" 
	Defaults[[paste0("vpcRun",title)]] = "<output directory relative to project directory>"
	Defaults[[paste0("vpcColnames",title)]] =  "DV, PRED, RES, WRES"
	Defaults[[paste0("vpcSource",title)]] = "<data.csv (optionally BQL imputed) relative to project directory>"
	Defaults[[paste0("vpcRep",title)]] = 1000
	Defaults[[paste0("dataSubset",title)]] = ""
	Defaults[[paste0("mergeKey",title)]] = c("NMID", "TAFD")
	Defaults[[paste0("sortBy",title)]] = TRUE
	Defaults[[paste0("renameToDefaults",title)]] = TRUE
	Defaults[[paste0("vpcSourceDV",title)]] = "DV"

	#Additional data
	Defaults[[paste0("addlVpcSource",title)]] = "<data.csv Data source of additional layer of observed points>"
# 	Defaults[[paste0("addlVpcSourceY",title)]] = "DV"
#   Defaults[[paste0("addlVpcSourceX",title)]] = "TAFD"
  Defaults[[paste0("addlRenameToDefaults",title)]] = TRUE
  Defaults[[paste0("addlDataParse_vpc",title)]] = ""

  #VPC
  Defaults[[paste0("yByObs",title)]]   = "DVobs"
  Defaults[[paste0("predVar",title)]]  = "DV"
  Defaults[[paste0("xBy",title)]]      = "TAFD"
  Defaults[[paste0("simCol",title)]]   = "IREP"
  Defaults[[paste0("PI",title)]]       = "2.5, 50, 97.5"
  Defaults[[paste0("shadingType",title)]]  = "simulated percentiles"
  # Defaults[[paste0("includeCI",title)]]= TRUE
  Defaults[[paste0("ci",title)]]       = 95
  Defaults[[paste0("predCor",title)]]       = TRUE
  Defaults[[paste0("predCol",title)]]  = "PRED"
  Defaults[[paste0("doseCor",title)]]       = FALSE
  Defaults[[paste0("doseCol",title)]]  = "DOSE"
  Defaults[[paste0("lb",title)]]       = 0
  Defaults[[paste0("bql",title)]]      = FALSE
  Defaults[[paste0("BQLlevel",title)]] = 0.5
  Defaults[[paste0("BQLmethod",title)]]= "Drop"
  Defaults[[paste0("bins",title)]]     = F
  Defaults[[paste0("binBy",title)]]    = 7
  Defaults[[paste0("label",title)]] = ""
  Defaults[[paste0("addlLabel",title)]] = ""
  
        
        
  #AUX
  
  Defaults[[paste("groupP", title, sep="")]]      = FALSE
  Defaults[[paste("markBy", title, sep="")]]      = ""
  #Defaults[[paste("markByAdd", title, sep="")]] 
  Defaults[[paste("facetBy", title, sep="")]]     = ""
  Defaults[[paste("fdeets",title,sep="")]]        = FALSE
  Defaults[[paste("facetFact",title,sep="")]]     = ""
  Defaults[[paste("fnrow",title,sep="")]]         = ""
  Defaults[[paste("fscales",title,sep="")]]       = "fixed"
  
  Defaults[[paste("plotdeets", title, sep="")]]   = FALSE
  Defaults[[paste("Title", title, sep="")]]       = ""
  Defaults[[paste("Xtit", title, sep="")]]        = "Time (days)"
  Defaults[[paste("Ytit", title, sep="")]]        = "Concentration (prediction corrected)"
  Defaults[[paste("Xlim", title, sep="")]]        = ""
  Defaults[[paste("xForm", title, sep="")]]        = "none"
  Defaults[[paste("xScale", title, sep="")]]      = "none"
  Defaults[[paste("Ylim", title, sep="")]]        = ""
  Defaults[[paste("yForm", title, sep="")]]        = "none"
  Defaults[[paste("yScale", title, sep="")]]       = "none"
  Defaults[[paste("minorTicks", title, sep="")]]  = TRUE

  
  Defaults[[paste("reorg", title, sep="")]]       = FALSE
  Defaults[[paste("DataLim", title, sep="")]]     = ""
  #Defaults[[paste("Trans", title, sep="")]]      = ""
 
  Defaults[[paste("priorExists",title,sep="")]]=TRUE
	Defaults[[paste("LegendTitle", title, sep="")]]="Visual predictive check for <model>"
	Defaults[[paste("Legend", title, sep="")]]="Observed data (open circles) and median (solid line).  5th and 95th percentiles of the predictions for the 5th, median, and 95th percentiles are shown as shaded regions."
	Defaults[[paste("Footnote", title, sep="")]]="Footnote"
	Defaults[[paste("reset", title, sep="")]]=FALSE

	
	
	for(item in names(themeEditorDefaults)){
	  Defaults[[paste(item, title, sep="")]]=themeEditorDefaults[[item]]
	}
	
	
	return(Defaults)
	

	
}
