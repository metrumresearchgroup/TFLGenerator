cleanparse <- function(parsethis,data_obj_name){
  if(parsethis=="") return(NULL)
  x <- unlist(strsplit(parsethis,"\n"))
  x_inline <- grep("$DATA",x,fixed=T,value=T)
  x_within <- setdiff(x,x_inline)
  x_inline_new <- gsub("$DATA",data_obj_name,x_inline,fixed=T)
  commands <- c(x_inline_new,x_within)[match(x,c(x_inline,x_within))]
  within <- commands %in% x_within
  return(list(commands=commands,within=within))
}