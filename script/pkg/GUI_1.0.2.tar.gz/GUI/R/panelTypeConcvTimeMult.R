panelTypeConcvTimeMult <-
  function(plotType, input, Set=list()){
    
    #All if statements relate to a specific output type, which then add an additional panel
    if(input[[paste(plotType, "Num", sep="")]]>=1){
      
      numbers=as.numeric(unlist(str_extract_all(input[[paste(plotType, "Num", sep="")]], "\\d+")))
      if(length(numbers)>1){numRange=numbers[which(numbers!=0)]}
      if(length(numbers)==1){numRange=c(1:numbers)}
      for (n in numRange){
        
        title=paste(plotType, n, sep="")
        #set originating defaults
        checkPriors(plotType=plotType, input=input, n=n)
        
        nn=length(Set)
        
        
        Set[[nn+1]]=
          tabPanel(paste(plotType,n, sep="#"),
                   
                   sidebarPanel(
                     actionButton(paste("button", plotType, n, sep=""), "Generate Plot"),										 	
                     textRow(paste("ID", plotType, n, sep=""), "IDs (e.g., 1-10,12,15-20)", Defaults[[paste("ID", title, sep="")]]),
                     h1(""),
                     checkboxInput(paste("allID",plotType,n,sep=""),"All IDs (leave above ID box empty)"),
                     h1(""),
                     textRow(paste("nrow",plotType,n,sep=""), "Rows", Defaults[[paste("nrow",title,sep="")]]),
                     textRow(paste("ncol",plotType,n,sep=""), "Columns", Defaults[[paste("ncol",title,sep="")]]),
                     h1(""),
                     textRow(paste("page",plotType,n,sep=""), "Page to display here", Defaults[[paste("page",title,sep="")]]),
                     h1(""),
                     checkboxInput(paste("plotdeets", plotType, n, sep=""), "Plots Details", Defaults[[paste("plotdeets", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "plotdeets", plotType, n, sep="")),
                                      wellPanel(textRow(paste("Title", plotType, n, sep=""), "Figure Title",  Defaults[[paste("Title", title, sep="")]]),
                                                h2(""),
                                                textRow(paste("Xtit", plotType, n, sep=""), "X Axis Title", Defaults[[paste("Xtit", title, sep="")]]),
                                                h2(""),
                                                textRow(paste("Ytit", plotType, n, sep=""), "Y Axis Title", Defaults[[paste("Ytit", title, sep="")]]),
                                                h2(""),
                                                textRow(paste("Xlim", title, sep=""), "X Axis Limits",  Defaults[[paste("Xlim", title, sep="")]]),
                                                h2(""),
                                                inputSelect2(paste("xForm", title, sep=""), paste("xScale", title, sep=""), "Format", 
                                                             choices1=c("percent" = "percent",
                                                                        "comma" = "comma",
                                                                        "plain"="plain",
                                                                        "scientific" = "scientific"),
                                                             choices2=c("none"="identity",
                                                                        "log10" = "log10",
                                                                        "log" = "log"
                                                             ), 
                                                             selected1=Defaults[[paste("xForm", title, sep="")]],
                                                             selected2=Defaults[[paste("xScale", title, sep="")]]),
                                                
                                                
                                                
                                                h2(""),
                                                textRow(paste("Ylim", title, sep=""), "Y Axis Limits",  Defaults[[paste("Ylim", title, sep="")]]),
                                                h2(""),
                                                inputSelect2(paste("yForm", title, sep=""), paste("yScale", title, sep=""), "Format", 
                                                             choices1=c("percent" = "percent",
                                                                        "comma" = "comma",
                                                                        "plain"="plain",
                                                                        "scientific" = "scientific"),
                                                             choices2=c("none"="identity",
                                                                        "log10" = "log10",
                                                                        "log" = "log"
                                                             ), 
                                                             selected1=Defaults[[paste("yForm", title, sep="")]],
                                                             selected2=Defaults[[paste("yScale", title, sep="")]])
                                                
                                      )
                     ),
                     
                     checkboxInput(paste("AES", plotType, n, sep=""), "Change Defaults",  Defaults[[paste("AES", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "AES", plotType, n, sep="")),
                                      wellPanel( textRow(paste("yBy", plotType, n, sep=""), "Y Column", Defaults[[paste("yBy", title, sep="")]]),
                                                 h2(""),
                                                 textRow(paste("xBy", plotType, n, sep=""), "X Column", Defaults[[paste("xBy", title, sep="")]]),
                                                 h2(""),
                                                 textRow(paste("idVar", plotType, n, sep=""), "ID Column", Defaults[[paste("idVar", title, sep="")]]),
                                                 h2(""),
                                                 textRow(paste("predVar", plotType, n, sep=""), "Pop Pred Column", Defaults[[paste("predVar", title, sep="")]]),
                                                 h2(""),
                                                 textRow(paste("ipredVar", plotType, n, sep=""), "Ind Pred Column", Defaults[[paste("ipredVar", title, sep="")]]),
                                                 h2(""),
                                                 textRow(paste("doseVar",title,sep=""), "Dose variable", Defaults[[paste("doseVar",title,sep="")]]),
                                                 h2(""),
                                                 textRow(paste("doseLab",title,sep=""), "Dose label", Defaults[[paste("doseLab",title,sep="")]])
                                                 
                                      )
                     ),
                     
                     
                     checkboxInput(paste("reorg", plotType, n, sep=""), "Manipulate Data", Defaults[[paste("reorg", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "reorg", plotType, n, sep="")),
                                      wellPanel(boxInput(paste("DataLim", title, sep=""), "Limit",  Defaults[[paste("DataLim", title, sep="")]])
                                                # ,
                                                # boxInput(paste("Trans", title, sep=""), "Transform", Defaults[[paste("Trans", title, sep="")]])
                                      )
                     ),	 
                     checkboxInput(paste("reset", plotType, n, sep=""), "Reset to Defaults", FALSE)
                   ),
                   
                   mainPanel(div(align="center",
                                 textOutput(paste0("generated",plotType,n)),
                                 boxInputLong(paste("LegendTitle", plotType, n, sep=""), "Figure Title", Defaults[[paste("LegendTitle", title, sep="")]]),
                                 plotOutput(paste("Plot", plotType,n,  sep=""), width="800px", height="600px"),
                                 boxInputWide(paste("Legend", plotType, n, sep=""), "Legend Text", Defaults[[paste("Legend", title, sep="")]]),
                                 boxInputLong(paste("Footnote", plotType, n, sep=""), "Footnote", Defaults[[paste("Footnote", title, sep="")]])
                                 #imageOutput(paste("Plot", plotType,n,  sep=""), width="637.5px", height="825px")
                                 
                                 
                   ))
                   
          )
        names(Set)[[nn+1]]=paste("Tab", plotType,n,  sep="")
      }
    }
    return(Set)	
  }
