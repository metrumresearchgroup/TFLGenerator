makeDefaultGOF <-
function(title, Defaults){																
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
  
	
	Defaults[[paste("markBy", title, sep="")]]=""
	Defaults[[paste("preserveMarkByLevels",title,sep="")]]=FALSE
	Defaults[[paste("timeBy", title, sep="")]]="TAFD"
	Defaults[[paste("timeLimit",title,sep="")]]=""
	Defaults[[paste("timeScale",title,sep="")]]="identity"
	Defaults[[paste("timeLab",title,sep="")]]="Time (weeks)"
	Defaults[[paste("timeFmt",title,sep="")]]="plain"
	Defaults[[paste("concBy",title,sep="")]]="DV"
	Defaults[[paste("concLimit",title,sep="")]]=""
	Defaults[[paste("concScale",title,sep="")]]="log10"
	Defaults[[paste("concLab",title,sep="")]]="Observed Serum Concentration (ug/mL)"
	Defaults[[paste("predBy",title,sep="")]]="PRED"
	Defaults[[paste("predLimit",title,sep="")]]=""
	Defaults[[paste("predScale",title,sep="")]]="log10"
	Defaults[[paste("predLab",title,sep="")]]="Population Prediction (ug/mL)"
	Defaults[[paste("ipredBy",title,sep="")]]="IPRED"
	Defaults[[paste("ipredLimit",title,sep="")]]=""
	Defaults[[paste("ipredScale",title,sep="")]]="log10"
	Defaults[[paste("ipredLab",title,sep="")]]="Individual Prediction (ug/mL)"
	Defaults[[paste("cwresBy",title,sep="")]]="CWRES"
	Defaults[[paste("cwresLimit",title,sep="")]]=""
	Defaults[[paste("cwresScale",title,sep="")]]="identity"
	Defaults[[paste("cwresLab",title,sep="")]]="Conditional Weighted Residuals"
	Defaults[[paste("npdeBy",title,sep="")]]="NPDE"
	Defaults[[paste("npdeLimit",title,sep="")]]=""
	Defaults[[paste("npdeScale",title,sep="")]]="identity"
	Defaults[[paste("npdeLab",title,sep="")]]="NPDE"
	
	Defaults[[paste("Title",title,sep="")]]="Goodness of Fit Plots"
	
	Defaults[[paste("smooth",title,sep="")]]=TRUE
	Defaults[[paste("plotdeets",title,sep="")]]=FALSE
	Defaults[[paste("timedeets",title,sep="")]]=FALSE
	Defaults[[paste("concdeets",title,sep="")]]=FALSE
	Defaults[[paste("preddeets",title,sep="")]]=FALSE
	Defaults[[paste("ipreddeets",title,sep="")]]=FALSE
	Defaults[[paste("cwresdeets",title,sep="")]]=FALSE
	Defaults[[paste("npdedeets",title,sep="")]]=FALSE
	
	Defaults[[paste("reorg",title,sep="")]]=FALSE
	Defaults[[paste("DataLim", title, sep="")]]=""
	Defaults[[paste("Trans", title, sep="")]]=""
	Defaults[[paste("LegendTitle", title, sep="")]]="Goodness of Fit Plots"
	Defaults[[paste("Legend", title, sep="")]]="Caption"
	Defaults[[paste("Footnote", title, sep="")]]="The red line is the lowess (local regression smoother) trend line"
	Defaults[[paste("reset", title, sep="")]]=FALSE
	return(Defaults)	
}
