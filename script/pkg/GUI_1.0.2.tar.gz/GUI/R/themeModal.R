themeModal=function(pTheme){
  bsModal(id = "updateThemePopup", 
          title = "Update Plot Theme", 
          trigger = "updateTheme", 
          size = "large",
          do.call(tabsetPanel,
                  unlist(lapply(1:length(pTheme),FUN = function(j){
                    if(themeListDepth(pTheme[j])>2){
                      list(themeMakePanel(pTheme[j]))
                    }else{
                      unlist(lapply(j, function(i) {themeMakePanel(pTheme[i])}),F)}
                  }),F)
          ),
          hr(),
          actionButton(inputId = "setTheme",label = "Set Theme")
  )
}