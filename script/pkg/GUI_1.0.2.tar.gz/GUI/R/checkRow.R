checkRow <-
function (inputId, label, value) 
{
	inputTag <- tags$input(id = inputId, type = "checkbox")
	if (!is.null(value) && value) 
		inputTag$attribs$checked <- "checked"
	
	div(class='row',
			div(class="span1", p(label, style="min-width:10px;max-width:200px")),
			div(class="span1", 	tags$label(style="min-width:10px;max-width:150px",
			                               class = "checkbox",
			                               `for` = inputId, inputTag 
			))
	)
	
}
