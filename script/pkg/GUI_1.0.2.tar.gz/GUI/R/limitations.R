limitations <-
function(limitThis){
	if(nchar(limitThis)>1){
		limitThis=unlist(str_split(limitThis, "\n"))
		# limitThis=sapply(limitThis, function(x){testLimits=str_split(x, ";[[:space:]]*")
		# 																				if(length(testLimits[[1]])<=1){testLimits=str_split(x, "[[:space:]]+")}
		# 																				return(testLimits)
		# 																				})
		limitThis=sapply(limitThis, function(x){
		  operator <- gregexpr("==|<=|<|>=|>",x)
		  testLimits=str_split(x, "==|<=|<|>=|>")
		  if(length(testLimits[[1]])<=1){
		    testLimits=str_split(x, "[[:space:]]+")
		  }else if(length(testLimits[[1]]==2)){
		    testLimits[[1]] <- c(str_trim(testLimits[[1]][1]), 
		                         substring(x,operator[1],operator[1]+attr(operator,"match.length")-1), 
		                         str_trim(testLimits[[1]][2]))
		      }
		  return(testLimits)
		})
		
		for (n in 1:length(limitThis)){

			if(length(limitThis[[n]])>=3){	
				test=unlist(str_split(limitThis[[n]][3], ","))
				test=suppressWarnings(as.numeric(test))
				if ((length(test)>1) & (NA %nin% test)){
					limitThis[[n]][3]=list(test)
				}
			}
			if(length(limitThis[[n]])==7){	
				test=unlist(str_split(limitThis[[n]][7], ","))
				test=suppressWarnings(as.numeric(test))
				if ((length(test)>1) & (NA %nin% test)){
					limitThis[[n]][7]=list(test)
				}
			}
			if(limitThis[[n]][1]=="" | length(limitThis[[n]])==1){limitThis[[n]]=NULL}
		}
	}
	
	
	return(limitThis)
	
}
