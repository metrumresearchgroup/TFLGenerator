# pList.new<<-do.call(callType,argList)$pList
# theme.now=theme_get()
# if(length(p.new$theme)>0) theme.now=theme.now+p.new$theme
# p.theme<<-themeFetch(theme.now)
# 
# update.Theme=eventReactive(input$sendTheme,{
#   pList.new<<-do.call(callType,argList)$pList
#   p.new<<-pList.new[[1]]
#   
#   strThemeCallList=lapply(names(p.theme),function(item){
#     themeNewVal(p.theme[item],p.new,input)
#   })
#   strThemeCall=paste0("p.new<<-p.new+theme(",paste0(unlist(strThemeCallList),collapse = ","),")")
#   eval(parse(text=strThemeCall))
#   pList.new[[1]]<<-p.new
#   return(pList.new)
# })
# 
# observeEvent(input$SetThemeGlobal,{
#   if(length(p.new$theme)>0) theme.now=theme.now+p.new$theme
#   theme_set(theme_get()%+replace%theme.now)
# })
# 
# update.ThemeGrid=eventReactive(input$SetThemeGrid,{
#   p.now<<-pList.new[[1]]
#   if(length(p.now$theme)>0) theme.now=theme.now+p.now$theme
#   
#   for(i in 1:length(pList.new)) pList.new[[i]]<<- pList.new[[i]]+theme.now
#   
#   return(pList.new)
# })
# 
# output$popTheme=renderUI({
#   bsModal(id = "updateThemePopup", title = "Update Plot Theme", trigger = "updateTheme", size = "large",
#           
#           do.call(tabsetPanel,
#                   
#                   unlist(lapply(1:length(p.theme),FUN = function(j){
#                     if(themeListDepth(p.theme[j])>2){
#                       list(themeMakePanel(p.theme[j]))
#                     }else{
#                       unlist(lapply(j, function(i) {themeMakePanel(p.theme[i])}),F)}
#                   }),F)
#                   
#                   
#           ),
#           hr(),
#           actionButton("sendTheme","Set Theme")
#           
#           
#   )
# })