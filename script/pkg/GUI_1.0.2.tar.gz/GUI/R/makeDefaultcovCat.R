makeDefaultcovCat <-
function(title, Defaults){																
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	Defaults[[paste("groupP", title, sep="")]]=FALSE	
	Defaults[[paste("facetBy", title, sep="")]]=""
	Defaults[[paste("facetFact", title, sep="")]]=""
	Defaults[[paste("strat", title, sep="")]]=""
	Defaults[[paste("reorg", title, sep="")]]=FALSE
	Defaults[[paste("plotdeets", title, sep="")]]=FALSE
	Defaults[[paste("notches",title,sep="")]]=TRUE

	Defaults[[paste("catList", title, sep="")]]="RACE;Race\nSEX;Gender"
	Defaults[[paste("conList", title, sep="")]]="ETA1;ETA (CL)"
	Defaults[[paste("nCols", title, sep="")]]=2
	Defaults[[paste("idVar", title, sep="")]]="NMID"
	Defaults[[paste("Ylim", title, sep="")]]=""
	Defaults[[paste("yForm", title, sep="")]]="none"
	Defaults[[paste("yScale", title, sep="")]]="identity"

	Defaults[[paste("DataLim", title, sep="")]]="!duplicated(NMID)"
	Defaults[[paste("Trans", title, sep="")]]=""
	Defaults[[paste("AES", title, sep="")]]=FALSE					
	Defaults[[paste("LegendTitle", title, sep="")]]="Distribution of <y variable(s)> Stratified by <x variable(s)>"
	Defaults[[paste("Legend", title, sep="")]]="Caption"
	Defaults[[paste("Footnote", title, sep="")]]="Footnote"
	Defaults[[paste("reset", title, sep="")]]=FALSE
	return(Defaults)	
}
