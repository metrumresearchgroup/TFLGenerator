#' @export
makeDefaultNMTab <-
function(title, Defaults){		
  Defaults[[paste("priorExists",title,sep="")]]=TRUE
	Defaults[[paste("Sig", title, sep="")]]=3
	Defaults[[paste("ConfInt", title, sep="")]]=0.95
	Defaults[[paste("OffDiagonals", title, sep="")]]=FALSE
	Defaults[[paste("unTransform", title, sep="")]]=FALSE
	Defaults[[paste("removeFixed", title, sep="")]]=FALSE
	Defaults[[paste("LegendTitle", title, sep="")]]="Parameter Estimates from <model> "
	Defaults[[paste("Legend", title, sep="")]]="The estimates and their corresponding precisions (%RSE) are those found from the population analysis."
	Defaults[[paste("Footnote", title, sep="")]]="Footnote"
	Defaults[[paste("reset", title, sep="")]]=FALSE

	return(Defaults)
	

	
}
