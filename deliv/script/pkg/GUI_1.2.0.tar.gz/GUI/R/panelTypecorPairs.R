#' @export
panelTypecorPairs <-
  function(plotType, input, Set=list(), varNames=""){
    
    #All if statements relate to a specific output type, which then add an additional panel
    if(input[[paste(plotType, "Num", sep="")]]>=1){
      
      numbers=as.numeric(unlist(str_extract_all(input[[paste(plotType, "Num", sep="")]], "\\d+")))
      if(length(numbers)>1){numRange=numbers[which(numbers!=0)]}
      if(length(numbers)==1){numRange=c(1:numbers)}
      for (n in numRange){
        
        title=paste(plotType, n, sep="")
        #set originating defaults
        checkPriors(plotType=plotType, input=input, n=n)
        
        nn=length(Set)
        
        Set[[nn+1]]=
          tabPanel(paste(plotType,n, sep="#"),
                   
                   sidebarPanel(
                     actionButton(paste("button", plotType, n, sep=""), "Generate Plot"),
                     # checkboxInput(paste("groupP", plotType, n, sep=""), "Group Plots", Defaults[[paste("groupP", title, sep="")]]),
                     # conditionalPanel(condition = (paste("input.", "groupP", plotType, n, sep="")),
                     #                  wellPanel(
                     #                    textRow(paste("facetBy", plotType, n, sep=""), "Facet by:", Defaults[[paste("facetBy", title, sep="")]]),
                     #                    textRow(paste("facetFact", plotType, n, sep=""), "Factor Facet:", Defaults[[paste("facetFact", title, sep="")]])
                     #                    #, textRow(paste("strat", plotType, n, sep=""), "Stratify by:", Defaults[[paste("strat", title, sep="")]])
                     #                  )
                     # ),
                     
                     
                     checkboxInput(paste("plotdeets", plotType, n, sep=""), "Plots Details", Defaults[[paste("plotdeets", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "plotdeets", plotType, n, sep="")),
                                      wellPanel(	
                                        selectInput(paste("corstat",plotType,n,sep=""),"Correlation statistic", choices=c("R2","r"),selected=Defaults[[paste("corstat",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("Xtit",title,sep=""), "Parameter names", Defaults[[paste("Xtit",title,sep="")]]),
                                        h2(""),
                                        textRow(paste("Xlim", title, sep=""), "X Axis Limits",  Defaults[[paste("Xlim", title, sep="")]]),
                                        h2(""),
                                        inputSelect2(paste("xForm", title, sep=""), paste("xScale", title, sep=""), "Format", choices1=c("percent" = "percent",
                                                                                                                                         "comma" = "comma",
                                                                                                                                         "none"="none",
                                                                                                                                         "scientific" = "scientific"),
                                                     choices2=c("none"="identity",
                                                                "log10" = "log10",
                                                                "log" = "log"
                                                     ), 
                                                     selected1=Defaults[[paste("xForm", title, sep="")]],
                                                     selected2=Defaults[[paste("xScale", title, sep="")]]),
                                        h2(""),
                                        textRow(paste("Ylim", title, sep=""), "Y Axis Limits",  Defaults[[paste("Ylim", title, sep="")]]),
                                        h2(""),
                                        inputSelect2(paste("yForm", title, sep=""), paste("yScale", title, sep=""), "Format", choices1=c("percent" = "percent",
                                                                                                                                         "comma" = "comma",
                                                                                                                                         "none"="none",
                                                                                                                                         "scientific" = "scientific"),
                                                     choices2=c("none"="identity",
                                                                "log10" = "log10",
                                                                "log" = "log"
                                                     ), 
                                                     selected1=Defaults[[paste("yForm", title, sep="")]],
                                                     selected2=Defaults[[paste("yScale", title, sep="")]]),
                                        checkboxInput(paste("minorTicks", plotType,n,sep=""), "Minor Ticks?", Defaults[[paste("minorTicks", title, sep="")]]),
                                        conditionalPanel(paste("input.", "minorTicks", plotType, n, sep=""),
                                                         numericInput(inputId = paste("minorTickNum", plotType,n,sep=""), label = "Number of Minor Ticks", min = 1,max = 20,value = Defaults[[paste("minorTickNum", title, sep="")]])
                                        )
                                        
                                      )
                     ),
                     
                     checkboxInput(paste("AES", plotType, n, sep=""), "Change Defaults",  Defaults[[paste("AES", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "AES", plotType, n, sep="")),
                                      wellPanel( 
                                        selectizeInput(paste("xCols", plotType, n, sep=""), 
                                                       "Parameters to compare",  
                                                       choices=varNames,
                                                       selected=Defaults[[paste("xCols", title, sep="")]],
                                                       multiple=T)
                                        
                                      )
                     ),
                     
                     
                     
                     checkboxInput(paste("reorg", plotType, n, sep=""), "Manipulate Data", Defaults[[paste("reorg", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "reorg", plotType, n, sep="")),
                                      wellPanel(boxInput(paste("DataLim", title, sep=""), "Limits and transformations",  Defaults[[paste("DataLim", title, sep="")]])
                                                #,
                                                #boxInput(paste("Trans", title, sep=""), "Transform", Defaults[[paste("Trans", title, sep="")]])
                                      )
                     ),
                     checkboxInput(paste("theme", plotType, n, sep=""), "Manipulate Theme"),
                     do.call(ThemeEditorUI,list(plotType,n)),	 
                     checkboxInput(paste("reset", plotType, n, sep=""), "Reset to Defaults", FALSE)
                   ),
                   do.call(plotMainPanel,list(plotType,n))
                   
          )
#        names(Set)[[nn+1]]=paste("Tab", plotType,n,  sep="")
      }
    }
    return(Set)	
  }
