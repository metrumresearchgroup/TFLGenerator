#' @name getvpcFile
#' @title Read in a vpc file from disk
#' @description Typically tab output from NONMEM
#' @param n Index of the vpcDataList to populate
#' @param currentWD Project directory under which <vpcRun> is found
#' @param vpcRun Simulation run number with corresponding output
#' @param vpcColnames Column names for the simulated output (as NOHEADER is expected)
#' @param vpcRep Number of "subproblems"
#' @param vpcSource The source file used to create <vpcRun>
#' @param vpcSourceDV The DV name in the source (i.e., observed DV)
#' @param dataSubset Character vector of columns to be dropped from the source data (for memory efficiency)
#' @param mergeKey Optional key on which to merge the source and simulations.  If not specified, the intersection is used
#' @param rename_cols Named list of column names to rename. Expected names of that list: DVCol, TAFDCol, NMIDCol, STUDYCol, IPREDCol, PREDCol.  If FALSE, renaming is skipped
#' @param dataParse_vpc Code to be parsed against the merged data (passed to the GUI:::cleanparse function)
#' @param sortBy Sort by NMID, TAFD, STUDY?  TRUE by default, if not specified use dataParse_vpc to specify.
#' @export

getvpcFile <- function(n,item="VPC", project="",
                       vpcRun="",vpcColnames="",vpcRep="",vpcSource="",vpcSourceDV="DV",dataSubset="",mergeKey="",
                       rename_cols=NULL,
                       dataParse_vpc="", sortBy=TRUE
) {
  title <- paste0("VPC",n)

  # These will read the source file in $DATA.  Query the user instead, so omitted.
  # vpcctl <- try(read.nmctl(file.path(project,vpcRun,paste0(basename(vpcRun),".ctl"))))
  
  vpcloc <- list.files(file.path(project,vpcRun))
  vpcloc <- grep(paste0(basename(vpcRun),".tab|TAB"),vpcloc,value=T)
  if(length(vpcloc)==0){
    return("VPC files not found")
  }
  if(length(vpcloc)>1){
    return(" More than one vpc tab found, using ", vpcloc[1],"\n")
  }
  if(vpcColnames=="") return( "Input column names for the NONMEM table file")
  vpcColnames <- sapply(unlist(strsplit(vpcColnames,",")), stringr:::str_trim)
  dat <- try(read.table(file.path(project,vpcRun,vpcloc),header=F,nrows=1))
  if(dat[1]=="TABLE"){
    return("VPC simulations need to be run with NOHEADER")
  }
  
  dat <- try(read_table(file.path(project,vpcRun,vpcloc),col_names=F))
  if(length(vpcColnames)!=ncol(dat)){
    return("Number of specified column names is not equal to number of coluns in simulation table")
  }
  
  colnames(dat) <- vpcColnames
  
  if(vpcRep=="") return("Enter the number of simulation replicates")
  vpcRep <- as.numeric(vpcRep)
  dat$IREP <- rep(1:vpcRep,each=nrow(dat)/vpcRep)
  
  # Tack on the source data ----
  
  ## Load the source
  vpcsrc <- try(read_csv(file=file.path(project,vpcSource)))
  if(any(class(vpcsrc)=="tryError")) return("Please select a valid source data location")
  
  # Rename observed DV
  if(vpcSourceDV!=""){
    vpcsrc[,paste0(vpcSourceDV,"obs")] <- 
      vpcsrc[,vpcSourceDV]
    vpcsrc[,vpcSourceDV] <- NULL
    missing <- is.na(vpcsrc[,paste0(vpcSourceDV,"obs")])
    if(sum(missing)>0) cat(file=stderr(), "Dropping missing columns in the VPC data")
    vpcsrc <- vpcsrc[!missing,]
  }
  
  # Subset to the requested columns
  if(dataSubset!=""){
    vpcsrc <- subset(vpcsrc, select=dataSubset)
    vpcsrc <- vpcsrc[!duplicated(vpcsrc),]
  }
  
  # Merge ----
  #This isn't necessary, but is a check to ensure the user is using the right datasets.
  
  if(any(colnames(dat)%in%colnames(vpcsrc))){
    if(all(mergeKey=="")) mergeKey <- intersect(names(dat),names(vpcsrc))
    dat <- try(dplyr::left_join(dat, 
                                vpcsrc, 
                                by=mergeKey))
    missing <- sum(is.na(vpcsrc[,paste0(vpcSourceDV,"obs")]))
    if(missing!=0) cat(file=stderr(), "Some simulation values have no matching observations!\n")
  }else if(nrow(dat)==nrow(vpcsrc)) dat <- cbind(vpcsrc,dat)
  
  if(class(rename_cols)=="list"){
    if(rename_cols$DVCol   != "") names(dat)[which(names(dat)== rename_cols$DVCol)] = "DV"
    if(rename_cols$TAFDCol != "") names(dat)[which(names(dat)== rename_cols$TAFDCol)]="TAFD"
    if(rename_cols$NMIDCol != "") names(dat)[which(names(dat)== rename_cols$NMIDCol)]="NMID"
    if(rename_cols$STUDYCol != "") names(dat)[which(names(dat)==rename_cols$STUDYCol)]="STUDY"
    if(rename_cols$IPREDCol != "") names(dat)[which(names(dat)==rename_cols$IPREDCol)]="IPRED"
    if(rename_cols$PREDCol != "") names(dat)[which(names(dat)== rename_cols$PREDCol)]="PRED"
  }
  
  # Run parser on merged data
  if(dataParse_vpc!=""){
    parsecommands <- cleanparse(dataParse_vpc,"dat")
    if(!is.null(parsecommands)){
      for(i in 1:length(parsecommands$commands)){
        if(parsecommands$within[i]) tryCatch(eval(parse(text=paste0("dat <- within(dat, {", parsecommands$commands[i], "})"))),
                                             error=function(e) cat(file=stderr(),paste("Parsing command broken:\n",parsecommands$commands[i],"\n", e)))
        if(!parsecommands$within[i]) tryCatch(eval(parse(text=paste0("dat <- ", parsecommands$commands[i]))),
                                              error=function(e) cat(file=stderr(),print(paste("Parsing command broken:\n",parsecommands$commands[i],"\n", e))))
      }
    }
  }
  
  if(sortBy==T){
    if(all(c("DV","TAFD","NMID")%in%names(dat))){
      if("STUDY" %in% names(dat)) dat <- dat[order(dat$STUDY,dat$NMID,dat$TAFD),] else dat <- dat[order(dat$NMID,dat$TAFD),]
    }
  }# else we assume the user has done so in the parser
  
  if(exists("subjectExclusions",envir=.GlobalEnv)){
    if(("NMID" %in% names(dat)) & ("NMID" %in% names(subjectExclusions))){
      if("STUDY" %in% names(dat) & ("STUDY" %in% names(subjectExclusions))){
        dat <- filter(dat, paste(NMID,STUDY) %nin% paste(subjectExclusions$NMID,subjectExclusions$STUDY) )
      }else{
        dat <- filter(dat, NMID %nin% subjectExclusions$NMID)
      }
    }
  }
  if(exists("observationExclusions",envir=.GlobalEnv)){
    commoncols <- intersect(names(dat), names(observationExclusions))
    dat <- dat[paste(dat[,commoncols]) %nin%  paste(observationExclusions[,commoncols]),]
  }
  # vpcDataList[[paste0("addl","VPC",n)]] <<- isolate(dat)
  
  return(dat)
  
}

# vpcAddlFile ----

getvpcAddlFile <- function(n, project="",
                           addlVpcSource="",vpcSourceDV="DV", addlDataParse_vpc="",
                           rename_cols=list(DVCol="DV", TAFDCol="TIME", NMIDCol="NMID", STUDYCol="STUDY", IPREDCol="IPRED", PREDCol="PRED"),
                           dataParse_vpc="", sortBy=TRUE
) {
  title <- paste0("VPC",n)
  
  ## Load it first
  dat <- try(read_csv(file=file.path(project,addlVpcSource)))
  if(any(class(dat)=="tryError")) return("Please select a valid source data location")
  
  if(class(rename_cols)=="list"){
    if(rename_cols$DVCol != "")    names(dat)[which(names(dat)==rename_cols$DVCol)] = "DV"
    if(rename_cols$TAFDCol != "")  names(dat)[which(names(dat)==rename_cols$TAFDCol)]="TAFD"
    if(rename_cols$NMIDCol != "")  names(dat)[which(names(dat)==rename_cols$NMIDCol)]="NMID"
    if(rename_cols$STUDYCol != "") names(dat)[which(names(dat)==rename_cols$STUDYCol)]="STUDY"
    if(rename_cols$IPREDCol != "") names(dat)[which(names(dat)==rename_cols$IPREDCol)]="IPRED"
    if(rename_cols$PREDCol != "")  names(dat)[which(names(dat)==rename_cols$PREDCol)]="PRED"
  }
  
  # Run parser on merged data
  if(addlDataParse_vpc!=""){
    parsecommands <- cleanparse(addlDataParse_vpc,"dat")
    if(!is.null(parsecommands)){
      for(i in 1:length(parsecommands$commands)){
        if(parsecommands$within[i]) tryCatch(eval(parse(text=paste0("dat <- within(dat, {", parsecommands$commands[i], "})"))),
                                             error=function(e) cat(file=stderr(),paste("Parsing command broken:\n",parsecommands$commands[i],"\n", e)))
        if(!parsecommands$within[i]) tryCatch(eval(parse(text=paste0("dat <- ", parsecommands$commands[i]))),
                                              error=function(e) cat(file=stderr(),print(paste("Parsing command broken:\n",parsecommands$commands[i],"\n", e))))
      }
    }
  }
  
  if(all(class(dat) != "try-error")){
    # Rename observed DV
    if(vpcSourceDV!=""){
      dat[,paste0(vpcSourceDV,"obs")] <- 
        dat[,vpcSourceDV]
      dat[,"vpcSourceDV"] <- NULL
      missing <- is.na(dat[,paste0(vpcSourceDV,"obs")])
      if(sum(missing)>0) cat(file=stderr(), "Observed (additional) values dropped for missingness")
      dat <- dat[!missing,]
    }
  }
  
  if(exists("subjectExclusions",envir=.GlobalEnv)){
    if(("NMID" %in% names(dat)) & ("NMID" %in% names(subjectExclusions))){
      if("STUDY" %in% names(dat) & ("STUDY" %in% names(subjectExclusions))){
        dat <- filter(dat, paste(NMID,STUDY) %nin% paste(subjectExclusions$NMID,subjectExclusions$STUDY) )
      }else{
        dat <- filter(dat, NMID %nin% subjectExclusions$NMID)
      }
    }
  }
  if(exists("observationExclusions",envir=.GlobalEnv)){
    commoncols <- intersect(names(dat), names(observationExclusions))
    dat <- dat[paste(dat[,commoncols]) %nin%  paste(observationExclusions[,commoncols]),]
  }
  # vpcDataList[[paste0("addl","VPC",n)]] <<- isolate(dat)
  return(dat)
  
}