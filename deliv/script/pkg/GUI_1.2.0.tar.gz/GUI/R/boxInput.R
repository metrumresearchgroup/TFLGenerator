#' @export
boxInput <-
function (inputId, label, value) 
{
	div(class='row',
			div(class="span3 offset1", p(label, style="min-width:100px;max-width:150px")),
			div(class="span3 offset1", tags$textarea(id=inputId, type="text", value, style="min-width:105px;max-width:150px"))
	)
	
}
