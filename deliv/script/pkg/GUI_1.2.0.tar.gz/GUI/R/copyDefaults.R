#' @export
copyDefaults <-
function(plotType, n, Defaults){
	
	priorSet=grep(paste(plotType, n-1, sep=""), names(Defaults))
	dummySet=Defaults[priorSet]
	names(dummySet)=sub(n-1, n, names(dummySet))
	#replace the two functions with function names

	Defaults=c(Defaults, dummySet)
	
	
}
