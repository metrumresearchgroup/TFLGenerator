#' @export
inputSelect <-
function(inputId, label, choices, selected = NULL, multiple = FALSE) 
{
	choices <- choicesWithNames(choices)
	if (is.null(selected) && !multiple) 
		selected <- names(choices)[[1]]
	selectTag <- tags$select(id = inputId)
	if (multiple) 
		selectTag$attribs$multiple <- "multiple"
	optionTags <- mapply(choices, names(choices), SIMPLIFY = FALSE, 
											 USE.NAMES = FALSE, FUN = function(choice, name) {
											 	optionTag <- tags$option(value = choice, name)
											 	if (name %in% selected) 
											 		optionTag$attribs$selected = "selected"
											 	optionTag
											 })
	selectTag <- tagSetChildren(selectTag, list = optionTags)
	
	div(class='row',
			div(class="span2 offset1", p(label, style="min-width:75px;max-width:90px")),
			div(class="span2",style="min-width:105px;max-width:150px", selectTag)
	)
}
