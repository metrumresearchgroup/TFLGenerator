#' @export
boxInputWide <-
function (inputId, label, value) 
{
	div(class='row',
			div(tags$textarea(id=inputId, rows=3, type="text", value, style="min-width:505px;max-width:600px"), align="center")
	)
	
}
