numberRow <-
function (inputId, label, value) 
{
	
	div(class='row',
			div(class="span3 offset1", p(label, style="min-width:100px;max-width:200px")),
			div(class="span3 offset1", tags$input(id=inputId, type="number", value=value, style="min-width:105px;max-width:150px"))
	)
	
}
