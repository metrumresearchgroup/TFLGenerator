#' @export
checkPriors <-
function(plotType, input, n){
title=paste(plotType, n, sep="")

if (paste("priorExists", plotType, n, sep="") %nin% names(Defaults)){
	#if there is already a plot immediately prior to the new plot, set the defaults equal to those
	if(paste("priorExists", plotType, n-1, sep="") %in% names(Defaults)){Defaults<<-copyDefaults(plotType, n, Defaults)}
	#if there isn't a plot, create new defaults
	if (paste("priorExists", plotType, n-1, sep="") %nin% names(Defaults)){Defaults<<-do.call(paste("makeDefault",plotType, sep=""), args=list(title, Defaults))}
}

if (paste("priorExists", plotType, n, sep="") %in% names(Defaults)){
	#if there is alread a plot with that number, but the value is false
	if (!Defaults[[paste("priorExists", plotType, n, sep="")]]){Defaults<<-do.call(paste("makeDefault",plotType, sep=""), args=list(title, Defaults))}
}

if (paste("reset", plotType, n, sep="") %in% names(input)){
	if (input[[paste("reset", plotType, n, sep="")]]){Defaults<<-do.call(paste("makeDefault",plotType, sep=""), args=list(title, Defaults))}	
}
return(NULL)
}
