#' @export
transformations <-
function(transThis){
	if(nchar(transThis)>1){
		transThis=unlist(str_split(transThis, "\n"))
		transThis=sapply(transThis, function(x){testTrans=str_split(x, ";[[:space:]]*")
																						if(length(testTrans[[1]])<=1){testTrans=str_split(x, "[[:space:]]+")}
																						return(testTrans)
																						})
		if(length(transThis)<=1){transThis=sapply(transThis, function(x){str_split(x, "[[:space:]]+")})}
		for (n in 1:length(transThis)){
			if(length(transThis[[n]])>=3){	
				test=unlist(str_split(transThis[[n]][3], ","))
				test=suppressWarnings(as.numeric(test))
				if ((length(test)>1) & (NA %nin% test)){
					
					transThis[[n]][3]=list(test)
				}
			}
			
		}
		if(transThis[[n]][1]==""){transThis[[n]]=NULL}
	}
	
	return(transThis)
}
