#' @export
Popup <-
function(title, content,
											placement=c('right', 'top', 'left', 'bottom'),
											trigger=c('click', 'hover', 'focus', 'manual')) {
	tagList(
		singleton(
			tags$head(
				tags$script("$(function() { $(\"[data-toggle='popover']\").popover(); })")
			)
		),
		tags$a(
			href = "#", class = "btn btn-mini", `data-toggle` = "popover",
			title = title, `data-content` = content, `data-animation` = TRUE,
			`data-placement` = match.arg(placement, several.ok=TRUE)[1],
			`data-trigger` = match.arg(trigger, several.ok=TRUE)[1],
			tags$i(class="icon-exclamation-sign") #this is an icon from the font-awesome library
		)
	)
}
