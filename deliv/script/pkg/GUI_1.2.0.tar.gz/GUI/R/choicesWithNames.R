#' @export
choicesWithNames <- function(choices) {
	# get choice names
	choiceNames <- names(choices)
	if (is.null(choiceNames))
		choiceNames <- character(length(choices))
	# default missing names to choice values
	missingNames <- choiceNames == ""
	choiceNames[missingNames] <- paste(choices)[missingNames]
	names(choices) <- choiceNames
	# return choices
	return (choices)
}