demogTab <-
	function(datFile, group="STUD",idVar="NMID", facetBy="",
					 statList=c("n", "Mean","sd", "Min", "Max"),
					 conList=list(c("AGE", "years"), c("HGTB", "cm"), c("WGTB", "kg")),
					 covList=c("SEX", "DIS"),
						sigDig=3)
		{ 
		
		cons=sapply(conList, function(x){x[[1]][1]})
		units=sapply(conList, function(x){x[[2]][1]})
		subData=datFile[!duplicated(datFile[c(idVar, group, facetBy)]),]
		
		
		subDataCon=subData[,c(facetBy,group,cons)]
		subDataCon=melt(subDataCon, id.vars=c(group,facetBy), variable_name="Parameter")
	
		
		
		# New version of length which can handle NA's: if na.rm==T, don't count them
		length2 <- function (x, na.rm=TRUE) {
			if (na.rm) sum(!is.na(x))
			else       length(x)
		}
		
		###Analyze the continuous variables
		statData=ddply(subDataCon, .variables=c(facetBy, group, "Parameter"),
									 .fun= function(xx) {
									 	c( n     	= length2(xx[,"value"], na.rm=TRUE),
									 		 Mean= signif(mean(xx[,"value"], na.rm=TRUE), digits=sigDig),
 								 		 Median=signif(median(xx[,"value"], na.rm=TRUE), digits=sigDig),
									 		 sd=signif(sd(xx[,"value"], na.rm=TRUE), digits=sigDig),
								 		 CV=signif((sd(xx[,"value"], na.rm=TRUE)/mean(xx[,"value"], na.rm=TRUE)*100),digits=sigDig),
 									 		 Min=signif(min(xx[,"value"], na.rm=TRUE),digits=sigDig),
									 		 Max=signif(max(xx[,"value"], na.rm=TRUE),digits=sigDig)
									 	)
									 	
									 } )
		
		
		statData$Desc=paste(statData[[statList[2]]],
		                    paste("(", statData[[statList[3]]], ")", sep=""),
		                    paste("[", statData$Min, "-", statData$Max, "]", sep="")
		                    )
		
		
		statData=statData[,c(facetBy, group, "Parameter","n", "Desc")]
	
		
		statData$Parameter=paste(statData$Parameter, paste("(", 	sapply(statData$Parameter, FUN=function(x){units[which(cons==x)]}), ")", sep=""))
	
		statData=cast(statData, formula=as.formula(sprintf("%s+%s ~ Parameter", facetBy, group)), value="Desc")
  
		nfacets=length(unique(statData[facetBy]))
		
		
		print(grid.arrange(
		  tableGrob(t(data.frame(names(statData[names(statData)!=facetBy]))), show.rownames=FALSE)
		))
		
		
		
		print(grid.arrange(
		  tableGrob(data.frame(t(data.frame(names(statData[names(statData)!=facetBy]))),row.names=FALSE))
		))
		
		
		p1=renderTableGrob(statData)
		return(p1)
	}
