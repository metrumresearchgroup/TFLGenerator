
saveGrob <-
function(plot, Name, file,
									fac="", mar="", gro="", str="", legtit=Name, leg=sprintf("Information about %s", Name)){
	
	fileTitle=file
	
	if(!file.exists(fileTitle)){
		#Add empty Grob List
		guiGrobs=list()
		save(guiGrobs, file=fileTitle)
		
	}
	
	#if the grobs aren't loaded already, load them in
	if(!exists("guiGrobs", envir=.GlobalEnv)){
		load(file=fileTitle, envir=.GlobalEnv, verbose=TRUE)
	}
	
	#Now append the new Grob 
	nn=length(guiGrobs)
	if (Name==""){saveName=nn}
	#convert the items to a list of the proper order
	if ("list" %nin% class(plot)){
		plot=list(Facets=fac, Marks=mar, Groups=gro, Stratification=str, LegendTitle=legtit, Legend=leg, Plot=plot)
	}
	
	guiGrobs[[Name]]<<-plot
	
	save(guiGrobs, file=fileTitle)

}
