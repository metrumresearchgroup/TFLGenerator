panelTypedemogTab <-
function(plotType, input, Set=list()){
	
	#All if statements relate to a specific output type, which then add an additional panel
	if(input[[paste(plotType, "Num", sep="")]]>=1){
		
		numbers=as.numeric(unlist(str_extract_all(input[[paste(plotType, "Num", sep="")]], "\\d+")))
		if(length(numbers)>1){numRange=numbers[which(numbers!=0)]}
		if(length(numbers)==1){numRange=c(1:numbers)}
		for (n in numRange){
			
			title=paste(plotType, n, sep="")
			#set originating defaults
			checkPriors(plotType=plotType, input=input, n=n)
			
			nn=length(Set)
			
			
			Set[[nn+1]]=
				tabPanel(paste(plotType,n, sep="#"),
								 
								 sidebarPanel(
actionButton(paste("button", plotType, n, sep=""), "Generate Plot"),										 	checkboxInput(paste("AES", plotType, n, sep=""), "Change Defaults",  Defaults[[paste("AES", title, sep="")]]),
								 	conditionalPanel(condition = (paste("input.", "AES", plotType, n, sep="")),
								 									 wellPanel( textRow(paste("group", plotType, n, sep=""), "Group by", Defaults[[paste("group", title, sep="")]]),
								 									 					 textRow(paste("idVar", plotType, n, sep=""), "ID Column", Defaults[[paste("idVar", title, sep="")]]),
								 									 					 textRow(paste("statList", plotType, n, sep=""), "List of Statistics", Defaults[[paste("statList", title, sep="")]]),
								 									 					 boxInput(paste("conList", plotType, n, sep=""), "Continuous Variables", Defaults[[paste("conList", title, sep="")]]),
								 									 					 textRow(paste("covList", plotType, n, sep=""), "Discrete Variables", Defaults[[paste("covList", title, sep="")]]),
								 									 					 numberRow(paste("sigDig", plotType, n, sep=""), "Number of Significant Digits", Defaults[[paste("sigDig", title, sep="")]])
								 									 )
								 	),
								 	
								 	
								 	checkboxInput(paste("reorg", plotType, n, sep=""), "Manipulate Data", Defaults[[paste("reorg", title, sep="")]]),
								 	conditionalPanel(condition = (paste("input.", "reorg", plotType, n, sep="")),
								 									 wellPanel(boxInput(paste("DataLim", title, sep=""), "Limit",  Defaults[[paste("DataLim", title, sep="")]]),
								 									 					boxInput(paste("Trans", title, sep=""), "Transform", Defaults[[paste("Trans", title, sep="")]])
								 									 )
								 	),	 
								 	checkboxInput(paste("reset", plotType, n, sep=""), "Reset to Defaults", FALSE)
								 ),
								 
								 mainPanel(div(align="center",
								 							boxInputLong(paste("LegendTitle", plotType, n, sep=""), "Figure Title", Defaults[[paste("LegendTitle", title, sep="")]]),
								 							plotOutput(paste("Plot", plotType,n,  sep=""), width="800px", height="400px"),
								 							boxInputWide(paste("Legend", plotType, n, sep=""), "Legend Text", Defaults[[paste("Legend", title, sep="")]]),
								 							boxInputLong(paste("Footnote", plotType, n, sep=""), "Footnote", Defaults[[paste("Footnote", title, sep="")]])
								 							
								 ))
								 
				)
			names(Set)[[nn+1]]=paste("Tab", plotType,n,  sep="")
		}
	}
	return(Set)	
}
