covCon <-
function(datFile, conList_x, conList_y, nCols=2,
								xLimit=NULL, yLimit=NULL,
								xForm=waiver(), yForm=waiver(),
								xScale="identity", yScale="identity",
								facetBy="", fF="", fnrow=NULL, fncol=NULL,fscales="fixed",
         corstat="R2",
								...){
	
  # if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
  # if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
  
	#for individual plots, nCols=1, xBy and yBy is a single column name (such as "RACE" and "ETA1)
	#for a multiple plot object

  if(facetBy!="" & all(fF!="")){
    datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
  }
  
  if(class(conList_x)!="list"){
    conList_x <- list(conList_x)
  }
  if(class(conList_y)!="list"){
    conList_y <- list(conList_y)
  }
  
  yCols=sapply(conList_y, function(x){x[[1]][1]})
  yLabs=sapply(conList_y, function(x){if(length(x)==2) x[[2]][1] else x[[1]][1]})
  xCols=sapply(conList_x, function(x){x[[1]][1]})
  xLabs=sapply(conList_x, function(x){if(length(x)==2) x[[2]][1] else x[[1]][1]})
  
  
	pList=list()
	for (x in xCols){
		for (y in yCols){	
			#perform a one way analysis of variance
			mod1 = lm(datFile[,y]~datFile[,x], data = datFile)
			modsum = summary(mod1)
			r2 = ifelse("adj.r.squared" %in% names(modsum), paste("R^2=",signif(modsum$adj.r.squared, digits=3)), "")
			r = paste0("r=", signif(cor(datFile[,x],datFile[,y],use="pairwise.complete.obs",method="pearson"),digits=3))
			
			my.p =ifelse(((dim(modsum$coefficients)[1]>=2) & dim(modsum$coefficients)[2]>=4), 
			             ifelse(modsum$coefficients[2,4]>0.001,
			                    paste("p=",signif(modsum$coefficients[2,4],digits=3)),
			                    "p<0.001"),
			             "")
			
			label <- ifelse(corstat=="R2", sprintf("%s : %s",r2, my.p), sprintf("%s : %s",r, my.p))
			
		p1=	
				ggplot(datFile, aes_string(x=x, y=y))+
				geom_smooth(method="loess", se=FALSE, colour="red", lty=2)+
				geom_abline(intercept=mod1$coeff[1], slope=mod1$coeff[2],  colour="red")+
				geom_point(shape=1)+
				geom_hline(yintercept=0, lty=2)+
				labs(x=xLabs[which(x==xCols)], y=yLabs[which(y==yCols)], title=label)+
				scale_x_continuous(breaks=pretty_breaks(), limits=xLimit, labels=eval(xForm), trans=xScale)+
				scale_y_continuous(breaks=pretty_breaks(), limits=yLimit, labels=eval(yForm), trans=yScale)+
				theme(panel.background = element_blank(),
							axis.text=element_text(size=12, colour="black"),	axis.line=element_line(),
							panel.border=element_blank(), panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
							plot.margin=unit(c(.1,0,.1,0), "cm"))
		
			if (facetBy!=""){
				p1=p1 +facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,ncol=fncol,scales=fscales)
				
			}
			
			pList[[paste("plot",x, "vs", y, sep="")]]=p1
		
		
		}
	}
	
	
	if(length(c(xCols,yCols))==2){
	  p1 <- pList[[1]]
	  return(pList[[1]])
	}
	if(length(c(xCols,yCols))>2){
	  
	  for(i in 1:length(pList)) class(pList[[i]]) <- "ggplot"
	  p1 <- do.call("arrangeGrob", c(pList, ncol=nCols))
	  return(do.call("arrangeGrob", c(pList, ncol=nCols)))
	}
	
	return(p1)
}
