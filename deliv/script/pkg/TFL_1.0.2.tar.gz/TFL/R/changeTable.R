changeTable=function(oldTable, 
										 xrow,
										 xcol,
										 entry){
	
	if(xrow!=0){
		
		newData=oldTable$d
		newData=apply(newData, c(1,2), as.character)
		newData[xrow, xcol]=entry
		
		q = c()
		for (i in c(1:ncol(newData))){
			q = c(q, as.character(newData[,i]))
		}
		
		idx=grep("core-label", oldTable$lg$lgt)
		for(i in idx){
			IDX=as.numeric(str_extract(oldTable$lg$lgt[[i]]$name,"\\d+"))
			oldTable$lg$lgt[[i]]$label=(q[[IDX]])
		}
	}
	
	if(xrow==0){
		
		newNames=names(oldTable$d)
		newNames[xcol]=entry
		idx=grep("col-label", oldTable$lg$lgt)
		for(i in idx){
			IDX=as.numeric(str_extract(oldTable$lg$lgt[[i]]$name,"\\d+"))
			oldTable$lg$lgt[[i]]$label=(newNames[[IDX]])
		}
	}
	
	return(oldTable)
}