


geom_box <- function (mapping = NULL, data = NULL, stat = "box",
											position = "dodge", outlier.colour = NULL,
											outlier.shape = NULL, outlier.size = NULL,
											notch = FALSE, notchwidth = .5, ci=c(0,.25,.5,.75,1), ...) {
	
	outlier_defaults <- ggplot2:::Geom$find('point')$default_aes()
	
	outlier.colour <- outlier.colour %||% outlier_defaults$colour
	outlier.shape <- outlier.shape %||% outlier_defaults$shape
	outlier.size <- outlier.size %||% outlier_defaults$size
	
	GeomBox$new(mapping = mapping, data = data, stat = stat,
							position = position, outlier.colour = outlier.colour,
							outlier.shape = outlier.shape, outlier.size = outlier.size, notch = notch,
							notchwidth = notchwidth,ci=ci, ...)
}