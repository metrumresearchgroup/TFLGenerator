#' @export
boxInputLong <-
function (inputId, label, value) 
{
	div(class='row',
			div(tags$textarea(id=inputId, row=2, type="text", value, style="min-width:505px;max-width:600px;color: #3377FF; font-size: 11pt"), align = "center")
	)
	
}
