#' @export
jsPrint=function(e) runjs(paste0("console.log('",e,"')"))