#' @title Find the dimensions of a plot
#' @param grob A ggplot
#' @param height height in inches
#' @param shape "squares", "rectangles", or "panel"
#' @export

plotDims <- function(grob,height=NULL,shape=NULL){
  
  grobnm=gsub('[0-9]','',names(grob))
  grobnm=gsub('-','',grobnm,fixed=T)
  
  #default
  dimOut=list(height=height,width=height)
  
  if(grobnm%in%defaultPlot$Shapes$plot){
    if(is.null(shape)) shape=defaultPlot$Shapes$shape[grobnm==defaultPlot$Shapes$plot]
    if(is.null(height)) height=defaultPlot$Ratio$height[defaultPlot$Ratio$shape==shape]
    
    #c('squares','rectangles','panel')
    if(shape%in%defaultPlot$Ratio$shape) dimOut=list(height=height,width=defaultPlot$Ratio$scale[defaultPlot$Ratio$shape==shape]*height)
  }
  
  #listing,table, input figure
  if(grepl("Tab|inputFigure|inputListing[[:digit:]]",grobnm)){
    if(!grepl("Exclusions",grobnm)){
      htwdth <- .identify(grob[[1]]$Plot)
      ratio <- as.numeric(htwdth["height"]) / as.numeric(htwdth["width"])
      heighti <- htwdth["height"]
      widthi <- htwdth["width"]
      if(heighti > 700){
        heighti <- 700; widthi <- heighti / ratio
      }
      if(widthi > 600){
        widthi <- 600; heighti <- widthi * ratio
      }
      dimOut=list(height=heighti/100, width=widthi/100)
    }
  }
  
  return(dimOut)
}