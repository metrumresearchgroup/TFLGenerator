#' @title VPC plot
#' @description Plot a VPC, allowing for prediction correction as well as a 
#' variety of types
#' @param datFile data, typically output from a NONMEM simulation run
#' @param yByObs Column of \code{datFile} corresponding to the observed DV
#' @param predVar \code{datFile} column holding the fully conditional prediction
#' @param xBy x variable for VPC
#' @param xLimit limits of x (x1,x2 or x1-x2)
#' @param yLimit limits of y (y1,y2, or y1-y2)
#' @param xScale "identity", "log", "log10"
#' @param minorTicks logical; plot minor ticks?
#' @param minorTickNum number of minor ticks per major
#' @param Title title
#' @param xLab label for x axis
#' @param ylab label for y axis 
#' @param PI prediction interval quantiles
#' @param ci confidence around the prediction intervals
#' @param PIns prediction interval quantiles when using "no shading" for shading type
#' @param ciPM confidence interval when using predicted median CI for shading
#' @param includeCI plot with shading?
#' @param facetBy column on which to facet by
#' @param fF factor releveling, e.g. for GENDER "0,Female;1,Male"
#' @param fscales passed to scales in ggplot2:::facet_wrap
#' @param doseCol column holding dosing information, used if dose correcting
#' @param doseCor should we dose correct?
#' @param predCol column containing population prediction column
#' @param predCor correct for pop pred?
#' @param lowerBound lower bound for y axis
#' @param simCol column holding the simulation replicate number
#' @param smoothed ignored
#' @param binned logical; bin the x axis?
#' @param binBy either a single numeric value on which to split the x axis by, or 
#' a comma separated vector of bin cutpoints (e.g., 0,7,14,28,56)
#' @param shadingType "predicted median", "simulated percentiles", or "no shading"
#' @param shadingTypeShape "Each Percentile".. or not
#' @export

VPC <-
  function(datFile, yByObs="DVobs", predVar="DV", xBy="TAFD",
           markBy="",
           xLimit=NULL, yLimit=NULL,
           xForm=waiver(), yForm=waiver(),
           xScale="identity", yScale="log10", 
           minorTicks=FALSE,
           minorTickNum=10,
           Title="", xLab="Time", yLab="PK Concentration",
           PI=c(0.1, 0.5, 0.9), 
           ci=0.95, 
           PIns=c(0.1, 0.5, 0.9), 
           ciPM=0.95, 
           includeCI=FALSE,
           facetBy="", fF="",fnrow=NULL,fscales="fixed",
           doseCol="DOSE", doseCor=FALSE,
           predCol="PRED", predCor=FALSE, lowerBound=0,
           simCol=NULL,
           smoothed=TRUE, binned=TRUE, binBy=7,
           smoothLevel=.8, tryFormula="y~x",
           BQLlevel=10, BQLmethod="retain",
           shadingType="simulated percentiles",
           shadingTypeShape="Each Percentile",
           showObs=T,
           label="", includeAddl_pts=FALSE, includeAddl_trend=FALSE,  addlLabel="",
           themeUpdate=list(),
           themeTextSize=14,
           themePlotTitleSize=1.2,
           themeAxisTxtSize=0.8,
           themeAxisTxtColour='black',
           themeAxisTitleTxtSize=0.9,
           themeAxisTitleColour='black',
           themePanelBackgroundFill='white',
           themePanelGridSize=NULL,
           themePanelGridColour='white',
           themePanelLineType=1,
           themePanelTitleSize=1.2,
           themePlotTitleColour='black',
           themePlotLegendPosition='right',
           ...) 	{
    
    cat(file=stderr(), paste0("LOG: ", Sys.time(), " Running VPC\n"))
    
    # Worker function ----
    VPCfun <- function(){
      # Commented out, using dplyr instead
      # # Set up parallel backend
      # cl <- makeCluster(8)
      # # registerDoParallel(8)
      # registerDoParallel(cl)
      # lp <- installed.packages()["TFL","LibPath"]
      # clusterCall(cl, fun=function(x) .libPaths(lp))
      # on.exit(stopCluster(cl))    
      logTrans <- grepl("log",yScale)
      
      if(addlLabel=="") addlLabel <- NULL
      if(label=="") label <- NULL
      if("addl" %in% names(datFile)){
        if(all(class(datFile$addl)!="try-error")) addl <- as.data.frame(datFile$addl)
      }
      
      if(!(includeAddl_pts|includeAddl_trend)){
        addLabel <- NULL
        addl <- NULL
      }
      
      if("vpc" %in% names(datFile)) datFile <- as.data.frame(datFile$vpc)
      if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
      
      if(facetBy!="" & all(fF!="")){
        datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
        if(!is.null(addl)){
          addl[,facetBy] <- factor(addl[,facetBy],fF[,1],fF[,2])
        }
      }

      if(shadingType=='predicted median') ci=ciPM
      if(shadingType=='no shading') PI=PIns
      
      
      
      if(ci > 1) ci <- as.numeric(ci)/100
      
      BQLlevel <- as.numeric(BQLlevel)
      
      if(tolower(BQLmethod) %in% c("drop")){
        datFile[which(datFile[,yByObs]<=BQLlevel),yByObs] <- NA
        datFile[which(datFile[,predVar]<=BQLlevel),predVar]=NA
        if(predCol %in% names(datFile)) datFile[which(datFile[,predCol]<=BQLlevel),predCol]=NA
        if(!is.null(addl)){
          addl[which(addl[,yByObs]<=BQLlevel),yByObs] <- NA
          if(predCol %in% names(addl)) addl[which(addl[,predCol]<=BQLlevel),predCol]=NA
        }
      }
      
      # if(tolower(BQLmethod) %in% c("none")){
      #   datFile=datFile[which(datFile[,yByObs]>=BQLlevel),]
      # }
      
      
      if(doseCor){
        datFile[,yByObs]=datFile[,yByObs]/datFile[,doseCol]
        datFile[,predVar]=datFile[,predVar]/datFile[,doseCol]
        if(predCol %in% names(datFile)) datFile[,predCol]=datFile[,predCol]/datFile[,doseCol]
        if(!is.null(addl)){
          addl[,yByObs]=addl[,yByObs]/addl[,doseCol]
          if(predCol %in% names(addl)) addl[,predCol]=addl[,predCol]/addl[,doseCol]
        }
      }
      
      if(binned){
        if(length(binBy)>1){
          breaks <- binBy
          if(min(datFile[,xBy])<min(breaks)) breaks <- c(min(datFile[,xBy]),breaks)
          if(max(datFile[,xBy])>max(breaks)) breaks <- c(breaks,max(datFile[,xBy]))
        }else{
          breaks=seq(0, max(datFile[,xBy])+binBy, by=binBy)
        }
        labels=as.numeric(breaks)
        labels=diff(labels)/2 + labels[-length(labels)]
        # labels=labels[-length(labels)]
        
        datFile[,paste(xBy,"bin", sep="")]=cut(unlist(datFile[,xBy]), breaks=breaks, labels=labels, include.lowest=TRUE )
        datFile[,paste(xBy,"bin", sep="")]=as.numeric(as.character(unlist(datFile[,paste(xBy,"bin", sep="")])))
        
        if(!is.null(addl)){
          if(xBy %in% names(addl)){
            addl[,paste(xBy,"bin", sep="")]=cut(unlist(addl[,xBy]), breaks=breaks, labels=labels, include.lowest=TRUE )
            addl[,paste(xBy,"bin", sep="")]=as.numeric(as.character(unlist(addl[,paste(xBy,"bin", sep="")])))
          }
        }
      }
      
      if(predCor & binned){
        for(item in unique(datFile[,paste(xBy,"bin", sep="")])){
          if(!logTrans){
            datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
              lowerBound+
              (datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]- lowerBound)*
              (
                (mean(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol], na.rm=TRUE)-lowerBound)
                /
                  (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]-lowerBound)
              )
            if(!is.null(addl)){
              if(predCol %in% names(addl)){
                addl[addl[,paste(xBy,"bin", sep="")]==item,yByObs]=
                  lowerBound+
                  (addl[addl[,paste(xBy,"bin", sep="")]==item,yByObs]- lowerBound)*
                  (
                    (mean(addl[addl[,paste(xBy,"bin", sep="")]==item,predCol], na.rm=TRUE)-lowerBound)
                    /
                      (addl[addl[,paste(xBy,"bin", sep="")]==item,predCol]-lowerBound)
                  )
              }else{
                cat(file=stderr(), "LOG: No population prediction column for addl data!\n")
                addl <- NULL
              }
            }
          }
          
          
          
          if(logTrans){
            base <- ifelse(yScale=="log10",10,exp(1))
            datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
              datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar]=
              (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar])+
              (
                log(mean(exp(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]), na.rm=TRUE),base=base)
                /
                  datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]
              )
            if(!is.null(addl)){
              if(predCol%in%names(addl)){
                datFile[datFile[,paste(xBy,"bin", sep="")]==item,yByObs]=
                  datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar]=
                  (datFile[datFile[,paste(xBy,"bin", sep="")]==item,predVar])+
                  (
                    log(mean(exp(datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]), na.rm=TRUE),base=base)
                    /
                      datFile[datFile[,paste(xBy,"bin", sep="")]==item,predCol]
                  )
              }else{
                cat(file=stderr(), "LOG: No population prediction column for addl data!\n")
                addl <- NULL
              }
            }
          }
        }	
      }
      
      if(markBy=="") markBy <- NULL
      groupBy=unique(c(facetBy,markBy,xBy, simCol))
      if(binned){groupBy=unique(c(facetBy,markBy,paste(xBy,"bin", sep=""), simCol))}
      groupBy=groupBy[nchar(groupBy)>0]
      
      
      
      #Create a Summary Table of observed including a loess smooth model
      fooSum=vpcSE(data=datFile[datFile[,simCol]==1,], xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy),  measurevar=yByObs, groupvars=groupBy,
                   na.rm=TRUE, pred.interval=PI/100, ci=ci,.drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                   simCol=simCol, shadingType=shadingType,
                   smoothed=smoothed, smoothLevel=smoothLevel)
      fooSum[,simCol] <- NULL
      

      #Create a Summary Table of the sim data including a loess smooth model
      fooSumPred=vpcSE(data=datFile, xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy), measurevar=predVar, groupvars=groupBy,
                       na.rm=TRUE, pred.interval=PI/100, ci=ci, .drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                       simCol=simCol, shadingType=shadingType,
                       smoothed=smoothed, smoothLevel=smoothLevel)
      
      foo=merge(fooSum, fooSumPred, all=TRUE)
      #test=merge(datFile, foo)
      
      if(!is.null(addl)){
        if(simCol %nin% names(addl)) addl[,simCol] <- 1
        fooSumaddl=vpcSE(data=addl[addl[,simCol]==1,],xBy=ifelse(binned,paste(xBy,"bin", sep=""), xBy),  measurevar=yByObs,
                         groupvars=setdiff(groupBy,simCol),
                         na.rm=TRUE, pred.interval=PI/100, ci=ci,.drop=TRUE, includeCI=includeCI, tryFormula=tryFormula,
                         simCol=simCol, shadingType=shadingType,
                         smoothed=smoothed, smoothLevel=smoothLevel)
        fooSumaddl[,"N"] <- NULL
        fooSumaddl <- melt(as.data.frame(fooSumaddl), id.vars=setdiff(groupBy,simCol))
        fooSumaddl$op <- "observed"
        fooSumaddl$lab <- ifelse(is.null(addlLabel), "additional", addlLabel)
      }
      
      obs <- datFile[datFile[,simCol]==min(datFile[,simCol]),]
      these <- c(xBy,groupBy,yByObs)[c(xBy,groupBy,yByObs) %in% names(obs)]
      obs <- obs[,these]
      obs <- melt(obs, id.vars=setdiff(these,yByObs))
      obs[,simCol] <- NULL
      
      if(!is.null(addl)){
        these <- which(names(addl) %in% c(xBy,groupBy,yByObs))
        addl <- addl[,these]
        addl <- melt(addl, id.vars=setdiff(names(addl),yByObs))
        addl$op <- "observed"
        addl$lab <- ifelse(is.null(addlLabel), "additional", addlLabel)
      }
      
      summ <- foo[,c(setdiff(groupBy,simCol),
                     setdiff(grep(paste0("^",predVar),names(foo),value=T),
                             c(predVar)
                     ))]
      summ <- melt(summ, id.vars=setdiff(groupBy,simCol))
      summ$op <- ifelse(grepl(paste0("^",yByObs),summ$variable),"observed","predicted")
      
      #Add in better ticks if the scale is log10
      if (logTrans){
        obs <- obs[ !is.na(obs$value), ]
        obs <- obs[ obs$value>0, ]
        summ <- summ[ summ$value>0, ]
        if(!is.null(addl)){
          addl <- addl[ !is.na(addl$value), ]
          addl <- addl[ addl$value>0, ]
        }
      }
      obs$op <- "observed"
      obs$lab <- ifelse(is.null(label), "original", label)
      summ$lab <- ifelse(is.null(label), "original", label)
      
      if(length(unique(summ[,markBy]))>1){
        obs$lab <- sprintf("%s (%s=%s)",obs$lab,markBy,as.character(obs[,markBy]))
        summ$lab <- sprintf("%s (%s=%s)",summ$lab,markBy,as.character(summ[,markBy]))
        if(!is.null(addl)){
            fooSumaddl$lab <- sprintf("%s (%s=%s)",fooSumaddl$lab,markBy,as.character(fooSumaddl[,markBy]))
        }
      }
      
      summ$variable <- gsub(paste0("^",yByObs,"q"),"",summ$variable)
      summ$variable <- gsub(paste0("^",predVar,"q"),"",summ$variable)
      summ <- cast(summ)
      if(!is.null(addl)){
        fooSumaddl$variable <- gsub(paste0("^",yByObs,"q"),"",fooSumaddl$variable)
        fooSumaddl$variable <- gsub(paste0("^",predVar,"q"),"",fooSumaddl$variable)
        addlSum <- cast(fooSumaddl)
      }
      
      
      
      summ1=summ%>%melt(.id=1:(which(names(summ)=="HighHigh")-1))%>%filter(!is.na(value))%>%dplyr::rename(summ.val=value,summ.var=variable)
      summ2=summ1%>%dplyr::select(summ.var)%>%distinct()
      summ2$idx2=unlist(lapply(gregexpr('[A-Z]',summ2$summ.var),function(x) as.numeric(x)[2]-1))
      summ2$RibbonType=substr(summ2$summ.var,start = 1,stop=summ2$idx2)
      summ2$RibbonVal=substr(summ2$summ.var,start=summ2$idx2+1,stop = 10)
      
      summ3=summ1%>%left_join(summ2%>%dplyr::select(-idx2),by=c('summ.var'))
      
      obs1=obs%>%dplyr::rename(yobs=value)
      
      eqRibb=as.formula(paste(paste0(names(summ3)[names(summ3)%nin%c('summ.var','summ.val','RibbonVal')],collapse='+'),'RibbonVal',sep="~"))
      eqRibbBetween=as.formula(paste(paste0(names(summ3)[names(summ3)%nin%c('RibbonType','summ.val','RibbonVal','summ.var')],collapse='+'),'summ.var',sep="~"))
      
     
      ribb=summ3%>%filter(op=='predicted')%>%
        reshape2:::dcast(eqRibb,value.var = 'summ.val')%>%
        dplyr::rename(variable=RibbonType,ymax=High,ymin=Low,ymid=Mid)
      
      ribbBetween=summ3%>%filter(op=='predicted'&summ.var%in%c('HighLow','LowHigh'))%>%
        reshape2:::dcast(eqRibbBetween,value.var = 'summ.val')%>%
        dplyr::rename(ymin=HighLow,ymax=LowHigh)%>%mutate(variable='1')
      
      pts=summ3%>%filter(RibbonVal=='Mid')%>%dplyr::select(-c(RibbonVal,summ.var))%>%
        dplyr::rename(variable=RibbonType,y=summ.val)
      
      
      if(shadingTypeShape=="Each Percentile"){
        df=bind_rows(list(obs1,ribb,pts))
      }else{
        df=bind_rows(list(obs1,ribbBetween,pts)) 
      }
      
      if(!is.null(addl)){
        if(includeAddl_pts){
          addlPts=addl%>%dplyr::rename(yADDPts=value)%>%mutate(variable='DVobsExtra')%>%dplyr::select(-c(IREP,TAFD))
          df=bind_rows(list(df,addlPts))
        } 
        if(includeAddl_trend){
          addlTrend=addlSum%>%dplyr::rename(yADDTrend=MidMid)%>%mutate(variable='DVobsExtra')%>%dplyr::select(-c(HighMid,LowMid))
          df=bind_rows(list(df,addlTrend))
        } 
      }
      
      
      
      
      
      df$op=factor(df$op,levels=c("predicted",'observed'))
      
      
      
      
      if(!binned){
        p1=
          ggplot(data=df,aes_string(x=xBy))	
      }
      
      if(binned){
        p1=ggplot(data=df, aes_string(x=paste(xBy,"bin", sep="")))
      }
      
      p1=p1+
        #cleanScales +
        scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
        scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+	
        coord_cartesian(xlim = xLimit, ylim = yLimit)+
        labs(title=Title, x=xLab, y=yLab)
      
        aesLine=aes(y=y,colour=lab)
        aesPoint=aes(y=yobs,colour=lab)
        aesRibbon=aes(ymin=ymin,ymax=ymax,fill=lab)
        scaleCol=scale_colour_discrete(name="Observed")
        scaleShape=scale_shape_discrete(name="Observed")
        scaleLine=scale_linetype_discrete(name="Observed")
        scaleFill=scale_fill_discrete(name="Predicted")

# Simulated percentiles ----
      if(shadingType=="simulated percentiles"){
        
        # Observed ---
        p1=p1+df%>%filter(!is.na(y)&op=='observed')%>%dlply(.(variable),.fun=function(x) geom_line(data=x,aesLine,linetype=2))
        
        if(showObs){
          p1=p1+df%>%filter(!is.na(yobs))%>%dlply(.(variable),.fun=function(x) geom_point(data=x,aesPoint, alpha=.5))
        }
        
        # Predicted ---
        p1=p1+df%>%filter(!is.na(ymin))%>%dlply(.(variable),.fun=function(x) geom_ribbon(data=x,aesRibbon,alpha=.2))
        

        
      }
      
# No shading ----
      if(shadingType=="no shading"){
        scaleLine=scale_linetype_discrete(name="LineType")
        # Observed ---
        p1=p1+df%>%filter(!is.na(y))%>%dlply(.(variable),.fun=function(x) geom_line(data=x,aes(y=y,colour=lab,linetype=op)))
        
        
        if(showObs){
          p1=p1+df%>%filter(!is.na(yobs))%>%dlply(.(variable),.fun=function(x) geom_point(data=x,aes(y=yobs, color=lab),shape=1, alpha=.5))
        }
       
        # Predicted ---
        p1=p1+df%>%filter(!is.na(ymid))%>%dlply(.(variable),.fun=function(x) geom_line(data=x,aes(y=ymid,colour=lab,linetype=op)))
         
      } 
        

      

#Observed and predicted median ----
      
      if(shadingType=="predicted median"){
        
        scaleFill=scale_fill_discrete(name=paste0(round(ci*100,2),"% Conf Interval"))
        scaleCol=scale_colour_discrete(name=" ")
# Observed ---
        p1=p1+df%>%filter(!is.na(ymid)&variable=='Mid')%>%dlply(.(variable),.fun=function(x) geom_line(data=x,aes(y=ymid, color=lab),linetype=1))
        
        if(showObs){
          p1=p1+df%>%filter(!is.na(yobs))%>%dlply(.(variable),.fun=function(x) geom_point(data=x,aesPoint,alpha=0.5,shape=1))
        }
# Predicted ---
        p1=p1+df%>%filter(!is.na(ymid)&variable=='Mid')%>%dlply(.(variable),.fun=function(x) geom_ribbon(data=x,aesRibbon, alpha=0.3))

        }

      # Additional ----
      if(!is.null(addl)){
        if(includeAddl_pts) p1=p1+df%>%filter(!is.na(yADDPts))%>%dlply(.(variable),.fun=function(x) geom_point(data=x,aes(y=yADDPts, color=lab),shape=1, alpha=.5))
        if(includeAddl_trend) p1=p1+df%>%filter(!is.na(yADDTrend))%>%dlply(.(variable),.fun=function(x) geom_line(data=x,aes(y=yADDTrend, color=lab),linetype=2))
      }
    
      p1=p1+scaleCol+scaleFill+scaleLine+scaleShape

      if (minorTicks) p1=p1%>%addMinorTicks(xScale,yScale,xForm,yForm,xLimit,yLimit,minorTickNum)
      
      #Add in the faceting if it exists
      if (facetBy!=""){
        p1=p1 +facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,scales=fscales)
      }
      
      
      rel=ggplot2:::rel
      themeUpdate=theme(text=              element_text(size=themeTextSize),
                        axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                        axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                        plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                        panel.background = element_rect(fill = themePanelBackgroundFill),
                        legend.title = theme_bw()$legend.title,
                        panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
                        legend.position =  themePlotLegendPosition
      )
      p1=p1+cleanTheme+themeUpdate
      # +guides(fill=guide_legend(title=""), 
      #                                     colour=guide_legend(title=""), 
      #                                     shape=guide_legend(title=""))
      
      return(p1)
    }
    
    # With progress protection ----
    funframe <- environment()    
    ## Run either withProgress (in shiny) or not (from "naked" R)
    test <- tryCatch(
      withProgress(message="Running",{
        p1 <- VPCfun()
        assign("p",p1,envir=funframe)
      }),
      error=function(e){
        p1 <- arrangeGrob(textGrob(sprintf("You broke something\n%s", e)))
        assign("funerror", e, envir=funframe)
        assign("p", p1, envir=funframe)
      }
    )
    
    if(exists("funerror",envir=funframe)){
      if(grepl("not a ShinySession", funerror)){
        p1 <- VPCfun()
        assign("p",p1,envir=funframe)
      }
    }
    
    return(list(pList=list(p),plotRows=1,plotCols=1))
    
  }

