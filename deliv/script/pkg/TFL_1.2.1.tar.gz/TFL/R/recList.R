#' @export
recList <- function(len){
  if(length(len) == 1){
    v=replicate(len,list())
    v
  } else {
    lapply(1:len[1], function(...) rec.list(len[-1]))
  }
}