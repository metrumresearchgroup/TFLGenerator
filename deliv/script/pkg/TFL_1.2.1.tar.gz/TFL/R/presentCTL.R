#' @title Parses the CTL from Nonmem 
#' @description Simplified version of stripXML(), does not require proper control stream documentation
#' @usage presentXML(run, type = "covariance_information", project = getwd(), visualize = FALSE)
#' @param run character run number
#' @param type character indicating the type of information to be accessed
#' @param project string indicating home directory of the Nonmem Run defaults to the current working directory
#' @details type can be: 
#' "parallel_est"                  "table_series"             "estimation_method"              "estimation_title" 
#' "monitor"            "termination_status"       "termination_information"                        "etabar" 
#'  "etabarse"                    "etabarpval"                     "etashrink"                     "epsshrink" 
#' "estimation_elapsed_time"        "covariance_information"             "covariance_status"       "covariance_elapsed_time" 
#' "final_objective_function_text"      "final_objective_function"                         "theta"                         "omega" 
#' "sigma"                        "omegac"                        "sigmac"                       "thetase" 
#' "omegase"                       "sigmase"                      "omegacse"                      "sigmacse" 
#' "covariance"                   "correlation"                 "invcovariance"                   "eigenvalues" 
#' @return Output returns a data.frame 
#' @export

presentCTL=function(run, type="theta", project=getwd()){	
	require(XML)
	require(Hmisc)
	require(gridExtra)
	require(stringr)
	
	readIn=xmlTreeParse(sprintf("%s/%s/%s.xml", project, run, run), useInternalNodes=FALSE)
	readIn=readIn$doc$children[["output"]]
	
	
	#set up ctl
	ctl=xmlValue(readIn[["control_stream"]])
	ctl=unlist(ctl)
	ctl=unlist(str_split(ctl, "[$]"))
	idx=grep(paste("^", toupper(type),sep=""), ctl)
	if(length(idx)==0 & type!="PRE"){
		
		return(sprintf("%s is not available option", type))
		
	}
	
	if(length(idx)>0){
		foo=ctl[idx]
		foo=gsub(toupper(type), "", foo)
	}
	
	if(length(idx)==0 & type=="PRE"){
		idx=grep("^PROB", ctl)
		idx=c(1:(idx-1))
		if(length(idx)>0){foo=ctl[idx]
		}else(foo="")
	}
	
	return(foo)
}