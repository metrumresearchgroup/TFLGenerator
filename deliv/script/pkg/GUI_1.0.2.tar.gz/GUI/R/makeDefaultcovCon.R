makeDefaultcovCon <-
function(title, Defaults){																
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	Defaults[[paste("groupP", title, sep="")]]=FALSE	
	Defaults[[paste("facetBy", title, sep="")]]=""
	Defaults[[paste("facetFact", title, sep="")]]=""
	Defaults[[paste("fdeets", title, sep="")]]=FALSE
	Defaults[[paste('fnrow',title,sep="")]]=""
	Defaults[[paste('fncol',title,sep="")]]=""
	Defaults[[paste("fscales",title,sep="")]]="fixed"
	Defaults[[paste("strat", title, sep="")]]=""
	Defaults[[paste("reorg", title, sep="")]]=FALSE
	Defaults[[paste("plotdeets", title, sep="")]]=FALSE
	Defaults[[paste("corstat",title,sep="")]]="R2"
	
	Defaults[[paste("conList_x", title, sep="")]]="AGE;Age (years)\nWGTB;Weight (kg)"
	Defaults[[paste("conList_y", title, sep="")]]="ETA1;Eta (Cl)"
	Defaults[[paste("nCols", title, sep="")]]=2
	Defaults[[paste("Xlim", title, sep="")]]=""
	Defaults[[paste("xForm", title, sep="")]]="none"
	Defaults[[paste("xScale", title, sep="")]]="identity"
	Defaults[[paste("Ylim", title, sep="")]]=""
	Defaults[[paste("yForm", title, sep="")]]="none"
	Defaults[[paste("yScale", title, sep="")]]="identity"
	
	Defaults[[paste("DataLim", title, sep="")]]=""
	Defaults[[paste("Trans", title, sep="")]]=""
	Defaults[[paste("AES", title, sep="")]]=FALSE					
	Defaults[[paste("LegendTitle", title, sep="")]]="Relationship between <y variable(s)> and Covariates <x variable(s)>"
	Defaults[[paste("Legend", title, sep="")]]="Caption"
		Defaults[[paste("Footnote", title, sep="")]]="Footnote"
	Defaults[[paste("reset", title, sep="")]]=FALSE
	return(Defaults)	
}
