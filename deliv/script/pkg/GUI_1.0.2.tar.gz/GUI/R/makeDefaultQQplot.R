makeDefaultQQplot <-
function(title, Defaults){																
	Defaults[[paste("priorExists", title, sep="")]]=TRUE #This prevents resetting of defaults
	Defaults[[paste("groupP", title, sep="")]]=FALSE					
	Defaults[[paste("group", title, sep="")]]=NULL
	Defaults[[paste("markBy", title, sep="")]]=""				 
	Defaults[[paste("markByAdd", title, sep="")]]=""
	Defaults[[paste("facetBy", title, sep="")]]=""
	Defaults[[paste("facetFact", title, sep="")]]=""
	Defaults[[paste("fdeets", title, sep="")]]=FALSE
	Defaults[[paste('fnrow',title,sep="")]]=""
	Defaults[[paste('fncol',title,sep="")]]=""
	Defaults[[paste("fscales",title,sep="")]]="fixed"
	Defaults[[paste("strat", title, sep="")]]=""
	Defaults[[paste("reorg", title, sep="")]]=FALSE
	Defaults[[paste("plotdeets", title, sep="")]]=FALSE
	Defaults[[paste("Title", title, sep="")]]="Eta 1"
	Defaults[[paste("Xtit", title, sep="")]]="Quantile of standard normal"
	Defaults[[paste("Ytit", title, sep="")]]="Eta 1"
	Defaults[[paste("Xlim", title, sep="")]]=""
	Defaults[[paste("Ylim", title, sep="")]]=""
	Defaults[[paste("xForm", title, sep="")]]="comma"
	Defaults[[paste("xScale", title, sep="")]]="identity"
	Defaults[[paste("yForm", title, sep="")]]="comma"
	Defaults[[paste("yScale", title, sep="")]]="identity"
	Defaults[[paste("DataLim", title, sep="")]]=""
	Defaults[[paste("Trans", title, sep="")]]=""
	Defaults[[paste("AES", title, sep="")]]=FALSE	
	Defaults[[paste("xBy", title, sep="")]]="ETA1"						
	Defaults[[paste("LegendTitle", title, sep="")]]="Quantile-quantile Plots of <random effect>"
	Defaults[[paste("Legend", title, sep="")]]="Caption"
		Defaults[[paste("Footnote", title, sep="")]]="Distribution of <random effect> is compared to the standard normal distibution."
	Defaults[[paste("reset", title, sep="")]]=FALSE
	return(Defaults)
	
}
