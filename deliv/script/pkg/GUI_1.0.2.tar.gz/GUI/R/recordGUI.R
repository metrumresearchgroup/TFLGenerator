recordGUI <-
function(doWhat, toWhat, input, item, number, manipArgs=list(), currentWD,grob,ordering=NULL,
         pkgDir="/data/tflgenerator/script/pkg"){
	newDir=sprintf("%s/%s_%s/", currentWD, gsub("[[:space:]]|\\.", "_", input$projectTitle), Sys.Date())
	fileHead=sprintf("%s%s_%s", newDir, input$saveAs, Sys.Date())
	grobTitle=paste(fileHead, "_Grobs.rda", sep="")
	fileTitle=paste(fileHead, "_Script.R", sep="")
	
	pngFolder=paste(newDir, "PNG/", sep="")
	dir.create(paste(newDir, "PNG/", sep=""), showWarnings=FALSE)
	
	
	
	#This section readies a file for input of function calls
	if(!file.exists(newDir)){
	  dir.create(newDir)}
	
	if(!file.exists(fileTitle)){
	  
	  #create packages
	  if(file.exists(file.path(pkgDir,"PACKAGES"))){
	    file.copy(from=pkgDir, to=newDir, recursive=TRUE)
	    file.copy(from=file.path(dirname(pkgDir),"pkgSetup.R"),to=newDir)
	  }
	  
	  # Get the versions of TFL and GUI
	  guiv <- sessionInfo()$other[["GUI"]]$Version
	  tflv <- sessionInfo()$other[["TFL"]]$Version
	  
	  #create the *R script
	  foo <- "#Use pkgSetup.R to install the pkg repository into ./lib\n\n"
	  foo=c(foo, paste("#Project~", input$projectTitle), 
	        sprintf("#R Script Recorded from GUI\n#on %s\n#%s\n\n\n#For Help with active grobs see:
																													\n#?indexGrobs\n#?revealGrobs\n#?loadGrobs\n", as.character(Sys.Date()), input$projectInfo))
	  foo <- c(foo, 
	           "#--------------------------------------\n",
	           sprintf("# GUI version: %s\n# TFL version: %s\n\n",guiv,tflv))
	  write(foo, file=fileTitle, append=FALSE)
	  
	  
		#write in the initial parameters
		foo=c("\n########\n#Initial Global Parameters\n",
					sprintf("#Project Directory\nprojDir='%s'",newDir),
					"#Create Directory (no warning if directory exists)\ndir.create(projDir, showWarnings=FALSE)",
					sprintf("\n#Project File Header\nprojHead='%s'",fileHead),
					sprintf("\n#Grob File\ngrobFile='%s'",grobTitle)
		)
		write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		
		#load libraries
		foo=c(
		  'Sys.setenv(PATH=paste0(Sys.getenv("PATH"),":/usr/bin")) # Need imagemagick (in /usr/bin)\n',
		  ".libPaths('lib')\n",
		  "library(GUI)\n",
		  "library(TFL)\n" ,
		  "library(ggplot2)\n",
		  "library(gridExtra)\n",
		  "library(grid)\n",
		  "library(DT)\n",
		  "library(animation)\n",
		  "library(dplyr)\n",
		  "library(gtools)\n\n"
		)
		write(foo,file=fileTitle, Sys.Date(), append=TRUE)
		
		foo=sprintf("\n#PNG Folder\npngFolder='%s'",pngFolder)
		write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		
		#write in color pallete
		
		#if(input$Color){
			foo=sprintf("\n#Color Pallette, shapes and lines for Plotting\ncleanScales=setColorScale()")
			write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		#}
		
		# if(!input$Color){
		# 	foo=sprintf("\n#Black and White Pallette, shapes and lines for Plotting\ncleanScales=setGrayScale()")
		# 	write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		# }
		
		# write arguments
		foo=c("\n########\n#Current working directory\n",
		      sprintf("currentWD <- '%s'", currentWD)
		)
		write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		      
		
		# write in the initial tabFile

		extensions=unlist(str_split(input$ext, ','))
		extensions=gsub('[[:space:]]*', '', extensions)
		extensions=unlist(str_split(input$ext, ','))
		extensions=gsub('[[:space:]]*', '', extensions)
		runs=input$runno
		runs=unlist(str_split(input$runno, ","))
		runs=gsub("[[:space:]]*", "", runs)
		foo <- list()
		foo <- c(foo, sprintf('tabledat=matrix()\n'))
		for(irun in runs) {
		  for(iext in extensions){
		    ext=iext
		    fileName=sprintf("%s/%s/%s%s", currentWD, irun, irun, ext)
		    foo <- c(foo, 
		             sprintf('foo <- read.table("%s", header=%s, skip=%s, stringsAsFactors=F, fill=TRUE)\n', fileName, input$header, input$skipLines),
		             sprintf('foo$Run=%s\n',irun),
		             sprintf('tabledat=merge(tabledat, foo, all=TRUE)\n'),
		             sprintf('tabledat=tabledat[rowSums(is.na(tabledat)) != ncol(tabledat),]\n'),
		             sprintf('tabledat$V1=NULL\n')
		    )
		  }	
		}      

		foo <- c(foo, sprintf('tabledat=data.frame(tabledat, stringsAsFactors=F)\n'))
		parsecommands <- cleanparse(input[["dataParse_table"]],"tabledat")
		if(!is.null(parsecommands)){
		  for(i in 1:length(parsecommands$commands)){
		    if(parsecommands$within[i]) foo <- c(foo, paste0("tabledat <- within(tabledat, {", parsecommands$commands[i], "})\n"))
		    if(!parsecommands$within[i]) foo <- c(foo, paste0("tabledat <- ", parsecommands$commands[i],"\n"))
		  }
		}		
		write(unlist(foo), file=fileTitle, Sys.Date(), append=TRUE)
		
		#write in the initial sourceFile
		foo <- list()
		if(input$srcData %nin% c("", " ", "sourcedata.csv")){
		  srcDatFile=sprintf("%s/%s", currentWD, input$srcData)
		  foo <- c(foo, 
		           sprintf('srcdat=as.best(read.csv("%s", stringsAsFactors=F, fill=TRUE))\n', srcDatFile),
		           sprintf('srcdat=srcdat[rowSums(is.na(srcdat)) != ncol(srcdat),]\n'),
		           sprintf('srcdat=data.frame(srcdat, stringsAsFactors=F)\n')
		  )
		}
		
		parsecommands <- cleanparse(input[["dataParse_source"]],"srcdat")
		if(!is.null(parsecommands)){
		  for(i in 1:length(parsecommands$commands)){
		    if(parsecommands$within[i]) foo <- c(foo, paste0("srcdat <- within(srcdat, {", parsecommands$commands[i], "})\n"))
		    if(!parsecommands$within[i]) paste0("srcdat <- ", parsecommands$commands[i], "\n")
		  }
		}
		
		write(unlist(foo), file=fileTitle, Sys.Date(), append=TRUE)
		

		#merge to get the analysis file
		foo <- list()
		foo <- c(foo,
		         sprintf('if(exists("tabledat") & exists("srcdat")){ \n dat <- merge(srcdat, tabledat, all=TRUE) \n }else { \n if(exists("tabledat")) dat <- tabledat else dat <- srcdat \n }\n\n')
		)

		if("DVCol" %in% names(input)) foo <- c(foo, sprintf('names(dat)[which(names(dat)=="%s")]= "DV"\n',as.character(input[["DVCol"]])))
		if("TAFDCol" %in% names(input)) foo <- c(foo, sprintf('names(dat)[which(names(dat)=="%s")]="TAFD"\n', as.character(input[["TAFDCol"]])))
		if("NMIDCol" %in% names(input)) foo <- c(foo, sprintf('names(dat)[which(names(dat)=="%s")]="NMID"\n',as.character(input[["NMIDCol"]])))
		if("STUDYCol" %in% names(input)) foo <- c(foo, sprintf('names(dat)[which(names(dat)=="%s")]="STUDY"\n',as.character(input[["STUDYCol"]])))
		if("IPREDCol" %in% names(input)) foo <- c(foo, sprintf('names(dat)[which(names(dat)=="%s")]="IPRED"\n',as.character(input[["IPREDCol"]])))
		if("PREDCol" %in% names(input)) foo <- c(foo, sprintf('names(dat)[which(names(dat)=="%s")]="PRED"\n',as.character(input[["PREDCol"]])))
		
		foo <- c(foo,
		         paste0('if(all(c("DV","TAFD","NMID")%in%names(dat))){\n'),
		         paste0('\tif("STUDY" %in% names(dat)) dat <- dat[order(dat$STUDY,dat$NMID,dat$TAFD),] else dat <- dat[order(dat$NMID,dat$TAFD),] \n'),
		         paste0('}\n\n\n')
		)
		
		parsecommands <- cleanparse(input[["dataParse_analysis"]],"dat")
		if(!is.null(parsecommands)){
		  for(i in 1:length(parsecommands$commands)){
		    if(parsecommands$within[i]) foo <- c(foo, paste0("dat <- within(dat, {", parsecommands$commands[i], "})\n"))
		    if(!parsecommands$within[i]) foo <- c(foo, paste0("dat <- ", parsecommands$commands[i], "\n"))
		  }
		}

		write(unlist(foo), file=fileTitle, Sys.Date(), append=TRUE)
		
		# Subject exclusions
		if(any(grepl("subjectExclusion[[:digit:]]",names(Defaults)))){
		  foo <- list()
		  defs <- grep("subjectExclusion[[:digit:]]",names(Defaults),value=T)
		  codes <- sapply(defs, function(x) strsplit(Defaults[[x]],"::",fixed=T)[[1]][1])
		  reasons <- sapply(defs, function(x) strsplit(Defaults[[x]],"::",fixed=T)[[1]][2])
		  codes <- codes[!is.na(reasons)]
		  reasons <- reasons[!is.na(reasons)]
		  foo <- c(foo,sprintf('codes <- "%s"\n',codes))
		  foo <- c(foo,sprintf('reasons <- "%s"\n',reasons))
		  foo <- c(foo,sprintf('excldat <- dat[dat[,"%s"] %%in%% codes, ]\n',input[["subjectExclusion_col"]]))
		  
		  # Ensure there are no patients in the excluded dataset left
		  foo <- c(foo, 
		           'if("NMID" %in% names(dat)){\n', 
		           '\tif(c("STUDY" %in% names(dat))){\n', 
		           '\t\tids <- unique(paste(excldat$NMID, excldat$STUDY))\n', 
		           '\t\tsubjectExclusions <- dat[paste(dat$NMID,dat$STUDY)%in%ids,]\n',
		           '\t\tdat <- dat[paste(dat$NMID,dat$STUDY)%nin%ids,]\n',
		           '\t}else{\n',
		           '\t\tids <- unique(paste(excldat$NMID))\n',
		           '\t\tsubjectExclusions <- dat[paste(dat$NMID) %in% ids,]\n',
		           '\t\tdat <- dat[paste(dat$NMID)%nin%ids,]\n',
		           '\t}\n', '}\n\n'
		  )
		  
		  foo <- 
		    c(foo,sprintf('subjectExclusions$excl_reasons <- metrumrg:::map(subjectExclusions[,"%s"],codes, reasons)',input[["subjectExclusion_col"]]))
		  write(unlist(foo), file=fileTitle, Sys.Date(), append=TRUE)
		  
		}
		
		# Observation exclusions
		if(any(grepl("observationExclusion[[:digit:]]",names(Defaults)))){
		  foo <- list()
		  foo=list()
		  defs <- grep("observationExclusion[[:digit:]]",names(Defaults),value=T)
		  codes <- sapply(defs, function(x) strsplit(Defaults[[x]],"::",fixed=T)[[1]][1])
		  reasons <- sapply(defs, function(x) strsplit(Defaults[[x]],"::",fixed=T)[[1]][2])
		  codes <- codes[!is.na(reasons)]
		  reasons <- reasons[!is.na(reasons)]
		  foo <- c(foo,sprintf('codes <- "%s"\n',codes))
		  foo <- c(foo,sprintf('reasons <- "%s"\n',reasons))
		  foo <- c(foo,sprintf('observationExclusions <- dat[dat[,"%s"] %%in%% codes, ]\n',input[["observationExclusion_col"]]))
      foo <- c(foo, sprintf('dat <- dat[dat[,"%s"] %%nin%% codes,]\n',input[["observationExclusion_col"]]))
		  foo <- c(foo, sprintf('observationExclusions$excl_reasons <- metrumrg:::map(observationExclusions[,"%s"],codes, reasons)',input[["observationExclusion_col"]]))
		  write(unlist(foo), file=fileTitle, Sys.Date(), append=TRUE)
		  
		}
	}
	

	#####	#Add in a section for this specific plot
	
	foo=c("\n#########\n" , "#Plotting")
	write(foo, file=fileTitle, Sys.Date(), append=TRUE)	

	#Now input that particular Function
	plotNum=paste(item, number, sep="")
	foo=c("\n##\n#Plot of", plotNum,
				"\n#", 	input[[paste("LegendTitle", str_sub(doWhat,end=-4), number, sep="")]],
				"\n#", 	input[[paste("Legend", str_sub(doWhat,end=-4), number, sep="")]],
				"\n##\n",
				sprintf("plotNum='%s'\n", plotNum)
	)
	write(unlist(foo), file=fileTitle, Sys.Date(), append=TRUE)			
	
	if(length(manipArgs)>0){
		#write in data manipulation if it occurs
	  mkargs <- makeArgs(manipArgs, completeArg=TRUE)
	  mkargs <- gsub("=dataFile","=dat",mkargs,fixed=T)
		foo=sprintf("#Manipulate data by plot specific limitation or transformation\ntempDat=manipDat(%s)\n", mkargs)
		write(foo, file=fileTitle, Sys.Date(), append=TRUE)
		
		toWhat[["datFile"]]="tempDat"
	}
		
	captured <- captureFunSimple(doWhat, plotNum, toWhat, input=input)
	#replaceThese <- c("comma","percent","log10","plain")
	captured <- gsub("xForm='plain'",'xForm=plain',captured,fixed=T)
	captured <- gsub("yForm='plain'",'yForm=plain',captured,fixed=T)
	
	# for(this in replaceThese){
	#   pos <- str_locate_all(captured,sprintf('="%s"',this))[[1]]
	#   posslash <- str_locate_all(captured,sprintf("='%s'",this))[[1]]
	#   if(length(pos)>0) str_sub(captured,pos) <- sprintf("=%s",this)
	#   if(length(posslash)>0) str_sub(captured,posslash) <- sprintf("=%s",this)
	# }

	if(grepl("ConcvTimeMult|Exclusion",plotNum)){
	  pos <- str_locate_all(captured,"tmpDir=NULL")
	  for(i in 1:length(pos)){
	    str_sub(captured,pos[[i]][,'start'],pos[[i]][,'end']) <- sprintf('tmpDir="%s"',pngFolder)
	  }
	}

	foo=ifelse(input$verbose,
	           c(sprintf("#Text for function %s\n\n%s",
	                     doWhat, captured)),
	           c(sprintf("\t\t%s=%s(%s\n\t\t\t\t\t)",plotNum, doWhat, 
	                     makeArgs(toWhat, completeArg=TRUE)))
	)

	write(unlist(foo), file=fileTitle, Sys.Date(), append=TRUE)		


	foo <- list()
	if(doWhat %in% c("demogTabCat","demogTabCont","RNM")){
	  if("Footnote" %in% names(grob)){ 
	    foo <- c(foo,sprintf('Footnote <- "%s"\n',grob$Footnote))
	  }else{
	    foo <- c(foo,sprintf('Footnote <- ""\n'))
	  }
	  foo=c(foo,sprintf('%s <- renderTex(tex,plotNum,tmpDir="%s",footnote=Footnote)\n',plotNum,pngFolder))
	}else if(doWhat %in% c("ConcvTimeMult")){
	    foo <- sprintf("# Files are located here:\n %s$src\n",plotNum)
	}else{
	  foo=c(
	    sprintf("\n\n\tprint(%s)\n", plotNum)
	  )
	  if(doWhat != "inputFile"){
	    foo=c(foo,sprintf("\n#Save the Plot\nsavePlots(%s, directory='%s', saveName='%s')\n",plotNum, 
	                      dirname(pngFolder),plotNum))
	  }
	}
	
	foo <- c(foo, 
	         sprintf('FigureTitle <- "%s"\n',grob$LegendTitle),
	         sprintf('FigureCaption <- "%s"\n',grob$Legend)
	         )

	if(doWhat %nin% c("demogTabCat","demogTabCont","RNM")){
	  if("Footnote" %in% names(grob)){
	    foo <- c(foo, sprintf('Footnote <- "%s"\n',grob$Footnote))
	  }else{
	    foo <- c(foo, 'Footnote <- ""\n')
	  }
	}else{
	  foo <- c(foo, 'Footnote <- ""\n')
	}
	
	foo <- c(foo, sprintf('Type="%s"\n\n',plotList$sidebarType[plotList$type==item]))

	if(doWhat %in% c("RNM","demogTabCat","demogTabCont")){
	  foo <- c(foo,sprintf('Plot <- %s["src"]\n',plotNum))
	}else if(grepl("ConcvTimeMult",doWhat)){
	  foo <- c(foo,sprintf('Plot <- %s[["src"]]\n',plotNum))
	}else if(grepl("Exclusion",doWhat)){
	    foo <- c(foo, sprintf('Plot <- %s\n',plotNum))
	}else if(doWhat == "inputFile"){
	  if("longText" %in% names(grob)){
	    foo <- c(foo, sprintf('longText <- %s$preview\n',plotNum))
	  }else{
	    foo <- c(foo, sprintf('if("src" %%in%% names(%s)) Plot <- %s$src\n',plotNum,plotNum))
	  }
	}else{
	  foo <- c(foo, sprintf('Plot <- %s\n',plotNum))
	}

	foo <- c(foo,sprintf("\n#Update the Grob\nsaveGrob(Plot, Name='%s', file=grobFile, legtit=FigureTitle, leg=FigureCaption, foot=Footnote, type=Type)\n", 
	                       plotNum))
	
	if("longText" %in% names(grob)){
	  foo <- c(foo,  'guiGrobs[["inputListing_text1"]]$longText <- longText')
	}

	write(unlist(foo), file=fileTitle, Sys.Date(), append=TRUE)	


	if(input$RTF){
		#delete all previous RTF writes
		test=readLines(fileTitle)	
		idx=c(grep("#Create an RTF", test), grep("ordering <-",test), grep("writeRTF", test))
		idn=c(1:length(test))[which(c(1:length(test)) %nin% idx)]
		test=test[idn]
		test[length(test)+1]=""
		test[length(test)+1]="#Create an RTF"
		test[length(test)+1]=""
		if(!is.null(ordering)){
		  ordering <- paste0('ordering <- c("', paste(ordering, collapse='" , "'), '")')
		  test[length(test)+1]=ordering
		}else{
		  test[length(test)+1]=sprintf("ordering <- NULL")
		}
		test[length(test)+1]=sprintf("writeRTF('%s',ordering=ordering)",grobTitle)
		writeLines(test, con=fileTitle)
		
	}
	
}
