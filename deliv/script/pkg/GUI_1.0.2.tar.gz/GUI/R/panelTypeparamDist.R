panelTypeparamDist <-
  function(plotType, input, Set=list(), varNames=""){
    
    #All if statements relate to a specific output type, which then add an additional panel
    if(input[[paste(plotType, "Num", sep="")]]>=1){
      
      numbers=as.numeric(unlist(str_extract_all(input[[paste(plotType, "Num", sep="")]], "\\d+")))
      if(length(numbers)>1){numRange=numbers[which(numbers!=0)]}
      if(length(numbers)==1){numRange=c(1:numbers)}
      for (n in numRange){
        
        title=paste(plotType, n, sep="")
        #set originating defaults
        checkPriors(plotType=plotType, input=input, n=n)
        
        nn=length(Set)
        
        Set[[nn+1]]=
          tabPanel(paste(plotType,n, sep="#"),
                   
                   sidebarPanel(
                     actionButton(paste("button", plotType, n, sep=""), "Generate Plot"),
                     
                     checkboxInput(paste("plotdeets", plotType, n, sep=""), "Plots Details", Defaults[[paste("plotdeets", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "plotdeets", plotType, n, sep="")),
                                      wellPanel(numberRow(paste("binWidth", plotType,n,sep=""), "Width of bin", Defaults[[paste("binWidth", title, sep="")]]),
                                                selectizeInput(paste("xCols", plotType, n, sep=""), 
                                                               "Parameters to compare",  
                                                               choices=varNames,
                                                               selected=Defaults[[paste("xCols", title, sep="")]],
                                                               multiple=T),
                                      ),
                     ),
                     
                     checkboxInput(paste("reorg", plotType, n, sep=""), "Manipulate Data", Defaults[[paste("reorg", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "reorg", plotType, n, sep="")),
                                      wellPanel(boxInput(paste("DataLim", title, sep=""), "Limit",  Defaults[[paste("DataLim", title, sep="")]])
                                                # ,
                                                # boxInput(paste("Trans", title, sep=""), "Transform", Defaults[[paste("Trans", title, sep="")]])
                                      )
                     ),	 
                     checkboxInput(paste("reset", plotType, n, sep=""), "Reset to Defaults", FALSE)
                   ),
                   
                   mainPanel(div(align="center",
                                 boxInputLong(paste("LegendTitle", plotType, n, sep=""), "Figure Title", Defaults[[paste("LegendTitle", title, sep="")]]),
                                 plotOutput(paste("Plot", plotType,n,  sep=""), width="600px", height="600px"),
                                 boxInputWide(paste("Legend", plotType, n, sep=""), "Legend Text", Defaults[[paste("Legend", title, sep="")]]),
                                 boxInputLong(paste("Footnote", plotType, n, sep=""), "Footnote", Defaults[[paste("Footnote", title, sep="")]])
                                 
                   ))
                   
          )
        names(Set)[[nn+1]]=paste("Tab", plotType,n,  sep="")
      }
    }
    return(Set)	
  }
