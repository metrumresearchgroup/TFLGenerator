panelTypecovCat <-
  function(plotType, input, Set=list()){
    
    #All if statements relate to a specific output type, which then add an additional panel
    if(input[[paste(plotType, "Num", sep="")]]>=1){
      
      numbers=as.numeric(unlist(str_extract_all(input[[paste(plotType, "Num", sep="")]], "\\d+")))
      if(length(numbers)>1){numRange=numbers[which(numbers!=0)]}
      if(length(numbers)==1){numRange=c(1:numbers)}
      for (n in numRange){
        
        title=paste(plotType, n, sep="")
        #set originating defaults
        checkPriors(plotType=plotType, input=input, n=n)
        
        nn=length(Set)
        
        Set[[nn+1]]=
          tabPanel(paste(plotType,n, sep="#"),
                   
                   sidebarPanel(
                     actionButton(paste("button", plotType, n, sep=""), "Generate Plot"),										 	
                     # checkboxInput(paste("groupP", plotType, n, sep=""), "Group Plots", Defaults[[paste("groupP", title, sep="")]]),
                     # conditionalPanel(condition = (paste("input.", "groupP", plotType, n, sep="")),
                     #                  wellPanel(
                     #                    # textRow(paste("facetBy", plotType, n, sep=""), "Facet by:", Defaults[[paste("facetBy", title, sep="")]]),
                     #                    # textRow(paste("facetFact", plotType, n, sep=""), "Factor Facet:", Defaults[[paste("facetFact", title, sep="")]]),
                     #                    # textRow(paste("strat", plotType, n, sep=""), "Stratify by:", Defaults[[paste("strat", title, sep="")]]),
                     #                  )
                     # ),
                     
                     
                     checkboxInput(paste("plotdeets", plotType, n, sep=""), "Plots Details", Defaults[[paste("plotdeets", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "plotdeets", plotType, n, sep="")),
                                      wellPanel(
                                        textRow(paste("nCols", plotType, n, sep=""), "Number of Columns", Defaults[[paste("nCols", title, sep="")]]),
                                        h2(""),
                                        textRow(paste("Ylim", title, sep=""), "Y Axis Limits",  Defaults[[paste("Ylim", title, sep="")]]),
                                        h2(""),
                                        inputSelect2(paste("yForm", title, sep=""), paste("yScale", title, sep=""), "Format", 
                                                     choices1=c("percent" = "percent",
                                                                "comma" = "comma",
                                                                "none"="none",
                                                                "scientific" = "scientific"
                                                     ),
                                                     choices2=c("none"="identity",
                                                                "log10" = "log10",
                                                                "log" = "log"
                                                     ), 
                                                     selected1=Defaults[[paste("yForm", title, sep="")]],
                                                     selected2=Defaults[[paste("yScale", title, sep="")]]),
                                        h2(""),
                                        checkboxInput(paste("notches",plotType,n,sep=""),"Notched boxplots?",Defaults[[paste("notches",title,sep="")]])
                                        
                                      )
                     ),
                     
                     checkboxInput(paste("AES", plotType, n, sep=""), "Change Defaults",  Defaults[[paste("AES", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "AES", plotType, n, sep="")),
                                      wellPanel( 
                                        boxInput(paste("conList", plotType, n, sep=""), "Continuous Variables", Defaults[[paste("conList", title, sep="")]]),
                                        h2(""),
                                        boxInput(paste("catList", plotType, n, sep=""), "Categorical Variables", Defaults[[paste("catList", title, sep="")]]),
                                        # textRow(paste("xCols", plotType, n, sep=""), "Categorical Parameters",  Defaults[[paste("xCols", title, sep="")]]),
                                        # textRow(paste("yCols", plotType, n, sep=""), "Continuous Parameters", Defaults[[paste("yCols", title, sep="")]]),
                                        h2(""),
                                        textRow(paste("idVar", plotType, n, sep=""), "ID Column", Defaults[[paste("idVar", title, sep="")]])
                                      )
                     ),
                     
                     
                     
                     checkboxInput(paste("reorg", plotType, n, sep=""), "Manipulate Data", Defaults[[paste("reorg", title, sep="")]]),
                     conditionalPanel(condition = (paste("input.", "reorg", plotType, n, sep="")),
                                      wellPanel(boxInput(paste("DataLim", title, sep=""), "Limit",  Defaults[[paste("DataLim", title, sep="")]])
                                                # ,
                                                # boxInput(paste("Trans", title, sep=""), "Transform", Defaults[[paste("Trans", title, sep="")]])
                                      )
                     ),	 
                     checkboxInput(paste("reset", plotType, n, sep=""), "Reset to Defaults", FALSE)
                   ),
                   
                   mainPanel(div(align="center",
                                 textOutput(paste0("generated",plotType,n)),
                                 boxInputLong(paste("LegendTitle", plotType, n, sep=""), "Figure Title", Defaults[[paste("LegendTitle", title, sep="")]]),
                                 plotOutput(paste("Plot", plotType,n,  sep=""), width="600px", height="600px"),
                                 boxInputWide(paste("Legend", plotType, n, sep=""), "Legend Text", Defaults[[paste("Legend", title, sep="")]]),
                                 boxInputLong(paste("Footnote", plotType, n, sep=""), "Footnote", Defaults[[paste("Footnote", title, sep="")]])
                                 
                   ))
                   
          )
        names(Set)[[nn+1]]=paste("Tab", plotType,n,  sep="")
      }
    }
    return(Set)	
  }
