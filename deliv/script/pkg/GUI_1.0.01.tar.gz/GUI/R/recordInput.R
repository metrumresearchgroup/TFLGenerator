recordInput <-
function(input, Defaults, currentWD, autosave=F){
  stem <- ifelse(autosave, '~tfl', input$saveTemplateAs)
	newDir=sprintf("%s/%s_%s/", currentWD, gsub("[[:space:]]|\\.", "_", input$projectTitle), Sys.Date())
	fileHead=sprintf("%s%s_%s",newDir, gsub("[[:space:]]|\\.", "_", stem), Sys.Date())
	inputTitle=paste(fileHead, "_Input_Parameters.R", sep="")
	if(!file.exists(newDir)){
		dir.create(newDir)}
	
	#create the *R script
	foo=c(paste("#Project~", input$projectTitle), sprintf("#Parameter Input Recorded from GUI\n#on %s\n\n", as.character(Sys.Date())))
	write(foo, file=inputTitle, append=FALSE)
	
	#create the first part of the default assignment
	foo=c("Defaults=list(\n\t\t\t\t\t\t\t\t")
	write(foo, file=inputTitle, append=TRUE)
	
	foo=vector()
	for(stuff in names(Defaults)){
		
		this=Defaults[[stuff]]
		this_foo=sprintf("%s=%s", stuff, this)
		if(class(this)=="character"){
		  this <- gsub("\\\\", "\\\\\\\\\\", this)
		  this <- gsub("'","\\'",this,fixed=T)
		  this_foo=sprintf("%s='%s'", stuff, this)
		  }
		foo=c(foo, this_foo)
		
	}
	foo=paste(foo, collapse=",\n\t\t\t\t\t\t\t\t")
	write(foo, file=inputTitle, append=TRUE)
	foo=c(")")
	write(foo, file=inputTitle, append=TRUE)
}


