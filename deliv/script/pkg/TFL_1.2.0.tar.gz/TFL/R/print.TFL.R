#' @title print method for most TFL package generated plots
#' @description arrange pList into plots and columns using the print method
#' @export

print.TFL=function(pList,plotCols=NULL,plotRows=NULL){
  
  numPlots = length(pList)
  if(numPlots==3 & is.null(plotCols) & is.null(plotRows)){
    plotCols <- pList$plotCols
    plotRows <- pList$plotRows
    pList <- pList$pList
    numPlots <- length(pList)
  }
  if(is.null(plotCols)||is.null(plotRows)){
    cols=min(numPlots,2)
    plotCols = cols                      
    plotRows = ceiling(numPlots/plotCols)
  }
  if(numPlots > plotCols*plotRows){
    if(plotCols<plotRows){
      plotCols <- ceiling(numPlots/plotRows)
    }else{
      plotRows <- ceiling(numPlots/plotCols)
    }
  }
  
  grid.newpage()
  pushViewport(viewport(layout = grid.layout(plotRows,plotCols)))
  for (i in 1:numPlots) {
    curRow = ceiling(i/plotCols)
    curCol = (i-1) %% plotCols + 1
    print(pList[[i]], vp = vplayout(curRow, curCol ))
  }
  
}