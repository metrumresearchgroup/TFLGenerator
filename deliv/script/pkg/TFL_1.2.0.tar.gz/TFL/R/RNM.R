#' @title Create a Nonmem run output table from the XML output
#' @description Table includes parameter estimates, variance
#' @usage RNM(Run, Sig = 3, ConfInt = 0.95, View = TRUE, saveCSV = FALSE, saveFig = FALSE, OffDiagonals = TRUE, project = getwd(), height = NULL, width = NULL, unTransform = FALSE)
#' @param Run character vector of run numbers
#' @param Sig numeric significant figures to display in the table
#' @param ConfInt  numeric indicating confidence intervals to display in the table (.95 indicates 95\%)
#' @param View view the output table in the Rstudio interface (logical)
#' @param saveCSV save the output table as a *.csv file within the parent directory
#' @param saveFig the output table as a *.png within the parent directory
#' @param OffDiagonals include the off diagonal values in the table presentation
#' @param project string indicating home directory of the Nonmem Run defaults to the current working directory
#' @param height numeric in inches, indicating the height of *png output
#' @param width numeric in inches, indicating the width of *png output
#' @param unTransform logical indicating whether to revert transformed parameter estimates. Looks for "LOGD" in the title feild, without this defaults to all thetas
#' @param removeFixed - (logical) TRUE will remove all fixed values (nonzero) from the output table
#' @return LaTex table
#' @export

RNM=function(Run, Sig=3, ConfInt=0.95, View=TRUE,saveCSV=FALSE, saveFig=FALSE, OffDiagonals=TRUE, project=getwd(), height=NULL, width=NULL, unTransform=FALSE, removeFixed=FALSE, ...){
  require(metrumrg)
  require(Hmisc)
  require(stringr)
  require(plyr)
  #require(msm)
  
  #set Confidence interval
  CId=as.character(signif(ConfInt*100), digits=2)  
  
  run <- Run[1]
  
  xmlFile=sprintf("%s/%s/%s.xml", project,run,run)
  # does the file exist?  If not, exit.
  if( !file.exists(xmlFile) ) {
    print(sprintf('error! "%s.xml" does not exist.',xmlFile))
    return( NULL )
  }
  
  theta=stripXML(run, "theta", project=project)
  thetase=stripXML(run, "thetase", project=project)
  thetase=plyr:::rename(thetase, c("value"="se"))
  theta=merge(theta, thetase, all=TRUE)	
  theta$Desc <- gsub("%","\\%",theta$Desc,fixed=T)
  theta$Title <- gsub("%","\\%",theta$Title,fixed=T)
  
  
  omega=stripXML(run, "omega", project=project)
  omegase=stripXML(run, "omegase", project=project)
  omegase=plyr:::rename(omegase, c("value"="se"))
  omega=merge(omega, omegase, all=TRUE)	
  omegac=stripXML(run, "omegac", project=project)
  omegac=plyr:::rename(omegac, c("value"="c"))
  omega=merge(omega, omegac, all=TRUE)	
  omegacse=stripXML(run, "omegacse", project=project)
  omegacse=plyr:::rename(omegacse, c("value"="cse"))
  omega=merge(omega, omegacse, all=TRUE)	
  omega$Desc <- gsub("%","\\%",omega$Desc,fixed=T)
  omega$Title <- gsub("%","\\%",omega$Title,fixed=T)
  
  sigma=stripXML(run, "sigma", project=project)
  sigmase=stripXML(run, "sigmase", project=project)
  sigmase=plyr:::rename(sigmase, c("value"="se"))
  sigma=merge(sigma, sigmase, all=TRUE)	
  sigmac=stripXML(run, "sigmac", project=project)
  sigmac=plyr:::rename(sigmac, c("value"="c"))
  sigma=merge(sigma, sigmac, all=TRUE)	
  sigmacse=stripXML(run, "sigmacse", project=project)
  sigmacse=plyr:::rename(sigmacse, c("value"="cse"))
  sigma=merge(sigma, sigmacse, all=TRUE)	
  sigma$Desc <- gsub("%","\\%",sigma$Desc,fixed=T)
  sigma$Title <- gsub("%","\\%",sigma$Title,fixed=T)
  
  all=merge(theta, omega, all=TRUE)
  all=merge(all, sigma, all=TRUE)
  
  
  ciMult=qt(ConfInt/2 + 0.5, Inf) #This generates the ci multiplier 
  
  all$CI=as.numeric(all$se)*ciMult
  
  #Create Confidence Bounds
  all[,paste(CId,"\\% CI\nLower Bound", sep="")]=signif(all$value-all$CI, digits=Sig)
  all[all$FIX==1,paste(CId,"\\% CI\nLower Bound", sep="")]="-"
  all[,paste(CId,"\\% CI\nUpper Bound", sep="")]=signif(all$value+all$CI, digits=Sig)
  all[all$FIX==1,paste(CId,"\\% CI\nUpper Bound", sep="")]="-"
  
  if(unTransform){
    #transform based on description
    transList=c("value", paste(CId,"\\% CI\nLower Bound", sep=""), paste(CId,"\\% CI\nUpper Bound", sep=""))
    idx=grep("LOGD", all$Title)
    if (length(idx)==0){
      idx=grep("theta", all$class)
    }
    if(length(idx>0)){
      all[idx, "se"]=sapply(	idx, function (y){deltamethod(~exp(x1), all[y, "value"], all[y, "se"]^2)})
      all[idx,names(all)%in%transList]=exp(all[idx,names(all)%in%transList])
      all[idx,names(all)%in%c(transList, "se")]=signif(all[idx,names(all)%in%c(transList, "se")], digits=3)
    }
    #remove the LOGD notation
    all$Title=gsub("[[:space:]]*LOGD[[:space:]]*", "", all$Title)
  }
  
  
  all$prse=all$se/all$value*100
  
  all$crse=all$cse/all$c
  
  all$Variability=NA
  
  all$Calc=gsub("[[:space:]]*", "", all$Calc)
  
  all$Variability[which(all$Calc=="P")]="CV %"
  all$value[which(all$Calc=="P")]= all$c[which(all$Calc=="P")]*100
  all$prse[which(all$Calc=="P")]=all$crse[which(all$Calc=="P")]*100

  all[,paste0(CId,"\\% CI\nLower Bound")][which(all$Calc=="P")] <- signif((all$c[which(all$Calc=="P")] - ciMult*all$cse[which(all$Calc=="P")])*100,Sig)
  all[,paste0(CId,"\\% CI\nUpper Bound")][which(all$Calc=="P")] <- signif((all$c[which(all$Calc=="P")] + ciMult*all$cse[which(all$Calc=="P")])*100,Sig)
  
  all$Variability[which(all$Calc=="A")] <- "SD"
  all$value[which(all$Calc=="A")] <- all$c[which(all$Calc=="A")]
  all$prse[which(all$Calc=="A")] <- all$crse[which(all$Calc=="A")]*100
  all[,paste0(CId,"\\% CI\nLower Bound")][which(all$Calc=="A")] <- signif(all$c[which(all$Calc=="A")] - ciMult*all$cse[which(all$Calc=="A")],Sig)
  all[,paste0(CId,"\\% CI\nUpper Bound")][which(all$Calc=="A")] <- signif(all$c[which(all$Calc=="A")] + ciMult*all$cse[which(all$Calc=="A")],Sig)
  
  all$Variability[which(all$Calc=="F")]= "r"
  all$value[which(all$Calc=="F")] <- all$c[which(all$Calc=="F")]
  all$prse[which(all$Calc=="F")] <- all$crse[which(all$Calc=="F")]*100
  all[,paste0(CId,"\\% CI\nLower Bound")][which(all$Calc=="F")] <- signif(all$c[which(all$Calc=="F")] - ciMult*all$cse[which(all$Calc=="F")],3)
  all[,paste0(CId,"\\% CI\nUpper Bound")][which(all$Calc=="F")] <- signif(all$c[which(all$Calc=="F")] + ciMult*all$cse[which(all$Calc=="F")],3)
  
  
  all$Calc=NULL
  all$Variability <- gsub("%","\\%",all$Variability,fixed=T)
  
  all[all$FIX==1,paste(CId,"\\% CI\nLower Bound", sep="")]="-"
  all[all$FIX==1,paste(CId,"\\% CI\nUpper Bound", sep="")]="-"
  
  
  Out=all
  #Now reformat make 
  Out$"Final Estimate"=as.character(signif(Out$value, digits=Sig))
  #Out$"Final Estimate"[Out$FIX==1]=paste(	Out$"Final Estimate"[Out$FIX==1], "FIX")
  
  if(is.null(Out$Parameter)) Out$Parameter <- NA
  
  #Create a Nice Parameter
  # Out$Parameter[which(Out$class=="theta")]=
  #       paste(
  #     	Out$Title[which(Out$class=="theta")], " ($\\theta_", Out$type1[which(Out$class=="theta")], "$)", 
  #     	sep="")
  title <- strsplit(Out$Title,"_")
  title <- lapply(title, function(l){
    l[1] <- paste0("\\text{",l[1],"}")
    if(length(l)>1) l <- paste0(l[1],"_",l[-1])
    l
  })
  Out$Title <- unlist(title)
  Out$Parameter[which(Out$class=="theta")]= paste0("$", Out$Title[which(Out$class=="theta")], "$")
  
  # Out$Parameter[which(Out$class!="theta")]=paste(
  # 	Out$Title[which(Out$class!="theta")], 
  # 	" ($\\", Out$class[which(Out$class!="theta")], 
  # 	"_{", Out$type1[which(Out$class!="theta")],",",Out$type2[which(Out$class!="theta")] , "})$", 
  # 	sep="")
  
  Out$Parameter[which(Out$class!="theta")]=paste(
    "$\\", Out$class[which(Out$class!="theta")],
    "_{", Out$Title[which(Out$class!="theta")] , "}$",
    sep="")
  
  for(i in which(Out$Variability=="r")){
    cl <- Out$class[i]
    t1 <- Out$type1[i]
    t2 <- Out$type2[i]
    Out$Parameter[i] <- paste0("$\\text{Cor}_{",
                               Out$Title[Out$type1==t1 & Out$type2==t1 & Out$class==cl],
                               "-",
                               Out$Title[Out$type1==t2 & Out$type2==t2 & Out$class==cl],
                               "}$")
  }
  
  #Create RSE
  Out$"pRSE"=paste(as.character(abs(signif(as.numeric(Out$prse), digits=Sig))), "\\%", sep="")
  Out$"pRSE"[which(Out$"pRSE"=="Inf\\%")]="."
  Out$"pRSE"[Out$FIX==1]="Fixed"
  
  Out$"Notes"=Out$Desc
  Out$"Notes"[Out$Notes==""]=Out$Variability[Out$Notes==""]
  Out$class=as.numeric(factor(Out$class, levels=c("theta", "omega", "sigma")))
  Out$Equal=ifelse(Out$type1==Out$type2, 1, 0)
  Out=Out[order(Out$class, as.numeric(Out$type2), Out$Equal),]
  
  if (OffDiagonals==FALSE) {Out=Out[which(Out$type1==Out$type2),]}
  
  #Insert some blank spaces for the pretties
  blank=rep(c(" REPLACE IIV "), times=dim(Out)[2]) 
  Omega1=grep("omega", Out$Parameter)[1]
  Out=rbind(Out[1:(Omega1-1),],blank, Out[-(1:(Omega1-1)),])
  blank=rep(c(" REPLACE RESERR "), times=dim(Out)[2]) 
  Sigma1=grep("sigma", Out$Parameter)[1]
  Out=rbind(Out[1:(Sigma1-1),],blank, Out[-(1:(Sigma1-1)),])
  
  
  #Remove fixed values if necessary
  if(removeFixed){
    Out=Out[!(Out$FIX==1 & Out$value==0),]
  }
  
  outThese <- c("Parameter","Final Estimate", "pRSE", paste(CId,"\\% CI\nLower Bound", sep=""), paste(CId,"\\% CI\nUpper Bound", sep=""), "Notes","class")
  #pool(outThese,names(Out))
  Out=Out[,outThese]
  
  #replace NAs or 0s
  #Out=data.frame(apply(Out, c(1,2), function(x){ifelse(x==0, "", x)}), stringsAsFactors=FALSE, check.names=FALSE)
  Out=data.frame(apply(Out, c(1,2), function(x){ifelse(is.na(x), "", x)}), stringsAsFactors=FALSE, check.names=FALSE)
  
  #Change all : characters to ~ because it screws up the later files
  Out=data.frame(apply(Out, c(1,2), function(x){gsub(pattern=":", replacement = "~", x)}), stringsAsFactors=FALSE, check.names=FALSE)
  
  #Create a title
  dummyTitle=paste(paste("Nonmem Summary Table for run", run, ifelse(unTransform, "untransformed", "")), 
                   paste( presentXML(run, "estimation_title", project=project), signif(as.numeric(presentXML(run, "final_objective_function", project=project)), digits=6), sep="="),
                   sep=" ")
  #   dummyTable=tableGrob(Out, show.rownames=FALSE, 
  #   										 equal.height=FALSE,gpar.coltext=gpar(fontsize=14),
  #   										 gpar.coretext=gpar(fontsize=12),gpar.corefill = gpar(fill = "white", col = "white"),
  #   										 gpar.rowfill=gpar(fill = "white", col = "white"), gpar.colfill=gpar(fill = "white", col = "white"),
  #   										 separator="black")
  Out <- plyr:::rename(Out, c(`Final Estimate`="Estimate", Notes="Units"))
  Out[,paste0("CI (", CId, "\\%)")] <- 
    paste0( "(", Out[,paste0(CId,"\\% CI\nLower Bound")], ", ",
            Out[,paste0(CId,"\\% CI\nUpper Bound")], ")" )
  Out[,paste0("CI (", CId, "\\%)")][ Out[,paste0("CI (", CId, "\\%)")]=="( ,  )"  ] <- ""
  Out[,paste0("CI (", CId, "\\%)")][ Out[,paste0("CI (", CId, "\\%)")]=="(-, -)"  ] <- "-"
  
  Out <- Out[!grepl("\n",names(Out),fixed=T)]
  Out <- shuffle(Out, who=paste0("CI (", CId, "\\%)"), after="pRSE")
  Outi <- Out
  Outi$grp <- Outi$class 
  Outi$grp[Outi$class>3] <- 4
  Out$pRSE <- gsub("%","",Out$pRSE,fixed=T)
  Out <- plyr:::rename(Out, c(pRSE="$\\%$RSE"))
  Out$class <- NULL
  tex <- tabular(Out,grid=T,rowgroups=Outi$grp)
  
  tex[ grep("REPLACE IIV",tex) ] <- sprintf("\\multicolumn{%s}{l}{Interindividual variability} \\\\ \\hline", ncol(Out))
  tex[ grep("REPLACE RESERR",tex) ] <- sprintf("\\multicolumn{%s}{l}{Residual error} \\\\ \\hline", ncol(Out))
  
  return(tex)
  
}

