#' @title Loads currently available Grobs
#' @description After production of a grob list with saveGrob, loads guiGrobs into the current environment
#' @usage loadGrobs(file)
#' @param file character path to file location
#' @return loads list of grob (ggplot objects)
#' @note the file noted in this loading can not be opened directly, it must be loaded into an envirnoment.
#' @examples loadGrobs("~/vplatt/0068/0068/AMG_111_04-04-2014_Grobs.R")


loadGrobs <-
function(file){
#	source("~//AMG386//Base386Functions.R")
	load(file, envir=.GlobalEnv)
	indexGrobs()	
}
