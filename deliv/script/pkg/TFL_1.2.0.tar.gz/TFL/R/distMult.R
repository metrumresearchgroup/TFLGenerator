#' title Multipanel distribution
#' @param datFile data.frame
#' @param idVar ID variable in \code{datFile}
#' @param conList list of two element vectors giving the continuous variables in
#' \code{datFile} you wish to summarize, and the "pretty" names of those variables
#' for printing
#' @param notches Notched boxplots?
#' @param order Some permutation of "Density", "QQ", and "Boxplot"
#' @param theme* various parameters for the plot theme
#' @export

distMult <-
	function(datFile, 
	         idVar="NMID",
					 conList=list(c("WGTB","Weight (kg)"),
					              c("AGE", "Age (years)"),
					              c("CL",  "Creatinine Clearance (mL/min)")
					 ),
					 notches=T,
					 order=c("Density","QQ","Boxplot"),
					 themeUpdate=list(),
					 themeTextSize=14,
					 themePlotTitleSize=1.2,
					 themeAxisTxtSize=0.8,
					 themeAxisTxtColour='black',
					 themeAxisTitleTxtSize=0.9,
					 themeAxisTitleColour='black',
					 themePanelBackgroundFill='white',
					 themePanelGridSize=NULL,
					 themePanelGridColour='white',
					 themePanelLineType=1,
					 themePanelTitleSize=1.2,
					 themePlotTitleColour='black'
	)
					 
		{ 
	  f = function(x) {
	    r = quantile(x, probs = c(0.4, 0.4,0.5, 0.6, 0.6))
	    names(r) <- c("ymin", "lower", "middle", "upper", "ymax")
	    r
	  }
	  if(class(conList)!="list"){
	    catList <- list(catList)
	  }

		cons=sapply(conList, function(x){x[[1]][1]})
		conLabs=sapply(conList, function(x){x[[2]][1]})
		
		rel=ggplot2:::rel
		themeUpdate=theme(text=              element_text(size=themeTextSize),
		                  axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
		                  axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
		                  plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
		                  panel.background = element_rect(fill = themePanelBackgroundFill),
		                  panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
		)

		pList <- lapply(cons, function(xBy){
		  datFile0 <- datFile
		  
		  newDat=data.frame(matrix(,ncol=3))
		  names(newDat)=c(xBy, "normFit", "meanCol")
		  
		  xx=	datFile[, xBy]
		  if(length(xx)>200){
		    padx=c(
		      seq(from=min(xx, na.rm=TRUE)-abs(min(xx, na.rm=TRUE)), to=min(xx, na.rm=TRUE), length.out=10),
		      xx,
		      seq(from=max(xx,na.rm=TRUE), to=max(xx,na.rm=TRUE)+abs(max(xx,na.rm=TRUE)), length.out=10)
		    )
		  }else{
		    padx <- xx
		  }
		  normFit=dnorm(x=padx, mean=mean(xx, na.rm=TRUE), sd=sd(xx, na.rm=TRUE))
		  meanCol=rep(mean(xx, na.rm=TRUE), times=length(padx))
		  foo=data.frame(cbind(padx, normFit, meanCol))
		  names(foo)=c(xBy, "normFit", "meanCol")
		  newDat=rbind(newDat, foo)
		  newDat=newDat[!is.na(newDat$normFit),]
		  newDat=unique(newDat)
		  newDat$pads <- TRUE
		  newDat$pads[newDat[,xBy]%in%datFile[,xBy]] <- FALSE

		  datFile=merge(datFile, newDat, all=TRUE)
		  datFile[,xBy]=as.numeric(datFile[,xBy])
		  datFile$normFit=as.numeric(datFile$normFit)
		  datFile$meanCol=as.numeric(datFile$meanCol)
		  
		  if(length(conLabs)>1) xLab <- conLabs[xBy == cons]

		  dens=
		    ggplot(newDat, aes_string(x=xBy))	+
		    cleanScales+
		    geom_density(colour="dodgerblue3", adjust=3, kernel="gaussian",lwd=1.25)+
		    geom_histogram(data=filter(newDat, !pads), aes(y=..density..),colour="white", fill="deepskyblue", 
		                   #binwidth=binWidth, 
		                   alpha=.4)+
		    #scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
		    #scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
		    #geom_line(aes(y=normFit), col="red", lty="dotted",lwd=1.25)+	
		    geom_vline(aes(xintercept=meanCol), colour="red")+	
		    labs(x=xLab) + 
		    cleanTheme +themeUpdate
		  
		  box=				
		    ggplot(filter(datFile, !pads), aes_string(y=xBy, x=1))+
		    stat_boxplot(geom ='errorbar') +	
		    geom_boxplot(notch=notches, fill="dodgerblue3", alpha=0.4, outlier.shape=20)+
		    # stat_summary(fun.data = f, geom="boxplot", fill="grey", alpha=.2, lty=2)+
		    geom_hline(data=data.frame(med=median(datFile[,xBy])), aes(yintercept=med), colour="darkgrey", lty=2)+
		    labs(x="", y=xLab)+
		    scale_y_continuous(breaks=pretty_breaks())+
		    xlim(c(0,2)) + 
		    theme(panel.background = element_blank(),
		          #axis.text.y=element_text(size=8, colour="black"),
		          axis.line=element_line(),
		          axis.text.x=element_blank(),
		          #axis.title.y=element_text(size=8),
		          axis.ticks.x=element_blank(),
		          panel.border=element_blank(), 
		          #panel.grid.major = element_blank(), 
		          #panel.grid.minor = element_blank(),
		          plot.margin=unit(c(.1,0,.1,0), "cm"))+
		    cleanTheme +themeUpdate
		    
		  qq =
		    ggplot(filter(datFile, !pads), aes_string(sample=xBy))	+
		    cleanScales+
		    stat_qq(na.rm=TRUE)+
		    stat_qqline()+
		    labs(x="Quantiles of Standard Normal", y=xLab)+
		    cleanTheme +themeUpdate
		  
		  list(dens=dens, qq=qq, box=box)[match(order,c("Density","QQ","Boxplot"))]
		})

		pList2=unlist(pList,recursive = F)
		
		p1=list(pList=pList2,plotCols = 3,plotRows = length(pList))
		class(p1)<-c(class(p1),'TFL')
		return(p1)

	}
