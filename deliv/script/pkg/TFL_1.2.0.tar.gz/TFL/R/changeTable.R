#' @title Change text of tableGrob
#' @description Allows alterations to the text of a tableGrob (a table graphical object)
#' @usage changeTable(oldTable, xrow, xcol, entry)
#' @param oldTable name of tableGrob object to be altered
#' @param xrow numeric describing the row in which the cell resides (0 refers to the column names i.e. the headers)
#' @param xcol numeric describing the column in which the cell resides
#' @param entry character text to replace old value
#' @return returns a tableGrob
#' @examples
#'  foo=demogTab(exData)
#'  grid.arrange(changeTable(foo, 0,1, "Test"))
#' @export

changeTable=function(oldTable, 
										 xrow,
										 xcol,
										 entry){
	
	if(xrow!=0){
		
		newData=oldTable$d
		newData=apply(newData, c(1,2), as.character)
		newData[xrow, xcol]=entry
		
		q = c()
		for (i in c(1:ncol(newData))){
			q = c(q, as.character(newData[,i]))
		}
		
		idx=grep("core-label", oldTable$lg$lgt)
		for(i in idx){
			IDX=as.numeric(str_extract(oldTable$lg$lgt[[i]]$name,"\\d+"))
			oldTable$lg$lgt[[i]]$label=(q[[IDX]])
		}
	}
	
	if(xrow==0){
		
		newNames=names(oldTable$d)
		newNames[xcol]=entry
		idx=grep("col-label", oldTable$lg$lgt)
		for(i in idx){
			IDX=as.numeric(str_extract(oldTable$lg$lgt[[i]]$name,"\\d+"))
			oldTable$lg$lgt[[i]]$label=(newNames[[IDX]])
		}
	}
	
	return(oldTable)
}