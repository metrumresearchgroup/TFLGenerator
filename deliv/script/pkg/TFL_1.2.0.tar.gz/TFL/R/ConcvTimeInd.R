#' @title Concentration vs time profiles for groups of patients (spaghetti plot)
#' 
#' @description Longitundinal plot showing individual concentration vs time
#' profiles, including observed, conditional, and unconditional (on random effects)
#'  values of concentration
#' 
#' @param datFile A \code{data.frame} containing the necessary variables for the
#' figure
#' @param xBy Name of the variable denoting the x axis (typically time) in 
#' \code{datFile}
#' @param yBy Name of the variable containing the observed concentration values
#' @param idVar Name of the variable containing the patient number identifier
#' @param ID The ID in \code{datFile[,idVar]} you wish to plot 
#' @param predVar Population prediction column
#' @param ipredVar Individual prediction column
#' @param xLimit Two element numeric vector giving the lower and upper limits of 
#' \code{xBy}
#' @param yLimit Two element numeric vector giving the lower and upper limits of
#'  the concentration axis (y)
#' @param xForm One of "percent", "comma", "none", or "scientific" denoting the
#' labeling to be used for the x-axis
#' @param yForm One of "percent", "comma", "none", or "scientific" denoting the
#' labeling to be used for the y-axis
#' @param minorTicks Logical, include minor ticks?
#' @param minorTickNum Integer, number of minor ticks between major ticks
#' @param Title String, the title for the plot
#' @param theme* Various controls for the ggplot2 theme
#' 
#' @return  A concentration vs time ggplot2 object of class \code{TFL} which
#' can be plotted or printed with the corresponding method.  
#' @export

ConcvTimeInd <-
  function(datFile, groupBy="NMID", xBy="TAFD", yBy="DV", 
           markBy="DOSE", markByType="Discrete",preserveMarkByLevels=F,
           Color=T,
           xLimit=NULL, yLimit=NULL,
           xForm=waiver(), yForm=waiver(),
           minorTicks=FALSE,
           minorTickNum=10,
           xScale="identity", yScale="log10", 
           Title="Individuals", xLab="Time", yLab="Concentration",
           facetBy="", fF="", fnrow=NULL, fncol=NULL,fscales="fixed",
           themeUpdate=list(),
           themeTextSize=14,
           themePlotTitleSize=1.2,
           themeAxisTxtSize=0.8,
           themeAxisTxtColour='black',
           themeAxisTitleTxtSize=0.9,
           themeAxisTitleColour='black',
           themePanelBackgroundFill='white',
           themePanelGridSize=NULL,
           themePanelGridColour='white',
           themePanelLineType=1,
           themePanelTitleSize=1.2,
           themePlotTitleColour='black',
           themePlotLegendPosition='right',
           ...)
  {
    
    if(!is.null(fnrow)){
      if(fnrow==""){ fnrow <- NULL }else{  fnrow=as.numeric(fnrow) }
    }
    if(!is.null(fncol)){
      if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol) }
    }
           
    # Only update in the scope of this function
    if(preserveMarkByLevels){
      if(Color){ 
        cleanScales <- setColorScale(shapeList = shape_pal()(6),drop=F) 
      }else{ 
          cleanScales <- setGrayScale(shapeList = shape_pal()(6),drop=F)}
    }
    
    if(facetBy!="" & all(fF!="")){
      datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
    }
    
    var_lvls=length(levels(datFile[[markBy]]))
    shp_aes=if(var_lvls<=6&markByType=="Discrete"){
      aes_string(shape=markBy) 
    }else{
      aes_string()  
    }
    
    aes_base=aes_string(x=xBy, y=yBy, group=groupBy, color=markBy)

    p1=ggplot(datFile, aes_base)+
      geom_line(shp_aes)+
      geom_point(shp_aes)+
      scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
      scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
      labs(title=Title, x=xLab, y=yLab)
    
    if (minorTicks) p1=p1%>%addMinorTicks(xScale,yScale,xForm,yForm,xLimit,yLimit,minorTickNum)
    
    #Add in the faceting if it exists
    if (facetBy!=""){
      p1=p1 +facet_wrap(as.formula(paste("~", facetBy)),nrow=fnrow,ncol=fncol,scales=fscales)
    }
    
    rel=ggplot2:::rel
    themeUpdate=theme(text=              element_text(size=themeTextSize),
                      axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                      axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                      plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                      panel.background = element_rect(fill = themePanelBackgroundFill),
                      panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
                      legend.position =  themePlotLegendPosition
    )
    
    if(markByType=='Discrete') p1=p1+cleanScales
    
    p1=p1+cleanTheme +themeUpdate
    
    
    p1=list(pList=list(p1),plotCols=1,plotRows=1)
    class(p1)<-c(class(p1),'TFL')
    return(p1)
    
  }
