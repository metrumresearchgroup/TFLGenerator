#' @title Create a standard Quantile-Quantile plot
#' @description Creates a standard quantile-quantile plot using a qnorm estimation of the data. 
#' @usage QQplot(datFile, xBy = "ETA1", groupBy = NULL, markBy = NULL, xLimit = NULL, yLimit = NULL, xForm = waiver(), yForm = waiver(), xScale = "identity", yScale = "identity", Title = "", xLab = "sprintf(\'Theoretical \%s\', xBy)", yLab = "sprintf(\'Observed \%s\', xBy)", facetBy = "", ...)
#' @param datFile data.frame output of a NM run containing ER-SSAP standard column names and numeric-only columns
#' @param xBy character column name for sample column (quantiles will be created using the qnorm estimation within stat_qq)
#' @param groupBy character colum name to group data within the plot
#' @param markBy character column name for characteristic groupings within the plot (such as color and shape)
#' @param xLimit vector input for x-axis limits example: c(0,10)
#' @param yLimit vector input for y-axis limits example: c(.1,100000)
#' @param xForm function format of the x-axis (options: comma, scientific, percent or waiver() for no formatting)
#' @param yForm function format of the y-axis (options: comma, scientific, percent or waiver() for no formatting)
#' @param xScale function format for the x-axis (options, "identity", log10_trans(), log_trans())
#' @param yScale function format for the y-axis (options, "identity", log10_trans(), log_trans())
#' @param Title character figure title
#' @param xLab character x-axis title
#' @param yLab character y-axis title
#' @param facetBy character column name for optional faceting
#' @details Standard post-analysis qq plot.
#' @return returns ggplot object (grob) that must be saved or printed
#' @export

QQplot=function(
  datFile,  xBy="ETA1",
  groupBy=NULL,
  markBy=NULL,
  markByType="Discrete",
  xLimit=NULL, yLimit=NULL,
  xForm=waiver(), yForm=waiver(),
  xScale="identity", yScale="identity", 
  Title="",
  xLab='sprintf("Theoretical %s", xBy)',
  yLab='sprintf("Observed %s", xBy)',
  facetBy="", fF="",fnrow=NULL, fncol=NULL,fscales="fixed",
  minorTicks=FALSE,
  minorTickNum=10,
  themeUpdate=list(),
  themeTextSize=14,
  themePlotTitleSize=1.2,
  themeAxisTxtSize=0.8,
  themeAxisTxtColour='black',
  themeAxisTitleTxtSize=0.9,
  themeAxisTitleColour='black',
  themePanelBackgroundFill='white',
  themePanelGridSize=NULL,
  themePanelGridColour='white',
  themePanelLineType=1,
  themePanelTitleSize=1.2,
  themePlotTitleColour='black',
  ...){
  

  
  if(fnrow==""){ fnrow <- NULL }else{ fnrow=as.numeric(fnrow)}
  if(fncol==""){ fncol <- NULL }else{ fncol=as.numeric(fncol)}
  
  if(facetBy!="" & all(fF!="")){
    datFile[,facetBy] <- factor(datFile[,facetBy],fF[,1],fF[,2])
  }
  
  if(!is.null(markBy)&markByType=='Discrete'){
    if(class(datFile[,markBy])!="factor") datFile[,markBy] <- factor(datFile[,markBy], sort(unique(datFile[,markBy])))
  }

  shp_aes=aes_string()
  
  if(!is.null(markBy)&markByType=="Discrete"){
    var_lvls=length(levels(datFile[[markBy]]))
    if(var_lvls<=6) shp_aes=aes_string(shape=markBy)
  }
  
  aes_base=aes_string(sample=xBy, group=groupBy, color=markBy)
  
  p1=
    ggplot(datFile, aes_base)	+
    scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
    scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
    stat_qq(shp_aes,na.rm=TRUE)+
    stat_qqline(shp_aes)+
    labs(title=Title, x=xLab, y=yLab)
  
  if (minorTicks) p1=p1%>%addMinorTicks(xScale,yScale,xForm,yForm,xLimit,yLimit,minorTickNum)
  
  #Add in the faceting if it exists
  if (facetBy!=""){
    p1=p1 +facet_wrap(as.formula(paste("~", facetBy)), nrow=fnrow,ncol=fncol,scales=fscales)
  }
  
  rel=ggplot2:::rel
  themeUpdate=theme(text=              element_text(size=themeTextSize),
                    axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                    axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                    plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                    panel.background = element_rect(fill = themePanelBackgroundFill),
                    panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType)
  )
  
  if(markByType=='Discrete') p1=p1+cleanScales
  p1=p1+cleanTheme +themeUpdate
  
  p1=list(pList=list(p1),plotCols=1,plotRows=1)
  class(p1)<-c(class(p1),'TFL')
  return(p1)
  
}