#' @title Multipanel concentration vs time profiles for individual patients
#' 
#' @description Longitundinal plot showing individual concentration vs time
#' profile, including observed, conditional, and unconditional (on random effects)
#'  values of concentration
#' 
#' @param datFile A \code{data.frame} containing the necessary variables for the
#' figure
#' @param groupBy Column name that identifies the subset of \code{datFile} to be
#' used in each of the panels; typically, this is "NMID" or "ID.
#' @param ID Numeric vector, the ID's in \code{datFile[,idVar]} you wish to plot
#' @param xBy Name of the variable denoting the x axis (typically time) in 
#' \code{datFile}
#' @param yBy Name of the variable containing the observed concentration values
#' @param ipredVar Individual prediction column
#' @param predVar Population prediction column
#' @param doseVar Column name of \code{datFile} in which dosing labels are held.  
#' If specified, these doses will appear as titles per patient
#' @param doseLab A label to be appended to the value in doseVar
#' @param markBy ignored
#' @param xLimit Two element numeric vector giving the lower and upper limits of 
#' \code{xBy}
#' @param yLimit Two element numeric vector giving the lower and upper limits of
#'  the concentration axis (y)
#' @param minorTicks Logical, include minor ticks?
#' @param minorTickNum Integer, number of minor ticks between major ticks
#' @param Title String, the title for the plot
#' @param theme* Various controls for the ggplot2 theme
#' 
#' @return  A concentration vs time ggplot2 object of class \code{TFL} which
#' can be plotted or printed with the corresponding method.  
#' @export

ConcvTimeMult <-
  function(datFile,
           groupBy="NMID", xBy="TAFD", yBy="DV", ipredVar="IPRE", predVar="PRED", doseVar="DOSE", doseLab="mg/kg",
           markBy="DOSE", preserveMarkByLevels=F, Color=T,
           xLimit=NULL, yLimit=NULL,
           xForm=waiver(), yForm=waiver(),
           xScale="identity", yScale="log10", 
           Title="Individuals", xLab="Time", yLab="Concentration",
           ncol=3, nrow=3, ID=NULL,
           minorTicks=FALSE,
           minorTickNum=10,
           genAll=T, page=1,
           themeUpdate=list(),
           themeTextSize=14,
           themePlotTitleSize=1.2,
           themeAxisTxtSize=0.8,
           themeAxisTxtColour='black',
           themeAxisTitleTxtSize=0.9,
           themeAxisTitleColour='black',
           themePanelBackgroundFill='white',
           themePanelGridSize=NULL,
           themePanelGridColour='white',
           themePanelLineType=1,
           themePanelTitleSize=1.2,
           themePlotTitleColour='black',
           ...)
  {
    
    # if(is.null(tmpDir)){
    #   tmpDir <- tempdir()
    #   dir.create(tmpDir,recursive = T,showWarnings=F)
    #   if(genAll){
    #     preexisting <- grep(paste0(item,n),list.files(tmpDir),value=T)
    #     unlink(file.path(tmpDir,preexisting))
    #   }
    # }else{
    #   if(!dir.exists(tmpDir)){ 
    #     return() 
    #     }
    # }
    if(class(yForm)=="character") yForm <- as.name(yForm)
    if(class(xForm)=="character") xForm <- as.name(xForm)
    if(doseVar=="" | (doseVar%nin%names(datFile))) doseVar <- NULL
    if(doseLab=="" | is.null(doseVar)) doseLab <- NULL
    # filename <- file.path(tmpDir,paste0(item,n,"_%1d.png"))
    
    #if(regenPlots){
      
      # Delete old files first
      # sapply(grep(paste0(item,n,"*.png"),list.files(tmpDir),value=T),unlink)
      
      # Only update in the scope of this function
      if(preserveMarkByLevels){
        if(Color){ cleanScales <- setColorScale(drop=F,shapeList = shape_pal()(6)) }else{ cleanScales <- setGrayScale(drop=F,shapeList = shape_pal()(6))}
      }
      
      if(!is.null(ID)) datFile <- datFile[datFile[,groupBy]%in%ID,]
      
      datFile$groupBy <- datFile[,groupBy]
      
     n.tot=as.numeric(nrow)*as.numeric(ncol)
     d=sort(unique(datFile[,groupBy]))
     plotIdx=split(d, ceiling(seq_along(d)/n.tot))

     if((!genAll) & (page!=0)) plotIdx=plotIdx[page]
     
      pList=llply(plotIdx,function(idx){
        df=datFile[datFile[,groupBy]%in%idx,]
        df=melt(df, id.vars=c(groupBy, xBy, doseVar), measure.vars=c(yBy, predVar, ipredVar))
        df$variable=factor(df$variable, levels=c(yBy, predVar, ipredVar), labels=c("Observed", "Population Predicted", "Individual"))
        
        df$facet_id=paste0("ID=",df[,groupBy],", ",df[,doseVar]," ",doseLab)
        facetLvl=unique(df$facet_id)
        if(length(facetLvl)<n.tot) {
          facetLvlTemp=sapply(1:n.tot,function(x) paste0(rep(' ',x),collapse=''))
          facetLvlTemp[1:length(facetLvl)]=facetLvl
          facetLvl=facetLvlTemp
        }
        
        df$facet_id=factor(df$facet_id,levels=facetLvl)
        var_lvls=length(levels(df[['variable']]))
        pt_aes=if(var_lvls<=6){
          aes_string(shape="variable") 
        }else{
          aes_string()  
        }
        
        
        p1=ggplot(data=df, aes_string(x=xBy, y="value", color="variable"))+
          geom_line(aes_string(lty="variable"),show.legend = F)+
          geom_point(pt_aes,show.legend = F)+
          scale_y_continuous(limits=yLimit, labels=eval(yForm), trans=yScale)+
          scale_x_continuous(labels=eval(xForm), breaks=pretty_breaks(), limits=xLimit, trans=xScale)+
          labs(x=xLab, y=yLab, shape=NULL, lty=NULL, color=NULL) +
          scale_shape_manual( values = c("O", ".", "."))+
          scale_colour_manual(values = c('black', 'black','blue'))+
          scale_linetype_manual( values=c(0,1,3))+
          facet_wrap(~facet_id,scales='free',dir='v',nrow=as.numeric(nrow),ncol=as.numeric(ncol),drop=F)
        
        if (minorTicks) p1=p1%>%addMinorTicks(xScale,yScale,xForm,yForm,xLimit,yLimit,minorTickNum)
        
        rel=ggplot2:::rel
        themeUpdate=theme(text=              element_text(size=themeTextSize),
                          axis.text =        element_text(size=rel(themeAxisTxtSize),colour = themeAxisTxtColour),
                          axis.title =       element_text(size=rel(themeAxisTitleTxtSize),colour = themeAxisTitleColour),
                          plot.title =       element_text(size=rel(themePlotTitleSize),colour=themePlotTitleColour),
                          panel.background = element_rect(fill = themePanelBackgroundFill),
                          panel.grid.major=  element_line(size=themePanelGridSize,colour=themePanelGridColour,linetype=themePanelLineType),
                          strip.background = element_rect(colour='white')
        )
        
        p1=p1+cleanTheme +themeUpdate + theme(plot.margin=unit(c(0,0.5,0.25,0.25),"cm"))
        
        p1
        
        
      })
      
     
      
      p1=lapply(1:length(pList),function(i) list(pList=pList[i],plotCols=1,plotRows=1))
      class(p1)<-c(class(p1),'TFL')
      
      return(p1)
      
  
  }
