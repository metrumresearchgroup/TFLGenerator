inputFile <- function(filelocation=""){
  if(is.null(filelocation) | (filelocation=="") ) break
  
  if(grepl("png|jpg",filelocation,ignore.case=T)){
    # This is an image
    l <- list(
      preview = quote(system(sprintf("ls -al %s",filelocation))),
      src = filelocation
    )
  }else if(grepl(".doc",filelocation,fixed=T)){
    # Doc
    l <- list(
      preview = "At this time, merging .doc documents is not supported"
    )
  }else if(grepl("pdf",filelocation)){
    l <- list(
      preview <- quote({"PDF integration not currently possible, convert your pdf images to png first."})
    )
  }else{
    # This is text
    if(file.exists(filelocation)){
      l <- list(
        preview = readLines(filelocation)
      )
    }else{
      preview <- quote({"Text file doesn't exist"})
    }
  }
  p1 <- l
  return(l)
}
  
